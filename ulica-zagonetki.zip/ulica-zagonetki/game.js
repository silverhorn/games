(function () {
  'use strict';
  var KEY = 'ulicaZagonetki.v1';
  var $ = function (id) { return document.getElementById(id); };

  // ---------- stanje i čuvanje ----------
  var S = load();
  function load() {
    try {
      var s = JSON.parse(localStorage.getItem(KEY));
      if (s && typeof s === 'object') { s.houses = s.houses || {}; s.pts = s.pts || 0; return s; }
    } catch (e) {}
    return { name: '', pts: 0, houses: {}, mute: false };
  }
  function save() { try { localStorage.setItem(KEY, JSON.stringify(S)); } catch (e) {} }

  // ---------- zvuk ----------
  var ac = null;
  function tone(freq, start, dur, type) {
    if (S.mute) return;
    try {
      ac = ac || new (window.AudioContext || window.webkitAudioContext)();
      var o = ac.createOscillator(), g = ac.createGain();
      o.type = type || 'sine'; o.frequency.value = freq;
      var t = ac.currentTime + start;
      g.gain.setValueAtTime(0.0001, t);
      g.gain.exponentialRampToValueAtTime(0.18, t + 0.02);
      g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
      o.connect(g); g.connect(ac.destination); o.start(t); o.stop(t + dur + 0.05);
    } catch (e) {}
  }
  var sfx = {
    ok: function () { tone(523, 0, .12); tone(659, .1, .12); tone(784, .2, .2); },
    bad: function () { tone(200, 0, .18, 'square'); tone(150, .15, .25, 'square'); },
    click: function () { tone(660, 0, .05, 'triangle'); },
    win: function () { [523, 659, 784, 1047].forEach(function (f, i) { tone(f, i * .12, .22); }); }
  };

  // ---------- pomoćne ----------
  // Pretvaranje latinice u ćirilicu (za ime i za latiničnu tastaturu)
  var LATKEY = {A:'А',B:'Б',V:'В',G:'Г',D:'Д','Đ':'Ђ',E:'Е','Ž':'Ж',Z:'З',I:'И',J:'Ј',K:'К',L:'Л',M:'М',N:'Н',O:'О',P:'П',R:'Р',S:'С',T:'Т','Ć':'Ћ',U:'У',F:'Ф',H:'Х',C:'Ц','Č':'Ч','Š':'Ш'};
  function toCyr(s) {
    var out = '', i = 0, two, up, c;
    while (i < s.length) {
      c = s.charAt(i); up = c !== c.toLowerCase(); two = s.substr(i, 2).toLowerCase();
      if (two === 'lj' || two === 'nj' || two === 'dž') {
        var b = two === 'lj' ? 'љ' : (two === 'nj' ? 'њ' : 'џ'); out += up ? b.toUpperCase() : b; i += 2; continue;
      }
      var m = LATKEY[c.toUpperCase()];
      out += m ? (up ? m : m.toLowerCase()) : c; i++;
    }
    return out;
  }

  function shuffle(arr) {
    var a = arr.slice();
    for (var i = a.length - 1; i > 0; i--) {
      var j = Math.floor(Math.random() * (i + 1)); var t = a[i]; a[i] = a[j]; a[j] = t;
    }
    return a;
  }
  function lettersOnly(s) { return s.replace(/ /g, ''); }
  function show(id) {
    ['s-welcome', 's-map', 's-play', 's-result'].forEach(function (x) { $(x).classList.toggle('hidden', x !== id); });
    window.scrollTo(0, 0);
  }
  function updatePts() { $('pts').textContent = '⭐ ' + S.pts; }
  function houseDone(i) { return !!S.houses[HOUSES[i].id]; }
  function houseUnlocked(i) { return i === 0 || houseDone(i - 1); }

  // ---------- mapa ulice ----------
  function renderMap() {
    $('hello').textContent = 'Агент ' + (S.name || 'Непознати') + ', улица те чека! 🌆';
    var st = $('street'); st.innerHTML = '';
    HOUSES.forEach(function (h, i) {
      var b = document.createElement('button');
      var locked = !houseUnlocked(i), done = houseDone(i);
      b.className = 'house' + (locked ? ' locked' : '') + (done ? ' done' : '');
      var stars = done ? '★'.repeat(S.houses[h.id].stars) + '☆'.repeat(3 - S.houses[h.id].stars) : (locked ? '🔒' : '');
      b.innerHTML = '<span class="em">' + h.em + '</span><div class="nm">' + h.name + '</div><div class="st">' + stars + '</div>';
      b.onclick = function () { if (!locked) { sfx.click(); startHouse(i); } };
      st.appendChild(b);
    });
    updatePts(); show('s-map');
  }

  // ---------- igra ----------
  var cur = null;

  function startHouse(i) {
    cur = { h: i, idx: 0, mistakes: 0 };
    loadTask();
    show('s-play');
  }

  function loadTask() {
    var h = HOUSES[cur.h], t = h.tasks[cur.idx];
    cur.t = t; cur.done = false; cur.hints = 0; cur.wrongs = 0; cur.typed = []; cur.locked = 0;
    $('house-title').textContent = h.em + ' ' + h.name;
    $('progress').innerHTML = h.tasks.map(function (_, k) {
      return '<span class="dot' + (k < cur.idx ? ' on' : (k === cur.idx ? ' cur' : '')) + '"></span>';
    }).join('');
    $('story').textContent = cur.idx === 0 ? h.story : '';
    $('task').textContent = t.text && t.type !== 'boss' ? t.text : (t.note || '');
    $('clue').textContent = t.clue || '';
    $('msg').textContent = ''; $('msg').className = 'msg';
    $('next').classList.add('hidden'); $('hint').classList.remove('hidden'); $('clear').classList.remove('hidden');
    $('hint').textContent = '💡 Наговештај (-5)';
    document.querySelector('.card .answer').parentNode.classList.remove('win');

    var isTiles = (t.type === 'letters' || t.type === 'riddle' || t.type === 'sentence');
    $('pool').classList.toggle('hidden', !isTiles);
    $('keyboard').classList.toggle('hidden', isTiles);
    $('cipher-box').classList.toggle('hidden', isTiles);

    if (isTiles) {
      var items, target;
      if (t.type === 'sentence') { target = t.answers[0].split(' '); }
      else { target = t.word.split(''); }
      cur.target = target;
      var accepted = t.type === 'sentence' ? t.answers : [t.word];
      cur.accepted = accepted;
      var tiles = target.map(function (x, k) { return { id: k, text: x }; });
      var order, tries = 0;
      do {
        order = shuffle(tiles); tries++;
      } while (tries < 20 && accepted.indexOf(order.map(function (x) { return x.text; }).join(t.type === 'sentence' ? ' ' : '')) >= 0);
      cur.pool = order; cur.answer = [];
      renderTiles();
    } else {
      var plain = t.type === 'boss' ? t.text : t.word;
      cur.plain = plain;
      var cipherText = enc(plain, t.shift);
      cur.targetLetters = lettersOnly(plain);
      $('task').textContent = t.type === 'boss' ? (t.note || 'Дешифруј поруку!') : t.text;
      renderCipher(cipherText, t.shift, t.type === 'boss');
      buildKeyboard(t.type === 'boss');
      renderTyped();
    }
  }

  // ----- tile zadaci -----
  function renderTiles() {
    var isSent = cur.t.type === 'sentence';
    var ans = $('answer'), pool = $('pool');
    ans.innerHTML = ''; pool.innerHTML = '';
    cur.answer.forEach(function (tile, k) {
      var b = document.createElement('button');
      b.className = 'tile' + (isSent ? ' word' : '') + (k < cur.locked ? ' hinted' : '');
      b.textContent = tile.text;
      b.onclick = function () { if (cur.done || k < cur.locked) return; sfx.click(); cur.pool.push(cur.answer.splice(k, 1)[0]); renderTiles(); };
      ans.appendChild(b);
    });
    cur.pool.forEach(function (tile, k) {
      var b = document.createElement('button');
      b.className = 'tile' + (isSent ? ' word' : '');
      b.textContent = tile.text;
      b.onclick = function () { pickTile(k); };
      pool.appendChild(b);
    });
  }
  function pickTile(k) {
    if (cur.done) return;
    sfx.click();
    cur.answer.push(cur.pool.splice(k, 1)[0]);
    renderTiles();
    if (cur.pool.length === 0) checkTiles();
  }
  function checkTiles() {
    var sep = cur.t.type === 'sentence' ? ' ' : '';
    var got = cur.answer.map(function (x) { return x.text; }).join(sep);
    if (cur.accepted.indexOf(got) >= 0) return win();
    wrong('Скоро! Додирни слова да их вратиш, или притисни ↺.');
  }

  // ----- šifre -----
  function renderCipher(cipherText, shift, isBoss) {
    var box = $('cipher-box');
    var top = '', bot = '';
    CIPH.forEach(function (p) {
      top += '<span>' + enc(p, shift) + '</span>';
      bot += '<span>' + p + '</span>';
    });
    box.innerHTML =
      '<div class="cipher-text">' + cipherText + '</div>' +
      '<div class="decoder">' +
      '<div class="r1"><span class="lab">шифра</span>' + top + '</div>' +
      '<div class="r2"><span class="lab">слово</span>' + bot + '</div></div>';
  }
  function buildKeyboard(withSpace) {
    var kb = $('keyboard'); kb.innerHTML = '';
    CIPH.forEach(function (c) {
      var b = document.createElement('button'); b.className = 'key'; b.textContent = c;
      b.onclick = function () { typeChar(c); }; kb.appendChild(b);
    });
    if (withSpace) {
      var sp = document.createElement('button'); sp.className = 'key wide'; sp.style.background = 'var(--yellow)'; sp.style.color = '#3b2a00';
      sp.textContent = 'размак'; sp.onclick = function () { typeChar(' '); }; kb.appendChild(sp);
    }
    var bk = document.createElement('button'); bk.className = 'key wide'; bk.textContent = '⌫';
    bk.onclick = backspace; kb.appendChild(bk);
  }
  function renderTyped() {
    var ans = $('answer'); ans.innerHTML = '';
    cur.typed.forEach(function (ch, k) {
      if (ch === ' ') { var sp = document.createElement('span'); sp.style.width = '18px'; ans.appendChild(sp); return; }
      var b = document.createElement('span'); b.className = 'tile' + (k < cur.locked ? ' hinted' : ''); b.textContent = ch; ans.appendChild(b);
    });
  }
  function typeChar(c) {
    if (cur.done || cur.t.type === 'letters' || cur.t.type === 'riddle' || cur.t.type === 'sentence') return;
    var typedLetters = lettersOnly(cur.typed.join('')).length;
    if (c === ' ') {
      if (cur.t.type !== 'boss' || !cur.typed.length || cur.typed[cur.typed.length - 1] === ' ') return;
      sfx.click(); cur.typed.push(' '); renderTyped(); return;
    }
    if (typedLetters >= cur.targetLetters.length) return;
    sfx.click(); cur.typed.push(c); renderTyped();
    if (typedLetters + 1 === cur.targetLetters.length) {
      if (lettersOnly(cur.typed.join('')) === cur.targetLetters) win();
      else {
        wrong('Упс, провери таблицу па пробај поново!');
        setTimeout(function () { if (!cur.done) { cur.typed = cur.typed.slice(0, cur.locked); renderTyped(); } }, 650);
      }
    }
  }
  function backspace() {
    if (cur.done || cur.typed.length <= cur.locked) return;
    sfx.click(); cur.typed.pop(); renderTyped();
  }

  // ----- zajedničko -----
  function wrong(text) {
    cur.wrongs++; sfx.bad();
    var a = $('answer'); a.classList.remove('shake'); void a.offsetWidth; a.classList.add('shake');
    $('msg').textContent = text; $('msg').className = 'msg bad';
  }
  function win() {
    cur.done = true;
    var earned = Math.max(0, 10 - 5 * cur.hints - 2 * cur.wrongs);
    S.pts += earned; cur.mistakes += cur.hints + cur.wrongs; save(); updatePts();
    sfx.ok();
    $('msg').textContent = '✔ Тачно! +' + earned + ' ⭐'; $('msg').className = 'msg ok';
    $('answer').parentNode.classList.add('win');
    $('hint').classList.add('hidden'); $('clear').classList.add('hidden');
    var last = cur.idx === HOUSES[cur.h].tasks.length - 1;
    $('next').textContent = last ? 'ОТКЉУЧАЈ КУЋУ 🔓' : 'ДАЉЕ ▶';
    $('next').classList.remove('hidden');
  }

  function hint() {
    if (cur.done) return;
    var t = cur.t, isTiles = (t.type === 'letters' || t.type === 'riddle' || t.type === 'sentence');
    var total = isTiles ? cur.target.length : cur.targetLetters.length;
    if (cur.hints >= total - 1) { $('msg').textContent = 'Већ имаш скоро све слово по слово! 😉'; $('msg').className = 'msg'; return; }
    cur.hints++; cur.locked = cur.hints; sfx.click();
    if (isTiles) {
      var all = cur.answer.concat(cur.pool), used = [], ans = [];
      for (var i = 0; i < cur.hints; i++) {
        for (var k = 0; k < all.length; k++) {
          if (used.indexOf(k) < 0 && all[k].text === cur.target[i]) { used.push(k); ans.push(all[k]); break; }
        }
      }
      cur.answer = ans;
      cur.pool = all.filter(function (_, k) { return used.indexOf(k) < 0; });
      renderTiles();
    } else {
      var out = [], n = 0, plain = cur.plain;
      for (var j = 0; j < plain.length && n < cur.hints; j++) { out.push(plain[j]); if (plain[j] !== ' ') n++; }
      cur.typed = out; cur.locked = out.length; renderTyped();
    }
    $('msg').textContent = 'Откривено ' + cur.hints + '. место! (-5)'; $('msg').className = 'msg';
  }

  function clearAll() {
    if (cur.done) return;
    sfx.click();
    var isTiles = (cur.t.type === 'letters' || cur.t.type === 'riddle' || cur.t.type === 'sentence');
    if (isTiles) {
      var keep = cur.answer.slice(0, cur.locked), rest = cur.answer.slice(cur.locked);
      cur.answer = keep; cur.pool = shuffle(cur.pool.concat(rest)); renderTiles();
    } else { cur.typed = cur.typed.slice(0, cur.locked); renderTyped(); }
    $('msg').textContent = ''; $('msg').className = 'msg';
  }

  function nextTask() {
    var h = HOUSES[cur.h];
    if (cur.idx < h.tasks.length - 1) { cur.idx++; loadTask(); return; }
    var m = cur.mistakes, stars = m <= 2 ? 3 : (m <= 6 ? 2 : 1);
    var prev = S.houses[h.id] ? S.houses[h.id].stars : 0;
    S.houses[h.id] = { stars: Math.max(prev, stars) }; save();
    sfx.win();
    var finalHouse = cur.h === HOUSES.length - 1;
    $('r-emoji').textContent = finalHouse ? '🏆' : '🔓';
    $('r-title').textContent = finalHouse ? 'МРАК ЈЕ ПОРАЖЕН!' : h.name + ' је откључана!';
    $('r-stars').textContent = '★'.repeat(stars) + '☆'.repeat(3 - stars);
    $('r-text').textContent = finalHouse
      ? 'Браво, агенте ' + S.name + '! Спасио си улицу загонетки. Имаш ' + S.pts + ' бодова. Ти си прави шеф агенције! 🕵️'
      : 'Супер, агенте ' + S.name + '! Следећа кућа је отворена. Још једна мисија те чека!';
    show('s-result');
  }

  // ---------- događaji ----------
  $('start').onclick = function () {
    var n = $('name').value.trim();
    if (!n) { $('name').focus(); return; }
    S.name = toCyr(n).toUpperCase(); save(); sfx.click(); renderMap();
  };
  $('name').addEventListener('keydown', function (e) { if (e.key === 'Enter') $('start').click(); });
  $('back').onclick = function () { renderMap(); };
  $('hint').onclick = hint;
  $('clear').onclick = clearAll;
  $('next').onclick = nextTask;
  $('r-btn').onclick = renderMap;
  $('reset').onclick = function () {
    if (confirm('Да ли сигурно желиш да почнеш све испочетка? Сви бодови нестају.')) {
      S = { name: S.name, pts: 0, houses: {}, mute: S.mute }; save(); renderMap();
    }
  };
  $('mute').onclick = function () { S.mute = !S.mute; $('mute').textContent = S.mute ? '🔇' : '🔊'; save(); };
  $('mute').textContent = S.mute ? '🔇' : '🔊';

  // fizička tastatura
  document.addEventListener('keydown', function (e) {
    if ($('s-play').classList.contains('hidden') || !cur || cur.done) return;
    if (e.ctrlKey || e.metaKey || e.altKey) return;
    var t = cur.t, isTiles = (t.type === 'letters' || t.type === 'riddle' || t.type === 'sentence');
    if (e.key === 'Backspace') {
      e.preventDefault();
      if (isTiles) { if (cur.answer.length > cur.locked) { cur.pool.push(cur.answer.pop()); renderTiles(); } }
      else backspace();
      return;
    }
    if (e.key.length !== 1) return;
    var ch = e.key.toUpperCase(); ch = LATKEY[ch] || ch;
    if (isTiles) {
      if (t.type === 'sentence') return;
      for (var k = 0; k < cur.pool.length; k++) if (cur.pool[k].text === ch) { pickTile(k); return; }
    } else if (ch === ' ') { e.preventDefault(); typeChar(' '); }
    else if (CIPH.indexOf(ch) >= 0) typeChar(ch);
  });

  // početak
  if (S.name) { $('name').value = S.name; renderMap(); } else { show('s-welcome'); }
})();
