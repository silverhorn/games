(function () {
  'use strict';
  var app = document.getElementById('app');
  var BOARD = window.BOARD, RULES = window.RULES, HEROES = window.HEROES;
  var CELL = 40, PAD = 16;
  var W = BOARD.SIZE * CELL + PAD * 2;

  function esc(s) { return String(s).replace(/[&<>"]/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]; }); }
  function px(r, c) { return [PAD + c * CELL + CELL / 2, PAD + r * CELL + CELL / 2]; }
  function rectAt(r, c, w, h, cls, fill, opacity) {
    var x = PAD + c * CELL, y = PAD + r * CELL;
    return '<rect x="' + x + '" y="' + y + '" width="' + (w * CELL) + '" height="' + (h * CELL) + '" class="' + (cls || '') + '"' +
      (fill ? ' fill="' + fill + '"' : '') + (opacity !== undefined ? ' opacity="' + opacity + '"' : '') + '/>';
  }

  var g = null;          // stanje partije (iz RULES)
  var names = {};        // id -> ime koje je igrač uneo
  var pending = null;    // { die, bonus, opts } kad igrač bira koju figuru pomera
  var busy = false;       // sprečava duple klikove tokom animacije kocke
  var lastRoll = 1;

  // ---------------- podešavanje igrača ----------------
  function setup() {
    g = null; pending = null;
    var h = '<h1>🦸 Ne ljuti se, Super-porodico!</h1>';
    h += '<p class="sub">4 igrača, klasična pravila: kocka se baca do 3 puta dok ne izbaci šesticu za prvi izlazak, posle toga — klasika!</p>';
    h += '<section class="card"><h2 style="margin-top:0">Ko igra?</h2><div class="plist">';
    BOARD.PLAYERS.forEach(function (p) {
      var hero = HEROES[p.id];
      names[p.id] = names[p.id] || hero.name;
      h += '<div class="prow" style="background:' + p.color + '22">' +
        '<span class="sw" style="background:' + p.color + '"><svg width="22" height="22" viewBox="-9 -9 18 18">' + hero.icon + '</svg></span>' +
        '<input data-id="' + p.id + '" maxlength="16" value="' + esc(names[p.id]) + '">' +
        '<span class="hero">' + hero.name + '<br>' + hero.sub + '</span></div>';
    });
    h += '</div><div class="row"><button class="btn primary" id="go">Počni igru ▶</button></div></section>';
    app.innerHTML = h;
    Array.prototype.forEach.call(app.querySelectorAll('.prow input'), function (inp) {
      inp.addEventListener('input', function () { names[inp.getAttribute('data-id')] = inp.value; });
    });
    document.getElementById('go').addEventListener('click', startGame);
  }

  function startGame() {
    var ids = BOARD.PLAYERS.map(function (p) { return p.id; });
    g = RULES.newGame(ids);
    RULES.updatePhase(g);
    pending = null;
    renderGame('Igra počinje! Na potezu je ' + nameOf(RULES.currentPlayerId(g)) + '.');
  }

  function nameOf(id) { return names[id] || HEROES[id].name; }

  // ---------------- tabla (SVG) ----------------
  function boardSvg() {
    var s = '<svg viewBox="0 0 ' + W + ' ' + W + '" role="img" aria-label="tabla">';
    s += '<rect width="' + W + '" height="' + W + '" fill="#ffffff"/>';
    // baze
    BOARD.PLAYERS.forEach(function (p) {
      s += rectAt(p.baseR, p.baseC, BOARD.C1, BOARD.C1, '', p.color, 0.16);
      var slots = p.baseSlots;
      for (var i = 0; i < 4; i++) {
        if (g.pieces[p.id][i] !== 0) continue; // ako je figura tu, iscrtaće se kao pion
        var c0 = px(slots[i][0], slots[i][1]);
        s += '<circle cx="' + c0[0] + '" cy="' + c0[1] + '" r="12" class="slot" stroke="' + p.color + '"/>';
      }
    });
    // prsten
    BOARD.RING.forEach(function (cell) { s += rectAt(cell[0], cell[1], 1, 1, 'cell-ring'); });
    // kućne staze (obojene)
    BOARD.PLAYERS.forEach(function (p) {
      p.home.forEach(function (cell) { s += rectAt(cell[0], cell[1], 1, 1, '', p.color, 0.3); });
    });
    // centar
    s += rectAt(BOARD.HOLE, BOARD.HOLE, 1, 1, 'cell-hole');
    // pioni
    var curId = RULES.currentPlayerId(g);
    BOARD.PLAYERS.forEach(function (p) {
      var hero = HEROES[p.id];
      g.pieces[p.id].forEach(function (step, idx) {
        var cell = BOARD.cellFor(p, step, idx, idx);
        var c0 = px(cell[0], cell[1]);
        var clickable = pending && p.id === curId && pending.opts.indexOf(idx) !== -1;
        var cls = 'pawn' + (clickable ? ' clickable' : '') + (p.id === curId ? ' current' : '');
        s += '<g class="' + cls + '" data-id="' + p.id + '" data-idx="' + idx + '" transform="translate(' + c0[0] + ' ' + c0[1] + ')">' +
          '<circle class="body" r="11" fill="' + p.color + '"/>' +
          '<g transform="scale(0.78)">' + hero.icon + '</g></g>';
      });
    });
    s += '</svg>';
    return s;
  }

  function dieFace(n) {
    var map = { 1: [4], 2: [0, 8], 3: [0, 4, 8], 4: [0, 2, 6, 8], 5: [0, 2, 4, 6, 8], 6: [0, 2, 3, 5, 6, 8] };
    var on = map[n] || [4];
    var h = '';
    for (var i = 0; i < 9; i++) h += '<span class="pip' + (on.indexOf(i) !== -1 ? ' on' : '') + '"></span>';
    return h;
  }

  // ---------------- glavni ekran igre ----------------
  function renderGame(msg) {
    var curId = RULES.currentPlayerId(g);
    var p = BOARD.byId(curId), hero = HEROES[curId];
    var h = '<div class="row" style="justify-content:space-between;max-width:480px;margin:0 auto 6px">' +
      '<button class="btn" id="quit">⬅ Nova igra</button></div>';
    h += '<div class="panel"><span class="turn-banner" style="background:' + p.color + '">' +
      '<span class="sw2"><svg width="18" height="18" viewBox="-9 -9 18 18">' + hero.icon + '</svg></span>' +
      'Na potezu: ' + esc(nameOf(curId)) + '</span></div>';
    h += '<div class="boardwrap">' + boardSvg() + '</div>';
    h += '<div class="legend">' + BOARD.PLAYERS.map(function (pl) {
      return '<span><span class="dot" style="background:' + pl.color + '"></span>' + esc(nameOf(pl.id)) + '</span>';
    }).join('') + '</div>';
    h += '<div class="panel"><div class="msg" id="msg">' + esc(msg || '') + '</div>';
    h += '<div class="die-wrap"><button class="die" id="die" aria-label="baci kocku">' + dieFace(lastRoll) + '</button></div>';
    h += '<div class="row" id="nextrow" style="display:none"><button class="btn primary" id="nextBtn">Dalje ➜</button></div></div>';
    app.innerHTML = h;
    document.getElementById('quit').addEventListener('click', function () {
      if (window.confirm('Prekinuti partiju i vratiti se na podešavanje?')) setup();
    });
    var dieBtn = document.getElementById('die');
    dieBtn.addEventListener('click', onRollClick);
    if (pending) dieBtn.disabled = true;
    Array.prototype.forEach.call(app.querySelectorAll('.pawn.clickable'), function (elp) {
      elp.addEventListener('click', function () {
        onPawnClick(elp.getAttribute('data-id'), parseInt(elp.getAttribute('data-idx'), 10));
      });
    });
  }

  function showNext(msg, label) {
    renderGame(msg);
    var dieEl = document.getElementById('die');
    dieEl.style.display = 'none';
    dieEl.disabled = true;
    var row = document.getElementById('nextrow');
    row.style.display = 'flex';
    document.getElementById('nextBtn').textContent = label || 'Dalje ➜';
    document.getElementById('nextBtn').addEventListener('click', function () {
      RULES.nextTurn(g);
      renderGame('Na potezu je ' + nameOf(RULES.currentPlayerId(g)) + '.');
    });
  }

  function onRollClick() {
    if (busy || pending) return;
    busy = true;
    var dieBtn = document.getElementById('die');
    dieBtn.classList.add('rolling');
    dieBtn.disabled = true;
    var n = 0, ticks = 8;
    var iv = setInterval(function () {
      dieBtn.innerHTML = dieFace(1 + Math.floor(Math.random() * 6));
      n++;
      if (n >= ticks) {
        clearInterval(iv);
        var d = 1 + Math.floor(Math.random() * 6);
        lastRoll = d;
        busy = false;
        resolveRoll(d);
      }
    }, 70);
  }

  function resolveRoll(d) {
    var id = RULES.currentPlayerId(g);
    if (g.phase === 'need-six') {
      var r = RULES.rollForExit(g, d);
      if (r.exited) {
        var m = nameOf(id) + ' je bacio/la ' + d + ' — figura izlazi! 🎉' + captureMsg(r.captured) + ' Baci ponovo (bonus za šesticu)!';
        renderGame(m);
      } else if (r.endTurn) {
        showNext(nameOf(id) + ' je bacio/la ' + d + ' (3/3 bez šestice). Red prelazi na sledećeg igrača.', 'Sledeći igrač ➜');
      } else {
        renderGame(nameOf(id) + ' je bacio/la ' + d + ' (' + g.exitTries + '/3) — nema šestice još. Baci ponovo!');
      }
      return;
    }
    var note = RULES.noteSix(g, d);
    if (note.forfeited) {
      showNext('Treća šestica zaredom! Po pravilima, ovaj bacaj propada. Red prelazi dalje.', 'Sledeći igrač ➜');
      return;
    }
    var opts = RULES.movable(g, id, d);
    if (opts.length === 0) {
      if (note.bonus) {
        renderGame('Bacio/la si ' + d + ', ali nijedna figura ne može da se pomeri. Šestica ipak donosi novi bacaj!');
      } else {
        showNext('Bacio/la si ' + d + ' — nijedna figura ne može da se pomeri. Red prelazi dalje.', 'Sledeći igrač ➜');
      }
      return;
    }
    if (opts.length === 1) {
      finishMove(id, opts[0], d, note.bonus);
      return;
    }
    pending = { die: d, bonus: note.bonus, opts: opts };
    renderGame(nameOf(id) + ' je bacio/la ' + d + ' — izaberi koju figuru pomeraš (ona treperi) ✨');
  }

  function onPawnClick(id, idx) {
    if (!pending) return;
    var cur = RULES.currentPlayerId(g);
    if (id !== cur) return;
    var die = pending.die, bonus = pending.bonus;
    pending = null;
    finishMove(id, idx, die, bonus);
  }

  function captureMsg(list) {
    if (!list || !list.length) return '';
    var names2 = list.map(function (c) { return nameOf(c.id); });
    return ' 💥 Pojeo/la je: ' + names2.join(', ') + ' (vraćaju se u bazu)!';
  }

  function finishMove(id, idx, die, bonus) {
    var r = RULES.applyMove(g, id, idx, die);
    var msg = nameOf(id) + ' pomera figuru za ' + die + '.' + captureMsg(r.captured);
    if (r.finished) msg += ' 🏁 Jedna figura je stigla kući!';
    if (g.winner) { showWin(g.winner); return; }
    if (bonus) {
      renderGame(msg + ' Šestica! Baci ponovo.');
    } else {
      showNext(msg, 'Sledeći igrač ➜');
    }
  }

  function showWin(id) {
    var hero = HEROES[id], p = BOARD.byId(id);
    var h = '<section class="card result"><div class="big">🏆</div>' +
      '<h2>' + esc(nameOf(id)) + ' je pobednik!</h2>' +
      '<p class="sub">Sve 4 figure (' + hero.name + ') su stigle kući.</p>' +
      '<div class="row"><button class="btn primary" id="again">🔁 Igraj ponovo</button><button class="btn" id="home">🏠 Novo podešavanje</button></div></section>';
    app.innerHTML = h;
    document.getElementById('again').addEventListener('click', startGame);
    document.getElementById('home').addEventListener('click', setup);
  }

  setup();
})();
