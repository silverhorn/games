NE LJUTI SE, SUPER-PORODICO! (za 4 igrača, 7-10 godina)

Originalna super-porodica (nije iz nijednog filma/serije): Tata Snagator (crveni),
Mama Elastika (zeleni), Munja (žuti), Nevidljiva Mia (plavi).

Pokretanje: raspakuj zip i dvaput klikni na index.html. Igra se na jednom uređaju,
svi igrači vide istu tablu (nema skrivenih informacija, pa nema "predaje uređaja").

PRAVILA:
- Dok igrač nema nijednu figuru na tabli, baca kocku do 3 puta dok ne izbaci šesticu.
  Izbaci li šesticu, figura izlazi i igrač odmah baca ponovo (bonus). Ne izbaci li je
  u 3 bacanja, red prelazi na sledećeg igrača.
- Kad igrač ima bar jednu figuru na tabli, baca jednom. Ako može da pomeri više
  figura tim brojem, bira koju klikom na nju (figura trepti).
- Sletanje tačno na polje protivničke figure vraća tu figuru u bazu.
- Za ulazak u "kuću" (centar) potreban je tačan broj — preveliki broj se ne može
  iskoristiti za tu figuru.
- Šestica uvek nosi dodatni bacaj. Tri šestice zaredom poništavaju taj bacaj i
  potez odmah prelazi dalje (klasično pravilo).
- Pobednik je prvi igrač kome sve 4 figure stignu kući.

TEHNIČKI DETALJI (za dalje uređivanje):
- data/board.js — geometrija table (prsten od 40 polja, 4 kućne staze po 4 polja),
  programski generisana i proverena (bez preklapanja/praznina).
- data/rules.js — čista logika igre (testirana sa 500 simuliranih partija + ciljani
  testovi za hvatanje, tačan broj za kuću, tri šestice, izlazak iz baze).
- data/heroes.js — imena i ikonice likova (originalne, crtane u kodu).
- app.js — tabla (SVG), kocka i tok poteza.
- Imena igrača se mogu promeniti na početnom ekranu.
