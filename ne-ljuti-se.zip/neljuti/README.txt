NE LJUTI SE, GUSARI! (za 4 igrača, 7-10 godina)

Originalne gusarske posade (nisu iz nijednog filma/serije), svaka plovi ka
Ostrvu blaga u centru table: Kapetan Riđobradi (crveni), Zeleni Papagaj
(zeleni), Zlatousti Gusari (žuti), Kapetan Plava Dubina (plavi).

Pokretanje: raspakuj zip i dvaput klikni na index.html. Igra se na jednom
uređaju, svi igrači vide istu tablu (nema skrivenih informacija, pa nema
"predaje uređaja").

PRAVILA:
- Dok igrač (posada) nema nijedan brod na tabli, baca kocku do 3 puta dok ne
  izbaci šesticu. Izbaci li šesticu, brod isplovljava iz luke i igrač odmah
  baca ponovo (bonus). Ne izbaci li je u 3 bacanja, red prelazi na sledeću
  posadu.
- Kad posada ima bar jedan brod na tabli, baca jednom. Ako može da pomeri
  više brodova tim brojem, bira koji klikom na njega (brod trepti).
- Sletanje tačno na polje protivničkog broda ga potapa — vraća se u luku
  (bazu).
- Za pristajanje na Ostrvo blaga (centar) potreban je tačan broj — preveliki
  broj se ne može iskoristiti za taj brod.
- Šestica uvek nosi dodatni bacaj. Tri šestice zaredom poništavaju taj bacaj
  i potez odmah prelazi dalje (klasično pravilo).
- Pobednik je prva posada kojoj sva 4 broda stignu na Ostrvo blaga.

TEMA:
- Table ima drveni Montessori stil sa okeanskom pozadinom, kućne staze su
  numerisane (1-4, sa strelicom ka ostrvu), a u centru je kružni "medaljon"
  Ostrva blaga — po jedan isečak boje za svaku posadu oko zlatnika 💰.

TEHNIČKI DETALJI (za dalje uređivanje):
- data/board.js — geometrija table (prsten od 40 polja, 4 kućne staze po 4
  polja), programski generisana i proverena (bez preklapanja/praznina).
- data/rules.js — čista logika igre (testirana sa 500 simuliranih partija +
  ciljani testovi za hvatanje/potapanje, tačan broj za pristajanje, tri
  šestice, izlazak iz luke).
- data/heroes.js — imena i ikonice gusarskih posada (originalne, crtane u
  kodu: lobanja, zastava, sidro, kormilo).
- app.js — tabla (SVG, drvena pozadina + ostrvo blaga), kocka i tok poteza.
- Imena igrača (posada) se mogu promeniti na početnom ekranu.
