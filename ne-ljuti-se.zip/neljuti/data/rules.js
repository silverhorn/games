// Čista logika igre "Ne ljuti se čoveče", bez DOM-a — testabilna u Node-u i u pregledaču.
(function () {
  'use strict';
  var BOARD = window.BOARD;

  function newGame(playerIds) {
    var pieces = {};
    playerIds.forEach(function (id) {
      pieces[id] = [0, 0, 0, 0]; // 0 = u bazi; 1..40 prsten; 41..44 staza; 45 stigla
    });
    return {
      order: playerIds.slice(),
      turn: 0,          // indeks u order
      pieces: pieces,
      sixStreak: 0,     // uzastopne šestice u ovom potezu
      phase: 'need-six', // 'need-six' (sve figure u bazi) ili 'roll' (normalan potez)
      winner: null,
      log: []
    };
  }

  function currentPlayerId(g) { return g.order[g.turn]; }
  function allInBase(g, id) { return g.pieces[id].every(function (s) { return s === 0; }); }
  function allHome(g, id) { return g.pieces[id].every(function (s) { return s === 45; }); }
  function hasActive(g, id) { return g.pieces[id].some(function (s) { return s >= 1 && s <= 44; }); }
  function hasInBase(g, id) { return g.pieces[id].some(function (s) { return s === 0; }); }

  // 'need-six' kad igrač nema nijednu figuru na tabli (van baze), a ima bar jednu u bazi da izvede.
  function updatePhase(g) {
    var id = currentPlayerId(g);
    g.phase = (!hasActive(g, id) && hasInBase(g, id)) ? 'need-six' : 'roll';
  }

  // Figure igrača `id` koje mogu legalno da se pomere za `die`; vraća niz indeksa (0..3)
  function movable(g, id, die) {
    var out = [];
    g.pieces[id].forEach(function (step, i) {
      if (step === 0) return; // u bazi se izlazi samo sa 6, obrađeno posebno
      if (step === 45) return; // već stigla
      var dest = step + die;
      if (dest > 45) return; // premašuje kuću — nedozvoljeno (mora tačan broj)
      out.push(i);
    });
    return out;
  }

  // Da li polje (korak) te boje sadrži protivničke figure na istom globalnom polju prstena
  function opponentsOnCell(g, id, destStep) {
    if (destStep < 1 || destStep > 40) return []; // van prstena (baza/staza/kuća) nema sudara
    var p = BOARD.byId(id);
    var cell = p.ringPos(destStep);
    var hits = [];
    g.order.forEach(function (oid) {
      if (oid === id) return;
      var op = BOARD.byId(oid);
      g.pieces[oid].forEach(function (ostep, oi) {
        if (ostep < 1 || ostep > 40) return;
        var ocell = op.ringPos(ostep);
        if (ocell[0] === cell[0] && ocell[1] === cell[1]) hits.push({ id: oid, idx: oi });
      });
    });
    return hits;
  }

  // Primeni potez: pomeri figuru `idx` igrača `id` za `die` koraka. Vraća opis šta se desilo.
  function applyMove(g, id, idx, die) {
    var before = g.pieces[id][idx];
    var dest = before + die;
    g.pieces[id][idx] = dest;
    var captured = opponentsOnCell(g, id, dest);
    captured.forEach(function (h) { g.pieces[h.id][h.idx] = 0; });
    var finished = allHome(g, id);
    if (finished) g.winner = id;
    return { from: before, to: dest, captured: captured, finished: finished };
  }

  // Izvede izlazak figure iz baze (korak 0 -> 1)
  function applyExit(g, id) {
    var idx = g.pieces[id].indexOf(0);
    g.pieces[id][idx] = 1;
    var captured = opponentsOnCell(g, id, 1);
    captured.forEach(function (h) { g.pieces[h.id][h.idx] = 0; });
    return { idx: idx, captured: captured };
  }

  function nextTurn(g) {
    g.sixStreak = 0;
    g.exitTries = 0;
    g.turn = (g.turn + 1) % g.order.length;
    updatePhase(g);
  }

  // Poziva se kada igrač nema nijednu figuru van baze: baca kocku do 3 puta dok ne izbaci šesticu.
  // Vraća { exited: bool, endTurn: bool, captured: [...] }
  function rollForExit(g, die) {
    var id = currentPlayerId(g);
    g.exitTries = (g.exitTries || 0) + 1;
    if (die === 6) {
      var r = applyExit(g, id);
      g.phase = 'roll';
      g.sixStreak = 1; // šestica nosi dodatni bacaj
      return { exited: true, endTurn: false, captured: r.captured };
    }
    if (g.exitTries >= 3) return { exited: false, endTurn: true, captured: [] };
    return { exited: false, endTurn: false, captured: [] };
  }

  // Normalan potez: igrač već ima bar jednu figuru van baze. `idx` bira UI/test kad ima više opcija.
  // Vraća { moved, idx, captured, finished, bonus, forfeited, endTurn }
  function rollNormal(g, die, idx) {
    var id = currentPlayerId(g);
    if (die === 6) {
      g.sixStreak = (g.sixStreak || 0) + 1;
      if (g.sixStreak >= 3) {
        g.sixStreak = 0;
        return { moved: false, captured: [], bonus: false, forfeited: true, endTurn: true };
      }
    } else {
      g.sixStreak = 0;
    }
    var opts = movable(g, id, die);
    if (opts.length === 0) {
      return { moved: false, captured: [], bonus: die === 6, forfeited: false, endTurn: die !== 6 };
    }
    var useIdx = idx === undefined || opts.indexOf(idx) === -1 ? opts[0] : idx;
    var r = applyMove(g, id, useIdx, die);
    return {
      moved: true, idx: useIdx, captured: r.captured, finished: r.finished,
      bonus: die === 6 && !g.winner, forfeited: false, endTurn: !(die === 6 && !g.winner)
    };
  }

  // Beleži šesticu u normalnoj fazi (van simulacije): vraća da li je ovo 3. šestica zaredom (propada potez).
  function noteSix(g, die) {
    if (die === 6) {
      g.sixStreak = (g.sixStreak || 0) + 1;
      if (g.sixStreak >= 3) { g.sixStreak = 0; return { forfeited: true, bonus: false }; }
      return { forfeited: false, bonus: true };
    }
    g.sixStreak = 0;
    return { forfeited: false, bonus: false };
  }

  window.RULES = {
    newGame: newGame, currentPlayerId: currentPlayerId, allInBase: allInBase, allHome: allHome,
    updatePhase: updatePhase, movable: movable, opponentsOnCell: opponentsOnCell,
    applyMove: applyMove, applyExit: applyExit, nextTurn: nextTurn,
    rollForExit: rollForExit, rollNormal: rollNormal, noteSix: noteSix
  };
})();
