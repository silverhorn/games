// Geometrija table: prsten od 40 polja (krst), 4 baze, 4 kućne staze po 4 polja.
// Proverena generatorom (bez duplikata i praznina) — videti napomenu u README-u.
(function () {
  'use strict';
  var R = 5, HOLE = R, C1 = R - 1, C2 = R + 1, FAR = 0, FAR2 = 2 * R, SIZE = 2 * R + 1;

  function buildRing() {
    var ring = [];
    function push(r, c) { ring.push([r, c]); }
    // GORE
    push(C1, C1);
    for (var r = C1 - 1; r >= FAR; r--) push(r, C1);
    push(FAR, HOLE);
    push(FAR, C2);
    for (r = FAR + 1; r <= C1; r++) push(r, C2);
    // DESNO
    for (var c = C2 + 1; c <= FAR2; c++) push(C1, c);
    push(HOLE, FAR2);
    push(C2, FAR2);
    for (c = FAR2 - 1; c >= C2; c--) push(C2, c);
    // DOLE
    for (r = C2 + 1; r <= FAR2; r++) push(r, C2);
    push(FAR2, HOLE);
    push(FAR2, C1);
    for (r = FAR2 - 1; r >= C2; r--) push(r, C1);
    // LEVO
    for (c = C1 - 1; c >= FAR; c--) push(C2, c);
    push(HOLE, FAR);
    push(C1, FAR);
    for (c = FAR + 1; c <= C1; c++) push(C1, c);
    var last = ring[ring.length - 1];
    if (last[0] === ring[0][0] && last[1] === ring[0][1]) ring.pop();
    return ring;
  }

  var RING = buildRing(); // 40 [red,kolona]

  // Boje: redosled poteza je uvek tl -> tr -> br -> bl (u smeru kazaljke).
  var PLAYERS = [
    { id: 'tl', name: 'Crveni', color: '#e5584f', dark: '#a8352d', start: 0, baseR: 0, baseC: 0 },
    { id: 'tr', name: 'Zeleni', color: '#2bb673', dark: '#1d8a56', start: 10, baseR: 0, baseC: C2 + 1 },
    { id: 'br', name: 'Žuti', color: '#ffc83d', dark: '#c9960f', start: 20, baseR: C2 + 1, baseC: C2 + 1 },
    { id: 'bl', name: 'Plavi', color: '#2d7ff9', dark: '#1c5bc2', start: 30, baseR: C2 + 1, baseC: 0 }
  ];

  // Kućne staze (4 polja, redom od ulaska ka centru) po igraču, ručno postavljene uz centar
  var HOME_CELLS = {
    tl: [[HOLE, 1], [HOLE, 2], [HOLE, 3], [HOLE, 4]],
    tr: [[1, HOLE], [2, HOLE], [3, HOLE], [4, HOLE]],
    br: [[HOLE, 9], [HOLE, 8], [HOLE, 7], [HOLE, 6]],
    bl: [[9, HOLE], [8, HOLE], [7, HOLE], [6, HOLE]]
  };

  // Mesta za 4 figure u bazi (unutar 4x4 ugaonog bloka), i mesta u "kući" (završeno)
  function baseSlots(p) {
    var r0 = p.baseR, c0 = p.baseC;
    var off = [[0.8, 0.8], [2.6, 0.8], [0.8, 2.6], [2.6, 2.6]];
    return off.map(function (o) { return [r0 + o[0], c0 + o[1]]; });
  }
  // PLAYERS[i].ring40[k] = globalni indeks u RING za relativni korak p (1..40)
  PLAYERS.forEach(function (p) {
    p.ringPos = function (step) { return RING[(p.start + step - 1) % 40]; }; // step: 1..40
    p.home = HOME_CELLS[p.id]; // step 41..44 -> home[0..3]
    p.baseSlots = baseSlots(p);
  });

  // mesta za završene figure: 4 mala mesta zbijena oko poslednje ćelije staze (tik uz centar)
  function finishCluster(cell) {
    var r = cell[0], c = cell[1]; // px() već centrira unutar jedinične ćelije
    return [[r - 0.22, c - 0.22], [r - 0.22, c + 0.22], [r + 0.22, c - 0.22], [r + 0.22, c + 0.22]];
  }
  var FINISH_SLOTS = {
    tl: finishCluster(HOME_CELLS.tl[3]),
    tr: finishCluster(HOME_CELLS.tr[3]),
    br: finishCluster(HOME_CELLS.br[3]),
    bl: finishCluster(HOME_CELLS.bl[3])
  };
  PLAYERS.forEach(function (p) { p.finishSlots = FINISH_SLOTS[p.id]; });

  function byId(id) { return PLAYERS.filter(function (p) { return p.id === id; })[0]; }

  // Vraća [red,kolona] za trenutnu poziciju figure.
  // step: 0 = u bazi (baseIdx 0..3); 1..40 = na prstenu; 41..44 = kućna staza; 45 = stigla kući
  function cellFor(player, step, baseIdx, homeIdx) {
    if (step === 0) return player.baseSlots[baseIdx];
    if (step >= 1 && step <= 40) return player.ringPos(step);
    if (step >= 41 && step <= 44) return player.home[step - 41];
    return player.finishSlots[homeIdx];
  }

  window.BOARD = {
    SIZE: SIZE, HOLE: HOLE, C1: C1, C2: C2, FAR: FAR, FAR2: FAR2,
    RING: RING, PLAYERS: PLAYERS, byId: byId, cellFor: cellFor,
    FINISH_LEN: 45 // ukupno koraka da figura stigne kući (40 prsten + 4 staza + 1 "stigla")
  };
})();
