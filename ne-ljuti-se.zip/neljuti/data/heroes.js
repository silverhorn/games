// Originalne gusarske posade (nisu iz nijednog filma) — po jedna posada za svaku boju.
(function () {
  'use strict';
  window.HEROES = {
    tl: { name: 'Kapetan Riđobradi', sub: 'lobanja i kosti', icon: iconSkull('#ffffff') },
    tr: { name: 'Zeleni Papagaj', sub: 'gusarska zastava', icon: iconFlag('#ffffff') },
    br: { name: 'Zlatousti Gusari', sub: 'sidro', icon: iconAnchor('#7a5a00') },
    bl: { name: 'Kapetan Plava Dubina', sub: 'kormilo broda', icon: iconWheel('#ffffff') }
  };

  function iconSkull(c) {
    return '<g fill="' + c + '">' +
      '<path d="M0 -7.5 C4.5 -7.5 7 -4.6 7 -1.2 C7 1.6 5.4 3 4.4 4.3 C4 4.8 3.9 5.6 3.9 6.4 H-3.9 C-3.9 5.6 -4 4.8 -4.4 4.3 C-5.4 3 -7 1.6 -7 -1.2 C-7 -4.6 -4.5 -7.5 0 -7.5Z"/>' +
      '<circle cx="-3" cy="-1.3" r="2.1" fill="#000"/><circle cx="3" cy="-1.3" r="2.1" fill="#000"/>' +
      '<path d="M0 0.6 L1.3 2.6 H-1.3Z" fill="#000"/>' +
      '<rect x="-2.6" y="4.4" width="1.4" height="1.4" fill="#000"/><rect x="-0.6" y="4.4" width="1.4" height="1.4" fill="#000"/><rect x="1.3" y="4.4" width="1.4" height="1.4" fill="#000"/>' +
      '</g>' +
      '<g stroke="' + c + '" stroke-width="1.8" stroke-linecap="round">' +
      '<line x1="-8.5" y1="-8.5" x2="8.5" y2="8.5"/><line x1="8.5" y1="-8.5" x2="-8.5" y2="8.5"/></g>';
  }
  function iconFlag(c) {
    return '<line x1="-5" y1="8" x2="-5" y2="-8" stroke="' + c + '" stroke-width="1.6"/>' +
      '<path d="M-5 -8 H7 L3 -4 L7 0 H-5Z" fill="' + c + '"/>' +
      '<circle cx="-0.3" cy="-5.2" r="1.5" fill="#1f2d3d"/>';
  }
  function iconAnchor(c) {
    return '<g fill="none" stroke="' + c + '" stroke-width="1.8" stroke-linecap="round">' +
      '<circle cx="0" cy="-6.6" r="1.7" fill="' + c + '" stroke="none"/>' +
      '<line x1="0" y1="-5" x2="0" y2="6.5"/>' +
      '<line x1="-4.5" y1="-2.2" x2="4.5" y2="-2.2"/>' +
      '<path d="M-6.5 1 C-6.5 4.6 -3.2 6.8 0 7.2 C3.2 6.8 6.5 4.6 6.5 1"/>' +
      '</g>';
  }
  function iconWheel(c) {
    var s = '<circle cx="0" cy="0" r="6.4" fill="none" stroke="' + c + '" stroke-width="1.6"/>' +
      '<circle cx="0" cy="0" r="2" fill="' + c + '"/>';
    for (var a = 0; a < 360; a += 45) {
      var r1 = a * Math.PI / 180;
      var x1 = 6.4 * Math.cos(r1), y1 = 6.4 * Math.sin(r1);
      var x2 = 9 * Math.cos(r1), y2 = 9 * Math.sin(r1);
      s += '<line x1="' + x1.toFixed(1) + '" y1="' + y1.toFixed(1) + '" x2="' + x2.toFixed(1) + '" y2="' + y2.toFixed(1) + '" stroke="' + c + '" stroke-width="1.6" stroke-linecap="round"/>';
    }
    return s;
  }
})();
