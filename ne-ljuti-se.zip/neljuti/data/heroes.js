// Originalna super-porodica (nije iz nijednog filma) — po jedan heroj za svaku boju.
(function () {
  'use strict';
  window.HEROES = {
    tl: { name: 'Tata Snagator', sub: 'super snaga', icon: iconFist('#ffffff') },
    tr: { name: 'Mama Elastika', sub: 'rasteže se', icon: iconSpiral('#ffffff') },
    br: { name: 'Munja', sub: 'super brzina', icon: iconBolt('#7a5a00') },
    bl: { name: 'Nevidljiva Mia', sub: 'nevidljivost', icon: iconMask('#ffffff') }
  };

  function iconFist(c) {
    return '<g fill="' + c + '"><circle cx="0" cy="0" r="6.5"/><rect x="-3.2" y="-7.5" width="2.2" height="4" rx="1"/><rect x="-0.6" y="-8.3" width="2.2" height="4.8" rx="1"/><rect x="2" y="-7.5" width="2.2" height="4" rx="1"/></g>';
  }
  function iconSpiral(c) {
    return '<path d="M0 6 C5 6 6 2 3 0 C0 -2 -2 1 0 2.4 C2 3.6 4 1 2.5 -1 C1 -3 -3 -3 -4 0" fill="none" stroke="' + c + '" stroke-width="1.6" stroke-linecap="round"/>';
  }
  function iconBolt(c) {
    return '<path d="M1.5 -7 L-4 1 H-0.5 L-2 7 L5 -1 H1 Z" fill="' + c + '"/>';
  }
  function iconMask(c) {
    return '<path d="M-7 -1 C-7 -4 -3 -5 0 -3.5 C3 -5 7 -4 7 -1 C7 2 4 3.5 0 2 C-4 3.5 -7 2 -7 -1Z" fill="none" stroke="' + c + '" stroke-width="1.6" stroke-dasharray="2.2 1.6"/>' +
      '<circle cx="-3.3" cy="-1" r="1.3" fill="' + c + '"/><circle cx="3.3" cy="-1" r="1.3" fill="' + c + '"/>';
  }
})();
