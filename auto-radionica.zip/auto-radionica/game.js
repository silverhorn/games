(function(){
'use strict';
const T=THREE;
const $=(s,r=document)=>r.querySelector(s);
const PI=Math.PI;
const rnd=(a,b)=>a+Math.random()*(b-a);

/* ================= ZVUK ================= */
let ac=null,muted=false;
try{muted=localStorage.getItem('auto-radionica-muted')==='1'}catch(e){}
function ctx(){ac=ac||new (window.AudioContext||window.webkitAudioContext)();if(ac.state==='suspended')ac.resume();return ac}
function tone(f,d,t,type,v){
  if(muted)return;
  try{
    const a=ctx(),o=a.createOscillator(),g=a.createGain();
    o.type=type||'sine';o.frequency.value=f;v=v||.14;
    o.connect(g);g.connect(a.destination);
    const s=a.currentTime+(t||0);
    g.gain.setValueAtTime(v,s);g.gain.exponentialRampToValueAtTime(.001,s+d);
    o.start(s);o.stop(s+d);
  }catch(e){}
}
const snd={
  tap(){tone(620,.08)},
  pick(){tone(520,.07);tone(700,.09,.06)},
  put(){tone(180,.12,0,'square',.12);tone(900,.1,.05,'triangle',.1)},
  no(){tone(260,.22,0,'triangle',.1)},
  phase(){[523,659,784,1047].forEach((f,i)=>tone(f,.25,i*.11))},
  horn(){tone(392,.5,0,'square',.07);tone(494,.5,0,'square',.07)},
  click(){tone(1400,.03,0,'square',.08)}
};
let eng=null;
function engineStart(){
  if(muted||eng)return;
  try{
    const a=ctx();
    const o1=a.createOscillator(),o2=a.createOscillator(),lfo=a.createOscillator();
    const lp=a.createBiquadFilter(),g=a.createGain(),lg=a.createGain();
    o1.type='sawtooth';o2.type='square';lp.type='lowpass';lp.frequency.value=420;
    g.gain.value=0;lfo.frequency.value=22;lg.gain.value=.04;
    lfo.connect(lg);lg.connect(g.gain);
    o1.connect(lp);o2.connect(lp);lp.connect(g);g.connect(a.destination);
    const n=a.currentTime;
    o1.frequency.setValueAtTime(16,n);o1.frequency.linearRampToValueAtTime(30,n+.7);o1.frequency.linearRampToValueAtTime(46,n+1.1);
    o2.frequency.setValueAtTime(8,n);o2.frequency.linearRampToValueAtTime(23,n+.7);o2.frequency.linearRampToValueAtTime(46,n+1.1);
    lfo.frequency.setValueAtTime(30,n);lfo.frequency.linearRampToValueAtTime(14,n+1.1);
    g.gain.linearRampToValueAtTime(.12,n+.5);
    o1.start();o2.start();lfo.start();
    eng={o1,o2,lfo,g,lp};
  }catch(e){}
}
function engineRev(k){
  if(!eng)return;
  const n=ac.currentTime;
  eng.o1.frequency.setTargetAtTime(46+k*40,n,.25);
  eng.o2.frequency.setTargetAtTime(46+k*40,n,.25);
  eng.lfo.frequency.setTargetAtTime(14+k*14,n,.25);
  eng.lp.frequency.setTargetAtTime(420+k*500,n,.25);
}
function engineStop(){
  if(!eng)return;
  const e=eng;eng=null;
  try{
    const n=ac.currentTime;
    e.g.gain.cancelScheduledValues(n);e.g.gain.setTargetAtTime(0,n,.12);
    setTimeout(()=>{try{e.o1.stop();e.o2.stop();e.lfo.stop()}catch(x){}},500);
  }catch(x){}
}

/* ================= SCENA ================= */
const canvas=$('#cv'),stage=$('#stage');
const renderer=new T.WebGLRenderer({canvas,antialias:true});
renderer.setPixelRatio(Math.min(window.devicePixelRatio||1,2));
renderer.shadowMap.enabled=true;renderer.shadowMap.type=T.PCFSoftShadowMap;
renderer.outputEncoding=T.sRGBEncoding;
const scene=new T.Scene();
const SKY_DAY=new T.Color(0xbfe6ff),SKY_NIGHT=new T.Color(0x0a1530);
scene.background=SKY_DAY.clone();
scene.fog=new T.Fog(0xbfe6ff,45,210);
const camera=new T.PerspectiveCamera(40,1,.1,500);
const hemi=new T.HemisphereLight(0xffffff,0x8c9db5,.85);scene.add(hemi);
const sun=new T.DirectionalLight(0xffffff,.95);
sun.position.set(5,10,6);sun.castShadow=true;
sun.shadow.mapSize.set(1024,1024);
Object.assign(sun.shadow.camera,{left:-6,right:6,top:6,bottom:-6,near:1,far:30});
sun.shadow.bias=-.0004;
scene.add(sun);

/* tlo / put */
function roadTexture(){
  const c=document.createElement('canvas');c.width=256;c.height=256;
  const g=c.getContext('2d');
  g.fillStyle='#454d5c';g.fillRect(0,0,256,256);
  for(let i=0;i<900;i++){g.fillStyle=`rgba(${rnd(0,255)|0},${rnd(0,255)|0},${rnd(0,255)|0},.05)`;g.fillRect(rnd(0,256),rnd(0,256),2,2)}
  g.fillStyle='#f4f4f4';
  g.fillRect(0,128-5,128,10);               /* isprekidana sredina */
  g.fillRect(0,14,256,8);g.fillRect(0,256-22,256,8); /* ivice */
  const t=new T.CanvasTexture(c);
  t.wrapS=t.wrapT=T.RepeatWrapping;t.repeat.set(47,1);t.anisotropy=4;
  return t;
}
const roadTex=roadTexture();
const road=new T.Mesh(new T.PlaneGeometry(300,12),new T.MeshStandardMaterial({map:roadTex,roughness:.95}));
road.rotation.x=-PI/2;road.receiveShadow=true;scene.add(road);
const grass=new T.Mesh(new T.PlaneGeometry(700,700),new T.MeshStandardMaterial({color:0x7bc96f,roughness:1}));
grass.rotation.x=-PI/2;grass.position.y=-.02;grass.receiveShadow=true;scene.add(grass);


/* ================= KRAJOLIK ================= */
function mulberry(a){return function(){a|=0;a=a+0x6D2B79F5|0;let t=Math.imul(a^a>>>15,1|a);t=t+Math.imul(t^t>>>7,61|t)^t;return((t^t>>>14)>>>0)/4294967296}}
const sc={
  win:new T.MeshStandardMaterial({color:0xcfe8ff,emissive:0xffd36b,emissiveIntensity:0,roughness:.3}),
  bulb:new T.MeshStandardMaterial({color:0xfff4c4,emissive:0xffe08a,emissiveIntensity:0}),
  trunk:new T.MeshStandardMaterial({color:0x6b4a2b,roughness:1}),
  crown:new T.MeshStandardMaterial({color:0xffffff,roughness:.9}),
  bush:new T.MeshStandardMaterial({color:0x3f9a4a,roughness:1}),
  stone:new T.MeshStandardMaterial({color:0x8a8f98,roughness:1}),
  pole:new T.MeshStandardMaterial({color:0x4b5360,roughness:.7}),
  water:new T.MeshStandardMaterial({color:0x4aa8e8,roughness:.15,metalness:.2}),
  door:new T.MeshStandardMaterial({color:0x7a4a2a,roughness:.8})
};
const GEO={trunk:new T.CylinderGeometry(.18,.26,1.6,6),pine:new T.ConeGeometry(1.2,3.6,8),round:new T.IcosahedronGeometry(1.5,1),bush:new T.SphereGeometry(.7,8,6)};
const WALLS=[0xf2e3c9,0xe8c9a0,0xd9e7f2,0xf4d6d6,0xcfe5c8],ROOFS=[0xb5472f,0x8a4b2a,0x3f5f8a,0x7a3b3b];
function buildHouse(rnd,x,z,side){
  const g=new T.Group();g.position.set(x,0,z);g.rotation.y=side>0?PI:0;
  const wall=new T.MeshStandardMaterial({color:WALLS[(rnd()*WALLS.length)|0],roughness:.9});
  const roof=new T.MeshStandardMaterial({color:ROOFS[(rnd()*ROOFS.length)|0],roughness:.8});
  const b=new T.Mesh(new T.BoxGeometry(5,2.6,4),wall);b.position.y=1.3;g.add(b);
  const r=new T.Mesh(new T.ConeGeometry(3.9,1.9,4),roof);r.rotation.y=PI/4;r.scale.z=.82;r.position.y=3.55;g.add(r);
  const dr=new T.Mesh(new T.BoxGeometry(.9,1.6,.1),sc.door);dr.position.set(0,.8,2.02);g.add(dr);
  for(const wx of [-1.6,1.6]){const w=new T.Mesh(new T.BoxGeometry(.9,.9,.1),sc.win);w.position.set(wx,1.5,2.02);g.add(w)}
  const ch=new T.Mesh(new T.BoxGeometry(.5,1.2,.5),sc.stone);ch.position.set(1.4,3.7,-.6);g.add(ch);
  return g;
}
function makeTile(seed,idx){
  const rnd=mulberry(seed),R=(a,b)=>a+rnd()*(b-a);
  const g=new T.Group(),houses=[];
  for(const side of [-1,1]){
    if(rnd()<.9){const x=R(-11,11),z=side*R(12,15);houses.push({x,z});g.add(buildHouse(rnd,x,z,side))}
  }
  const N=75,tr=new T.InstancedMesh(GEO.trunk,sc.trunk,N),pi=new T.InstancedMesh(GEO.pine,sc.crown,N),ro=new T.InstancedMesh(GEO.round,sc.crown,N);
  let nt=0,np=0,nr=0;const d=new T.Object3D(),col=new T.Color();
  for(let i=0;i<N;i++){
    const side=rnd()<.5?-1:1,x=R(-20,20),z=side*(rnd()<.3?R(8.5,14):R(14,50));
    if(houses.some(h=>Math.abs(h.x-x)<5&&Math.abs(h.z-z)<5))continue;
    const s=R(.8,1.7);
    d.rotation.set(0,rnd()*6,0);d.scale.setScalar(s);
    d.position.set(x,.8*s,z);d.updateMatrix();tr.setMatrixAt(nt++,d.matrix);
    if(rnd()<.55){
      d.position.set(x,2.8*s,z);d.updateMatrix();pi.setMatrixAt(np,d.matrix);pi.setColorAt(np,col.setHSL(.33+R(-.03,.03),.55,R(.2,.3)));np++;
    }else{
      d.position.set(x,2.5*s,z);d.updateMatrix();ro.setMatrixAt(nr,d.matrix);ro.setColorAt(nr,col.setHSL(.27+R(-.05,.07),.55,R(.28,.42)));nr++;
    }
  }
  tr.count=nt;pi.count=np;ro.count=nr;
  g.add(tr);if(np)g.add(pi);if(nr)g.add(ro);
  const bu=new T.InstancedMesh(GEO.bush,sc.bush,16);
  for(let i=0;i<16;i++){const s=R(.7,1.4);d.rotation.set(0,0,0);d.scale.set(s,s*.8,s);d.position.set(R(-20,20),.35*s,(rnd()<.5?-1:1)*R(6.9,8.3));d.updateMatrix();bu.setMatrixAt(i,d.matrix)}
  g.add(bu);
  for(const side of [-1,1])for(const lx of [-10,10]){
    const p=new T.Mesh(new T.CylinderGeometry(.07,.1,4.5,6),sc.pole);p.position.set(lx,2.25,side*6.7);g.add(p);
    const a=new T.Mesh(new T.BoxGeometry(.9,.08,.08),sc.pole);a.position.set(lx,4.5,side*6.3);g.add(a);
    const bl=new T.Mesh(new T.SphereGeometry(.17,10,8),sc.bulb);bl.position.set(lx,4.4,side*5.9);g.add(bl);
  }
  if(idx%2===1){
    const side=rnd()<.5?-1:1,lk=new T.Mesh(new T.CircleGeometry(R(5,8),28),sc.water);
    lk.rotation.x=-PI/2;lk.position.set(R(-6,6),.03,side*R(24,32));lk.scale.set(1.4,1,1);g.add(lk);
  }
  return g;
}
const tiles=[];
for(let i=0;i<4;i++){const t=makeTile(11+i*7,i);t.position.x=-60+i*40;scene.add(t);tiles.push(t)}
/* planine, brda, oblaci, zvezde (staticno) */
const bgGroup=new T.Group();scene.add(bgGroup);
(function(){
  const rnd=mulberry(5);
  const mm=new T.MeshStandardMaterial({color:0x7d8fb0,roughness:1,flatShading:true}),sm=new T.MeshStandardMaterial({color:0xf4f8ff,roughness:1,flatShading:true});
  for(let i=0;i<16;i++){
    const a=i/16*PI*2+rnd()*.2,R_=110+rnd()*30,h=22+rnd()*22,w=18+rnd()*14;
    const m=new T.Mesh(new T.ConeGeometry(w,h,6),mm);m.position.set(Math.cos(a)*R_,h/2-2,Math.sin(a)*R_);bgGroup.add(m);
    const c=new T.Mesh(new T.ConeGeometry(w*.35,h*.3,6),sm);c.position.set(m.position.x,h*.85-2,m.position.z);bgGroup.add(c);
  }
  const hm=new T.MeshStandardMaterial({color:0x62b35a,roughness:1});
  for(let i=0;i<10;i++){
    const a=i/10*PI*2+rnd(),R_=70+rnd()*20,s=12+rnd()*10;
    const h=new T.Mesh(new T.SphereGeometry(s,16,10),hm);h.scale.y=.45;h.position.set(Math.cos(a)*R_,-s*.18,Math.sin(a)*R_);bgGroup.add(h);
  }
})();
const cloudMat=new T.MeshBasicMaterial({color:0xffffff,transparent:true,opacity:.92,fog:false});
const clouds=[];
(function(){
  const rnd=mulberry(9);
  for(let i=0;i<10;i++){
    const c=new T.Group();
    for(let k=0;k<4;k++){const sp=new T.Mesh(new T.SphereGeometry(3+rnd()*2.5,10,8),cloudMat);sp.position.set(k*3.2-5,rnd()*1.2,rnd()*2);sp.scale.y=.6;c.add(sp)}
    c.position.set(-120+rnd()*240,26+rnd()*14,(rnd()<.5?-1:1)*(25+rnd()*90));scene.add(c);clouds.push(c);
  }
})();
const starMat=new T.PointsMaterial({color:0xffffff,size:2.2,sizeAttenuation:false,transparent:true,opacity:0,fog:false});
(function(){
  const rnd=mulberry(3),v=[];
  for(let i=0;i<350;i++){const a=rnd()*PI*2,e=.15+rnd()*1.3,r=300;v.push(Math.cos(a)*Math.cos(e)*r,Math.sin(e)*r,Math.sin(a)*Math.cos(e)*r)}
  const g=new T.BufferGeometry();g.setAttribute('position',new T.Float32BufferAttribute(v,3));
  scene.add(new T.Points(g,starMat));
})();

/* ================= MATERIJALI ================= */
const mats={
  body:new T.MeshStandardMaterial({color:0xd8322f,roughness:.32,metalness:.35}),
  chrome:new T.MeshStandardMaterial({color:0xe6ebf2,roughness:.15,metalness:.95}),
  metal:new T.MeshStandardMaterial({color:0x8a95a5,roughness:.45,metalness:.7}),
  engine:new T.MeshStandardMaterial({color:0x7d8999,roughness:.5,metalness:.6}),
  blockMat:new T.MeshStandardMaterial({color:0x7d8999,roughness:.5,metalness:.6}),
  needle:new T.MeshBasicMaterial({color:0xff3b30}),
  black:new T.MeshStandardMaterial({color:0x1b202b,roughness:.6,metalness:.2}),
  dark:new T.MeshStandardMaterial({color:0x303846,roughness:.6,metalness:.3}),
  rubber:new T.MeshStandardMaterial({color:0x16181e,roughness:.9}),
  rim:new T.MeshStandardMaterial({color:0xcfd6df,roughness:.25,metalness:.9}),
  red:new T.MeshStandardMaterial({color:0xd23a3a,roughness:.5,metalness:.2}),
  yellow:new T.MeshStandardMaterial({color:0xffc83a,roughness:.5}),
  battery:new T.MeshStandardMaterial({color:0x2b5fc9,roughness:.5}),
  seat:new T.MeshStandardMaterial({color:0x2d4d86,roughness:.85}),
  white:new T.MeshStandardMaterial({color:0xf5f7fa,roughness:.5}),
  glass:new T.MeshStandardMaterial({color:0x9fd8ff,roughness:.05,metalness:.1,transparent:true,opacity:.32,side:T.DoubleSide,depthWrite:false}),
  mirror:new T.MeshStandardMaterial({color:0xc9e6ff,roughness:.05,metalness:1}),
  head:new T.MeshStandardMaterial({color:0xfff6c8,emissive:0xffe58a,emissiveIntensity:0,roughness:.1}),
  tail:new T.MeshStandardMaterial({color:0xa81818,emissive:0xff2a2a,emissiveIntensity:0,roughness:.3}),
  edge:new T.LineBasicMaterial({color:0x202733})
};
const ghostSel=new T.MeshBasicMaterial({color:0xffd24a,transparent:true,opacity:.5,depthWrite:false,side:T.DoubleSide});
const ghostDim=new T.MeshBasicMaterial({color:0x4fd8ff,transparent:true,opacity:.14,depthWrite:false,side:T.DoubleSide});
const ghostGlow=new T.MeshBasicMaterial({color:0xffd24a,transparent:true,opacity:.25,depthWrite:false});
const ghostNone=new T.MeshBasicMaterial({transparent:true,opacity:0,depthWrite:false});
let arrows=[];

/* ================= POMOCNE FUNKCIJE ================= */
function mesh(geo,mat){const m=new T.Mesh(geo,mat);m.castShadow=true;m.receiveShadow=true;return m}
function box(w,h,d,mat,x,y,z){const m=mesh(new T.BoxGeometry(w,h,d),mat);m.position.set(x||0,y||0,z||0);return m}
function cylX(r,len,mat,x,y,z){const m=mesh(new T.CylinderGeometry(r,r,len,20),mat);m.rotation.z=PI/2;m.position.set(x||0,y||0,z||0);return m}
function cylZ(r,len,mat,x,y,z){const m=mesh(new T.CylinderGeometry(r,r,len,20),mat);m.rotation.x=PI/2;m.position.set(x||0,y||0,z||0);return m}
function cylY(r,len,mat,x,y,z){const m=mesh(new T.CylinderGeometry(r,r,len,20),mat);m.position.set(x||0,y||0,z||0);return m}
function bar(a,b,r,mat){
  a=new T.Vector3(...a);b=new T.Vector3(...b);
  const d=new T.Vector3().subVectors(b,a),l=d.length();
  const m=mesh(new T.CylinderGeometry(r,r,l,10),mat);
  m.position.copy(a).addScaledVector(d,.5);
  m.quaternion.setFromUnitVectors(new T.Vector3(0,1,0),d.normalize());
  return m;
}
function extr(shape,depth,mat,z0){
  const m=mesh(new T.ExtrudeGeometry(shape,{depth,bevelEnabled:false}),mat);m.position.z=z0;return m;
}
function outline(m){
  const l=new T.LineSegments(new T.EdgesGeometry(m.geometry,25),mats.edge);
  l.position.copy(m.position);return l;
}
function quad(p,mat){ // 4 tacke -> ravan (staklo)
  const g=new T.BufferGeometry();
  const v=[...p[0],...p[1],...p[2],...p[0],...p[2],...p[3]];
  g.setAttribute('position',new T.Float32BufferAttribute(v,3));g.computeVertexNormals();
  return new T.Mesh(g,mat);
}

/* mere karoserije */
const TOP=1.15,DX0=-.85,DX1=.8,ROOF=1.75,WB=1.17;

/* ================= DELOVI (graditelji) ================= */
const WP=[[1.5,.45,-.95],[1.5,.45,.95],[-1.5,.45,-.95],[-1.5,.45,.95]];
function bWheel(i){
  const p=WP[i],s=p[2]>0?1:-1;
  const g=new T.Group();g.position.set(...p);
  const spin=new T.Group();g.add(spin);g.userData.spin=spin;
  spin.add(mesh(new T.TorusGeometry(.33,.12,16,36),mats.rubber));
  spin.add(cylZ(.27,.2,mats.black,0,0,0));
  spin.add(cylZ(.25,.04,mats.rim,0,0,s*.09));
  spin.add(cylZ(.075,.07,mats.chrome,0,0,s*.12));
  for(let k=0;k<5;k++){
    const a=k/5*PI*2;
    const sp=box(.07,.17,.03,mats.rim,Math.cos(a)*.15,Math.sin(a)*.15,s*.115);
    sp.rotation.z=a-PI/2;spin.add(sp);
    spin.add(cylZ(.016,.05,mats.chrome,Math.cos(a+.3)*.09,Math.sin(a+.3)*.09,s*.13));
  }
  const disc=cylZ(.2,.03,mats.metal,0,0,-s*.08);spin.add(disc);
  return g;
}
const ENG_POS=[1.5,.78,0],ENG_S=.72;
function eg(){const g=new T.Group();const e=new T.Group();e.scale.setScalar(ENG_S);e.position.set(...ENG_POS);g.add(e);return [g,e]}
const CX=k=>-.3+.2*k;
function bBlock(){
  const [g,e]=eg();
  e.add(box(.9,.4,.7,mats.blockMat,0,0,0));
  const pist=[],rods=[],flames=[];
  e.add(cylX(.035,.86,mats.metal,0,-.2,0));
  for(let k=0;k<4;k++){
    const x=CX(k);
    const p=new T.Group();p.position.set(x,0,0);
    p.add(cylY(.075,.1,mats.chrome,0,0,0));
    p.add(cylY(.078,.012,mats.dark,0,.03,0));p.add(cylY(.078,.012,mats.dark,0,0,0));
    e.add(p);pist.push(p);
    const r=box(.025,1,.025,mats.metal,x,-.1,0);e.add(r);rods.push(r);
    const f=mesh(new T.SphereGeometry(.09,10,8),new T.MeshBasicMaterial({color:0xff8a1f,transparent:true,opacity:0,depthWrite:false}));
    f.position.set(x,.16,0);e.add(f);flames.push(f);
  }
  for(const z of [-.36,.36])for(let k=0;k<5;k++)e.add(cylZ(.025,.03,mats.chrome,-.4+k*.2,.15,z));
  g.userData.eng={pist,rods,flames};
  return g;
}
function bPan(){const [g,e]=eg();e.add(box(.8,.14,.58,mats.black,0,-.27,0));e.add(cylY(.03,.03,mats.chrome,0,-.35,0));return g}
function bEHead(){
  const [g,e]=eg();e.add(box(.9,.16,.66,mats.dark,0,.28,0));
  for(let k=0;k<5;k++){e.add(cylY(.025,.02,mats.chrome,-.4+k*.2,.37,.3));e.add(cylY(.025,.02,mats.chrome,-.4+k*.2,.37,-.3))}
  return g;
}
function bPlug(i){
  const [g,e]=eg(),x=CX(i);
  e.add(cylY(.04,.05,mats.chrome,x,.385,0));
  e.add(cylY(.025,.09,mats.white,x,.44,0));
  e.add(cylY(.04,.04,mats.black,x,.49,0));
  e.add(bar([x,.49,0],[x,.44,-.2],.012,mats.black));
  return g;
}
function bCover(){
  const [g,e]=eg();
  e.add(box(.78,.07,.5,mats.red,0,.38,0));
  e.add(cylY(.06,.04,mats.yellow,-.3,.43,.14));
  for(const x of [-.34,.34])for(const z of [-.2,.2])e.add(cylY(.02,.02,mats.chrome,x,.43,z));
  return g;
}
function bIntake(){
  const [g,e]=eg();
  e.add(cylX(.07,.8,mats.metal,0,.22,-.52));
  for(let k=0;k<4;k++)e.add(cylZ(.035,.2,mats.chrome,CX(k),.2,-.42));
  e.add(cylX(.06,.1,mats.black,.45,.22,-.52));
  e.add(box(.45,.2,.25,mats.black,0,.28,-.82));
  e.add(bar([.45,.22,-.52],[.2,.28,-.78],.04,mats.black));
  return g;
}
function bExMan(){
  const [g,e]=eg();
  for(let k=0;k<4;k++)e.add(cylZ(.035,.22,mats.chrome,CX(k),.2,.43));
  e.add(cylX(.05,.8,mats.metal,0,.2,.54));
  e.add(box(.03,.14,.14,mats.dark,.42,.2,.54));
  return g;
}
function bBelt(){
  const [g,e]=eg();
  const P=[[-.05,0,.14],[.22,.24,.07],[.2,-.22,.07]];
  P.forEach(p=>e.add(cylX(p[2],.05,mats.black,.48,p[0],p[1])));
  for(let k=0;k<3;k++){
    const a=P[k],b=P[(k+1)%3];
    e.add(bar([.5,a[0],a[1]],[.5,b[0],b[1]],.012,mats.rubber));
  }
  e.add(cylX(.07,.1,mats.metal,.4,.2,-.22));
  return g;
}
function bAlt(){
  const [g,e]=eg();
  e.add(cylX(.1,.2,mats.metal,.34,.22,.24));
  for(let k=0;k<5;k++)e.add(cylX(.105,.012,mats.dark,.27+k*.035,.22,.24));
  e.add(cylX(.03,.06,mats.red,.2,.3,.34));
  return g;
}
function bRadiator(){
  const g=new T.Group();
  g.add(box(.1,.5,1.45,mats.black,2.02,.85,0));
  for(let k=0;k<9;k++)g.add(box(.115,.018,1.4,mats.metal,2.02,.64+k*.05,0));
  g.add(box(.12,.5,.08,mats.dark,2.02,.85,.76));g.add(box(.12,.5,.08,mats.dark,2.02,.85,-.76));
  g.add(bar([1.95,1.07,.7],[1.45,.98,.3],.035,mats.black));  // crevo gore
  g.add(bar([1.95,.65,-.7],[1.45,.7,-.3],.035,mats.black));  // crevo dole
  const fan=new T.Group();fan.position.set(1.9,.85,0);g.add(fan);
  fan.add(cylX(.07,.08,mats.black,0,0,0));
  for(let k=0;k<6;k++){
    const bl=new T.Group();bl.rotation.x=k/6*PI*2;
    const b=box(.015,.26,.09,mats.dark,0,.17,0);b.rotation.y=.5;bl.add(b);fan.add(bl);
  }
  const ring=mesh(new T.TorusGeometry(.33,.025,8,28),mats.dark);ring.rotation.y=PI/2;ring.position.set(1.9,.85,0);g.add(ring);
  g.userData.fan=fan;
  return g;
}
function bBattery(){
  const g=new T.Group();
  g.add(box(.42,.28,.26,mats.battery,1.1,.78,.6));
  g.add(box(.44,.03,.28,mats.dark,1.1,.93,.6));
  g.add(cylY(.03,.06,mats.red,1.0,.96,.54));g.add(cylY(.03,.06,mats.black,1.0,.96,.66));
  g.add(box(.2,.01,.1,mats.white,1.17,.945,.6));
  g.add(bar([1.0,.97,.54],[1.35,.9,.15],.012,mats.red));
  g.add(bar([1.0,.97,.66],[1.2,.5,.55],.012,mats.black));
  return g;
}
function bTank(){
  const g=new T.Group();
  g.add(cylZ(.25,.9,mats.metal,-1.55,.82,0));
  for(const z of [.45,-.45]){const c=mesh(new T.SphereGeometry(.25,18,12),mats.metal);c.position.set(-1.55,.82,z);g.add(c)}
  g.add(cylZ(.265,.04,mats.dark,-1.55,.82,.2));g.add(cylZ(.265,.04,mats.dark,-1.55,.82,-.2));
  g.add(bar([-1.5,1.05,.2],[-1.7,.96,.9],.05,mats.black));
  g.add(bar([-1.3,.62,0],[-.9,.6,0],.025,mats.black));
  return g;
}
function bExhaust(){
  const g=new T.Group(),m=mats.metal,r=.05;
  g.add(bar([1.79,.92,.37],[1.45,.46,.3],r,m));
  g.add(bar([1.45,.46,.3],[-1.2,.42,.3],r,m));
  g.add(cylX(.15,.72,mats.engine,-1.6,.4,.3));
  g.add(bar([-1.95,.4,.3],[-2.3,.42,.3],.055,m));
  g.add(cylX(.075,.1,mats.chrome,-2.3,.42,.3));
  for(const x of [.3,-.7]){g.add(bar([x,.42,.3],[x,.5,.3],.012,mats.black))}
  g.userData.tip=new T.Vector3(-2.38,.42,.3);
  return g;
}
function bSeat(i){
  const z=i?.42:-.42,g=new T.Group();
  g.add(box(.55,.14,.5,mats.seat,.05,.68,z));
  const back=box(.12,.62,.5,mats.seat,-.27,1.0,z);back.rotation.z=.18;g.add(back);
  const hr=box(.1,.2,.3,mats.seat,-.34,1.4,z);hr.rotation.z=.18;g.add(hr);
  g.add(box(.5,.05,.04,mats.dark,.05,.62,z+.25));g.add(box(.5,.05,.04,mats.dark,.05,.62,z-.25));
  g.add(bar([.2,.6,z-.15],[.2,.5,z-.15],.015,mats.metal));
  return g;
}
function bDash(){
  const g=new T.Group();
  g.add(box(.36,.26,1.62,mats.dark,.66,1.0,0));
  g.add(box(.3,.04,1.6,mats.black,.66,1.14,0));
  g.add(box(.9,.14,.28,mats.dark,.1,.67,0));
  g.add(cylY(.045,.02,mats.black,.42,.75,.0));
  for(const z of [.12,.55,.75])g.add(box(.02,.035,.13,mats.metal,.48,1.09,z));
  g.add(box(.02,.06,.22,mats.metal,.48,.95,.32));
  g.add(box(.2,.2,.1,mats.black,.5,.78,0));
  g.add(box(.12,.03,.34,mats.rubber,.64,.62,0));
  return g;
}
function faceTex(kind){
  const c=document.createElement('canvas');c.width=c.height=128;const g=c.getContext('2d');
  g.fillStyle=kind==='rev'?'#fff3cd':kind==='fuelg'?'#e3f6e3':kind==='temp'?'#e1f0ff':'#f7f9fc';
  g.beginPath();g.arc(64,64,62,0,7);g.fill();
  g.lineWidth=3;g.strokeStyle='#222';g.beginPath();g.arc(64,64,60,0,7);g.stroke();
  const ang=v=>2.35-v*4.7,pos=(a,R)=>[64-Math.sin(a)*R,64-Math.cos(a)*R];
  g.textAlign='center';g.textBaseline='middle';
  const ticks=(n,R1,R2)=>{g.strokeStyle='#222';g.lineWidth=3;for(let k=0;k<=n;k++){const a=ang(k/n),p=pos(a,R1),q=pos(a,R2);g.beginPath();g.moveTo(p[0],p[1]);g.lineTo(q[0],q[1]);g.stroke()}};
  const labels=(n,f,R,fs)=>{g.fillStyle='#111';g.font=`bold ${fs}px sans-serif`;for(let k=0;k<=n;k++){const p=pos(ang(k/n),R);g.fillText(f(k),p[0],p[1])}};
  if(kind==='speedo'){ticks(16,56,48);labels(4,k=>k*40,36,17);g.fillStyle='#333';g.font='bold 16px sans-serif';g.fillText('km/h',64,94)}
  if(kind==='rev'){
    g.strokeStyle='#d62d20';g.lineWidth=7;g.beginPath();g.arc(64,64,52,-ang(5/6)-Math.PI/2,-ang(1)-Math.PI/2,false);g.stroke();
    ticks(12,56,48);labels(6,k=>k,36,18);g.fillStyle='#333';g.font='bold 14px sans-serif';g.fillText('x1000',64,92);g.fillText('rpm',64,106);
  }
  if(kind==='fuelg'){ticks(4,56,44);g.fillStyle='#111';g.font='bold 30px sans-serif';let p=pos(ang(0),34);g.fillText('E',p[0],p[1]);p=pos(ang(1),34);g.fillText('F',p[0],p[1]);g.font='34px sans-serif';g.fillText('⛽',64,92)}
  if(kind==='temp'){ticks(4,56,44);g.font='bold 30px sans-serif';g.fillStyle='#1b6fd6';let p=pos(ang(0),34);g.fillText('C',p[0],p[1]);g.fillStyle='#d62d20';p=pos(ang(1),34);g.fillText('H',p[0],p[1]);g.font='34px sans-serif';g.fillText('🌡️',64,92)}
  const t=new T.CanvasTexture(c);t.anisotropy=4;return t;
}
const GAUGES={
  speedo:{r:.075,y:1.02,z:-.7},
  rev:{r:.075,y:1.02,z:-.34},
  fuelg:{r:.04,y:1.055,z:-.52},
  temp:{r:.04,y:.975,z:-.52}
};
function bGauge(kind){
  const cfg=GAUGES[kind],w=new T.Group();
  const g=new T.Group();g.position.set(.478,cfg.y,cfg.z);g.rotation.y=-PI/2;w.add(g);
  g.add(cylZ(cfg.r+.012,.02,mats.black,0,0,0));
  const face=new T.Mesh(new T.CircleGeometry(cfg.r,32),new T.MeshBasicMaterial({map:faceTex(kind)}));
  face.position.z=.011;g.add(face);
  const n=new T.Group();n.position.z=.016;
  n.add(box(cfg.r*.12,cfg.r*.85,.004,mats.needle,0,cfg.r*.4,0));
  n.add(cylZ(cfg.r*.14,.008,mats.black,0,0,0));
  n.rotation.z=2.35;g.add(n);
  w.userData.needle=n;
  return w;
}
const bSpeedo=()=>bGauge('speedo'),bRev=()=>bGauge('rev'),bFuelG=()=>bGauge('fuelg'),bTempG=()=>bGauge('temp');
function lampTex(emoji,col){
  const c=document.createElement('canvas');c.width=c.height=64;const g=c.getContext('2d');
  g.fillStyle=col;g.beginPath();g.arc(32,32,31,0,7);g.fill();
  g.font='34px sans-serif';g.textAlign='center';g.textBaseline='middle';g.fillText(emoji,32,35);
  return new T.CanvasTexture(c);
}
function bLamps(){
  const w=new T.Group(),g=new T.Group();g.position.set(.478,.905,0);g.rotation.y=-PI/2;w.add(g);
  const L=[['oil','🛢️','#b3201a',-.47],['bat','🔋','#b3201a',-.43],['eng','⚙️','#c78a00',-.39]];
  const lamps=[];
  L.forEach(l=>{
    const m=new T.MeshBasicMaterial({map:lampTex(l[1],l[2])});m.color.setScalar(.3);
    const d=new T.Mesh(new T.CircleGeometry(.018,16),m);d.position.set(-l[3]-.0,0,.012);
    // lokalno x = svetski +z, pa je pozicija po z: l[3]
    d.position.x=l[3];
    g.add(d);lamps.push({m,k:l[0]});
  });
  w.userData.lamps=lamps;
  return w;
}

const PED={clutch:-.62,brake:-.47,gas:-.31};
function bPedal(kind){
  const z=PED[kind],wd=kind==='gas'?.05:.11,w=new T.Group(),h=new T.Group();
  h.position.set(.74,.86,z);w.add(h);
  h.add(bar([0,0,0],[-.1,-.2,0],.011,mats.metal));
  const pad=new T.Group();pad.position.set(-.12,-.23,0);pad.rotation.z=.55;h.add(pad);
  pad.add(box(.025,.13,wd,mats.rubber,0,0,0));
  for(let k=0;k<3;k++)pad.add(box(.03,.012,wd*.9,mats.metal,0,-.04+k*.04,0));
  w.userData.hinge=h;
  return w;
}
const bGas=()=>bPedal('gas'),bClutch=()=>bPedal('clutch'),bBrake=()=>bPedal('brake');
function bGear(){
  const g=new T.Group(),st_=new T.Group();st_.position.set(.35,.74,0);g.add(st_);
  const boot=mesh(new T.ConeGeometry(.08,.1,14),mats.rubber);boot.position.set(.35,.78,0);g.add(boot);
  st_.add(bar([0,0,0],[0,.22,0],.014,mats.chrome));
  const knob=mesh(new T.SphereGeometry(.04,12,10),mats.black);knob.position.y=.25;st_.add(knob);
  g.userData.stick=st_;
  return g;
}
function bHandbrake(){
  const g=new T.Group(),piv=new T.Group();piv.position.set(-.12,.76,0);g.add(piv);
  g.add(box(.1,.04,.06,mats.dark,-.12,.745,0));
  piv.add(bar([0,0,0],[-.18,.14,0],.016,mats.dark));
  piv.add(box(.08,.035,.035,mats.black,-.2,.16,0));
  piv.add(box(.02,.02,.02,mats.red,-.22,.185,0));
  piv.rotation.z=-.2;
  g.userData.lever=piv;
  return g;
}
function radioTex(){
  const c=document.createElement('canvas');c.width=128;c.height=40;const g=c.getContext('2d');
  g.fillStyle='#0b2a12';g.fillRect(0,0,128,40);
  g.fillStyle='#6dff7a';g.font='bold 26px monospace';g.textAlign='center';g.textBaseline='middle';g.fillText('FM 98.5',64,22);
  return new T.CanvasTexture(c);
}
function bRadio(){
  const w=new T.Group(),g=new T.Group();g.position.set(.478,.99,0);g.rotation.y=-PI/2;w.add(g);
  g.add(box(.36,.1,.03,mats.black,0,0,0));
  const dm=new T.MeshBasicMaterial({map:radioTex()});dm.color.setScalar(.2);
  const d=new T.Mesh(new T.PlaneGeometry(.16,.05),dm);d.position.set(-.07,.012,.016);g.add(d);
  for(const x of [.09,.15])g.add(cylZ(.02,.02,mats.chrome,x,.012,.02));
  for(let k=0;k<5;k++)g.add(box(.025,.014,.012,mats.metal,-.15+k*.035,-.032,.017));
  w.userData.disp=dm;
  return w;
}
function bSBelt(i){
  const s=i?1:-1,g=new T.Group();
  const a=[-.33,1.38,s*.74],b=[.0,.82,s*.18];
  g.add(bar(a,b,.022,mats.dark));
  g.add(bar(b,[-.06,.8,s*.72],.02,mats.dark));
  g.add(box(.05,.06,.04,mats.red,b[0],b[1],b[2]));
  g.add(cylZ(.03,.02,mats.chrome,a[0],a[1],a[2]));
  return g;
}
function bFuelCap(){
  const g=new T.Group();
  g.add(box(.24,.22,.02,mats.body,-1.7,.96,.97));
  g.add(bar([-1.7,.96,.9],[-1.7,.96,.97],.04,mats.black));
  g.add(cylZ(.065,.03,mats.chrome,-1.7,.96,.99));
  g.add(box(.07,.02,.02,mats.dark,-1.7,.96,1.01));
  return g;
}
function bSteer(){
  const g=new T.Group();
  g.add(bar([.78,.92,-.42],[.46,1.22,-.42],.035,mats.black));
  const w=new T.Group();w.position.set(.43,1.25,-.42);
  w.quaternion.setFromUnitVectors(new T.Vector3(0,0,1),new T.Vector3(-.75,.66,0).normalize());
  w.add(mesh(new T.TorusGeometry(.2,.03,10,32),mats.black));
  w.add(cylZ(.06,.05,mats.dark,0,0,0));
  for(let k=0;k<3;k++){const a=k/3*PI*2+PI/2;const sp=box(.03,.2,.02,mats.dark,Math.cos(a)*.1,Math.sin(a)*.1,0);sp.rotation.z=a-PI/2;w.add(sp)}
  g.add(w);
  g.add(box(.06,.12,.04,mats.dark,.62,1.08,-.42));
  return g;
}
function sidePanelShape(){
  const s=new T.Shape();
  s.moveTo(-2.2,.45);s.lineTo(-2.0,.45);s.absarc(-1.5,.45,.5,PI,0,true);s.lineTo(1.0,.45);
  s.absarc(1.5,.45,.5,PI,0,true);s.lineTo(2.2,.45);s.lineTo(2.2,TOP);s.lineTo(DX1,TOP);
  s.lineTo(DX1,.65);s.lineTo(DX0,.65);s.lineTo(DX0,TOP);s.lineTo(-2.2,TOP);s.closePath();
  return s;
}
function bBody(){
  const g=new T.Group(),sh=sidePanelShape();
  for(const s of [-1,1]){
    const z0=s>0?.9:-.96;
    const p=extr(sh,.06,mats.body,z0);g.add(p);g.add(outline(p));
    g.add(box(4.0,.04,.02,mats.dark,-.1,.78,s*.97));
    g.add(box(1.8,.06,.05,mats.dark,.0,.5,s*.93)); // prag
  }
  g.add(box(.06,.7,1.82,mats.body,-2.17,.8,0));
  g.add(box(.05,.65,1.72,mats.dark,.95,.82,0));    // zid motora
  g.add(box(.95,.05,1.72,mats.dark,-1.7,1.1,0));    // polica gepeka
  return g;
}
function bDoor(i){
  const s=i?1:-1,z0=i?.9:-.96,g=new T.Group();
  const r=new T.Shape();r.moveTo(DX0,.65);r.lineTo(DX1,.65);r.lineTo(DX1,TOP);r.lineTo(DX0,TOP);r.closePath();
  const d=extr(r,.06,mats.body,z0);g.add(d);g.add(outline(d));
  const zg=s*.93;
  g.add(quad([[DX0,TOP,zg],[DX1,TOP,zg],[.3,ROOF,zg],[DX0,ROOF,zg]],mats.glass));
  g.add(bar([DX0,TOP,zg],[DX0,ROOF,zg],.03,mats.black));
  g.add(bar([DX0,ROOF,zg],[.3,ROOF,zg],.03,mats.black));
  g.add(bar([.3,ROOF,zg],[DX1,TOP,zg],.035,mats.black));
  g.add(bar([DX0,TOP,zg],[DX1,TOP,zg],.025,mats.chrome));
  g.add(box(.22,.045,.05,mats.chrome,-.55,.98,s*.99));
  g.add(box(.04,.05,.1,mats.dark,-.55,.98,s*.95));
  return g;
}
function bHood(){
  const g=new T.Group();
  const h=box(1.42,.07,1.78,mats.body,1.5,1.2,0);h.rotation.z=-.05;g.add(h);
  for(const z of [-.45,.45]){const r=box(1.1,.02,.06,mats.dark,1.45,1.24,z);r.rotation.z=-.05;g.add(r)}
  g.add(box(.05,.06,.3,mats.dark,2.17,1.15,0));
  return g;
}
function bTrunk(){
  const g=new T.Group();
  g.add(box(.95,.07,1.78,mats.body,-1.73,1.2,0));
  g.add(box(.03,.05,.3,mats.chrome,-2.2,1.17,0));
  return g;
}
function bWind(){
  const g=new T.Group(),z=.82;
  g.add(quad([[DX1,WB,-z],[DX1,WB,z],[.3,ROOF,z],[.3,ROOF,-z]],mats.glass));
  for(const s of [-1,1])g.add(bar([DX1,WB,s*z],[.3,ROOF,s*z],.045,mats.body));
  g.add(bar([DX1,WB,-z],[DX1,WB,z],.03,mats.black));
  g.add(bar([.3,ROOF,-z],[.3,ROOF,z],.03,mats.black));
  g.add(box(.05,.1,.28,mats.dark,.42,1.64,0)); // unutrasnji retrovizor
  return g;
}
function bRoof(){
  const g=new T.Group();
  g.add(box(1.15,.06,1.7,mats.body,(DX0+.3)/2,ROOF+.0,0));
  for(const s of [-1,1]){
    g.add(bar([DX0,ROOF,s*.82],[-1.25,WB,s*.82],.05,mats.body));
  }
  g.add(quad([[DX0,ROOF,-.8],[DX0,ROOF,.8],[-1.25,WB,.8],[-1.25,WB,-.8]],mats.glass));
  g.add(box(.2,.02,.2,mats.white,-.3,ROOF-.04,0));
  return g;
}
const WIP_Z=[-.5,.15];
function bWiper(i){
  const g=new T.Group();
  const U=new T.Vector3(-(DX1-.3),ROOF-WB,0).normalize();
  const N=new T.Vector3(ROOF-WB,DX1-.3,0).normalize();
  const X=new T.Vector3().crossVectors(U,N);
  const piv=new T.Group();
  piv.position.set(DX1,WB,WIP_Z[i]).addScaledVector(N,.03);
  piv.setRotationFromMatrix(new T.Matrix4().makeBasis(X,U,N));
  const arm=new T.Group();piv.add(arm);
  arm.add(box(.03,.62,.012,mats.black,0,.31,0));
  arm.add(box(.02,.5,.03,mats.rubber,0,.34,0));
  arm.add(cylZ(.035,.03,mats.dark,0,0,0));
  arm.rotation.z=PI/2;
  g.add(piv);g.userData.arm=arm;
  return g;
}
function bMirror(i){
  const s=i?1:-1,g=new T.Group();
  g.add(bar([.84,1.17,s*.92],[.88,1.27,s*1.08],.02,mats.dark));
  const h=box(.1,.15,.24,mats.body,.88,1.3,s*1.15);g.add(h);
  const m=box(.012,.12,.2,mats.mirror,.826,1.3,s*1.15);g.add(m);
  return g;
}
function bHead(i){
  const s=i?1:-1,g=new T.Group();
  g.add(cylX(.18,.1,mats.chrome,2.17,.95,s*.7));
  const lens=mesh(new T.SphereGeometry(.15,18,12),mats.head);lens.scale.set(.5,1,1);lens.position.set(2.2,.95,s*.7);g.add(lens);
  g.add(box(.04,.04,.24,mats.yellow,2.2,.76,s*.7));
  g.userData.spot=new T.Vector3(2.25,.95,s*.7);
  return g;
}
function bTail(i){
  const s=i?1:-1,g=new T.Group();
  g.add(box(.06,.17,.36,mats.tail,-2.23,.95,s*.64));
  g.add(box(.05,.05,.14,mats.white,-2.235,.84,s*.64));
  return g;
}
function bGrille(){
  const g=new T.Group();
  g.add(box(.06,.4,1.0,mats.black,2.17,.84,0));
  for(let k=0;k<5;k++)g.add(box(.075,.025,.98,mats.chrome,2.18,.7+k*.07,0));
  g.add(cylX(.07,.03,mats.chrome,2.21,.9,0)); // amblem (originalan krug)
  return g;
}
function bBumper(i){
  const f=i===0,x=f?2.3:-2.3,g=new T.Group();
  g.add(box(.2,.24,1.92,mats.chrome,x,.56,0));
  g.add(box(.22,.06,1.6,mats.dark,x,.46,0));
  for(const s of [-1,1]){const c=mesh(new T.SphereGeometry(.12,12,10),mats.chrome);c.scale.set(1,1.9,1);c.position.set(x,.56,s*.96);g.add(c)}
  if(f)g.add(box(.04,.1,.4,mats.yellow,x+.1,.56,0)); else g.add(box(.04,.1,.4,mats.white,x-.1,.56,0));
  return g;
}

/* ================= SPISAK DELOVA ================= */
const V=(x,y,z)=>new T.Vector3(x,y,z);
const PHASES=['Točkovi','Motor','Pogon i gorivo','Tabla i sedišta','Komande i radio','Karoserija','Stakla','Svetla','Pokreni!'];
const FINAL=PHASES.length-1;
const PHASE_DONE=[
 '🛞 Točkovi su na mestu!',
 '⚙️ <b>Motor je sklopljen!</b> Klipovi idu gore-dole, svećice pale gorivo, alternator pravi struju.',
 '⛽ Gorivo ide iz rezervoara do motora, a dim izlazi kroz auspuh. Akumulator daje struju.',
 '📟 Sad znaš sve sa table: brzinomer, obrtomer, merač goriva, temperatura i lampice.',
 '🦶 Znaš komande: gas, kvačilo i kočnica, pa menjač, ručna kočnica i radio.',
 '🚗 Karoserija je gotova. Zapamti: gorivo se sipa na poklopcu sa strane.',
 '🪟 Stakla i brisači su na mestu.',
 '💡 Sva svetla svetle!'
];
const PARTS=[
 {id:'wheel',name:'Točak',icon:'🛞',n:4,phase:0,build:bWheel,fly:i=>V(0,0,WP[i][2]>0?3.2:-3.2),
  info:'<b>Točak</b> — na njima auto vozi. Spolja je <b>guma</b>, a unutra metalna <b>felna</b>. Četiri točka drže ceo auto.'},
 {id:'block',name:'Blok motora',icon:'⚙️',n:1,phase:1,build:bBlock,fly:()=>V(0,3,0),
  info:'<b>Blok motora</b> je glavno telo motora. U njemu su 4 <b>cilindra</b>, a u svakom se gore-dole kreće <b>klip</b>. Klipovi okreću radilicu, a ona na kraju okreće točkove.'},
 {id:'pan',name:'Karter',icon:'🛢️',n:1,phase:1,after:'block',build:bPan,fly:()=>V(0,-1.5,0),
  info:'<b>Uljni karter</b> je „posuda“ ispod motora. U njemu je <b>ulje</b> koje podmazuje delove da se ne troše i ne greju.'},
 {id:'ehead',name:'Glava motora',icon:'🔩',n:1,phase:1,after:'block',build:bEHead,fly:()=>V(0,3,0),
  info:'<b>Glava motora</b> zatvara cilindre odozgo. U njoj su <b>ventili</b>: jedni puštaju vazduh i gorivo unutra, drugi izbacuju dim.'},
 {id:'plug',name:'Svećica',icon:'⚡',n:4,phase:1,after:'ehead',build:bPlug,fly:()=>V(0,2.5,0),
  info:'<b>Svećica</b> pravi malu <b>varnicu</b> u cilindru. Varnica pali smešu goriva i vazduha, a eksplozija gura klip. <b>Bez svećica se motor ne pali!</b> Ima ih 4, po jedna za svaki cilindar.'},
 {id:'cover',name:'Poklopac ventila',icon:'🟥',n:1,phase:1,after:'plug',build:bCover,fly:()=>V(0,3,0),
  info:'<b>Poklopac ventila</b> zatvara vrh motora i čuva ulje unutra. Na njemu je <b>žuti čep</b> — tu se dolijeva ulje.'},
 {id:'intake',name:'Usisna grana',icon:'🌬️',n:1,phase:1,after:'ehead',build:bIntake,fly:()=>V(0,0,-3),
  info:'<b>Usisna grana</b> dovodi vazduh u cilindre. Motor „diše“ kao mi: udahne vazduh, pomeša ga sa gorivom i sagori.'},
 {id:'exman',name:'Izduvna grana',icon:'♨️',n:1,phase:1,after:'ehead',build:bExMan,fly:()=>V(0,0,3),
  info:'<b>Izduvna grana</b> skuplja vreo dim iz sva 4 cilindra i šalje ga ka auspuhu.'},
 {id:'belt',name:'Kaiš i remenice',icon:'➰',n:1,phase:1,after:'block',build:bBelt,fly:()=>V(3,0,0),
  info:'<b>Kaiš i remenice</b>: radilica preko kaiša okreće alternator i pumpu za vodu, pa sve u motoru radi složno.'},
 {id:'alt',name:'Alternator',icon:'🔌',n:1,phase:1,after:'belt',build:bAlt,fly:()=>V(0,3,0),
  info:'<b>Alternator</b> pravi struju dok motor radi. Puni akumulator i napaja svetla.'},
 {id:'radiator',name:'Hladnjak',icon:'🌀',n:1,phase:2,build:bRadiator,fly:()=>V(2.5,0,0),
  info:'<b>Hladnjak</b> hladi motor. Ventilator duva vazduh da se motor ne pregreje.'},
 {id:'battery',name:'Akumulator',icon:'🔋',n:1,phase:2,build:bBattery,fly:()=>V(0,3,0),
  info:'<b>Akumulator</b> daje struju. Bez njega se motor ne pali i ne rade svetla.'},
 {id:'tank',name:'Rezervoar',icon:'⛽',n:1,phase:2,build:bTank,fly:()=>V(0,3.5,0),
  info:'<b>Rezervoar</b> čuva gorivo (benzin ili dizel) koje motor „pije“. Gorivo se sipa kroz crevo sa strane auta.'},
 {id:'exhaust',name:'Auspuh',icon:'💨',n:1,phase:2,build:bExhaust,fly:()=>V(-3,1,0),
  info:'<b>Auspuh</b> izbacuje dim iz motora napolje i smanjuje buku.'},
 {id:'seat',name:'Sedište',icon:'💺',n:2,phase:3,build:bSeat,fly:()=>V(0,3,0),
  info:'<b>Sedišta</b> su da udobno sedimo. Vozač sedi levo.'},
 {id:'dash',name:'Tabla',icon:'📟',n:1,phase:3,build:bDash,fly:()=>V(0,3,0),
  info:'<b>Instrument tabla</b>: tu su sve mere i lampice koje pokazuju šta se dešava sa autom. Sad ćemo je opremiti.'},
 {id:'speedo',name:'Brzinomer',icon:'🏎️',n:1,phase:3,after:'dash',build:bSpeedo,fly:()=>V(-2,0,0),
  info:'<b>Brzinomer</b> pokazuje koliko brzo vozimo, u <b>km/h</b> (kilometara na sat).'},
 {id:'rev',name:'Obrtomer',icon:'🔴',n:1,phase:3,after:'dash',build:bRev,fly:()=>V(-2,0,0),
  info:'<b>Obrtomer</b> pokazuje koliko se brzo okreće motor. Ako igla ode u <b>crveno</b>, motor se prejako okreće.'},
 {id:'fuelg',name:'Merač goriva',icon:'⛽',n:1,phase:3,after:'dash',build:bFuelG,fly:()=>V(-2,0,0),
  info:'<b>Merač goriva</b> pokazuje koliko goriva ima u rezervoaru. <b>F</b> = pun, <b>E</b> = prazan — tada treba sipati gorivo.'},
 {id:'temp',name:'Temperatura',icon:'🌡️',n:1,phase:3,after:'dash',build:bTempG,fly:()=>V(-2,0,0),
  info:'<b>Temperatura motora</b>: <b>C</b> = hladan, <b>H</b> = vruć. Ako igla ode na H, motor se pregreva i treba stati!'},
 {id:'lamps',name:'Lampice',icon:'🚨',n:1,phase:3,after:'dash',build:bLamps,fly:()=>V(-2,0,0),
  info:'<b>Kontrolne lampice</b>: 🛢️ crvena = fali ulja, 🔋 crvena = akumulator se ne puni, ⚙️ žuta = proveri motor. Kad upališ motor, ugase se.'},
 {id:'steer',name:'Volan',icon:'☸️',n:1,phase:3,after:'dash',build:bSteer,fly:()=>V(0,3,0),
  info:'<b>Volan</b> okrećemo levo i desno da skrenemo auto.'},
 {id:'sbelt',name:'Pojas',icon:'🪢',n:2,phase:3,after:'seat',build:bSBelt,fly:()=>V(0,3,0),
  info:'<b>Sigurnosni pojas</b> nas drži da se ne povredimo kad auto naglo stane. <b>Uvek ga vežemo!</b>'},
 {id:'gas',name:'Gas',icon:'🦶',n:1,phase:4,build:bGas,fly:()=>V(-2,0,0),
  info:'<b>Gas</b> (desna noga): što jače pritisneš, motor jače radi i auto brže ide.'},
 {id:'clutch',name:'Kvačilo',icon:'🦵',n:1,phase:4,build:bClutch,fly:()=>V(-2,0,0),
  info:'<b>Kvačilo</b> (leva noga): na trenutak odvaja motor od točkova da bismo mogli da promenimo brzinu u menjaču.'},
 {id:'brake',name:'Kočnica',icon:'🛑',n:1,phase:4,build:bBrake,fly:()=>V(-2,0,0),
  info:'<b>Kočnica</b> (srednji pedal): pritisneš da auto uspori i stane. Kad kočiš, pozadi se jače upale crvena svetla.'},
 {id:'gear',name:'Menjač',icon:'🕹️',n:1,phase:4,after:'dash',build:bGear,fly:()=>V(0,3,0),
  info:'<b>Menjač</b>: biramo „brzinu“. Niža brzina je za polazak i uzbrdicu, viša za brzu vožnju. Pre promene pritisnemo kvačilo.'},
 {id:'handbrake',name:'Ručna kočnica',icon:'✋',n:1,phase:4,after:'dash',build:bHandbrake,fly:()=>V(0,3,0),
  info:'<b>Ručna kočnica</b>: kad parkiramo, podignemo je da auto ne bi sam otkotrljao. Pre vožnje je spustimo.'},
 {id:'radio',name:'Radio',icon:'📻',n:1,phase:4,after:'dash',build:bRadio,fly:()=>V(-2,0,0),
  info:'<b>Radio</b> svira muziku dok vozimo. Kad upališ motor, pritisni 📻 Radio.'},
 {id:'body',name:'Karoserija',icon:'🚗',n:1,phase:5,build:bBody,fly:()=>V(0,4,0),
  info:'<b>Karoserija</b> je „kostim“ auta. Štiti nas od kiše i vetra, a ima i otvore za točkove.'},
 {id:'door',name:'Vrata',icon:'🚪',n:2,phase:5,after:'body',build:bDoor,fly:i=>V(0,0,i?3:-3),
  info:'<b>Vrata</b> otvaramo da uđemo u auto. Imaju kvaku i prozor.'},
 {id:'fuelcap',name:'Poklopac goriva',icon:'⛽',n:1,phase:5,after:'body',build:bFuelCap,fly:()=>V(0,0,2.5),
  info:'<b>Poklopac za gorivo</b>: <b>ovde se sipa gorivo</b> (benzin ili dizel). Kroz crevo ide do rezervoara. Pazi: pogrešno gorivo kvari motor!'},
 {id:'hood',name:'Hauba',icon:'🟥',n:1,phase:5,after:'body',build:bHood,fly:()=>V(0,3,0),
  info:'<b>Hauba</b> pokriva motor. Kad treba, podignemo je da proverimo ulje.'},
 {id:'trunk',name:'Gepek',icon:'🧳',n:1,phase:5,after:'body',build:bTrunk,fly:()=>V(0,3,0),
  info:'<b>Gepek</b> je prostor za torbe i kofere.'},
 {id:'wind',name:'Vetrobran',icon:'🪟',n:1,phase:6,build:bWind,fly:()=>V(2,2.5,0),
  info:'<b>Vetrobran</b> je prednje staklo. Kroz njega vozač gleda put.'},
 {id:'roof',name:'Krov',icon:'🏠',n:1,phase:6,build:bRoof,fly:()=>V(0,3.5,0),
  info:'<b>Krov</b> pokriva putnike. Sa zadnjim staklom zatvara kabinu.'},
 {id:'wiper',name:'Brisač',icon:'🧹',n:2,phase:6,after:'wind',build:bWiper,fly:()=>V(0,2.5,0),
  info:'<b>Brisači</b> brišu kišu sa stakla da vozač dobro vidi.'},
 {id:'mirror',name:'Retrovizor',icon:'🪞',n:2,phase:6,build:bMirror,fly:i=>V(0,0,i?2.5:-2.5),
  info:'<b>Retrovizori</b> pokazuju šta je iza auta, bez okretanja glave.'},
 {id:'head',name:'Far',icon:'💡',n:2,phase:7,build:bHead,fly:()=>V(4,0,0),
  info:'<b>Farovi</b> svetle napred, naročito noću.'},
 {id:'tail',name:'Zadnje svetlo',icon:'🔴',n:2,phase:7,build:bTail,fly:()=>V(-4,0,0),
  info:'<b>Zadnja svetla</b> su crvena, da nas vide vozači iza nas. Beli deo pali se kad vozimo unazad.'},
 {id:'grille',name:'Maska',icon:'▦',n:1,phase:7,build:bGrille,fly:()=>V(4,0,0),
  info:'<b>Maska</b> propušta vazduh do hladnjaka.'},
 {id:'bumper',name:'Branik',icon:'🛡️',n:2,phase:7,build:bBumper,fly:i=>V(i?-4:4,0,0),
  info:'<b>Branici</b> štite auto kad se lagano udari. Jedan je napred, jedan pozadi.'}
];
const PBY={};PARTS.forEach(p=>PBY[p.id]=p);

/* ================= SASIJA (uvek tu) ================= */
const carRoot=new T.Group();scene.add(carRoot);
(function(){
  const g=new T.Group();
  for(const s of [-1,1])g.add(box(4.1,.1,.12,mats.dark,0,.5,s*.58));
  g.add(box(3.6,.04,1.25,mats.black,0,.56,0));
  for(const x of [-1.8,-.6,.6,1.8])g.add(box(.1,.1,1.25,mats.dark,x,.5,0));
  for(const x of [-1.5,1.5])g.add(cylZ(.045,2.0,mats.metal,x,.45,0));
  g.add(cylX(.05,1.2,mats.metal,0,.4,0)); // kardan
  g.add(box(.4,.2,.3,mats.dark,-1.5,.42,0)); // diferencijal
  g.traverse(o=>{o.castShadow=true});
  carRoot.add(g);
})();

/* ================= STANJE ================= */
const placed={};PARTS.forEach(p=>placed[p.id]=new Array(p.n).fill(false));
const objs={};PARTS.forEach(p=>objs[p.id]=new Array(p.n).fill(null));
const ghosts={};   // id_i -> root
let phase=0,sel=null,anims=[],started=false;

function ghostify(g,mat){
  const c=g.clone(true);
  c.traverse(o=>{if(o.isMesh){o.material=mat;o.castShadow=false;o.receiveShadow=false}else if(o.isLineSegments){o.visible=false}});
  return c;
}
function phaseParts(){return PARTS.filter(p=>p.phase===phase)}
function remaining(p){return placed[p.id].filter(x=>!x).length}
function avail(p){return !p.after||remaining(PBY[p.after])===0}

function buildGhosts(){
  Object.values(ghosts).forEach(g=>carRoot.remove(g));
  for(const k in ghosts)delete ghosts[k];
  phaseParts().forEach(p=>{
    if(!avail(p))return;
    for(let i=0;i<p.n;i++){
      if(placed[p.id][i])continue;
      const g=ghostify(p.build(i),ghostDim);
      g.userData.slot={part:p,i};
      const bb=new T.Box3().setFromObject(g),sz=bb.getSize(new T.Vector3()),c=bb.getCenter(new T.Vector3());
      g.userData.top=bb.max.y;g.userData.c=c;
      const mx=Math.max(sz.x,sz.y,sz.z);
      if(mx<1.0){
        const px=new T.Mesh(new T.SphereGeometry(Math.max(.24,mx*.55),14,10),ghostNone);
        px.position.copy(c).sub(g.position);px.userData.proxy=true;g.add(px);
      }
      ghosts[p.id+'_'+i]=g;carRoot.add(g);
    }
  });
  refreshGhostMats();
}
function refreshGhostMats(){
  arrows.forEach(a=>{carRoot.remove(a);a.geometry.dispose()});arrows=[];
  for(const k in ghosts){
    const g=ghosts[k],isSel=sel&&g.userData.slot.part===sel;
    g.traverse(o=>{if(o.isMesh)o.material=o.userData.proxy?(isSel?ghostGlow:ghostNone):(isSel?ghostSel:ghostDim)});
    if(isSel){
      const a=new T.Mesh(new T.ConeGeometry(.15,.32,14),new T.MeshBasicMaterial({color:0xffd24a}));
      a.rotation.x=PI;a.userData.by=g.userData.top+.4;a.position.set(g.userData.c.x,a.userData.by,g.userData.c.z);
      carRoot.add(a);arrows.push(a);
    }
  }
}

/* ================= UI ================= */
const shelf=$('#shelf'),bubble=$('#bubble'),msgEl=$('#msg'),stepsEl=$('#steps');
let msgT=0;
function say(t,ms){
  msgEl.textContent=t;msgEl.classList.add('show');
  clearTimeout(msgT);msgT=setTimeout(()=>msgEl.classList.remove('show'),ms||2200);
}
function setBubble(t){bubble.innerHTML=t}
function renderSteps(){
  stepsEl.innerHTML=PHASES.map((n,i)=>`<span class="${i<phase?'done':i===phase?'cur':''}">${i<phase?'✓ ':''}${i+1}. ${n}</span>`).join('');
  const cur=stepsEl.querySelector('.cur');if(cur&&cur.scrollIntoView)try{cur.scrollIntoView({inline:'center',block:'nearest'})}catch(e){}
}
function renderShelf(){
  if(phase>=FINAL){renderControls();return}
  shelf.innerHTML='';
  phaseParts().forEach(p=>{
    const r=remaining(p);if(!r||!avail(p))return;
    const b=document.createElement('button');
    b.className='card'+(sel===p?' sel':'');b.dataset.id=p.id;
    b.innerHTML=`<span class="ic">${p.icon}</span><b>${p.name}</b>${p.n>1?`<span class="cnt">×${r}</span>`:''}`;
    attachDrag(b,p);
    shelf.appendChild(b);
  });
}
function select(p){
  sel=p;snd.pick();
  setBubble(p.info+'<br><small>Prevuci deo na svetleće providno mesto na autu (ili dodirni mesto).</small>');
  refreshGhostMats();renderShelf();focusPart(p);
}

/* ===== prevlacenje kartice ===== */
function attachDrag(el,p){
  el.addEventListener('pointerdown',e=>{
    e.preventDefault();
    const sx=e.clientX,sy=e.clientY;let drag=null;
    const move=ev=>{
      if(!drag&&Math.hypot(ev.clientX-sx,ev.clientY-sy)>8){
        drag=document.createElement('div');drag.className='dragger';drag.textContent=p.icon;document.body.appendChild(drag);
        if(sel!==p)select(p);
      }
      if(drag){drag.style.left=ev.clientX+'px';drag.style.top=ev.clientY+'px'}
    };
    const up=ev=>{
      window.removeEventListener('pointermove',move);window.removeEventListener('pointerup',up);window.removeEventListener('pointercancel',up);
      if(drag){
        drag.remove();
        const r=canvas.getBoundingClientRect();
        if(ev.clientX>=r.left&&ev.clientX<=r.right&&ev.clientY>=r.top&&ev.clientY<=r.bottom)tryAt(p,ev.clientX,ev.clientY);
      }else select(p);
    };
    window.addEventListener('pointermove',move);window.addEventListener('pointerup',up);window.addEventListener('pointercancel',up);
  });
}

/* ===== pogadjanje providnih mesta ===== */
const ray=new T.Raycaster(),ndc=new T.Vector2();
function hitGhost(cx,cy){
  const r=canvas.getBoundingClientRect();
  ndc.set(((cx-r.left)/r.width)*2-1,-((cy-r.top)/r.height)*2+1);
  ray.setFromCamera(ndc,camera);
  const hits=ray.intersectObjects(Object.values(ghosts),true);
  for(const h of hits){let o=h.object;while(o&&!o.userData.slot)o=o.parent;if(o)return o.userData.slot}
  return null;
}
function tryAt(p,cx,cy){
  const h=hitGhost(cx,cy);
  if(h&&h.part===p&&!placed[p.id][h.i]){place(p,h.i);return}
  snd.no();
  if(h&&h.part!==p)say(`Ovde ide: ${h.part.name}. 🙂`);
  else say('Spusti deo na providno svetleće mesto. 🙂');
}
function onTap(cx,cy){
  if(phase>=FINAL){inspect(cx,cy);return}
  const h=hitGhost(cx,cy);
  if(!h){return}
  if(sel&&h.part===sel){place(sel,h.i)}
  else if(!sel){select(h.part)}
  else{snd.no();say(`Ovde ide: ${h.part.name}. Izaberi taj deo. 🙂`)}
}

/* ===== postavljanje ===== */
function place(p,i){
  const g=p.build(i);carRoot.add(g);
  const base=g.position.clone(),off=p.fly(i);
  g.position.copy(base).add(off);
  anims.push({g,base,off,t:0,part:p});
  objs[p.id][i]=g;placed[p.id][i]=true;
  g.userData.partRef=p;
  snd.put();
  if(!remaining(p)){sel=null;setBubble(`✔ <b>${p.name}</b> je na mestu!`)}
  say(['Bravo!','Super!','Tako je!','Odlično!'][(Math.random()*4)|0]+' 🔧');
  buildGhosts();renderShelf();
  if(phaseParts().every(q=>!remaining(q))){
    setTimeout(nextPhase,900);
  }else if(!sel){
    const nxt=phaseParts().find(q=>remaining(q)&&avail(q));if(nxt)setTimeout(()=>{if(!sel)select(nxt)},500);
  }
}
function nextPhase(){
  const done=PHASE_DONE[phase]||'';
  phase++;snd.phase();
  renderSteps();
  if(phase>=FINAL){
    sel=null;buildGhosts();
    setBubble('🎉 <b>Auto je sastavljen!</b> Sada ga pokreni. 🔑<br><small>Dodirni bilo koji deo auta da vidiš šta je.</small>');
    camGoal.az=.75;camGoal.el=.28;camGoal.dist=9;camGoal.tx=0;camGoal.ty=.8;camGoal.tz=0;
    renderControls();
  }else{
    sel=null;buildGhosts();
    setBubble(`${done}<br><b>Faza ${phase+1}: ${PHASES[phase]}</b> — izaberi deo sa police, pa ga stavi na providno mesto.`);
    renderShelf();
    const f=phaseParts().find(q=>avail(q));if(f)setTimeout(()=>{if(!sel)select(f)},600);
  }
}

/* ================= KAMERA ================= */
const cam={az:.8,el:.32,dist:10,tx:0,ty:.8,tz:0};
const camGoal=Object.assign({},cam);
function normAng(a){while(a>PI)a-=2*PI;while(a<-PI)a+=2*PI;return a}
function focusPart(p){
  let sx=0,sy=0,sz=0,n=0;
  for(let i=0;i<p.n;i++){if(placed[p.id][i])continue;const g=ghosts[p.id+'_'+i];if(!g)continue;
    const b=new T.Box3().setFromObject(g),c=b.getCenter(new T.Vector3());sx+=c.x;sy+=c.y;sz+=c.z;n++}
  if(!n)return;
  sx/=n;sy/=n;sz/=n;
  const dz=Math.abs(sz)>.3?Math.sign(sz):0.25,dx=Math.abs(sz)>.3?.5*Math.sign(sx||1):Math.sign(sx||1);
  let az=Math.atan2(dz,dx);
  if(n>1&&Math.abs(sz)<.3)az=.75;
  camGoal.az=cam.az+normAng(az-cam.az);
  camGoal.tx=sx*.7;camGoal.ty=Math.max(.6,sy*.8);camGoal.tz=sz*.5;
  const BIG=['body','roof','hood','trunk','door'],NEAR=['gas','clutch','brake','gear','handbrake','radio','sbelt','block','pan','ehead','plug','cover','intake','exman','belt','alt','fuelcap','dash','speedo','rev','fuelg','temp','lamps','steer'];
  camGoal.dist=BIG.includes(p.id)?9:NEAR.includes(p.id)?(n>1?6:4.8):(n>1?8:6.2);
  camGoal.el=sy>1.2?.55:.3;
  if(['dash','speedo','rev','fuelg','temp','lamps','steer','gas','clutch','brake','gear','handbrake','radio','sbelt'].includes(p.id)){
    const low=['gas','clutch','brake','gear','handbrake'].includes(p.id);
    camGoal.az=cam.az+normAng(PI+.3-cam.az);camGoal.dist=low?3.2:3.8;camGoal.el=low?.5:.35;camGoal.tx=.5;camGoal.ty=low?.75:1.05;camGoal.tz=(p.id==='gear'||p.id==='handbrake'||p.id==='radio')?0:-.4;
  }
  if(['block','ehead','plug','cover','pan','intake','exman','belt','alt'].includes(p.id)){camGoal.ty=.9;camGoal.tx=1.5;camGoal.tz=0;camGoal.el=.6;}
}
function updateCam(dt){
  const k=1-Math.pow(.0008,dt);
  for(const f of ['az','el','dist','tx','ty','tz'])cam[f]+=(camGoal[f]-cam[f])*k;
  const ce=Math.cos(cam.el);
  camera.position.set(cam.tx+cam.dist*ce*Math.cos(cam.az),cam.ty+cam.dist*Math.sin(cam.el),cam.tz+cam.dist*ce*Math.sin(cam.az));
  camera.lookAt(cam.tx,cam.ty,cam.tz);
}
/* dodir / prevlacenje po sceni */
const pts=new Map();let pinch0=0,downT=0,moved=0;
canvas.addEventListener('pointerdown',e=>{
  canvas.setPointerCapture(e.pointerId);pts.set(e.pointerId,{x:e.clientX,y:e.clientY});
  if(pts.size===1){moved=0;downT=performance.now()}
  if(pts.size===2){const a=[...pts.values()];pinch0=Math.hypot(a[0].x-a[1].x,a[0].y-a[1].y)}
});
canvas.addEventListener('pointermove',e=>{
  const p=pts.get(e.pointerId);if(!p)return;
  const dx=e.clientX-p.x,dy=e.clientY-p.y;moved+=Math.abs(dx)+Math.abs(dy);
  p.x=e.clientX;p.y=e.clientY;
  if(pts.size===1){
    camGoal.az-=dx*.008;cam.az-=dx*.008;
    camGoal.el=Math.max(.04,Math.min(1.4,camGoal.el+dy*.006));cam.el=camGoal.el;
  }else if(pts.size===2){
    const a=[...pts.values()],d=Math.hypot(a[0].x-a[1].x,a[0].y-a[1].y);
    if(pinch0){camGoal.dist=Math.max(4,Math.min(18,camGoal.dist*pinch0/d))}
    pinch0=d;
  }
});
function endPtr(e){
  const had=pts.has(e.pointerId);pts.delete(e.pointerId);
  if(had&&e.type==='pointerup'&&pts.size===0&&moved<8&&performance.now()-downT<600)onTap(e.clientX,e.clientY);
}
canvas.addEventListener('pointerup',endPtr);canvas.addEventListener('pointercancel',endPtr);
canvas.addEventListener('wheel',e=>{e.preventDefault();camGoal.dist=Math.max(4,Math.min(18,camGoal.dist*Math.exp(e.deltaY*.0012)))},{passive:false});

/* ================= BOJA ================= */
const COLORS=['#d8322f','#2b6fe0','#f2b705','#2fa862','#8e44ad','#ff7aa8','#f4f4f4'];
(function(){
  const box=$('#colors');
  COLORS.forEach((c,i)=>{
    const b=document.createElement('button');b.style.background=c;b.title='Boja auta';
    if(!i)b.classList.add('sel');
    b.onclick=()=>{mats.body.color.set(c);[...box.children].forEach(x=>x.classList.remove('sel'));b.classList.add('sel');snd.tap()};
    box.appendChild(b);
  });
})();

/* ================= POKRETANJE ================= */
const st={on:false,lights:false,wipers:false,drive:false,rpm:0,speed:0,night:0,wt:0,xray:false,temp:.08,startT:-9,ang:0,radio:false};
let spots=[],cones=[],smoke=[];
const smokeTex=(function(){
  const c=document.createElement('canvas');c.width=c.height=64;const g=c.getContext('2d');
  const r=g.createRadialGradient(32,32,2,32,32,30);r.addColorStop(0,'rgba(200,200,200,.9)');r.addColorStop(1,'rgba(200,200,200,0)');
  g.fillStyle=r;g.fillRect(0,0,64,64);return new T.CanvasTexture(c);
})();
function setupLights(){
  for(const s of [-1,1]){
    const sp=new T.SpotLight(0xfff2c0,0,24,.5,.5,1);sp.position.set(2.3,.95,s*.7);
    sp.target.position.set(10,.2,s*.7);carRoot.add(sp);carRoot.add(sp.target);spots.push(sp);
    const cone=new T.Mesh(new T.ConeGeometry(.9,4.5,24,1,true),new T.MeshBasicMaterial({color:0xfff2c0,transparent:true,opacity:0,blending:T.AdditiveBlending,depthWrite:false,side:T.DoubleSide}));
    cone.rotation.z=PI/2;cone.position.set(2.3+2.25,.95,s*.7);carRoot.add(cone);cones.push(cone);
  }
}
function renderControls(){
  shelf.innerHTML='';
  const w=document.createElement('div');w.className='ctl';
  const mk=(id,t,fn)=>{const b=document.createElement('button');b.className='btn'+(id==='key'?' big':'');b.id='c-'+id;b.innerHTML=t;b.onclick=fn;w.appendChild(b);return b};
  if(!st.on){
    mk('key','🔑 Upali motor',startEngine);
    mk('xray','🔍 Motor iznutra',()=>{setXray(!st.xray);snd.click();syncBtns()});
  }else{
    mk('eng','⏻ Ugasi motor',stopEngine);
    mk('xray','🔍 Motor iznutra',()=>{setXray(!st.xray);snd.click();syncBtns()});
    mk('lights','💡 Svetla',()=>{st.lights=!st.lights;snd.click();syncBtns()});
    mk('wipers','🌧️ Brisači',()=>{st.wipers=!st.wipers;snd.click();syncBtns()});
    mk('horn','📯 Truba',()=>snd.horn());
    mk('radio','📻 Radio',()=>{st.radio=!st.radio;st.radio?radioStart():radioStop();snd.click();syncBtns()});
    mk('drive','🚗 Vozi',()=>{st.drive=!st.drive;snd.click();syncBtns()});
  }
  shelf.appendChild(w);syncBtns();
}
function syncBtns(){
  const set=(id,on)=>{const b=$('#c-'+id);if(b)b.classList.toggle('on',!!on)};
  set('lights',st.lights);set('wipers',st.wipers);set('drive',st.drive);set('xray',st.xray);set('radio',st.radio);
}
function setXray(on){
  st.xray=on;
  const h=objs.hood[0];if(h)h.visible=!on;
  ['ehead','cover'].forEach(id=>{const o=objs[id][0];if(o)o.visible=!on});
  const m=mats.blockMat;m.transparent=on;m.opacity=on?.28:1;m.depthWrite=!on;m.needsUpdate=true;
  if(on){
    setBubble('🔍 <b>Motor iznutra</b>: <b>klipovi</b> idu gore-dole u cilindrima. Kad <b>svećica</b> pošalje varnicu, u cilindru zasvetli plamen i gurne klip.'+(st.on?'':' <br><small>Upali motor da vidiš kako radi.</small>')+'<br><small>Dodirni deo da vidiš šta je.</small>');
    camGoal.az=.9;camGoal.el=.75;camGoal.dist=4.4;camGoal.tx=1.5;camGoal.ty=.85;camGoal.tz=0;
  }else{
    setBubble('Hauba je opet na motoru. Dodirni bilo koji deo auta da vidiš šta je.');
    camGoal.az=.9;camGoal.el=.25;camGoal.dist=8.5;camGoal.tx=.3;camGoal.ty=.8;camGoal.tz=0;
  }
}
/* dodir na postavljen deo: objasni sta je */
function inspect(cx,cy){
  const r=canvas.getBoundingClientRect();
  ndc.set(((cx-r.left)/r.width)*2-1,-((cy-r.top)/r.height)*2+1);
  ray.setFromCamera(ndc,camera);
  const list=[];PARTS.forEach(p=>objs[p.id].forEach(g=>{if(g&&g.visible)list.push(g)}));
  const hits=ray.intersectObjects(list,true);
  for(const h of hits){
    let o=h.object;while(o&&!o.userData.partRef)o=o.parent;
    if(!o)continue;
    const p=o.userData.partRef;
    setBubble(p.info);snd.pick();
    arrows.forEach(a=>{carRoot.remove(a);a.geometry.dispose()});arrows=[];
    const bb=new T.Box3().setFromObject(o),c=bb.getCenter(new T.Vector3());
    const a=new T.Mesh(new T.ConeGeometry(.12,.28,14),new T.MeshBasicMaterial({color:0xffd24a,depthTest:false}));
    a.renderOrder=10;a.rotation.x=PI;a.userData.by=bb.max.y+.3;a.position.set(c.x,a.userData.by,c.z);
    carRoot.add(a);arrows.push(a);
    return;
  }
}
let radioT=null,radioI=0;
function radioStart(){
  if(radioT)return;
  const sc5=[523,587,659,784,880,1047];
  radioT=setInterval(()=>{
    if(!st.on||muted)return;
    const f=sc5[(Math.random()*sc5.length)|0]*(radioI%8===0?.5:1);
    tone(f,.3,0,'triangle',.045);
    if(radioI%4===0)tone(sc5[0]/2,.5,0,'sine',.045);
    radioI++;
  },300);
}
function radioStop(){clearInterval(radioT);radioT=null}
function startEngine(){
  st.on=true;st.startT=time;snd.click();engineStart();
  setBubble('🔑 <b>Brrrm!</b> Motor radi. Probaj svetla, brisače, trubu i vožnju.');
  if(!st.xray){camGoal.az=.9;camGoal.el=.22;camGoal.dist=8.5;camGoal.tx=.3;camGoal.ty=.8;camGoal.tz=0}
  renderControls();
}
function stopEngine(){
  st.on=false;st.drive=false;st.lights=false;st.wipers=false;st.radio=false;radioStop();engineStop();snd.click();
  setBubble('Motor je ugašen. Možeš ga ponovo upaliti. 🔑');renderControls();
}

/* ================= PETLJA ================= */
let last=performance.now(),time=0,smokeT=0;
function frame(now){
  requestAnimationFrame(frame);
  const dt=Math.min(.05,(now-last)/1000);last=now;time+=dt;
  updateCam(dt);

  // animacije postavljanja
  for(let i=anims.length-1;i>=0;i--){
    const a=anims[i];a.t+=dt/.65;
    const k=Math.min(1,a.t),e=1-Math.pow(1-k,3);
    a.g.position.copy(a.base).addScaledVector(a.off,1-e);
    if(k>=1){a.g.position.copy(a.base);anims.splice(i,1)}
  }
  // providne siluete pulsiraju
  ghostSel.opacity=.38+.22*Math.sin(time*5);
  ghostDim.opacity=.12;
  ghostGlow.opacity=.2+.15*Math.sin(time*5);
  arrows.forEach(a=>{a.position.y=a.userData.by+Math.sin(time*6)*.1});

  // motor / svetla / brisaci
  st.rpm+=((st.on?1:0)-st.rpm)*Math.min(1,dt*3);
  st.speed+=((st.drive&&st.on?1:0)-st.speed)*Math.min(1,dt*1.5);
  st.night+=((st.lights?1:0)-st.night)*Math.min(1,dt*2);
  if(st.on)engineRev(st.speed);
  const jit=st.rpm*.004;
  carRoot.position.y=Math.sin(time*70)*jit*(1+st.speed);
  carRoot.rotation.z=Math.sin(time*55)*jit*.5;
  // klipovi, plamen, instrumenti
  const blk=objs.block[0];
  st.ang+=st.rpm*(14+st.speed*26)*dt;
  if(blk){
    const d=blk.userData.eng,offs=[0,PI,PI,0];
    for(let k=0;k<4;k++){
      const th=st.ang+offs[k],pinY=-.2+.05*Math.cos(th),pinZ=.05*Math.sin(th);
      const py=pinY+Math.sqrt(.0625-pinZ*pinZ),x=-.3+.2*k;
      d.pist[k].position.y=py;
      const r=d.rods[k],dy=py-pinY,dz=-pinZ,len=Math.hypot(dy,dz);
      r.position.set(x,(py+pinY)/2,pinZ/2);r.rotation.x=Math.atan2(dz,dy);r.scale.y=len;
      const f=Math.max(0,Math.cos(th)-.5)/.5;
      d.flames[k].material.opacity=st.on?f*.9:0;d.flames[k].scale.setScalar(.6+.5*f);
    }
  }
  st.temp+=((st.on?.5:.08)-st.temp)*dt*.06;
  const ign=Math.min(1,st.rpm*3);
  const gv=(id,v)=>{const g=objs[id][0];if(g)g.userData.needle.rotation.z=2.35-Math.max(0,Math.min(1,v))*4.7};
  gv('speedo',st.speed*.55);
  gv('rev',st.rpm*(.13+.22*st.speed)+(st.on?Math.sin(time*9)*.008:0));
  gv('fuelg',.78*ign);
  gv('temp',st.temp*ign);
  const lp=objs.lamps[0];
  if(lp){const lampsOn=st.on&&time-st.startT<1.4;lp.userData.lamps.forEach(l=>l.m.color.setScalar(l.k!=='eng'&&lampsOn?1:.3))}
  // pedale, rucna kocnica, menjac, radio
  const crank=st.on&&time-st.startT<1.4,braking=!st.drive&&st.speed>.05&&st.on;
  const pedal=(id,v)=>{const o=objs[id][0];if(o){const h=o.userData.hinge;h.rotation.z+=(v*.3-h.rotation.z)*Math.min(1,dt*10)}};
  pedal('gas',st.on&&st.drive?.55+.45*st.speed:0);
  pedal('clutch',crank||(st.drive&&st.speed<.35)?1:0);
  pedal('brake',braking?1:0);
  const hb=objs.handbrake[0];
  if(hb){const L=hb.userData.lever,tg=(st.drive||st.speed>.05)?.45:-.2;L.rotation.z+=(tg-L.rotation.z)*Math.min(1,dt*5)}
  const gr=objs.gear[0];
  if(gr){const S=gr.userData.stick,tg=st.drive?-.14:0;S.rotation.z+=(tg-S.rotation.z)*Math.min(1,dt*6)}
  const rd=objs.radio[0];
  if(rd)rd.userData.disp.color.setScalar(st.on?(st.radio?1:.5):.2);
  // krajolik
  const mv=st.speed*6.3*dt;
  tiles.forEach(t=>{t.position.x-=mv;if(t.position.x<-80)t.position.x+=160});
  clouds.forEach(c=>{c.position.x-=dt*(.6+st.speed*.6);if(c.position.x<-130)c.position.x+=260});
  sc.win.emissiveIntensity=st.night*1.6;sc.bulb.emissiveIntensity=.15+st.night*2.2;
  starMat.opacity=Math.max(0,st.night*1.1-.1);
  cloudMat.color.setScalar(1-.75*st.night);
  const fan=objs.radiator[0]&&objs.radiator[0].userData.fan;
  if(fan)fan.rotation.x+=st.rpm*dt*(10+20*st.speed);
  // svetla
  const hl=objs.head.some(x=>x),tl=objs.tail.some(x=>x);
  mats.head.emissiveIntensity=hl&&st.lights?2.2:0;
  mats.tail.emissiveIntensity=tl?((!st.drive&&st.speed>.05&&st.on)?3:(st.lights?1.8:(st.on?.6:0))):0;
  spots.forEach((s,i)=>{s.intensity=hl?st.night*3:0});
  cones.forEach(c=>{c.material.opacity=hl?st.night*.07:0});
  scene.background.copy(SKY_DAY).lerp(SKY_NIGHT,st.night*.85);
  scene.fog.color.copy(scene.background);
  hemi.intensity=.85-.55*st.night;sun.intensity=.95-.7*st.night;
  // brisaci
  const wipers=objs.wiper;
  if(st.wipers){st.wt+=dt*1.5}
  else if(st.wt>0){const nx=st.wt+dt*1.5;st.wt=Math.floor(nx)>Math.floor(st.wt)?0:nx}
  const f=st.wt%1,th=PI/2-(PI/2-.12)*Math.sin(PI*f);
  wipers.forEach(w=>{if(w)w.userData.arm.rotation.z=st.wt>0?th:PI/2});
  // tockovi i put
  objs.wheel.forEach(w=>{if(w){w.userData.spin.rotation.z-=st.speed*dt*14}});
  roadTex.offset.x+=st.speed*dt*.98;
  // dim
  if(st.on&&objs.exhaust[0]){
    smokeT-=dt;
    if(smokeT<=0){
      smokeT=.09-.04*st.speed;
      const tip=objs.exhaust[0].userData.tip.clone();carRoot.localToWorld(tip);
      const sp=new T.Sprite(new T.SpriteMaterial({map:smokeTex,transparent:true,opacity:.55,depthWrite:false}));
      sp.position.copy(tip);sp.scale.setScalar(.12);
      sp.userData={v:new T.Vector3(-.7-st.speed*1.5,.5,rnd(-.15,.15)),age:0};
      scene.add(sp);smoke.push(sp);
    }
  }
  for(let i=smoke.length-1;i>=0;i--){
    const s=smoke[i];s.userData.age+=dt;const a=s.userData.age;
    s.position.addScaledVector(s.userData.v,dt);
    s.scale.setScalar(.12+a*.5);s.material.opacity=Math.max(0,.55-a*.4);
    if(a>1.4){scene.remove(s);s.material.dispose();smoke.splice(i,1)}
  }
  renderer.render(scene,camera);
}

/* ================= START ================= */
function resize(){
  const w=stage.clientWidth,h=stage.clientHeight;
  renderer.setSize(w,h,false);camera.aspect=w/h;camera.updateProjectionMatrix();
}
window.addEventListener('resize',resize);
$('#snd').onclick=()=>{muted=!muted;try{localStorage.setItem('auto-radionica-muted',muted?'1':'0')}catch(e){}$('#snd').textContent=muted?'🔇':'🔊';if(muted){engineStop();radioStop();st.radio=false;syncBtns()}else snd.tap()};
$('#snd').textContent=muted?'🔇':'🔊';
$('#back').textContent='↺ Iznova';$('#back').title='Počni iznova';
$('#back').onclick=()=>location.reload();

setupLights();
resize();
renderSteps();
buildGhosts();
setBubble(`<b>Dobrodošao u auto-radionicu!</b><br>Sklopi auto deo po deo. Prvo stavi <b>točkove</b>.`);
renderShelf();
setTimeout(()=>{const f=phaseParts()[0];if(f&&!sel)select(f)},700);
requestAnimationFrame(frame);
/*TEST*/
})();
