Auto-radionica - 3D igra sastavljanja automobila (originalan auto, bez marki).
Otvori index.html u browseru; three.min.js je u istom folderu, internet nije potreban.
8 faza: Tockovi, Motor (blok, karter, glava, svecice, poklopac ventila, usisna/izduvna grana, kais, alternator),
Pogon i gorivo (hladnjak, akumulator, rezervoar, auspuh), Tabla i sedista (brzinomer, obrtomer, merac goriva,
temperatura, lampice, volan), Karoserija (+ poklopac za gorivo), Stakla, Svetla, Pokreni.
Na kraju: kljuc, svetla, brisaci, truba, voznja, "Motor iznutra" (klipovi i plamen) i dodir na deo = objasnjenje.
