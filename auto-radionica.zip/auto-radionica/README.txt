Auto-radionica - 3D igra sastavljanja automobila.
Otvori index.html u browseru (potreban je internet samo za prvo ucitavanje stranice - ne, radi i bez njega; three.min.js je u istom folderu).
Prevuci deo sa police na providno mesto na autu. 6 faza, pa upali motor: svetla, brisaci, truba, voznja.
Auto je originalan (bez stvarnih marki i logotipa).
