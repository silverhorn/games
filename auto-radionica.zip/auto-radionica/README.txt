Auto-radionica - 3D igra sastavljanja automobila (originalan auto, bez marki).
Otvori index.html u browseru; three.min.js je u istom folderu, internet nije potreban.
9 faza (+ komande: gas, kvacilo, kocnica, menjac, rucna kocnica, radio; pojasevi uz sedista).
Pogon i gorivo (hladnjak, akumulator, rezervoar, auspuh), Tabla i sedista (brzinomer, obrtomer, merac goriva,
temperatura, lampice, volan), Karoserija (+ poklopac za gorivo), Stakla, Svetla, Pokreni.
Na kraju: kljuc, svetla, brisaci, truba, voznja, "Motor iznutra" (klipovi i plamen) i dodir na deo = objasnjenje.
Okolina: suma, kucice, brda, planine, oblaci, jezero i banderi koji se pomeraju dok vozis; noc kad upalis svetla.
