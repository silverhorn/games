// Podaci za Crtaonicu: sve je originalno crtano u kodu (platno 800x600, sredina je x=400).
window.CRT = (function () {
  'use strict';

  // ---- "Dovrši crtež": leva polovina (Path2D) — desna se dobija ogledalom ----
  // full: delovi koji se crtaju celi (na sredini), nisu preslikani
  var HALVES = [
    { id: 'leptir', name: 'Leptir', emo: '🦋',
      half: ['M400 300 C330 170 200 110 130 190 C90 245 170 325 400 320',
             'M400 322 C300 340 175 360 200 445 C235 525 345 485 400 385',
             'M398 248 C372 200 352 190 330 168'],
      full: [{ t: 'ellipse', x: 400, y: 325, rx: 11, ry: 85 }] },
    { id: 'srce', name: 'Srce', emo: '❤️',
      half: ['M400 520 C250 400 125 320 150 220 C172 130 320 110 400 205'], full: [] },
    { id: 'lisica', name: 'Lisica', emo: '🦊',
      half: ['M400 530 L255 410 L175 255 L190 115 L300 205 C340 195 370 195 400 197',
             'M315 305 m-14 0 a14 14 0 1 0 28 0 a14 14 0 1 0 -28 0'],
      full: [{ t: 'tri', x: 400, y: 440, w: 34, h: 28 }] },
    { id: 'raketa', name: 'Raketa', emo: '🚀',
      half: ['M400 70 C330 150 312 250 312 385 L248 470 L248 525 L312 485 L312 525 L400 525'],
      full: [{ t: 'circle', x: 400, y: 250, r: 34 }] },
    { id: 'drvo', name: 'Drvo', emo: '🌳',
      half: ['M400 95 C325 95 228 140 228 230 C165 252 158 345 230 372 C245 425 330 432 400 402',
             'M372 545 L377 405'],
      full: [] },
    { id: 'kuca', name: 'Kuća', emo: '🏠',
      half: ['M400 110 L150 300 L165 300 L165 525 L400 525', 'M400 525 L400 415 L325 415 L325 525'],
      full: [] }
  ];

  // ---- "Crtaj po koracima": primitive su u koordinatama platna ----
  var C = function (x, y, r) { return { t: 'circle', x: x, y: y, r: r }; };
  var R = function (x, y, w, h) { return { t: 'rect', x: x, y: y, w: w, h: h }; };
  var L = function (x1, y1, x2, y2) { return { t: 'line', x1: x1, y1: y1, x2: x2, y2: y2 }; };
  var P = function (pts) { return { t: 'poly', pts: pts }; };
  var E = function (x, y, rx, ry) { return { t: 'ellipse', x: x, y: y, rx: rx, ry: ry }; };

  var STEPS = [
    { id: 'macka', name: 'Mačka', emo: '🐱', steps: [
      { say: 'Veliki krug za glavu', s: [C(400, 330, 160)] },
      { say: 'Dva trougla za uši', s: [P([[270, 230], [285, 110], [370, 190]]), P([[530, 230], [515, 110], [430, 190]])] },
      { say: 'Dva oka', s: [C(340, 310, 22), C(460, 310, 22)] },
      { say: 'Mali trougao za nos', s: [P([[380, 370], [420, 370], [400, 395]])] },
      { say: 'Brkovi', s: [L(200, 350, 330, 370), L(200, 400, 330, 385), L(600, 350, 470, 370), L(600, 400, 470, 385)] }
    ] },
    { id: 'kuca', name: 'Kuća', emo: '🏠', steps: [
      { say: 'Veliki kvadrat — zidovi', s: [R(200, 280, 400, 270)] },
      { say: 'Trougao — krov', s: [P([[170, 285], [400, 110], [630, 285]])] },
      { say: 'Pravougaonik — vrata', s: [R(360, 400, 85, 150)] },
      { say: 'Dva prozora', s: [R(240, 340, 70, 70), R(490, 340, 70, 70)] },
      { say: 'Dimnjak i sunce', s: [R(490, 130, 45, 85), C(700, 100, 45)] }
    ] },
    { id: 'riba', name: 'Riba', emo: '🐠', steps: [
      { say: 'Veliki oval — telo', s: [E(380, 320, 200, 120)] },
      { say: 'Trougao — rep', s: [P([[570, 320], [700, 230], [700, 410]])] },
      { say: 'Oko', s: [C(250, 290, 22)] },
      { say: 'Peraje', s: [P([[360, 205], [420, 130], [470, 215]]), P([[380, 430], [430, 500], [470, 425]])] },
      { say: 'Mehurići', s: [C(140, 250, 14), C(110, 200, 10), C(150, 150, 18)] }
    ] },
    { id: 'brod', name: 'Brod', emo: '⛵', steps: [
      { say: 'Trup broda', s: [P([[170, 400], [630, 400], [550, 500], [250, 500]])] },
      { say: 'Jarbol', s: [L(400, 400, 400, 110)] },
      { say: 'Velika jedra', s: [P([[410, 130], [410, 380], [590, 380]]), P([[390, 180], [390, 380], [240, 380]])] },
      { say: 'Zastavica', s: [P([[400, 110], [400, 70], [470, 90]])] },
      { say: 'Talasi', s: [L(80, 540, 160, 520), L(160, 520, 240, 540), L(520, 540, 600, 520), L(600, 520, 690, 540)] }
    ] },
    { id: 'drvo', name: 'Drvo', emo: '🍎', steps: [
      { say: 'Debelo stablo', s: [R(360, 340, 80, 220)] },
      { say: 'Veliki krug — krošnja', s: [C(400, 230, 150)] },
      { say: 'Još dva kruga sa strane', s: [C(285, 290, 85), C(515, 290, 85)] },
      { say: 'Jabuke', s: [C(350, 200, 16), C(450, 250, 16), C(300, 300, 16), C(500, 320, 16)] },
      { say: 'Trava', s: [L(120, 560, 680, 560), L(210, 560, 225, 525), L(560, 560, 575, 525)] }
    ] }
  ];

  var WORDS = ['kuća', 'mačka', 'sunce', 'cvet', 'drvo', 'riba', 'auto', 'lopta', 'zvezda', 'srce', 'avion', 'brod',
    'kišobran', 'torta', 'pas', 'leptir', 'planina', 'raketa', 'sat', 'naočare', 'ptica', 'čizma', 'jabuka', 'mesec',
    'bicikl', 'sladoled', 'zmaj', 'sneško', 'krava', 'slon'];

  var PALETTE = ['#2b2d42', '#e5584f', '#ff8a1f', '#ffc83d', '#2bb673', '#2d7ff9', '#7b5cf0', '#ff7bb5', '#8d5a2b', '#ffffff'];

  var SHAPES = ['krug', 'trougao', 'kvadrat', 'zvezda', 'srce', 'talas', 'oval'];

  return { HALVES: HALVES, STEPS: STEPS, WORDS: WORDS, PALETTE: PALETTE, SHAPES: SHAPES };
})();
