CRTAONICA (za decu 7-10 godina) — dvoklik na index.html

7 delova:
- Slobodno crtanje: boje, 3 debljine, gumica, kanta za boju, ogledalo (simetrija), nazad, obriši.
- Dovrši crtež: leva polovina leptira/srca/lisice/rakete/drveta/kuće je gotova, dete crta desnu
  (dugme "Pokaži pomoć" prikaže isprekidanu liniju, "Ogledalo" samo ponavlja crtež).
- Crtaj po koracima: mačka, kuća, riba, brod, drvo — 5 koraka sa isprekidanom vodiljom; na kraju se boji.
- Pogodi šta crtam: dvoje, jedan crta zadatu reč, drugi bira među 4 ponuđene; poeni su zajednički (6 rundi).
- Čudovišta iz oblika: 3 nasumična oblika koje dete spaja u čudovište, pa ga imenuje.
- Oživi crtež: nacrtano pliva po moru, leti po nebu ili vozi po putu.
- Galerija: crteži se čuvaju u pregledaču (do 24), mogu da se preuzmu ili obrišu.

Sve je crtano u kodu, bez spoljnih slika. Radi na mišu i na dodir.
