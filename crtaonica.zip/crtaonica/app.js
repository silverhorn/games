(function () {
  'use strict';
  var app = document.getElementById('app');
  var D = window.CRT;
  var W = 800, H = 600;
  var anim = null; // id animacije koju treba zaustaviti pri izlasku

  // ---------- pomocne ----------
  function $(root, sel) { return root.querySelector(sel); }
  function esc(s) { return String(s).replace(/[&<>"]/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]; }); }
  function shuffle(a) { a = a.slice(); for (var i = a.length - 1; i > 0; i--) { var j = Math.floor(Math.random() * (i + 1)); var t = a[i]; a[i] = a[j]; a[j] = t; } return a; }
  function rnd(a, b) { return a + Math.random() * (b - a); }
  function toast(msg) {
    var t = document.createElement('div'); t.className = 'toast'; t.textContent = msg;
    document.body.appendChild(t); setTimeout(function () { t.remove(); }, 1800);
  }
  function stopAnim() { if (anim) { cancelAnimationFrame(anim); anim = null; } }
  function hexRgb(h) { var n = parseInt(h.slice(1), 16); return [n >> 16, (n >> 8) & 255, n & 255]; }
  function download(url, name) { var a = document.createElement('a'); a.href = url; a.download = name; document.body.appendChild(a); a.click(); a.remove(); }

  // ---------- galerija (localStorage) ----------
  function galLoad() { try { return JSON.parse(localStorage.getItem('crt_gal') || '[]'); } catch (e) { return []; } }
  function galSave(list) {
    for (var i = 0; i < 30; i++) {
      try { localStorage.setItem('crt_gal', JSON.stringify(list)); return true; } catch (e) { if (!list.length) return false; list.pop(); }
    }
    return false;
  }
  function galAdd(dataUrl, title) {
    var list = galLoad();
    list.unshift({ id: Date.now(), title: title || 'Moj crtež', img: dataUrl });
    list = list.slice(0, 24);
    return galSave(list);
  }

  // ---------- platno sa alatima ----------
  function Board(host, o) {
    o = o || {};
    host.innerHTML =
      '<div class="stage"><canvas class="guide" width="' + W + '" height="' + H + '"></canvas>' +
      '<canvas class="draw" width="' + W + '" height="' + H + '"></canvas></div>' +
      '<div class="tools" data-r="tools"></div>';
    var guide = $(host, 'canvas.guide'), draw = $(host, 'canvas.draw');
    var gctx = guide.getContext('2d'), ctx = draw.getContext('2d', { willReadFrequently: true });
    var st = { color: D.PALETTE[0], size: 10, tool: 'brush', mirror: false };
    var hist = [];
    var tools = $(host, '[data-r=tools]');

    var h = '';
    D.PALETTE.forEach(function (c, i) { h += '<button class="sw' + (i === 0 ? ' on' : '') + '" data-c="' + c + '" style="background:' + c + '" aria-label="boja"></button>'; });
    h += '<span class="sep"></span>';
    [4, 10, 22].forEach(function (s, i) { h += '<button class="sz' + (i === 1 ? ' on' : '') + '" data-s="' + s + '" aria-label="debljina"><i style="width:' + (s * 0.8 + 3) + 'px;height:' + (s * 0.8 + 3) + 'px"></i></button>'; });
    h += '<span class="sep"></span>';
    h += '<button class="btn on" data-t="brush">✏️ Olovka</button><button class="btn" data-t="eraser">🧽 Gumica</button><button class="btn" data-t="fill">🪣 Boja</button>';
    if (o.mirror !== false) h += '<button class="btn" data-a="mirror">↔️ Ogledalo</button>';
    h += '<button class="btn" data-a="undo">↩️ Nazad</button><button class="btn" data-a="clear">🗑️ Obriši</button>';
    tools.innerHTML = h;

    function snap() { hist.push(ctx.getImageData(0, 0, W, H)); if (hist.length > 25) hist.shift(); }
    function pos(e) { var r = draw.getBoundingClientRect(); return { x: (e.clientX - r.left) * W / r.width, y: (e.clientY - r.top) * H / r.height }; }
    function seg(a, b) {
      ctx.save();
      ctx.lineCap = 'round'; ctx.lineJoin = 'round'; ctx.lineWidth = st.size;
      if (st.tool === 'eraser') { ctx.globalCompositeOperation = 'destination-out'; ctx.strokeStyle = '#000'; } else ctx.strokeStyle = st.color;
      ctx.beginPath(); ctx.moveTo(a.x, a.y); ctx.lineTo(b.x, b.y); ctx.stroke();
      if (st.mirror) { ctx.beginPath(); ctx.moveTo(W - a.x, a.y); ctx.lineTo(W - b.x, b.y); ctx.stroke(); }
      ctx.restore();
    }
    function composite() {
      var c = document.createElement('canvas'); c.width = W; c.height = H;
      var x = c.getContext('2d'); x.fillStyle = '#fff'; x.fillRect(0, 0, W, H);
      x.drawImage(guide, 0, 0); x.drawImage(draw, 0, 0);
      return x.getImageData(0, 0, W, H);
    }
    function fill(px, py) {
      px = Math.floor(px); py = Math.floor(py);
      if (px < 0 || py < 0 || px >= W || py >= H) return;
      snap();
      var src = composite(), d = src.data, i0 = (py * W + px) * 4;
      var sr = d[i0], sg = d[i0 + 1], sb = d[i0 + 2];
      var fc = hexRgb(st.color), out = ctx.getImageData(0, 0, W, H), od = out.data;
      var seen = new Uint8Array(W * H), stack = [py * W + px];
      while (stack.length) {
        var p = stack.pop();
        if (seen[p]) continue;
        var i = p * 4;
        if (Math.abs(d[i] - sr) + Math.abs(d[i + 1] - sg) + Math.abs(d[i + 2] - sb) > 120) continue;
        seen[p] = 1;
        od[i] = fc[0]; od[i + 1] = fc[1]; od[i + 2] = fc[2]; od[i + 3] = 255;
        var x = p % W;
        if (x > 0) stack.push(p - 1);
        if (x < W - 1) stack.push(p + 1);
        if (p >= W) stack.push(p - W);
        if (p < W * (H - 1)) stack.push(p + W);
      }
      ctx.putImageData(out, 0, 0);
    }

    var last = null;
    draw.addEventListener('pointerdown', function (e) {
      e.preventDefault();
      var p = pos(e);
      if (st.tool === 'fill') { fill(p.x, p.y); return; }
      try { draw.setPointerCapture(e.pointerId); } catch (x) { /* nista */ }
      snap(); last = p; seg(p, p);
    });
    draw.addEventListener('pointermove', function (e) {
      if (!last) return;
      var p = pos(e); seg(last, p); last = p;
    });
    function end() { last = null; }
    draw.addEventListener('pointerup', end);
    draw.addEventListener('pointercancel', end);
    draw.addEventListener('lostpointercapture', end);

    tools.addEventListener('click', function (e) {
      var b = e.target.closest('button'); if (!b) return;
      if (b.dataset.c) {
        st.color = b.dataset.c;
        if (st.tool === 'eraser') setTool('brush');
        Array.prototype.forEach.call(tools.querySelectorAll('.sw'), function (x) { x.classList.toggle('on', x === b); });
      } else if (b.dataset.s) {
        st.size = +b.dataset.s;
        Array.prototype.forEach.call(tools.querySelectorAll('.sz'), function (x) { x.classList.toggle('on', x === b); });
      } else if (b.dataset.t) setTool(b.dataset.t);
      else if (b.dataset.a === 'mirror') { st.mirror = !st.mirror; b.classList.toggle('on', st.mirror); }
      else if (b.dataset.a === 'undo') { var s = hist.pop(); if (s) ctx.putImageData(s, 0, 0); }
      else if (b.dataset.a === 'clear') { snap(); ctx.clearRect(0, 0, W, H); if (api.onClear) api.onClear(); }
    });
    function setTool(t) {
      st.tool = t;
      Array.prototype.forEach.call(tools.querySelectorAll('[data-t]'), function (x) { x.classList.toggle('on', x.dataset.t === t); });
    }

    var api = {
      ctx: ctx, gctx: gctx, state: st, draw: draw, guide: guide, snap: snap,
      clearGuide: function () { gctx.clearRect(0, 0, W, H); },
      clearDraw: function () { ctx.clearRect(0, 0, W, H); hist = []; },
      onClear: null,
      // izvoz na beloj pozadini; withGuide uključuje i pomoćne linije
      exportCanvas: function (withGuide, scale) {
        scale = scale || 1;
        var c = document.createElement('canvas'); c.width = W * scale; c.height = H * scale;
        var x = c.getContext('2d'); x.fillStyle = '#fff'; x.fillRect(0, 0, c.width, c.height);
        if (withGuide) x.drawImage(guide, 0, 0, c.width, c.height);
        x.drawImage(draw, 0, 0, c.width, c.height);
        return c;
      },
      hasInk: function () {
        var d = ctx.getImageData(0, 0, W, H).data;
        for (var i = 3; i < d.length; i += 4) if (d[i] > 10) return true;
        return false;
      }
    };
    return api;
  }

  // ---------- crtanje oblika (vodilje / dovrši / čudovišta) ----------
  function prim(c, s) {
    c.beginPath();
    if (s.t === 'circle') c.arc(s.x, s.y, s.r, 0, Math.PI * 2);
    else if (s.t === 'ellipse') c.ellipse(s.x, s.y, s.rx, s.ry, 0, 0, Math.PI * 2);
    else if (s.t === 'rect') c.rect(s.x, s.y, s.w, s.h);
    else if (s.t === 'line') { c.moveTo(s.x1, s.y1); c.lineTo(s.x2, s.y2); }
    else if (s.t === 'poly' || s.t === 'tri') {
      var pts = s.pts || [[s.x - s.w, s.y], [s.x + s.w, s.y], [s.x, s.y + s.h]];
      c.moveTo(pts[0][0], pts[0][1]); for (var i = 1; i < pts.length; i++) c.lineTo(pts[i][0], pts[i][1]); c.closePath();
    }
  }
  function strokePrims(c, list, color, width, dash) {
    c.save(); c.strokeStyle = color; c.lineWidth = width; c.lineJoin = 'round'; c.lineCap = 'round';
    c.setLineDash(dash || []);
    list.forEach(function (s) { prim(c, s); c.stroke(); });
    c.restore();
  }
  function strokePaths(c, paths, color, width, dash, mirror) {
    c.save(); c.strokeStyle = color; c.lineWidth = width; c.lineJoin = 'round'; c.lineCap = 'round'; c.setLineDash(dash || []);
    if (mirror) { c.translate(W, 0); c.scale(-1, 1); }
    paths.forEach(function (d) { c.stroke(new Path2D(d)); });
    c.restore();
  }

  // ---------- ekrani ----------
  function home() {
    stopAnim();
    var modes = [
      ['free', '🎨', 'Slobodno crtanje', 'Crtaj šta god želiš'],
      ['half', '🦋', 'Dovrši crtež', 'Nacrtaj drugu polovinu'],
      ['steps', '🐱', 'Crtaj po koracima', 'Korak po korak do crteža'],
      ['guess', '🕵️', 'Pogodi šta crtam', 'Za dvoje — crtaj i pogađaj'],
      ['monster', '👾', 'Čudovišta iz oblika', 'Od oblika napravi čudovište'],
      ['alive', '✨', 'Oživi crtež', 'Tvoj crtež pliva i leti'],
      ['gallery', '🖼️', 'Moja galerija', 'Sačuvani crteži']
    ];
    var h = '<h1>🖍️ Crtaonica</h1><p class="sub">Izaberi šta želiš da radiš!</p><div class="grid">';
    modes.forEach(function (m) { h += '<button class="mode" data-m="' + m[0] + '"><div class="emo">' + m[1] + '</div><div class="name">' + m[2] + '</div><div class="desc">' + m[3] + '</div></button>'; });
    h += '</div>';
    app.innerHTML = h;
    app.querySelectorAll('.mode').forEach(function (b) {
      b.addEventListener('click', function () { ({ free: freeMode, half: halfMode, steps: stepsMode, guess: guessSetup, monster: monsterMode, alive: aliveMode, gallery: gallery })[b.dataset.m](); });
    });
  }

  function shell(title, extraTop) {
    stopAnim();
    app.innerHTML = '<div class="top"><button class="btn" id="back">⬅ Nazad</button><div class="title">' + title + '</div><span>' + (extraTop || '') + '</span></div><div id="body"></div>';
    $(app, '#back').addEventListener('click', home);
    return $(app, '#body');
  }

  function saveBar(host, board, defTitle, withGuide) {
    var d = document.createElement('div'); d.className = 'row';
    d.innerHTML = '<input type="text" maxlength="24" placeholder="Naziv crteža" value="' + esc(defTitle) + '">' +
      '<button class="btn green" data-s="gal">📌 U galeriju</button><button class="btn" data-s="png">⬇️ Preuzmi sliku</button>';
    host.appendChild(d);
    d.querySelector('[data-s=gal]').addEventListener('click', function () {
      if (!board.hasInk()) { toast('Prvo nešto nacrtaj! ✏️'); return; }
      var c = board.exportCanvas(withGuide, 0.7);
      var ok = galAdd(c.toDataURL('image/jpeg', 0.85), d.querySelector('input').value.trim() || defTitle);
      toast(ok ? 'Sačuvano u galeriju! 🖼️' : 'Nema mesta u galeriji.');
    });
    d.querySelector('[data-s=png]').addEventListener('click', function () {
      download(board.exportCanvas(withGuide, 1).toDataURL('image/png'), (d.querySelector('input').value.trim() || defTitle) + '.png');
    });
  }

  // 1) Slobodno crtanje
  function freeMode() {
    var b = shell('🎨 Slobodno crtanje');
    var board = Board(b);
    saveBar(b, board, 'Moj crtež', false);
  }

  // 2) Dovrši crtež
  function halfMode() {
    var b = shell('🦋 Dovrši crtež');
    var h = '<p class="sub">Leva strana je gotova — nacrtaj desnu! Uključi „Ogledalo“ pa će se crtež sam ponavljati.</p><div class="chips" id="chips">';
    D.HALVES.forEach(function (t, i) { h += '<button class="chip" data-i="' + i + '">' + t.emo + ' ' + t.name + '</button>'; });
    h += '</div><div id="bd"></div>';
    b.innerHTML = h;
    var board = null, help = false, cur = 0;
    function load(i) {
      cur = i;
      b.querySelectorAll('.chip').forEach(function (c) { c.classList.toggle('on', +c.dataset.i === i); });
      var bd = $(b, '#bd'); bd.innerHTML = '';
      board = Board(bd, {});
      var extra = document.createElement('div'); extra.className = 'row';
      extra.innerHTML = '<button class="btn" id="help">👀 Pokaži pomoć</button>';
      bd.insertBefore(extra, bd.firstChild.nextSibling);
      var t = D.HALVES[i];
      function paintHalf() {
        strokePaths(board.ctx, t.half, '#2b2d42', 6, null, false);
        strokePrims(board.ctx, t.full, '#2b2d42', 6);
      }
      paintHalf();
      board.onClear = paintHalf;
      help = false;
      $(bd, '#help').addEventListener('click', function () {
        help = !help; this.classList.toggle('on', help);
        board.clearGuide();
        if (help) strokePaths(board.gctx, t.half, '#9fb3c8', 5, [10, 10], true);
      });
      saveBar(bd, board, t.name, true);
    }
    b.querySelectorAll('.chip').forEach(function (c) { c.addEventListener('click', function () { load(+c.dataset.i); }); });
    load(0);
  }

  // 3) Crtaj po koracima
  function stepsMode() {
    var b = shell('🐱 Crtaj po koracima');
    var h = '<p class="sub">Prati isprekidanu liniju. Kad završiš korak, pritisni „Dalje“.</p><div class="chips" id="chips">';
    D.STEPS.forEach(function (t, i) { h += '<button class="chip" data-i="' + i + '">' + t.emo + ' ' + t.name + '</button>'; });
    h += '</div><div id="bd"></div>';
    b.innerHTML = h;
    function load(i) {
      b.querySelectorAll('.chip').forEach(function (c) { c.classList.toggle('on', +c.dataset.i === i); });
      var t = D.STEPS[i], k = 0, bd = $(b, '#bd');
      bd.innerHTML = '<div class="stepbar" id="sb"></div><div class="row"><button class="btn" id="prev">◀ Korak nazad</button><button class="btn primary" id="next">Dalje ▶</button></div><div id="bw"></div>';
      var board = Board($(bd, '#bw'), { mirror: false });
      function show() {
        board.clearGuide();
        for (var j = 0; j < k; j++) strokePrims(board.gctx, t.steps[j].s, '#c9d3df', 5);
        if (k < t.steps.length) strokePrims(board.gctx, t.steps[k].s, '#2d7ff9', 6, [12, 10]);
        $(bd, '#sb').textContent = k < t.steps.length ? 'Korak ' + (k + 1) + ' od ' + t.steps.length + ': ' + t.steps[k].say : '🎉 Bravo! Sada ga oboj kantom 🪣 i ukrasi!';
        $(bd, '#prev').disabled = k === 0;
        $(bd, '#next').disabled = k >= t.steps.length;
      }
      $(bd, '#prev').addEventListener('click', function () { if (k > 0) { k--; show(); } });
      $(bd, '#next').addEventListener('click', function () { if (k < t.steps.length) { k++; show(); } });
      show();
      saveBar(bd, board, t.name, false);
    }
    b.querySelectorAll('.chip').forEach(function (c) { c.addEventListener('click', function () { load(+c.dataset.i); }); });
    load(0);
  }

  // 4) Pogodi šta crtam (dvoje, saradnja)
  var G = null;
  function guessSetup() {
    var b = shell('🕵️ Pogodi šta crtam');
    b.innerHTML = '<div class="card"><p class="sub">Jedan crta zadatu reč, drugi pogađa među ponuđenim odgovorima. Pogodite li — poen za oboje! 6 rundi.</p>' +
      '<div class="row"><input type="text" id="n0" maxlength="14" placeholder="Igrač 1"><input type="text" id="n1" maxlength="14" placeholder="Igrač 2"></div>' +
      '<div class="row"><button class="btn primary" id="go">Počni ▶</button></div></div>';
    $(b, '#go').addEventListener('click', function () {
      G = { names: [$(b, '#n0').value.trim() || 'Igrač 1', $(b, '#n1').value.trim() || 'Igrač 2'], round: 0, score: 0, words: shuffle(D.WORDS).slice(0, 6) };
      guessPass();
    });
  }
  function guessPass() {
    var b = shell('🕵️ Runda ' + (G.round + 1) + ' / ' + G.words.length);
    var dr = G.round % 2, gs = 1 - dr;
    b.innerHTML = '<div class="card"><h2>Na redu je ' + esc(G.names[dr]) + ' da crta!</h2><p class="sub">' + esc(G.names[gs]) + ', okreni glavu — ne gledaj reč! 🙈</p>' +
      '<div class="row"><button class="btn primary" id="see">Vidi reč 👀</button></div></div>';
    $(b, '#see').addEventListener('click', function () {
      b.innerHTML = '<div class="card"><p class="sub">Nacrtaj:</p><div class="word">' + esc(G.words[G.round]) + '</div><div class="row"><button class="btn green" id="draw">Crtam! ✏️</button></div></div>';
      $(b, '#draw').addEventListener('click', guessDraw);
    });
  }
  function guessDraw() {
    var b = shell('🕵️ ' + esc(G.names[G.round % 2]) + ' crta');
    var board = Board(b, { mirror: false });
    var r = document.createElement('div'); r.className = 'row';
    r.innerHTML = '<button class="btn green" id="done">Gotovo ✔</button>';
    b.appendChild(r);
    $(b, '#done').addEventListener('click', function () {
      if (!board.hasInk()) { toast('Nacrtaj nešto! ✏️'); return; }
      guessPick(board.exportCanvas(false, 0.6).toDataURL('image/jpeg', 0.85));
    });
  }
  function guessPick(img) {
    var word = G.words[G.round], gs = 1 - (G.round % 2);
    var b = shell('🕵️ Pogađa ' + esc(G.names[gs]));
    var others = shuffle(D.WORDS.filter(function (w) { return w !== word; })).slice(0, 3);
    var opts = shuffle([word].concat(others));
    var h = '<div class="card"><img src="' + img + '" alt="crtež" style="width:100%;max-width:520px;border-radius:12px;box-shadow:0 0 0 2px #e3e8ef"><h2>Šta je nacrtano?</h2><div class="opts">';
    opts.forEach(function (o) { h += '<button class="opt" data-w="' + esc(o) + '">' + esc(o) + '</button>'; });
    h += '</div><div id="fb" class="stepbar"></div><div class="row"><button class="btn primary" id="nx" hidden>Dalje ➜</button></div></div>';
    b.innerHTML = h;
    var locked = false;
    b.querySelectorAll('.opt').forEach(function (o) {
      o.addEventListener('click', function () {
        if (locked) return; locked = true;
        var ok = o.dataset.w === word;
        if (ok) G.score++;
        b.querySelectorAll('.opt').forEach(function (x) { if (x.dataset.w === word) x.classList.add('good'); else if (x === o) x.classList.add('bad'); });
        $(b, '#fb').textContent = ok ? 'Bravo! Pogođeno! 🎉' : 'Skoro! Bilo je: ' + word;
        var nx = $(b, '#nx'); nx.hidden = false; nx.textContent = G.round === G.words.length - 1 ? 'Kraj 🏁' : 'Dalje ➜';
        nx.addEventListener('click', function () { G.round++; if (G.round >= G.words.length) guessEnd(); else guessPass(); });
      });
    });
  }
  function guessEnd() {
    var b = shell('🕵️ Kraj igre');
    var n = G.words.length, s = G.score;
    var msg = s >= 5 ? 'Savršen tim! 🏆' : s >= 3 ? 'Odličan tim! 🎉' : 'Dobar početak, probajte opet! 💪';
    b.innerHTML = '<div class="card"><div style="font-size:3.5rem">🎨</div><h2>' + esc(G.names[0]) + ' i ' + esc(G.names[1]) + '</h2><div class="word">' + s + ' / ' + n + '</div><p class="sub">' + msg + '</p>' +
      '<div class="row"><button class="btn primary" id="again">🔁 Opet</button><button class="btn" id="menu">🏠 Početak</button></div></div>';
    $(b, '#again').addEventListener('click', guessSetup);
    $(b, '#menu').addEventListener('click', home);
  }

  // 5) Čudovišta iz oblika
  function drawShape(c, kind, x, y, s, color) {
    c.save(); c.fillStyle = color; c.strokeStyle = '#2b2d42'; c.lineWidth = 5; c.lineJoin = 'round'; c.lineCap = 'round';
    c.beginPath();
    if (kind === 'krug') c.arc(x, y, s, 0, Math.PI * 2);
    else if (kind === 'oval') c.ellipse(x, y, s * 1.3, s * 0.8, 0, 0, Math.PI * 2);
    else if (kind === 'kvadrat') c.rect(x - s, y - s, s * 2, s * 2);
    else if (kind === 'trougao') { c.moveTo(x, y - s); c.lineTo(x + s * 1.1, y + s * 0.8); c.lineTo(x - s * 1.1, y + s * 0.8); c.closePath(); }
    else if (kind === 'zvezda') { for (var i = 0; i < 10; i++) { var r = i % 2 ? s * 0.45 : s * 1.1, a = -Math.PI / 2 + i * Math.PI / 5; c[i ? 'lineTo' : 'moveTo'](x + r * Math.cos(a), y + r * Math.sin(a)); } c.closePath(); }
    else if (kind === 'srce') { c.moveTo(x, y + s); c.bezierCurveTo(x - s * 1.6, y - s * 0.2, x - s * 0.7, y - s * 1.1, x, y - s * 0.3); c.bezierCurveTo(x + s * 0.7, y - s * 1.1, x + s * 1.6, y - s * 0.2, x, y + s); }
    else if (kind === 'talas') { c.moveTo(x - s * 1.4, y); c.bezierCurveTo(x - s * 0.9, y - s, x - s * 0.5, y - s, x, y); c.bezierCurveTo(x + s * 0.5, y + s, x + s * 0.9, y + s, x + s * 1.4, y); c.lineWidth = 12; c.strokeStyle = color; c.stroke(); c.restore(); return; }
    c.fill(); c.stroke(); c.restore();
  }
  function monsterMode() {
    var b = shell('👾 Čudovišta iz oblika');
    b.innerHTML = '<p class="sub">Dobio si 3 oblika. Poveži ih u čudovište — dodaj oči, ruke, noge, zube! Zatim mu daj ime.</p><div class="row"><button class="btn" id="dice">🎲 Novi oblici</button></div><div id="bd"></div>';
    var board = Board($(b, '#bd'), {});
    var names = ['Gloga', 'Bubi', 'Šmrk', 'Zubonja', 'Mrljko', 'Brundo', 'Fufi', 'Cvrle'];
    function roll() {
      board.snap(); board.clearDraw();
      var kinds = shuffle(D.SHAPES).slice(0, 3), cols = shuffle(['#ff8a1f', '#7b5cf0', '#2bb673', '#ff7bb5', '#2d7ff9', '#ffc83d', '#e5584f']);
      var xs = shuffle([190, 400, 610]);
      kinds.forEach(function (k, i) { drawShape(board.ctx, k, xs[i], rnd(220, 400), rnd(60, 95), cols[i]); });
    }
    board.onClear = null;
    $(b, '#dice').addEventListener('click', roll);
    roll();
    saveBar($(b, '#bd'), board, names[Math.floor(Math.random() * names.length)], false);
  }

  // 6) Oživi crtež
  var SCENES = [
    { id: 'more', emo: '🌊', name: 'More', hint: 'Nacrtaj brod, ribu, podmornicu...' },
    { id: 'nebo', emo: '☁️', name: 'Nebo', hint: 'Nacrtaj pticu, avion, balon...' },
    { id: 'put', emo: '🛣️', name: 'Put', hint: 'Nacrtaj auto, bicikl, kamion...' }
  ];
  function sceneBg(c, id, t) {
    var g;
    if (id === 'more') {
      g = c.createLinearGradient(0, 0, 0, H); g.addColorStop(0, '#bfe6ff'); g.addColorStop(0.45, '#eaf8ff'); g.addColorStop(0.46, '#4aa3df'); g.addColorStop(1, '#1d6fa5');
      c.fillStyle = g; c.fillRect(0, 0, W, H);
      c.fillStyle = '#ffe27a'; c.beginPath(); c.arc(660, 100, 50, 0, 7); c.fill();
      for (var k = 0; k < 3; k++) {
        c.fillStyle = 'rgba(255,255,255,' + (0.14 + k * 0.08) + ')'; c.beginPath(); c.moveTo(0, H);
        for (var x = 0; x <= W; x += 20) c.lineTo(x, 300 + k * 60 + Math.sin(x / 60 + t * (1.2 + k * 0.4)) * 12);
        c.lineTo(W, H); c.closePath(); c.fill();
      }
    } else if (id === 'nebo') {
      g = c.createLinearGradient(0, 0, 0, H); g.addColorStop(0, '#5aaef0'); g.addColorStop(1, '#d4efff');
      c.fillStyle = g; c.fillRect(0, 0, W, H);
      c.fillStyle = '#ffe27a'; c.beginPath(); c.arc(120, 100, 55, 0, 7); c.fill();
      c.fillStyle = 'rgba(255,255,255,.92)';
      [[0, 120, 1], [260, 260, 1.3], [520, 90, 0.9], [700, 330, 1.1]].forEach(function (cl) {
        var x = ((cl[0] + t * 30 * cl[2]) % (W + 300)) - 150, y = cl[1];
        c.beginPath(); c.ellipse(x, y, 70 * cl[2], 28 * cl[2], 0, 0, 7); c.ellipse(x + 45 * cl[2], y - 14 * cl[2], 45 * cl[2], 26 * cl[2], 0, 0, 7); c.ellipse(x - 45 * cl[2], y - 8 * cl[2], 40 * cl[2], 22 * cl[2], 0, 0, 7); c.fill();
      });
    } else {
      g = c.createLinearGradient(0, 0, 0, 420); g.addColorStop(0, '#9fd8ff'); g.addColorStop(1, '#e9f7ff');
      c.fillStyle = g; c.fillRect(0, 0, W, H);
      c.fillStyle = '#7cc57a'; c.beginPath(); c.moveTo(0, 420); for (var x2 = 0; x2 <= W; x2 += 20) c.lineTo(x2, 360 + Math.sin(x2 / 110) * 30); c.lineTo(W, 440); c.lineTo(0, 440); c.closePath(); c.fill();
      c.fillStyle = '#4b5563'; c.fillRect(0, 430, W, 150);
      c.fillStyle = '#fff'; var off = (t * 120) % 100;
      for (var x3 = -100; x3 < W + 100; x3 += 100) c.fillRect(x3 - off, 500, 50, 8);
      c.fillStyle = '#7cc57a'; c.fillRect(0, 580, W, 20);
    }
  }
  var aliveSaved = null; // canvas sa nacrtanim
  function aliveMode(sceneId) {
    var sc = SCENES.filter(function (s) { return s.id === sceneId; })[0] || SCENES[0];
    var b = shell('✨ Oživi crtež');
    var h = '<div class="chips">';
    SCENES.forEach(function (s) { h += '<button class="chip' + (s.id === sc.id ? ' on' : '') + '" data-s="' + s.id + '">' + s.emo + ' ' + s.name + '</button>'; });
    h += '</div><p class="sub">' + sc.hint + ' Gledaj levo-desno: crtež će ploviti ili letati!</p><div id="bd"></div>';
    b.innerHTML = h;
    b.querySelectorAll('.chip').forEach(function (c) { c.addEventListener('click', function () { aliveSaved = null; aliveMode(c.dataset.s); }); });
    var board = Board($(b, '#bd'), { mirror: false });
    sceneBg(board.gctx, sc.id, 0);
    board.gctx.fillStyle = 'rgba(255,255,255,.35)'; board.gctx.fillRect(0, 0, W, H);
    if (aliveSaved) board.ctx.drawImage(aliveSaved, 0, 0);
    var r = document.createElement('div'); r.className = 'row';
    r.innerHTML = '<button class="btn primary" id="go">✨ Oživi!</button>';
    $(b, '#bd').appendChild(r);
    $(b, '#go').addEventListener('click', function () {
      var d = board.ctx.getImageData(0, 0, W, H).data, x0 = W, y0 = H, x1 = 0, y1 = 0;
      for (var y = 0; y < H; y++) for (var x = 0; x < W; x++) if (d[(y * W + x) * 4 + 3] > 10) { if (x < x0) x0 = x; if (x > x1) x1 = x; if (y < y0) y0 = y; if (y > y1) y1 = y; }
      if (x1 <= x0 || y1 <= y0) { toast('Prvo nešto nacrtaj! ✏️'); return; }
      aliveSaved = document.createElement('canvas'); aliveSaved.width = W; aliveSaved.height = H; aliveSaved.getContext('2d').drawImage(board.draw, 0, 0);
      var sp = document.createElement('canvas'), w = x1 - x0 + 1, hh = y1 - y0 + 1;
      var k = Math.min(1, 200 / Math.max(w, hh)); sp.width = Math.ceil(w * k); sp.height = Math.ceil(hh * k);
      sp.getContext('2d').drawImage(board.draw, x0, y0, w, hh, 0, 0, sp.width, sp.height);
      aliveRun(sc, sp);
    });
  }
  function aliveRun(sc, sp) {
    var b = shell('✨ Tvoj crtež ožive!');
    b.innerHTML = '<div class="stage"><canvas width="' + W + '" height="' + H + '"></canvas></div><div class="row"><button class="btn" id="fix">✏️ Doradi crtež</button><button class="btn green" id="snap">📸 Slikaj</button></div>';
    var cv = $(b, 'canvas'), c = cv.getContext('2d');
    $(b, '#fix').addEventListener('click', function () { aliveMode(sc.id); });
    $(b, '#snap').addEventListener('click', function () { galAdd(cv.toDataURL('image/jpeg', 0.8), 'Oživljen crtež'); toast('Sačuvano u galeriju! 🖼️'); });
    var t0 = performance.now();
    function frame(now) {
      var t = (now - t0) / 1000;
      sceneBg(c, sc.id, t);
      var span = W + sp.width + 80, x = ((t * 90) % span) - sp.width, y, rot = 0;
      if (sc.id === 'more') { y = 330 - sp.height / 2 + Math.sin(t * 2) * 12; rot = Math.sin(t * 2) * 0.06; }
      else if (sc.id === 'nebo') { y = 250 + Math.sin(t * 1.3) * 60; rot = Math.cos(t * 1.3) * 0.12; }
      else { y = 470 - sp.height + Math.abs(Math.sin(t * 6)) * -8; rot = Math.sin(t * 6) * 0.015; }
      c.save(); c.translate(x + sp.width / 2, y + sp.height / 2); c.rotate(rot); c.drawImage(sp, -sp.width / 2, -sp.height / 2); c.restore();
      anim = requestAnimationFrame(frame);
    }
    anim = requestAnimationFrame(frame);
  }

  // 7) Galerija
  function gallery() {
    var b = shell('🖼️ Moja galerija');
    var list = galLoad();
    if (!list.length) { b.innerHTML = '<p class="sub">Još nema crteža. Nacrtaj nešto i pritisni „U galeriju“! 🎨</p>'; return; }
    var h = '<div class="gal">';
    list.forEach(function (it) { h += '<figure><img src="' + it.img + '" alt="" data-id="' + it.id + '"><figcaption>' + esc(it.title) + '</figcaption><div class="row"><button class="btn" data-dl="' + it.id + '">⬇️</button><button class="btn" data-del="' + it.id + '">🗑️</button></div></figure>'; });
    h += '</div>';
    b.innerHTML = h;
    b.addEventListener('click', function (e) {
      var t = e.target.closest('[data-dl],[data-del],img'); if (!t) return;
      var id = +(t.dataset.dl || t.dataset.del || t.dataset.id), cur = galLoad();
      var it = cur.filter(function (x) { return x.id === id; })[0]; if (!it) return;
      if (t.dataset.dl) download(it.img, it.title + '.jpg');
      else if (t.dataset.del) { galSave(cur.filter(function (x) { return x.id !== id; })); gallery(); }
      else window.open(it.img, '_blank');
    });
  }

  home();
})();
