/* Podaci za igru "Svemirska avantura" */
"use strict";

const PLANETS = [
  { id:"merkur", name:"Merkur", c1:"#cfc6bd", c2:"#6f655e", orbit:34, rr:4.5, rel:0.38, years:0.24, g:0.38,
    type:"Kamena planeta", dist:"58 miliona km", temp:"od −180 °C noću do 430 °C danju", day:"176 zemaljskih dana (od jednog izlaska Sunca do drugog)",
    year:"88 dana", moons:"nema meseca", icon:"🪨",
    how:"Nema vazduha koji bi nas štitio pa je nebo uvek crno, čak i danju. Dan je užasno vruć, a noć užasno hladna.",
    facts:["Najmanja planeta i najbliža Suncu.","Cela godina traje samo 88 dana – za jednu Zemljinu godinu napravi više od četiri kruga oko Sunca!","Pun je kratera, kao Mesec."],
    fun:"Merkur nije najtoplija planeta, iako je najbliži Suncu. To je Venera!" },
  { id:"venera", name:"Venera", c1:"#ffe3a1", c2:"#c9892f", orbit:52, rr:6.5, rel:0.95, years:0.62, g:0.91,
    type:"Kamena planeta", dist:"108 miliona km", temp:"465 °C – vruće kao u peći za picu", day:"117 zemaljskih dana",
    year:"225 dana", moons:"nema meseca", icon:"☁️",
    how:"Gusti oblaci od kiseline sve zaklanjaju, a vazduh je tako težak da bi te pritiskao kao duboko pod vodom.",
    facts:["Najtoplija planeta u Sunčevom sistemu.","Okreće se unazad – Sunce tamo izlazi na zapadu!","Veličinom je skoro blizanka Zemlje."],
    fun:"Venera je najsjajnija „zvezda“ na našem nebu – zovemo je Danica ili Večernjača, a zapravo je planeta." },
  { id:"zemlja", name:"Zemlja", c1:"#7ec8ff", c2:"#1d5fb0", orbit:70, rr:6.8, rel:1, years:1, g:1,
    type:"Kamena planeta", dist:"150 miliona km", temp:"prosečno 15 °C – taman da živimo", day:"24 sata",
    year:"365 dana", moons:"1 (Mesec)", icon:"🌍",
    how:"Ovde ima vode, vazduha i prijatne toplote. Zemlja je jedino mesto za koje sigurno znamo da ima život!",
    facts:["Oko 71% površine prekriva voda.","Putuje oko Sunca brzinom oko 107.000 km na sat.","Atmosfera nas štiti od zračenja i od većine meteora."],
    fun:"Zemlja je nagnuta, zato imamo četiri godišnja doba." },
  { id:"mars", name:"Mars", c1:"#ff9d6a", c2:"#a23a1b", orbit:88, rr:5.2, rel:0.53, years:1.88, g:0.38,
    type:"Kamena planeta", dist:"228 miliona km", temp:"prosečno −60 °C, kao dubok zimski dan", day:"24 sata i 37 minuta",
    year:"687 dana", moons:"2 (Fobos i Dejmos)", icon:"🔴",
    how:"Nebo je narandžasto-ružičasto, a tlo crveno od rđe. Vazduh je redak, pa bi ti trebalo odelo i boca sa vazduhom.",
    facts:["Crvena je zato što je tlo puno rđe (gvožđa).","Na njemu je Olimp, vulkan visok oko 22 km – skoro tri puta viši od Mont Everesta.","Danas tamo voze roveri i leteo je helikopter!"],
    fun:"Dan na Marsu traje skoro isto kao na Zemlji, samo 37 minuta duže." },
  { id:"jupiter", name:"Jupiter", c1:"#f3d9b4", c2:"#b2693c", orbit:112, rr:14, rel:11.2, years:11.9, g:2.53,
    type:"Gasovita planeta (džin)", dist:"778 miliona km", temp:"oko −145 °C na vrhu oblaka", day:"samo oko 10 sati",
    year:"12 zemaljskih godina", moons:"preko 90", icon:"🟠",
    how:"Nema čvrstog tla – samo oblaci i vetrovi. Kad bi nekako stao na oblake, osećao bi se više nego dvaput teži.",
    facts:["Najveća planeta: u nju bi stalo više od 1.300 Zemalja.","Velika crvena pega je ogromna oluja, starija od 150 godina.","Najbrže se okreće od svih planeta."],
    fun:"Jupiterov mesec Ganimed veći je od planete Merkur!" },
  { id:"saturn", name:"Saturn", c1:"#f6e3b0", c2:"#b99a58", orbit:140, rr:12, rel:9.45, years:29.5, g:1.07,
    type:"Gasovita planeta (džin)", dist:"1.427 miliona km", temp:"oko −178 °C", day:"oko 10 sati i 40 minuta",
    year:"29 zemaljskih godina", moons:"preko 140", icon:"🪐",
    how:"Prstenovi su sačinjeni od miliona komada leda i kamenja – od zrna peska do kuća.",
    facts:["Ima najlepše prstenove u Sunčevom sistemu.","Mada je ogroman, tako je „lagan“ da bi plutao na vodi – kad bi postojalo dovoljno veliko korito!","Ima mnogo meseca, među njima Titan i Enkelad."],
    fun:"Prstenovi su široki stotine hiljada kilometara, a debeli samo desetak metara na većini mesta." },
  { id:"uran", name:"Uran", c1:"#bff3f0", c2:"#4fb0b6", orbit:163, rr:9, rel:4, years:84, g:0.89,
    type:"Ledeni džin", dist:"2.871 milion km", temp:"oko −224 °C – jedna od najhladnijih", day:"oko 17 sati",
    year:"84 zemaljske godine", moons:"preko 25", icon:"🧊",
    how:"Plavozelena planeta od gasa i leda. Zbog nagnutosti, jedan pol dobija Sunce po 42 godine zaredom, pa onda 42 godine mrak!",
    facts:["Leži „na boku“ – okreće se kao lopta koja se kotrlja.","Ima tanke, tamne prstenove.","Čovek ga je otkrio teleskopom 1781. godine."],
    fun:"Meseci Urana nose imena po likovima iz Šekspirovih drama." },
  { id:"neptun", name:"Neptun", c1:"#7aa4ff", c2:"#1e3da5", orbit:184, rr:9, rel:3.9, years:164.8, g:1.14,
    type:"Ledeni džin", dist:"4.495 miliona km", temp:"oko −214 °C", day:"oko 16 sati",
    year:"165 zemaljskih godina", moons:"16", icon:"🔵",
    how:"Najudaljenija planeta. Tamo duvaju najjači vetrovi u Sunčevom sistemu – oko 2.000 km na sat!",
    facts:["Od svih planeta najdalje je od Sunca.","Otkriven je 1846. – prvo računom, a tek onda teleskopom.","Prvi pun krug oko Sunca od svog otkrića završio je tek 2011. godine."],
    fun:"Sunce se sa Neptuna vidi kao veoma sjajna zvezda, ne mnogo veća od tačkice." },
];
PLANETS.forEach((p,i)=>p.idx=i);
const MOON_G = 0.166;

const SUN = { id:"sunce", name:"Sunce",
  facts:["Sunce je zvezda, a ne planeta – džinovska vruća lopta od gasa.","U njega bi stalo oko milion i tri stotine hiljada Zemalja.","Svetlost sa Sunca do nas putuje oko 8 minuta i 20 sekundi.","Na površini je oko 5.500 °C, a u središtu oko 15 miliona °C.","Ima gotovo svu masu Sunčevog sistema (99,8%)."],
  fun:"Nikada ne gledaj direktno u Sunce – oštetilo bi ti oči. Čak ni kroz običan dvogled!" };

const MOONS = [
  { id:"mesec", name:"Mesec", of:"Zemlja", size:"3.474 km (četvrtina Zemlje)", dist:"384.400 km od Zemlje",
    facts:["Ima ga samo jedan, i svi ga vidimo iz iste strane – uvek nam okrene isto „lice“.","Težina na njemu je šest puta manja nego na Zemlji.","Prvi čovek na njemu bio je Nil Armstrong, 20. jula 1969.","Tragovi stopala ostaju hiljadama godina jer tamo nema vetra."],
    fun:"Mesec se svake godine udalji od Zemlje za oko 4 centimetra – otprilike koliko ti raste nokat." },
  { id:"fobos", name:"Fobos", of:"Mars", size:"oko 22 km (kao veći grad)", dist:"oko 6.000 km iznad Marsa",
    facts:["Nije okrugao, nego oblika krompira.","Obiđe Mars tri puta za jedan dan!","Ima veliki krater po imenu Stikni."],
    fun:"Fobos se polako približava Marsu, pa će se za desetine miliona godina raspasti i možda postati prsten." },
  { id:"io", name:"Io", of:"Jupiter", size:"3.640 km", dist:"oko 422.000 km od Jupitera",
    facts:["Ima preko 400 aktivnih vulkana – najviše u Sunčevom sistemu.","Žut je od sumpora, izgleda kao pica.","Jupiter ga stalno „masira“ svojom težom, pa mu se unutra zagreva."],
    fun:"Vulkani na Iou izbacuju lavu stotinama kilometara u visinu!" },
  { id:"evropa", name:"Evropa", of:"Jupiter", size:"3.122 km", dist:"oko 671.000 km od Jupitera",
    facts:["Prekrivena je ledom, a ispod leda je okean tečne vode.","Naučnici misle da bi tamo mogao da postoji život.","Ledena kora ima pukotine kao tamna linija."],
    fun:"Pod ledom Evrope ima više vode nego u svim okeanima na Zemlji!" },
  { id:"ganimed", name:"Ganimed", of:"Jupiter", size:"5.268 km", dist:"oko 1.070.000 km od Jupitera",
    facts:["Najveći mesec u Sunčevom sistemu.","Veći je i od planete Merkur!","Ima svoje magnetno polje."],
    fun:"Kad bi Ganimed kružio oko Sunca, zvali bismo ga planetom." },
  { id:"titan", name:"Titan", of:"Saturn", size:"5.150 km", dist:"oko 1.222.000 km od Saturna",
    facts:["Ima gustu narandžastu atmosferu – jedini mesec sa tako gustim vazduhom.","Na njemu ima jezera i reka, ali od tečnog gasa (metana), ne od vode.","Sonda Hajgens sletela je 2005. godine."],
    fun:"Na Titanu bi čovek mogao da leti uz par krila na rukama – vazduh je gust, a težina mala!" },
  { id:"enkelad", name:"Enkelad", of:"Saturn", size:"oko 500 km", dist:"oko 238.000 km od Saturna",
    facts:["Mali, beli kao sneg.","Iz pukotina na južnom polu izbacuje fontane vode i leda.","I ispod njegovog leda je okean."],
    fun:"Mlazevi leda sa Enkelada čine jedan od Saturnovih prstenova." },
];

const SATS = [
  { id:"sputnjik", name:"Sputnjik 1", orbit:1, what:"Prvi veštački satelit",
    facts:["Poleteo je 4. oktobra 1957. godine.","Bio je kao velika lopta (58 cm) i samo je slao „bip-bip“ signal.","Svet je prvi put čuo da je čovek poslao nešto u svemir."], job:"" },
  { id:"iss", name:"Međunarodna svemirska stanica (ISS)", orbit:1, what:"Kuća astronauta u svemiru",
    facts:["Kruži oko 400 km iznad nas, brzinom od oko 28.000 km na sat.","Jedan krug oko Zemlje obiđe za oko 90 minuta, pa astronauti vide oko 16 izlazaka Sunca na dan.","Astronauti tamo neprekidno žive više od 20 godina i rade naučne oglede."], job:"Gde astronauti žive i rade u svemiru?" },
  { id:"hubble", name:"Teleskop Habl", orbit:1, what:"Svemirski fotoaparat",
    facts:["Poleteo 1990, veličine autobusa.","Iznad vazduha vidi mnogo oštrije od teleskopa na Zemlji.","Snimio je hiljade lepih slika galaksija."], job:"Koji satelit fotografiše daleke galaksije?" },
  { id:"gps", name:"GPS satelit", orbit:2, what:"Pokazuje gde si",
    facts:["Ima ih oko 30 na visini oko 20.200 km.","Telefon sluša signal sa više njih i izračuna gde si.","Zato mape na telefonu znaju put do škole."], job:"Koji satelit pomaže telefonu da zna gde si?" },
  { id:"meteo", name:"Meteorološki satelit", orbit:3, what:"Prati vreme",
    facts:["Visi iznad iste tačke, na oko 36.000 km.","Gleda oblake i oluje, pa vremenska prognoza zna da stiže kiša.","Upozorava na oluje i poplave."], job:"Koji satelit prati oblake i vreme?" },
  { id:"tv", name:"TV satelit", orbit:3, what:"Šalje TV i internet signal",
    facts:["Na 36.000 km, kruži jednom dnevno – isto koliko se Zemlja okrene, pa deluje kao da stoji u mestu.","Zato antena na kući može da „gleda“ uvek u istu tačku neba.","Prenosi program i do udaljenih sela."], job:"Koji satelit šalje televizijski signal u kuće?" },
];

const ROVERS = [
  { id:"lunohod", name:"Lunohod 1", where:"Mesec", year:"1970", wheels:8, kind:"lunar",
    facts:["Prvi robot-rover na drugom svetu, upravljan daljinski sa Zemlje.","Imao je 8 točkova i poklopac koji se otvarao da ga Sunce puni.","Prešao je oko 10 kilometara."], fun:"Izgledao je kao kada sa točkovima i poklopcem." },
  { id:"sojourner", name:"Sodžorner", where:"Mars", year:"1997", wheels:6, kind:"small",
    facts:["Prvi rover na Marsu. Veličine kutije za mleko.","Težak je samo oko 10 kg.","Prešao je oko 100 metara, ali dokazao da roveri rade!"], fun:"Kretao se sporo, kao veoma polagana šetnja." },
  { id:"curiosity", name:"Kjuriositi", where:"Mars, krater Gejl", year:"2012", wheels:6, kind:"big",
    facts:["Veličine malog automobila, težak oko 900 kg.","Ima robotsku ruku, kamere i laser kojim „gađa“ stene da vidi od čega su.","Sletio je tako što ga je spustila leteća „dizalica“ na užadima."], fun:"Našao je dokaze da je na Marsu nekad bilo vode." },
  { id:"perseverance", name:"Persirvrans", where:"Mars, krater Džezero", year:"2021", wheels:6, kind:"big",
    facts:["Skuplja uzorke stena u cevčice, da ih jednom donesemo na Zemlju.","Doneo je i mali helikopter Indženjuiti – prvi let na drugoj planeti!","Ima mikrofon pa smo čuli zvuk Marsa."], fun:"Signal sa Marsa do Zemlje putuje od 3 do 22 minuta." },
];

const LAYERS = [
  { id:"kora", name:"Kora", color:"#6b9a4b", r:1, t:"Tanka čvrsta „ljuska“ po kojoj hodamo. Debela je od 5 do 70 km – u odnosu na Zemlju je tanka kao kora jabuke." },
  { id:"omotac", name:"Omotač", color:"#d06a3a", r:.9, t:"Debeo sloj vrele, polutečne stene. Čini veći deo Zemlje. Kada se pomera, nastaju vulkani i zemljotresi." },
  { id:"spjez", name:"Spoljašnje jezgro", color:"#f0a63a", r:.55, t:"Tečno gvožđe i nikl. Njegovo kretanje stvara magnetno polje koje štiti Zemlju – zbog njega kompas pokazuje sever." },
  { id:"unjez", name:"Unutrašnje jezgro", color:"#ffe27a", r:.2, t:"Čvrsta lopta od gvožđa, topla oko 5.400 °C – kao površina Sunca!" },
];

const QUIZ = [
  // LAKO
  { lv:0, q:"Šta nam danju daje svetlost i toplotu?", o:["Mesec","Sunce","Mars"], a:1, e:"Sunce je zvezda koja nas greje i obasjava." },
  { lv:0, q:"Koliko planeta ima u našem Sunčevom sistemu?", o:["6","8","12"], a:1, e:"Osam: Merkur, Venera, Zemlja, Mars, Jupiter, Saturn, Uran i Neptun." },
  { lv:0, q:"Oko čega se okreće Mesec?", o:["Oko Zemlje","Oko Marsa","Oko Sunca samo"], a:0, e:"Mesec je Zemljin prirodni satelit i kruži oko nas." },
  { lv:0, q:"Koja planeta se zove „crvena planeta“?", o:["Venera","Jupiter","Mars"], a:2, e:"Mars je crven jer je tlo puno rđe." },
  { lv:0, q:"Koja je najveća planeta?", o:["Zemlja","Jupiter","Mars"], a:1, e:"U Jupitera bi stalo više od 1.300 Zemalja." },
  { lv:0, q:"Koja planeta ima prelepe prstenove?", o:["Saturn","Merkur","Zemlja"], a:0, e:"Saturnovi prstenovi su od leda i kamenja." },
  // SREDNJE
  { lv:1, q:"Kako se zove vozilo koje istražuje Mars?", o:["Rover","Traktor","Autobus"], a:0, e:"Rover! Curiosity i Perseverance vozaju po Marsu." },
  { lv:1, q:"Šta je Mesec?", o:["Zvezda","Prirodni satelit","Planeta"], a:1, e:"Mesec je prirodni satelit – nastao sam od prirode, a ne od ljudi." },
  { lv:1, q:"Koja planeta je najbliža Suncu?", o:["Merkur","Zemlja","Neptun"], a:0, e:"Merkur je prvi od Sunca." },
  { lv:1, q:"Zašto imamo dan i noć?", o:["Sunce se gasi i pali","Zemlja se okreće oko svoje ose","Mesec zaklanja Sunce"], a:1, e:"Zemlja se okrene jednom za 24 sata, pa je strana okrenuta Suncu danju, a druga noću." },
  { lv:1, q:"Ko je prvi hodao po Mesecu?", o:["Jurij Gagarin","Nil Armstrong","Kjuriositi"], a:1, e:"Nil Armstrong, 20. jula 1969. Gagarin je bio prvi čovek u svemiru (1961)." },
  { lv:1, q:"Šta radi GPS satelit?", o:["Pravi kišu","Pomaže da znamo gde smo","Pravi struju"], a:1, e:"GPS sateliti šalju signal pomoću kog telefon izračuna gde si." },
  // TEŠKO
  { lv:2, q:"Koja planeta je najtoplija?", o:["Merkur","Venera","Mars"], a:1, e:"Venera – 465 °C! Gusti oblaci drže toplotu kao ćebe." },
  { lv:2, q:"Koliko traje jedna godina na Zemlji?", o:["30 dana","365 dana","1.000 dana"], a:1, e:"Za 365 dana Zemlja obiđe Sunce jednom." },
  { lv:2, q:"Koja planeta „leži na boku“?", o:["Uran","Venera","Mars"], a:0, e:"Uran je nagnut skoro 98°, pa se kotrlja po svojoj putanji." },
  { lv:2, q:"Zašto Mesec menja oblik (mene)?", o:["Zemlja ga zasenči svake noći","Vidimo različit deo osvetljene strane","On raste i smanjuje se"], a:1, e:"Mesec je uvek jednako veliki, a mi ga gledamo iz različitih uglova u odnosu na Sunce." },
  { lv:2, q:"Koji je najveći mesec u Sunčevom sistemu?", o:["Mesec","Ganimed","Titan"], a:1, e:"Ganimed (Jupiterov) – veći je i od planete Merkur." },
  { lv:2, q:"Koliko Zemalja bi stalo u Sunce?", o:["Oko 100","Oko 1.000","Preko milion"], a:2, e:"Preko 1,3 miliona! Sunce je ogromno." },
];
const LEVELS = ["Lako","Srednje","Teško"];

const BADGES = [
  { id:"planete", icon:"🪐", name:"Istraživač planeta", how:"Otvori svih 8 planeta" },
  { id:"sunce", icon:"☀️", name:"Prijatelj Sunca", how:"Saznaj sve o Suncu" },
  { id:"zemlja", icon:"🌍", name:"Čuvar Zemlje", how:"Isprobaj dan, noć i godišnja doba" },
  { id:"mesec", icon:"🌙", name:"Lovac na mesece", how:"Prođi kroz sve mene Meseca" },
  { id:"sateliti", icon:"🛰️", name:"Satelitski majstor", how:"Pogodi sve zadatke sa satelitima" },
  { id:"rover", icon:"🤖", name:"Vozač rovera", how:"Prikupi uzorke na Marsu" },
  { id:"raketa", icon:"🚀", name:"Lansiranje!", how:"Sastavi i lansiraj raketu" },
  { id:"skok", icon:"🦘", name:"Skakač", how:"Skoči na 4 različita sveta" },
  { id:"poredak", icon:"🔢", name:"Majstor redosleda", how:"Poredaj planete od Sunca" },
  { id:"kviz", icon:"🏆", name:"Svemirski kviz", how:"Završi kviz" },
];
