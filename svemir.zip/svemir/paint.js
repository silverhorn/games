/* Crtanje: sve je nacrtano kodom (originalna ilustracija) */
"use strict";

function rnd(seed){ // mali determinističan generator da crteži uvek izgledaju isto
  let s=seed>>>0||1;
  return ()=>{ s=(s*1664525+1013904223)>>>0; return s/4294967296; };
}
function clipCircle(c,x,y,r,fn){ c.save(); c.beginPath(); c.arc(x,y,r,0,Math.PI*2); c.clip(); fn(); c.restore(); }
function shade(c,x,y,r,light){ // sjenka na desnoj-donjoj strani lopte
  const g=c.createRadialGradient(x-r*.35,y-r*.4,r*.1,x,y,r*1.05);
  g.addColorStop(0,"rgba(255,255,255,"+(light||.0)+")"); g.addColorStop(.55,"rgba(0,0,0,0)"); g.addColorStop(1,"rgba(0,0,20,.55)");
  c.fillStyle=g; c.beginPath(); c.arc(x,y,r,0,Math.PI*2); c.fill();
}
function ball(c,x,y,r,c1,c2){
  const g=c.createRadialGradient(x-r*.3,y-r*.35,r*.1,x,y,r);
  g.addColorStop(0,c1); g.addColorStop(1,c2);
  c.fillStyle=g; c.beginPath(); c.arc(x,y,r,0,Math.PI*2); c.fill();
}
function crater(c,x,y,r,col){ c.fillStyle=col; c.beginPath(); c.arc(x,y,r,0,7); c.fill(); c.strokeStyle="rgba(255,255,255,.18)"; c.lineWidth=Math.max(.5,r*.2); c.beginPath(); c.arc(x-r*.15,y-r*.15,r,3.4,5.6); c.stroke(); }

function paintSun(c,x,y,r,t){
  const glow=c.createRadialGradient(x,y,r*.6,x,y,r*2.6);
  glow.addColorStop(0,"rgba(255,200,60,.55)"); glow.addColorStop(1,"rgba(255,160,20,0)");
  c.fillStyle=glow; c.beginPath(); c.arc(x,y,r*2.6,0,7); c.fill();
  const rays=14; c.strokeStyle="rgba(255,205,70,.55)"; c.lineWidth=Math.max(1.5,r*.1); c.lineCap="round";
  for(let i=0;i<rays;i++){ const a=i/rays*Math.PI*2+(t||0)*.15, l=r*(1.25+.12*Math.sin((t||0)*2+i)); c.beginPath(); c.moveTo(x+Math.cos(a)*r*1.1,y+Math.sin(a)*r*1.1); c.lineTo(x+Math.cos(a)*l*1.25,y+Math.sin(a)*l*1.25); c.stroke(); }
  ball(c,x,y,r,"#fff6b0","#ff9d1c");
  // zadovoljno lice
  c.fillStyle="#7a3b00"; c.beginPath(); c.arc(x-r*.32,y-r*.1,r*.09,0,7); c.arc(x+r*.32,y-r*.1,r*.09,0,7); c.fill();
  c.strokeStyle="#7a3b00"; c.lineWidth=Math.max(1,r*.07); c.beginPath(); c.arc(x,y+r*.05,r*.38,.25,Math.PI-.25); c.stroke();
}

function paintPlanet(c,x,y,r,id){
  const p=PLANETS.find(q=>q.id===id);
  if(id==="saturn"){ ring(c,x,y,r,true); }
  ball(c,x,y,r,p.c1,p.c2);
  const R=rnd(id.length*977+r|0);
  clipCircle(c,x,y,r,()=>{
    if(id==="merkur"){ for(let i=0;i<9;i++) crater(c,x+(R()-.5)*r*1.5,y+(R()-.5)*r*1.5,r*(.07+R()*.12),"rgba(70,60,55,.45)"); }
    if(id==="venera"){ c.lineWidth=r*.12; for(let i=0;i<6;i++){ c.strokeStyle="rgba(255,255,255,"+(.12+R()*.18)+")"; c.beginPath(); c.arc(x-r*.2+i*r*.1,y+(R()-.5)*r*.4,r*(.5+i*.15),3.6,5.6); c.stroke(); } }
    if(id==="zemlja"){
      c.fillStyle="#58b369"; for(let i=0;i<6;i++){ c.beginPath(); c.ellipse(x+(R()-.5)*r*1.3,y+(R()-.5)*r*1.3,r*(.14+R()*.22),r*(.1+R()*.2),R()*3,0,7); c.fill(); }
      c.fillStyle="rgba(255,255,255,.55)"; for(let i=0;i<5;i++){ c.beginPath(); c.ellipse(x+(R()-.5)*r*1.5,y+(R()-.5)*r*1.5,r*(.2+R()*.25),r*.07,R()*.8,0,7); c.fill(); }
      c.fillStyle="rgba(255,255,255,.8)"; c.beginPath(); c.ellipse(x,y-r*.95,r*.45,r*.15,0,0,7); c.fill();
    }
    if(id==="mars"){
      c.fillStyle="rgba(110,35,15,.35)"; for(let i=0;i<4;i++){ c.beginPath(); c.ellipse(x+(R()-.5)*r,y+(R()-.5)*r,r*(.15+R()*.2),r*(.1+R()*.12),R()*3,0,7); c.fill(); }
      c.fillStyle="rgba(255,255,255,.85)"; c.beginPath(); c.ellipse(x,y-r*.92,r*.35,r*.13,0,0,7); c.fill();
    }
    if(id==="jupiter"||id==="saturn"){
      const cols = id==="jupiter" ? ["#c98b5a","#f4e1c3","#a9693d","#ecd2ab","#b97a4a","#f6e5c8"] : ["#d9bd7e","#f6e7bd","#c3a361","#efddae","#d0b273","#f7ecc8"];
      cols.forEach((col,i)=>{ c.fillStyle=col; c.globalAlpha=.7; c.fillRect(x-r,y-r+(i/cols.length)*r*2+(i%2)*r*.03,r*2,r*.3); });
      c.globalAlpha=1;
      if(id==="jupiter"){ c.fillStyle="#c4532d"; c.beginPath(); c.ellipse(x+r*.28,y+r*.3,r*.2,r*.12,0,0,7); c.fill(); c.strokeStyle="rgba(255,240,220,.6)"; c.lineWidth=r*.03; c.stroke(); }
    }
    if(id==="uran"){ c.fillStyle="rgba(255,255,255,.2)"; c.fillRect(x-r,y-r*.12,r*2,r*.24); c.fillStyle="rgba(255,255,255,.1)"; c.fillRect(x-r,y+r*.35,r*2,r*.18); }
    if(id==="neptun"){ c.strokeStyle="rgba(255,255,255,.55)"; c.lineWidth=r*.07; c.lineCap="round"; c.beginPath(); c.moveTo(x-r*.6,y-r*.2); c.quadraticCurveTo(x,y-r*.35,x+r*.55,y-r*.1); c.stroke(); c.fillStyle="rgba(10,20,80,.45)"; c.beginPath(); c.ellipse(x-r*.25,y+r*.25,r*.2,r*.12,0,0,7); c.fill(); }
  });
  shade(c,x,y,r,.28);
  if(id==="saturn"){ ring(c,x,y,r,false); }
  if(id==="uran" && r>16){ c.strokeStyle="rgba(210,245,245,.55)"; c.lineWidth=Math.max(1,r*.05); c.beginPath(); c.ellipse(x,y,r*.28,r*1.7,0,0,7); c.stroke(); }
}
function ring(c,x,y,r,back){
  c.save(); c.translate(x,y); c.rotate(-.32);
  const cols=[["rgba(214,190,130,.9)",1.55,.45],["rgba(240,226,180,.9)",1.85,.55],["rgba(190,165,110,.8)",2.1,.6]];
  cols.forEach(([col,k,w])=>{ c.strokeStyle=col; c.lineWidth=Math.max(1,r*.13); c.beginPath(); c.ellipse(0,0,r*k,r*k*.3,0,back?Math.PI:0,back?Math.PI*2:Math.PI); c.stroke(); });
  c.restore();
}

function paintMoon(c,x,y,r,id){
  const R=rnd(id.length*131);
  if(id==="fobos"){ // krompir
    c.save(); c.translate(x,y); c.rotate(-.35);
    const g=c.createRadialGradient(-r*.3,-r*.3,r*.1,0,0,r*1.2); g.addColorStop(0,"#b9a99a"); g.addColorStop(1,"#5a4c44");
    c.fillStyle=g; c.beginPath(); c.moveTo(-r,0); c.bezierCurveTo(-r,-r*.8,r*.5,-r*.9,r,-r*.1); c.bezierCurveTo(r*1.05,r*.7,-r*.2,r*.85,-r,0); c.fill();
    crater(c,-r*.3,-r*.15,r*.28,"rgba(40,30,25,.5)"); crater(c,r*.35,r*.15,r*.13,"rgba(40,30,25,.45)"); crater(c,r*.05,r*.4,r*.09,"rgba(40,30,25,.4)");
    c.restore(); return;
  }
  const base={mesec:["#f1f1ee","#8b8b92"],io:["#ffe96b","#c47a1e"],evropa:["#f4efe9","#a58d7d"],ganimed:["#c9bdb0","#6d6159"],titan:["#ffc66a","#b4651b"],enkelad:["#ffffff","#a9c8e6"]}[id];
  ball(c,x,y,r,base[0],base[1]);
  clipCircle(c,x,y,r,()=>{
    if(id==="mesec"){ for(let i=0;i<10;i++) crater(c,x+(R()-.5)*r*1.6,y+(R()-.5)*r*1.6,r*(.06+R()*.14),"rgba(80,80,90,.35)"); }
    if(id==="io"){ c.fillStyle="#8a3a12"; for(let i=0;i<8;i++){ c.beginPath(); c.arc(x+(R()-.5)*r*1.5,y+(R()-.5)*r*1.5,r*(.04+R()*.07),0,7); c.fill(); } c.fillStyle="rgba(255,255,255,.4)"; c.beginPath(); c.arc(x-r*.3,y+r*.2,r*.1,0,7); c.fill(); }
    if(id==="evropa"){ c.strokeStyle="rgba(150,70,40,.7)"; c.lineWidth=Math.max(1,r*.04); for(let i=0;i<8;i++){ c.beginPath(); c.moveTo(x+(R()-.5)*r*2,y+(R()-.5)*r*2); c.lineTo(x+(R()-.5)*r*2,y+(R()-.5)*r*2); c.stroke(); } }
    if(id==="ganimed"){ c.fillStyle="rgba(60,50,45,.4)"; for(let i=0;i<5;i++){ c.beginPath(); c.ellipse(x+(R()-.5)*r*1.4,y+(R()-.5)*r*1.4,r*(.15+R()*.2),r*(.1+R()*.15),R()*3,0,7); c.fill(); } for(let i=0;i<4;i++) crater(c,x+(R()-.5)*r*1.4,y+(R()-.5)*r*1.4,r*.07,"rgba(255,255,255,.5)"); }
    if(id==="titan"){ c.fillStyle="rgba(255,190,90,.35)"; c.fillRect(x-r,y-r*.2,r*2,r*.5); }
    if(id==="enkelad"){ c.strokeStyle="rgba(120,170,220,.8)"; c.lineWidth=Math.max(1,r*.05); for(let i=0;i<5;i++){ c.beginPath(); c.moveTo(x-r+(i+.5)*r*.4,y+r*.5); c.lineTo(x-r+(i+.7)*r*.4,y-r*.3); c.stroke(); } }
  });
  shade(c,x,y,r,.25);
  if(id==="titan"){ c.strokeStyle="rgba(255,170,60,.45)"; c.lineWidth=r*.1; c.beginPath(); c.arc(x,y,r*1.05,0,7); c.stroke(); }
  if(id==="enkelad"){ c.fillStyle="rgba(160,210,255,.7)"; for(let i=0;i<6;i++){ c.beginPath(); c.arc(x+r*.3+(R()-.5)*r*.3,y+r*1.1+i*r*.15,r*.05,0,7); c.fill(); } }
}

function moonPhaseShape(c,x,y,r,p){ // p: 0..1 (0 = mlad, .5 = pun)
  ball(c,x,y,r,"#2b3162","#141836");
  const a=p*2*Math.PI, k=Math.cos(a), waning=p>.5;
  c.save(); if(waning){ c.translate(x*2,0); c.scale(-1,1); }
  c.beginPath();
  for(let i=0;i<=40;i++){ const th=i/40*Math.PI; const px=x+r*Math.sin(th), py=y-r*Math.cos(th); i?c.lineTo(px,py):c.moveTo(px,py); }
  for(let i=40;i>=0;i--){ const th=i/40*Math.PI; c.lineTo(x+r*k*Math.sin(th),y-r*Math.cos(th)); }
  c.closePath();
  const g=c.createRadialGradient(x-r*.2,y-r*.2,r*.1,x,y,r); g.addColorStop(0,"#fffbe8"); g.addColorStop(1,"#d9d6c8");
  c.fillStyle=g; c.fill();
  c.restore();
  c.strokeStyle="rgba(255,255,255,.2)"; c.lineWidth=1.5; c.beginPath(); c.arc(x,y,r,0,7); c.stroke();
}

function paintAstronaut(c,x,y,s,pose){ // (x,y) = stopala, s = visina; pose: 0 stoji, 1 skače (ruke gore)
  c.save(); c.translate(x,y); c.scale(s/100,s/100);
  c.lineCap="round"; c.lineJoin="round";
  c.fillStyle="#e8ecf8"; c.strokeStyle="#7f8bb5"; c.lineWidth=2;
  // rančić
  c.fillStyle="#c6cde6"; c.beginPath(); c.roundRect(-30,-72,16,38,6); c.fill(); c.stroke();
  // noge
  c.fillStyle="#e8ecf8"; c.beginPath(); c.roundRect(-14,-28,12,28,6); c.roundRect(2,-28,12,28,6); c.fill(); c.stroke();
  c.fillStyle="#ff8a4a"; c.beginPath(); c.roundRect(-16,-6,16,8,4); c.roundRect(0,-6,16,8,4); c.fill();
  // telo
  c.fillStyle="#f3f5ff"; c.beginPath(); c.roundRect(-20,-72,40,48,14); c.fill(); c.stroke();
  c.fillStyle="#7be0c3"; c.fillRect(-8,-56,16,8); c.fillStyle="#ff8fb1"; c.beginPath(); c.arc(8,-40,3,0,7); c.fill(); c.fillStyle="#6aa8ff"; c.beginPath(); c.arc(-2,-40,3,0,7); c.fill();
  // ruke
  c.strokeStyle="#e8ecf8"; c.lineWidth=11; c.beginPath();
  if(pose){ c.moveTo(-18,-64); c.lineTo(-30,-92); c.moveTo(18,-64); c.lineTo(30,-92); }
  else { c.moveTo(-18,-62); c.lineTo(-27,-40); c.moveTo(18,-62); c.lineTo(27,-40); }
  c.stroke();
  c.strokeStyle="#7f8bb5"; c.lineWidth=1.5; c.stroke();
  // kaciga
  c.fillStyle="#f6f8ff"; c.strokeStyle="#7f8bb5"; c.lineWidth=2; c.beginPath(); c.arc(0,-86,23,0,7); c.fill(); c.stroke();
  const vg=c.createLinearGradient(-14,-96,14,-72); vg.addColorStop(0,"#32407f"); vg.addColorStop(1,"#0f1638");
  c.fillStyle=vg; c.beginPath(); c.roundRect(-15,-96,30,20,9); c.fill();
  c.fillStyle="rgba(255,255,255,.6)"; c.beginPath(); c.ellipse(-6,-90,5,3,-.5,0,7); c.fill();
  c.restore();
}

function paintRover(c,x,y,s,kind,t){ // (x,y) = tlo ispod točkova, s = širina
  c.save(); c.translate(x,y); c.scale(s/100,s/100); c.lineJoin="round"; c.lineCap="round";
  const wheels=kind==="lunar"?4:3, wr=kind==="small"?9:11;
  // ramena točkova
  c.strokeStyle="#9aa3c0"; c.lineWidth=3; c.beginPath(); c.moveTo(-34,-22); c.lineTo(-34,-wr); c.moveTo(0,-22); c.lineTo(0,-wr); c.moveTo(34,-22); c.lineTo(34,-wr); c.stroke();
  // telo
  if(kind==="lunar"){
    c.fillStyle="#cfd5e8"; c.beginPath(); c.roundRect(-40,-52,80,32,10); c.fill();
    c.fillStyle="#e6e9f6"; c.beginPath(); c.ellipse(0,-52,40,16,0,Math.PI,0); c.fill();
    c.strokeStyle="#6f7aa8"; c.lineWidth=2; c.stroke();
    c.fillStyle="#ffd54a"; c.beginPath(); c.arc(-14,-38,5,0,7); c.arc(14,-38,5,0,7); c.fill();
  } else {
    c.fillStyle="#e5e8f4"; c.beginPath(); c.roundRect(-42,-52,84,32,8); c.fill(); c.strokeStyle="#6f7aa8"; c.lineWidth=2; c.stroke();
    c.fillStyle="#2c4fa3"; c.beginPath(); c.roundRect(-38,-62,76,10,3); c.fill();
    c.strokeStyle="#6aa8ff"; c.lineWidth=1; c.beginPath(); for(let i=-26;i<=26;i+=13){ c.moveTo(i,-62); c.lineTo(i,-52); } c.stroke();
    if(kind==="big"){
      c.strokeStyle="#cfd5e8"; c.lineWidth=4; c.beginPath(); c.moveTo(24,-60); c.lineTo(24,-86); c.stroke();
      c.fillStyle="#f6f8ff"; c.strokeStyle="#6f7aa8"; c.lineWidth=2; c.beginPath(); c.roundRect(14,-98,22,14,4); c.fill(); c.stroke();
      c.fillStyle="#1c2350"; c.beginPath(); c.arc(21,-91,3.4,0,7); c.arc(30,-91,3.4,0,7); c.fill();
      c.strokeStyle="#cfd5e8"; c.lineWidth=4; c.beginPath(); c.moveTo(-42,-38); c.lineTo(-56,-30); c.lineTo(-58,-20); c.stroke();
    } else { c.fillStyle="#1c2350"; c.beginPath(); c.arc(0,-38,4,0,7); c.fill(); }
  }
  // točkovi
  [-34,0,34].forEach(wx=>{
    c.fillStyle="#2a2f52"; c.beginPath(); c.arc(wx,-wr,wr,0,7); c.fill();
    c.strokeStyle="#9aa3c0"; c.lineWidth=2; c.beginPath(); c.arc(wx,-wr,wr*.55,0,7); c.stroke();
    const a=(t||0)*3; c.beginPath(); c.moveTo(wx,-wr); c.lineTo(wx+Math.cos(a)*wr*.55,-wr+Math.sin(a)*wr*.55); c.stroke();
  });
  c.restore();
}

function paintRocket(c,x,y,s,parts,flame,t){ // (x,y) = dno rakete, s = visina celog sklopa
  c.save(); c.translate(x,y); c.scale(s/220,s/220); c.lineJoin="round";
  const wob=Math.sin((t||0)*30)*(flame?1.5:0);
  c.translate(wob,0);
  if(parts>=1){ // motori
    c.fillStyle="#7d86a8"; c.beginPath(); c.moveTo(-20,-10); c.lineTo(20,-10); c.lineTo(28,0); c.lineTo(-28,0); c.closePath(); c.fill();
    c.fillStyle="#9ba4c6"; c.beginPath(); c.roundRect(-30,-22,60,14,5); c.fill();
    if(flame){ const h=36+Math.random()*24; const g=c.createLinearGradient(0,0,0,h); g.addColorStop(0,"#fff6b0"); g.addColorStop(.5,"#ffb52e"); g.addColorStop(1,"rgba(255,80,20,0)");
      c.fillStyle=g; c.beginPath(); c.moveTo(-20,0); c.quadraticCurveTo(0,h*1.3,20,0); c.closePath(); c.fill(); }
  }
  if(parts>=2){ // rezervoar
    c.fillStyle="#f4f6ff"; c.strokeStyle="#8b94bd"; c.lineWidth=2; c.beginPath(); c.roundRect(-26,-132,52,112,6); c.fill(); c.stroke();
    c.fillStyle="#ff6b6b"; c.fillRect(-26,-90,52,12); c.fillStyle="#6aa8ff"; c.fillRect(-26,-70,52,6);
    c.fillStyle="#ff6b6b"; c.beginPath(); c.moveTo(-26,-24); c.lineTo(-48,0); c.lineTo(-26,-2); c.closePath(); c.moveTo(26,-24); c.lineTo(48,0); c.lineTo(26,-2); c.closePath(); c.fill();
  }
  if(parts>=3){ // kapsula
    c.fillStyle="#f4f6ff"; c.strokeStyle="#8b94bd"; c.beginPath(); c.moveTo(-26,-132); c.quadraticCurveTo(-26,-190,0,-218); c.quadraticCurveTo(26,-190,26,-132); c.closePath(); c.fill(); c.stroke();
    c.fillStyle="#2c4fa3"; c.beginPath(); c.arc(0,-168,12,0,7); c.fill(); c.strokeStyle="#cfd5e8"; c.lineWidth=3; c.stroke();
    c.fillStyle="rgba(255,255,255,.55)"; c.beginPath(); c.ellipse(-4,-172,4,3,-.6,0,7); c.fill();
  }
  c.restore();
}

function paintSat(c,x,y,s,id,rot){
  c.save(); c.translate(x,y); c.rotate(rot||0); c.scale(s/40,s/40); c.lineJoin="round";
  const panel=(px)=>{ c.fillStyle="#2c4fa3"; c.strokeStyle="#9fc0ff"; c.lineWidth=1; c.beginPath(); c.rect(px,-6,16,12); c.fill(); c.stroke(); c.beginPath(); c.moveTo(px+8,-6); c.lineTo(px+8,6); c.moveTo(px,0); c.lineTo(px+16,0); c.stroke(); };
  if(id==="sputnjik"){
    c.strokeStyle="#cfd5e8"; c.lineWidth=1.5; [[-24,-14],[-24,14],[24,-14],[24,14]].forEach(([ax,ay])=>{ c.beginPath(); c.moveTo(0,0); c.lineTo(ax,ay*.6); c.stroke(); });
    ball(c,0,0,9,"#f1f3ff","#7f89b3");
  } else if(id==="iss"){
    c.fillStyle="#cfd5e8"; c.fillRect(-4,-3,8,6); c.fillStyle="#9fa9cd"; c.fillRect(-14,-2,28,4);
    [-26,-14,14,26].forEach(px=>{ c.fillStyle="#e0a43a"; c.fillRect(px-5,-12,10,24); c.strokeStyle="#7a5410"; c.lineWidth=.8; c.strokeRect(px-5,-12,10,24); });
  } else if(id==="hubble"){
    c.fillStyle="#cfd5e8"; c.beginPath(); c.roundRect(-9,-6,18,12,3); c.fill(); c.fillStyle="#7f89b3"; c.fillRect(-13,-4,4,8);
    c.fillStyle="#1c2350"; c.beginPath(); c.arc(9,0,4,0,7); c.fill(); panel(-30); panel(14);
  } else if(id==="gps"){
    c.fillStyle="#e0b44a"; c.beginPath(); c.roundRect(-6,-6,12,12,2); c.fill(); panel(-24); panel(8);
    c.strokeStyle="#7be0c3"; c.lineWidth=1; c.beginPath(); c.arc(0,8,5,.2,Math.PI-.2); c.arc(0,8,9,.2,Math.PI-.2); c.stroke();
  } else if(id==="meteo"){
    c.fillStyle="#f4f6ff"; c.beginPath(); c.roundRect(-7,-7,14,14,3); c.fill(); panel(-26); panel(10);
    c.fillStyle="#6aa8ff"; c.beginPath(); c.arc(0,0,3.2,0,7); c.fill();
  } else { // tv
    c.fillStyle="#cfd5e8"; c.beginPath(); c.roundRect(-6,-6,12,12,2); c.fill(); panel(-24); panel(8);
    c.fillStyle="#f4f6ff"; c.beginPath(); c.ellipse(0,9,9,4,0,0,Math.PI); c.fill();
  }
  c.restore();
}

function paintStars(c,w,h,seed,n,off,alpha){
  const R=rnd(seed); c.fillStyle="#fff";
  for(let i=0;i<n;i++){ const x=R()*w, y=((R()*h+(off||0))%h+h)%h, s=R()*1.6+.3; c.globalAlpha=(alpha||1)*(.4+R()*.6); c.fillRect(x,y,s,s); }
  c.globalAlpha=1;
}
