SVEMIRSKA AVANTURA – igra za decu 7–10 godina
Raspakuj zip i otvori index.html u pregledaču (ne treba server ni internet).
Fajlovi: index.html, style.css, data.js, paint.js, app.js – sve ostaje u istom folderu.
