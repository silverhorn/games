/* Svemirska avantura – logika igre */
"use strict";

/* ---------- pomoćne funkcije ---------- */
const $=(s,r=document)=>r.querySelector(s), $$=(s,r=document)=>[...r.querySelectorAll(s)];
const esc=s=>String(s).replace(/[&<>"]/g,m=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;"}[m]));
const clamp=(v,a,b)=>Math.max(a,Math.min(b,v));
const fmt=(n,d=1)=>Number(n).toFixed(d).replace(".",",");
const shuffle=a=>{ a=a.slice(); for(let i=a.length-1;i>0;i--){ const j=Math.floor(Math.random()*(i+1)); [a[i],a[j]]=[a[j],a[i]]; } return a; };
const viewW=pad=>Math.max(240,document.documentElement.clientWidth-pad);
function setupCanvas(cv,w,h){
  const dpr=Math.min(window.devicePixelRatio||1,2);
  cv.width=Math.round(w*dpr); cv.height=Math.round(h*dpr); cv.style.width=w+"px"; cv.style.height=h+"px";
  const c=cv.getContext("2d"); c.setTransform(dpr,0,0,dpr,0,0); c._dpr=dpr; return c;
}
function pos(ev,cv,lw,lh){ const r=cv.getBoundingClientRect(); return [(ev.clientX-r.left)/r.width*lw,(ev.clientY-r.top)/r.height*lh]; }

const store={
  get(k,d){ try{ const v=localStorage.getItem("svemir_"+k); return v==null?d:JSON.parse(v); }catch(e){ return d; } },
  set(k,v){ try{ localStorage.setItem("svemir_"+k,JSON.stringify(v)); }catch(e){} }
};
const S={ kg:store.get("kg",25), badges:new Set(store.get("badges",[])), seen:new Set(store.get("seen",[])),
  jumped:new Set(store.get("jumped",[])), sound:store.get("sound",true) };

/* ---------- zvuk ---------- */
let AC=null;
function ac(){ if(!S.sound) return null; try{ AC=AC||new (window.AudioContext||window.webkitAudioContext)(); if(AC.state==="suspended") AC.resume(); }catch(e){ AC=null; } return AC; }
function tone(f,d,type,v,delay){ const a=ac(); if(!a) return; try{
  const o=a.createOscillator(), g=a.createGain(), t=a.currentTime+(delay||0); o.type=type||"sine"; o.frequency.value=f;
  g.gain.setValueAtTime(v||.1,t); g.gain.exponentialRampToValueAtTime(.0001,t+d); o.connect(g); g.connect(a.destination); o.start(t); o.stop(t+d+.02); }catch(e){} }
function rumble(sec){ const a=ac(); if(!a) return; try{
  const n=a.sampleRate*sec, b=a.createBuffer(1,n,a.sampleRate), d=b.getChannelData(0); for(let i=0;i<n;i++) d[i]=Math.random()*2-1;
  const s=a.createBufferSource(); s.buffer=b; const f=a.createBiquadFilter(); f.type="lowpass"; f.frequency.value=380;
  const g=a.createGain(); g.gain.setValueAtTime(.0001,a.currentTime); g.gain.exponentialRampToValueAtTime(.25,a.currentTime+.6); g.gain.exponentialRampToValueAtTime(.0001,a.currentTime+sec);
  s.connect(f); f.connect(g); g.connect(a.destination); s.start(); }catch(e){} }
const sfx={ tap(){ tone(540,.07,"sine",.07); }, ok(){ tone(660,.12,"sine",.1); tone(880,.2,"sine",.1,.1); }, no(){ tone(200,.2,"triangle",.09); },
  win(){ [523,659,784,1047].forEach((f,i)=>tone(f,.22,"sine",.1,i*.1)); }, beep(){ tone(880,.12,"square",.05); }, pop(){ tone(760,.06,"sine",.08); } };

/* ---------- toast i značke ---------- */
let toastT=0;
function toast(msg){ const t=$("#toast"); t.textContent=msg; t.classList.add("show"); clearTimeout(toastT); toastT=setTimeout(()=>t.classList.remove("show"),2800); }
function award(id){
  if(S.badges.has(id)) return; S.badges.add(id); store.set("badges",[...S.badges]);
  const b=BADGES.find(x=>x.id===id); toast("🏅 Nova značka: "+b.name+"!"); sfx.win(); renderBadges();
}
function renderBadges(){
  const box=$("#badges"); if(!box) return;
  box.innerHTML=BADGES.map(b=>`<button class="badge ${S.badges.has(b.id)?"on":""}" data-b="${b.id}" title="${esc(b.name)}: ${esc(b.how)}" aria-label="${esc(b.name)}">${b.icon}</button>`).join("");
  $("#badgeCount").textContent=`(${S.badges.size} od ${BADGES.length})`;
  $$(".badge",box).forEach(el=>el.onclick=()=>{ const b=BADGES.find(x=>x.id===el.dataset.b); toast((S.badges.has(b.id)?"✅ ":"🔒 ")+b.name+" – "+b.how); sfx.tap(); });
}

/* ---------- petlja za animaciju ---------- */
let raf=0, loopFn=null;
function stopLoop(){ cancelAnimationFrame(raf); loopFn=null; }
function runLoop(fn){ stopLoop(); loopFn=fn; let last=performance.now(); const f=t=>{ if(loopFn!==fn) return; const dt=Math.min(.05,(t-last)/1000); last=t; fn(dt,t/1000); raf=requestAnimationFrame(f); }; raf=requestAnimationFrame(f); }

/* ---------- donji list (sheet) ---------- */
function openSheet(html,after){
  $("#sheetBody").innerHTML=html; $("#sheet").hidden=false; $(".sheet-card").scrollTop=0; if(after) after($("#sheetBody")); sfx.pop();
}
function closeSheet(){ $("#sheet").hidden=true; $("#sheetBody").innerHTML=""; }
$("#sheetX").onclick=closeSheet;
$("#sheet").addEventListener("click",e=>{ if(e.target.id==="sheet") closeSheet(); });
document.addEventListener("keydown",e=>{ if(e.key==="Escape") closeSheet(); });
const factsHTML=a=>`<ul class="facts">${a.map(f=>`<li>${esc(f)}</li>`).join("")}</ul>`;

/* ---------- ruter ---------- */
let current="home", first=true;
const TITLES={home:"🚀 Svemirska avantura",system:"☀️ Sunčev sistem",earth:"🌍 Zemlja",moons:"🌙 Meseci",sats:"🛰️ Sateliti",rovers:"🤖 Roveri",rockets:"🚀 Rakete",games:"🎮 Igre"};
const VIEWS={};
function go(v){
  stopLoop(); closeSheet(); current=v;
  $$(".view").forEach(el=>el.hidden=el.id!=="v-"+v);
  $("#back").hidden=v==="home"; $("#title").textContent=TITLES[v];
  window.scrollTo(0,0); VIEWS[v]&&VIEWS[v](); if(!first) sfx.tap(); first=false;
}
$("#back").onclick=()=>go("home");
$("#snd").textContent=S.sound?"🔊":"🔇";
$("#snd").onclick=()=>{ S.sound=!S.sound; store.set("sound",S.sound); $("#snd").textContent=S.sound?"🔊":"🔇"; if(S.sound) sfx.ok(); };

/* ---------- početna ---------- */
const TILES=[
  ["system","Sunčev sistem","Sunce i 8 planeta",c=>paintSun(c,38,38,13,0)],
  ["earth","Zemlja","Dan, noć i godišnja doba",c=>paintPlanet(c,38,38,28,"zemlja")],
  ["moons","Meseci","Prirodni sateliti",c=>paintMoon(c,38,38,28,"mesec")],
  ["sats","Sateliti","Veštački sateliti",c=>paintSat(c,38,38,52,"iss",-.2)],
  ["rovers","Roveri","Vozila na Marsu",c=>paintRover(c,38,66,66,"big",0)],
  ["rockets","Rakete i šatl","Sastavi i lansiraj",c=>paintRocket(c,38,72,70,3,false,0)],
  ["games","Igre","Skoči, poredaj, kviz",c=>paintAstronaut(c,38,70,64,0)],
];
VIEWS.home=function(){
  const box=$("#tiles");
  if(!box.children.length){
    box.innerHTML=TILES.map(t=>`<button class="tile" data-go="${t[0]}"><canvas></canvas><b>${t[1]}</b><small>${t[2]}</small></button>`).join("");
    $$(".tile",box).forEach((el,i)=>{ const c=setupCanvas($("canvas",el),76,76); TILES[i][3](c); el.onclick=()=>go(el.dataset.go); });
  }
  renderBadges();
  const hc=setupCanvas($("#homeSun"),96,96);
  runLoop((dt,t)=>{ hc.clearRect(0,0,96,96); paintSun(hc,48,48,22,t); });
};

/* ---------- Sunčev sistem ---------- */
const SYS={ang:[],speed:1};
VIEWS.system=function(){
  const cv=$("#sysCv"), w=Math.min(560,viewW(28)), c=setupCanvas(cv,w,w), k=w/400;
  if(!SYS.ang.length) SYS.ang=PLANETS.map((p,i)=>i*.85+.4);
  const posOf=i=>[200+PLANETS[i].orbit*Math.cos(SYS.ang[i]),200+PLANETS[i].orbit*Math.sin(SYS.ang[i])];
  cv.onclick=e=>{
    const [x,y]=pos(e,cv,400,400); let best=-1,bd=1e9;
    PLANETS.forEach((p,i)=>{ const [px,py]=posOf(i); const d=Math.hypot(x-px,y-py)-p.rr; if(d<16&&d<bd){ bd=d; best=i; } });
    if(best>=0) planetSheet(PLANETS[best]); else if(Math.hypot(x-200,y-200)<30) sunSheet();
  };
  $$("[data-speed]").forEach(b=>b.onclick=()=>{ SYS.speed=+b.dataset.speed; $$("[data-speed]").forEach(x=>x.classList.toggle("on",x===b)); sfx.tap(); });
  buildStrip();
  runLoop((dt,t)=>{
    PLANETS.forEach((p,i)=>SYS.ang[i]+=dt*SYS.speed*.55/Math.pow(p.years,.72));
    c.setTransform(c._dpr*k,0,0,c._dpr*k,0,0); c.clearRect(0,0,400,400);
    paintStars(c,400,400,11,70,0,.8);
    c.strokeStyle="rgba(255,255,255,.12)"; c.lineWidth=1;
    PLANETS.forEach(p=>{ c.beginPath(); c.arc(200,200,p.orbit,0,7); c.stroke(); });
    paintSun(c,200,200,17,t);
    c.font="600 11px Trebuchet MS, sans-serif"; c.textAlign="center";
    PLANETS.forEach((p,i)=>{ const [x,y]=posOf(i); paintPlanet(c,x,y,p.rr,p.id);
      c.fillStyle=S.seen.has(p.id)?"rgba(180,255,220,.95)":"rgba(255,255,255,.85)"; c.fillText(p.name,x,y+p.rr+(p.id==="saturn"?18:12)); });
  });
};
function buildStrip(){
  const box=$("#strip"); box.innerHTML="";
  PLANETS.forEach(p=>{
    const d=Math.max(9,p.rel*10), pad=p.id==="saturn"?1.1:0.15, w=Math.round(d*(1+pad*2))+4, h=Math.round(d*1.7)+4;
    const b=document.createElement("button"); const cv=document.createElement("canvas"); b.appendChild(cv);
    const c=setupCanvas(cv,w,Math.min(h,d+20)); paintPlanet(c,w/2,Math.min(h,d+20)/2,d/2,p.id);
    const s=document.createElement("small"); s.textContent=p.name; b.appendChild(s); b.onclick=()=>planetSheet(p); box.appendChild(b);
  });
}
function markSeen(id){ if(!S.seen.has(id)){ S.seen.add(id); store.set("seen",[...S.seen]); } if(PLANETS.every(p=>S.seen.has(p.id))) award("planete"); }
function planetSheet(p){
  markSeen(p.id);
  openSheet(`<h2>${p.icon} ${esc(p.name)}</h2>
    <canvas id="shCv"></canvas>
    <div><span class="pill">${esc(p.type)}</span><span class="pill">${esc(p.dist)} od Sunca</span><span class="pill">meseci: ${esc(p.moons)}</span></div>
    <div class="how"><div><b>🌡️ Temperatura</b>${esc(p.temp)}</div><div><b>☀️ Jedan dan traje</b>${esc(p.day)}</div>
      <div><b>📅 Jedna godina</b>${esc(p.year)}</div><div><b>⚖️ Tvoja težina</b><span id="shKg"></span></div></div>
    <label>Koliko ti pokazuje vaga na Zemlji? <b id="shKgV"></b> kg</label>
    <input type="range" id="shKgR" min="10" max="60" value="${S.kg}" aria-label="Tvoja težina u kilogramima">
    <p>${esc(p.how)}</p>${factsHTML(p.facts)}<div class="fun">💡 ${esc(p.fun)}</div>
    <div class="row"><button class="btn" id="shJump">🦘 Skoči ovde!</button></div>`,body=>{
    const cv=$("#shCv",body), c=setupCanvas(cv,260,130); paintPlanet(c,130,65,p.id==="saturn"?34:p.id==="jupiter"?50:44,p.id);
    const upd=()=>{ $("#shKgV").textContent=S.kg; $("#shKg").textContent=`${fmt(S.kg*p.g)} kg`; };
    $("#shKgR").oninput=e=>{ S.kg=+e.target.value; store.set("kg",S.kg); upd(); }; upd();
    $("#shJump").onclick=()=>{ closeSheet(); go("games"); gameJump(p.id); };
  });
}
function sunSheet(){
  award("sunce");
  openSheet(`<h2>☀️ Sunce</h2><canvas id="shCv"></canvas><span class="pill">Zvezda</span><span class="pill">150 miliona km od Zemlje</span>
    ${factsHTML(SUN.facts)}<div class="fun">💡 ${esc(SUN.fun)}</div>`,body=>{ const c=setupCanvas($("#shCv",body),260,150); paintSun(c,130,75,38,0); });
}

/* ---------- Zemlja ---------- */
const EARTH={did:{dn:false,se:false},play:false,seA:Math.PI,season:"leto"};
const SEASONS={ proleće:{a:-Math.PI/2,t:"Proleće (mart): Zemlja nije nagnuta ni ka Suncu ni od njega. Dan i noć traju skoro isto, oko 12 sati. Dani postaju sve duži."},
  leto:{a:Math.PI,t:"Leto (jun): severna polutka, gde je i Srbija, nagnuta je ka Suncu. Zraci padaju strmije, dani su duži – toplo je! Na južnoj polutki je tada zima."},
  jesen:{a:Math.PI/2,t:"Jesen (septembar): opet ni ka Suncu ni od njega. Dan i noć su skoro jednaki, a dani postaju sve kraći."},
  zima:{a:0,t:"Zima (decembar): severna polutka je nagnuta od Sunca. Zraci padaju koso, dani su kratki – hladno je! U Australiji je tada leto." } };
function earthCheck(){ if(EARTH.did.dn&&EARTH.did.se) award("zemlja"); }
VIEWS.earth=function(){
  /* dan i noć */
  const dnW=Math.min(420,viewW(60)), dk=dnW/400, dnH=Math.round(260*dk);
  const dcv=$("#dnCv"), dc=setupCanvas(dcv,dnW,dnH);
  const drawDN=()=>{
    const h=+$("#dnHour").value%24; dc.setTransform(dc._dpr*dk,0,0,dc._dpr*dk,0,0); dc.clearRect(0,0,400,260);
    paintStars(dc,400,260,5,40,0,.7);
    paintSun(dc,44,130,24,0);
    dc.strokeStyle="rgba(255,225,120,.25)"; dc.lineWidth=2; [-60,-30,0,30,60].forEach(y=>{ dc.beginPath(); dc.moveTo(86,130+y*.5); dc.lineTo(160,130+y); dc.stroke(); });
    const cx=270,cy=130,R=88;
    ball(dc,cx,cy,R,"#6cc0ff","#1b5aa8");
    clipCircle(dc,cx,cy,R,()=>{
      dc.fillStyle="#5cb86b"; [[-30,-40,30,22],[20,10,34,20],[-48,28,24,18],[40,-48,20,14]].forEach(([x,y,rx,ry])=>{ dc.beginPath(); dc.ellipse(cx+x,cy+y,rx,ry,.5,0,7); dc.fill(); });
      dc.strokeStyle="rgba(255,255,255,.2)"; dc.lineWidth=1; [30,60].forEach(r=>{ dc.beginPath(); dc.arc(cx,cy,r,0,7); dc.stroke(); });
      const g=dc.createLinearGradient(cx-R*.2,0,cx+R*.25,0); g.addColorStop(0,"rgba(5,8,40,0)"); g.addColorStop(1,"rgba(5,8,40,.72)"); dc.fillStyle=g; dc.fillRect(cx-R*.2,cy-R,R*1.3,R*2);
    });
    dc.fillStyle="#fff"; dc.beginPath(); dc.arc(cx,cy,3,0,7); dc.fill();
    dc.fillStyle="rgba(255,255,255,.9)"; dc.font="600 12px Trebuchet MS, sans-serif"; dc.textAlign="center"; dc.fillText("Severni pol",cx,cy-9);
    const ang=Math.PI-(h-12)/24*2*Math.PI, mx=cx+Math.cos(ang)*R*.7, my=cy+Math.sin(ang)*R*.7, el=-Math.cos(ang);
    dc.fillStyle="#ff4d6d"; dc.strokeStyle="#fff"; dc.lineWidth=2.5; dc.beginPath(); dc.arc(mx,my,8,0,7); dc.fill(); dc.stroke();
    dc.fillStyle="#fff"; dc.fillText("Ti (Srbija)",mx,my-14);
    const hh=Math.floor(h), mm=Math.floor((h-hh)*60);
    const st=el>.18?"☀️ Dan":el<-.18?"🌙 Noć":"🌅 Zora ili sumrak";
    $("#dnTxt").textContent=`${String(hh).padStart(2,"0")}:${String(mm).padStart(2,"0")} – kod tebe je ${st}`;
  };
  drawDN(); $("#dnHour").oninput=()=>{ EARTH.did.dn=true; earthCheck(); drawDN(); };
  const startPlay=()=>{ EARTH.play=true; $("#dnPlay").textContent="⏸ Stani";
    runLoop(dt=>{ const r=$("#dnHour"); let v=+r.value+dt*2.4; if(v>=24) v-=24; r.value=v; EARTH.did.dn=true; earthCheck(); drawDN(); }); };
  EARTH.play=false; $("#dnPlay").textContent="▶ Pokreni sat";
  $("#dnPlay").onclick=()=>{ if(EARTH.play){ EARTH.play=false; stopLoop(); $("#dnPlay").textContent="▶ Pokreni sat"; } else startPlay(); sfx.tap(); };

  /* godišnja doba */
  const sW=Math.min(420,viewW(60)), sk=sW/400, sH=Math.round(290*sk), scv=$("#seCv"), sc=setupCanvas(scv,sW,sH);
  const pts=a=>[200+150*Math.cos(a),145+95*Math.sin(a)];
  const drawSE=()=>{
    sc.setTransform(sc._dpr*sk,0,0,sc._dpr*sk,0,0); sc.clearRect(0,0,400,290); paintStars(sc,400,290,9,40,0,.6);
    sc.strokeStyle="rgba(255,255,255,.2)"; sc.setLineDash([5,6]); sc.beginPath(); sc.ellipse(200,145,150,95,0,0,7); sc.stroke(); sc.setLineDash([]);
    paintSun(sc,200,145,22,0);
    sc.font="600 12px Trebuchet MS, sans-serif"; sc.textAlign="center";
    Object.entries(SEASONS).forEach(([n,s])=>{ const [x,y]=pts(s.a); sc.fillStyle=n===EARTH.season?"#ffd54a":"rgba(255,255,255,.7)";
      sc.fillText(n[0].toUpperCase()+n.slice(1),x,y+(Math.sin(s.a)>.5?44:Math.sin(s.a)<-.5?-36:(Math.cos(s.a)<0?-34:-34))); });
    const [ex,ey]=pts(EARTH.seA), R=22;
    ball(sc,ex,ey,R,"#6cc0ff","#1b5aa8");
    clipCircle(sc,ex,ey,R,()=>{ const dx=200-ex,dy=145-ey,l=Math.hypot(dx,dy),ux=dx/l,uy=dy/l;
      const g=sc.createLinearGradient(ex+ux*R,ey+uy*R,ex-ux*R,ey-uy*R); g.addColorStop(0,"rgba(0,0,30,0)"); g.addColorStop(.5,"rgba(0,0,30,0)"); g.addColorStop(.6,"rgba(0,0,30,.55)"); g.addColorStop(1,"rgba(0,0,30,.8)");
      sc.fillStyle=g; sc.fillRect(ex-R,ey-R,R*2,R*2); sc.fillStyle="#5cb86b"; sc.beginPath(); sc.ellipse(ex-4,ey-6,8,5,.4,0,7); sc.fill(); });
    const t=23.5*Math.PI/180, ax=Math.sin(t)*34, ay=Math.cos(t)*34;
    sc.strokeStyle="#fff"; sc.lineWidth=2; sc.beginPath(); sc.moveTo(ex-ax,ey+ay); sc.lineTo(ex+ax,ey-ay); sc.stroke();
    sc.fillStyle="#ff4d6d"; sc.beginPath(); sc.arc(ex+ax,ey-ay,4,0,7); sc.fill();
    sc.fillStyle="#fff"; sc.fillText("S",ex+ax+(ax>0?9:-9),ey-ay-2);
  };
  const btns=$("#seBtns"); btns.innerHTML="";
  Object.keys(SEASONS).forEach(n=>{ const b=document.createElement("button"); b.className="chip"+(n===EARTH.season?" on":""); b.textContent=({proleće:"🌸 Proleće",leto:"☀️ Leto",jesen:"🍂 Jesen",zima:"❄️ Zima"})[n];
    b.onclick=()=>{ EARTH.season=n; EARTH.did.se=true; earthCheck(); $$(".chip",btns).forEach(x=>x.classList.toggle("on",x===b)); $("#seTxt").textContent=SEASONS[n].t; sfx.tap();
      const target=SEASONS[n].a; let d=((target-EARTH.seA)%(2*Math.PI)-2*Math.PI)%(2*Math.PI); if(d===0||Math.abs(d)<1e-6) d=-2*Math.PI; const a0=EARTH.seA; let u=0;
      const prev=loopFn; runLoop(dt=>{ u=Math.min(1,u+dt/1.1); EARTH.seA=a0+d*(1-Math.pow(1-u,3)); drawSE(); if(u>=1){ EARTH.seA=target; drawSE(); stopLoop(); if(EARTH.play&&prev) { EARTH.play=false; $("#dnPlay").textContent="▶ Pokreni sat"; } } }); };
    btns.appendChild(b); });
  EARTH.seA=SEASONS[EARTH.season].a; $("#seTxt").textContent=SEASONS[EARTH.season].t; drawSE();

  /* slojevi */
  const lW=Math.min(300,viewW(60)), lcv=$("#layCv"), lc=setupCanvas(lcv,lW,lW), lk=lW/300, cut=[1,.88,.55,.22];
  let sel=-1;
  const drawL=()=>{
    lc.setTransform(lc._dpr*lk,0,0,lc._dpr*lk,0,0); lc.clearRect(0,0,300,300);
    const cols=["#5bb26a","#d9693a","#f2a43c","#ffe27a"], names=["Kora","Omotač","Spoljašnje jezgro","Unutrašnje jezgro"];
    for(let i=0;i<4;i++){ ball(lc,150,150,140*cut[i],cols[i],cols[i]); lc.strokeStyle=i===sel?"#fff":"rgba(255,255,255,.35)"; lc.lineWidth=i===sel?4:1.5; lc.beginPath(); lc.arc(150,150,140*cut[i],0,7); lc.stroke(); }
    lc.fillStyle="#102"; lc.font="700 13px Trebuchet MS, sans-serif"; lc.textAlign="center";
    lc.fillText("Kora",150,150-140*.94+4); lc.fillText("Omotač",150,150-140*.72+4); lc.fillText("Spoljašnje jezgro",150,150-140*.38+4); lc.font="700 11px Trebuchet MS, sans-serif"; lc.fillText("Unutr.",150,154);
  };
  const pick=i=>{ sel=i; drawL(); const L=LAYERS[i]; $("#layTxt").innerHTML=`<b>${esc(L.name)}</b>: ${esc(L.t)}`; sfx.pop(); };
  lcv.onclick=e=>{ const [x,y]=pos(e,lcv,300,300), d=Math.hypot(x-150,y-150)/140; let i=d>cut[0]?-1:d>cut[1]?0:d>cut[2]?1:d>cut[3]?2:3; if(i>=0) pick(i); };
  drawL(); $("#layTxt").textContent="Dodirni crtež.";
  $("#earthFacts").innerHTML=PLANETS[2].facts.concat(["Na ekvatoru se Zemlja okreće brzinom oko 1.670 km na sat – a mi to uopšte ne osećamo!","Zemljino magnetno polje štiti nas od Sunčevog vetra. Zbog njega na severu nastaju polarne svetlosti.","Sa Meseca bi Zemlja izgledala kao lepa plava klikerica."]).map(f=>`<li>${esc(f)}</li>`).join("");
};

/* ---------- Meseci ---------- */
const MOONPH={ seen:new Set() };
function phaseInfo(p){
  if(p<.03||p>.97) return ["nov","Mlad Mesec (nov)","Ne vidimo ga na nebu jer nam je okrenuta tamna strana."];
  if(p<.22) return ["rast","Mesec raste – tanak srp","Osvetljeni deo se širi sa desne strane."];
  if(p<.28) return ["prva","Prva četvrt","Vidi se pola Meseca. Liči na slovo D."];
  if(p<.47) return ["rast2","Mesec raste – skoro pun","Osvetljeno je sve više."];
  if(p<.53) return ["pun","Pun Mesec","Cela strana okrenuta nama je osvetljena!"];
  if(p<.72) return ["opada","Mesec opada – skoro pun","Osvetljeni deo se smanjuje sa desne strane."];
  if(p<.78) return ["poslednja","Poslednja četvrt","Vidi se druga polovina. Liči na slovo C."];
  return ["opada2","Mesec opada – srp","Ostaje tanak srp sa leve strane."];
}
VIEWS.moons=function(){
  const cv=$("#phCv"), c=setupCanvas(cv,240,240);
  const draw=()=>{ const d=+$("#phR").value, p=d/29.5; c.clearRect(0,0,240,240); paintStars(c,240,240,3,25,0,.6); moonPhaseShape(c,120,120,92,p%1);
    const [k,n,t]=phaseInfo(p%1); $("#phName").textContent=`${n} – dan ${Math.round(d)}`; $("#phTxt").textContent=t;
    MOONPH.seen.add(k); if(["nov","prva","pun","poslednja"].every(x=>MOONPH.seen.has(x))) award("mesec"); };
  $("#phR").oninput=draw; draw();
  const list=$("#moonList"); list.innerHTML="";
  MOONS.forEach(m=>{ const b=document.createElement("button"); b.className="item"; const cv2=document.createElement("canvas"); b.appendChild(cv2);
    const c2=setupCanvas(cv2,84,84); paintMoon(c2,42,42,34,m.id);
    b.insertAdjacentHTML("beforeend",`<b>${esc(m.name)}</b><small>mesec: ${esc(m.of)}</small>`); b.onclick=()=>moonSheet(m); list.appendChild(b); });
};
function moonSheet(m){
  openSheet(`<h2>🌙 ${esc(m.name)}</h2><canvas id="shCv"></canvas><span class="pill">kruži oko: ${esc(m.of)}</span><span class="pill">prečnik: ${esc(m.size)}</span><span class="pill">${esc(m.dist)}</span>
    ${factsHTML(m.facts)}<div class="fun">💡 ${esc(m.fun)}</div>`,body=>{ const c=setupCanvas($("#shCv",body),260,150); paintMoon(c,130,75,62,m.id); });
}

/* ---------- Sateliti ---------- */
const SAT={ ang:{}, info:false, q:[], i:0, done:0, locked:false };
const SAT_ORBITS={1:62,2:104,3:150};
VIEWS.sats=function(){
  const w=Math.min(440,viewW(28)), k=w/400, cv=$("#satCv"), c=setupCanvas(cv,w,w);
  if(!SAT.ang.sputnjik&&SAT.ang.sputnjik!==0){ SAT.ang={sputnjik:.3,iss:2.2,hubble:4.3,gps:1,meteo:.7,tv:3.8}; }
  const speed={sputnjik:1.3,iss:1.1,hubble:.9,gps:.45,meteo:.12,tv:.12};
  const place=s=>{ const r=SAT_ORBITS[s.orbit]; return [200+r*Math.cos(SAT.ang[s.id]),200+r*Math.sin(SAT.ang[s.id])]; };
  cv.onclick=e=>{ const [x,y]=pos(e,cv,400,400); let best=null,bd=1e9;
    SATS.forEach(s=>{ const [sx,sy]=place(s); const d=Math.hypot(x-sx,y-sy); if(d<24&&d<bd){ bd=d; best=s; } });
    if(best) onSat(best); };
  if(!SAT.q.length) newSatGame();
  showSatQ();
  runLoop(dt=>{
    SATS.forEach(s=>SAT.ang[s.id]+=dt*speed[s.id]);
    c.setTransform(c._dpr*k,0,0,c._dpr*k,0,0); c.clearRect(0,0,400,400); paintStars(c,400,400,21,60,0,.7);
    [["Niska orbita",62],["GPS orbita",104],["Visoka orbita",150]].forEach(([n,r],i)=>{ c.strokeStyle="rgba(255,255,255,.16)"; c.setLineDash([4,6]); c.beginPath(); c.arc(200,200,r,0,7); c.stroke(); c.setLineDash([]);
      c.fillStyle="rgba(255,255,255,.5)"; c.font="11px Trebuchet MS, sans-serif"; c.textAlign="center"; c.fillText(n,200,200-r-4); });
    paintPlanet(c,200,200,34,"zemlja");
    SATS.forEach(s=>{ const [x,y]=place(s); paintSat(c,x,y,s.id==="iss"?30:28,s.id,SAT.ang[s.id]+Math.PI/2);
      if(SAT.info){ c.fillStyle="rgba(255,255,255,.85)"; c.font="600 10px Trebuchet MS, sans-serif"; c.textAlign="center"; c.fillText(s.name.replace(/\s*\(.*\)/,"").replace("Međunarodna svemirska stanica","ISS"),x,y+25); } });
  });
  const chips=$("#satQ").parentElement; if(!$("#satMode")){ chips.insertAdjacentHTML("beforeend",`<div class="chips"><button class="chip on" id="satMode">📖 Pročitaj o satelitima</button></div>`); }
  $("#satMode").onclick=()=>{ SAT.info=!SAT.info; $("#satMode").classList.toggle("on",!SAT.info); $("#satMode").textContent=SAT.info?"🎯 Nazad na igru":"📖 Pročitaj o satelitima"; showSatQ(); sfx.tap(); };
};
function newSatGame(){ SAT.q=shuffle(SATS.filter(s=>s.job)); SAT.i=0; SAT.done=0; SAT.locked=false; }
function showSatQ(){
  const q=$("#satQ"), m=$("#satMsg");
  if(SAT.info){ q.textContent="Dodirni satelit da pročitaš kako radi."; m.textContent=""; return; }
  if(SAT.i>=SAT.q.length){ q.textContent="Sve si pogodio! 🎉 Dodirni satelit da pročitaš o njemu ili igraj ponovo."; m.innerHTML=`<button class="btn alt" id="satAgain">Igraj ponovo</button>`; $("#satAgain").onclick=()=>{ newSatGame(); showSatQ(); }; return; }
  q.textContent=`Zadatak ${SAT.i+1} od ${SAT.q.length}: ${SAT.q[SAT.i].job}`; m.textContent="Dodirni pravi satelit na slici.";
}
function onSat(s){
  if(SAT.info||SAT.i>=SAT.q.length){ openSheet(`<h2>🛰️ ${esc(s.name)}</h2><canvas id="shCv"></canvas><span class="pill">${esc(s.what)}</span>${factsHTML(s.facts)}`,b=>{ const c=setupCanvas($("#shCv",b),200,110); paintSat(c,100,55,90,s.id,0); }); return; }
  if(SAT.locked) return; const want=SAT.q[SAT.i], m=$("#satMsg");
  if(s.id===want.id){ SAT.locked=true; sfx.ok(); m.textContent=`✅ Tačno! ${s.name}: ${s.what}. ${s.facts[0]}`; SAT.i++; SAT.done++;
    setTimeout(()=>{ SAT.locked=false; if(SAT.i>=SAT.q.length){ award("sateliti"); } if(current==="sats") showSatQ(); },2600); }
  else { sfx.no(); m.textContent=`Hmm, to je ${s.name} (${s.what}). Probaj drugi!`; }
}

/* ---------- Roveri ---------- */
const RV={ level:1, W:6,H:6, rocks:new Set(), samples:new Set(), x:0,y:0, dx:0,dy:0, got:0, total:0, bump:0, wheel:0, cell:48, busy:false, msgT:0 };
const RVF=["Uzorak! Možda ima tragova vode.","Uzorak! Ova stena je stara milijarde godina.","Uzorak! Naučnici će ga ispitati laserom.","Uzorak! Crvena boja je od rđe.","Uzorak! Super, tako se skuplja materijal za laboratoriju!"];
VIEWS.rovers=function(){
  const list=$("#roverList"); list.innerHTML="";
  ROVERS.forEach(r=>{ const b=document.createElement("button"); b.className="item"; const cv=document.createElement("canvas"); b.appendChild(cv);
    const c=setupCanvas(cv,130,86); paintRover(c,65,80,110,r.kind,0);
    b.insertAdjacentHTML("beforeend",`<b>${esc(r.name)}</b><small>${esc(r.where)}, ${esc(r.year)}</small>`);
    b.onclick=()=>openSheet(`<h2>🤖 ${esc(r.name)}</h2><canvas id="shCv"></canvas><span class="pill">${esc(r.where)}</span><span class="pill">godina: ${esc(r.year)}</span>${factsHTML(r.facts)}<div class="fun">💡 ${esc(r.fun)}</div>`,
      bb=>{ const c2=setupCanvas($("#shCv",bb),240,130); paintRover(c2,120,122,170,r.kind,0); }); list.appendChild(b); });
  rvGen();
  $$(".pad button").forEach(b=>b.onclick=()=>rvMove(b.dataset.d));
  const cv=$("#rvCv"); let tx=0,ty=0;
  cv.ontouchstart=e=>{ tx=e.touches[0].clientX; ty=e.touches[0].clientY; };
  cv.ontouchend=e=>{ const t=e.changedTouches[0], dx=t.clientX-tx, dy=t.clientY-ty; if(Math.max(Math.abs(dx),Math.abs(dy))>24){ e.preventDefault(); rvMove(Math.abs(dx)>Math.abs(dy)?(dx>0?"r":"l"):(dy>0?"d":"u")); } };
  runLoop(dt=>{ RV.wheel+=dt; RV.dx+=(RV.x-RV.dx)*Math.min(1,dt*14); RV.dy+=(RV.y-RV.dy)*Math.min(1,dt*14); RV.bump=Math.max(0,RV.bump-dt*4); rvDraw(); });
};
document.addEventListener("keydown",e=>{
  if(current!=="rovers"||!$("#sheet").hidden) return;
  const m={ArrowUp:"u",ArrowDown:"d",ArrowLeft:"l",ArrowRight:"r",w:"u",s:"d",a:"l",d:"r"}[e.key]; if(m){ e.preventDefault(); rvMove(m); }
});
function rvGen(){
  const cfg=[[6,6,3,3],[7,7,8,4],[8,8,14,5]][Math.min(RV.level,3)-1]; RV.W=cfg[0]; RV.H=cfg[1];
  for(let tries=0;tries<200;tries++){
    RV.rocks=new Set(); const sx=0, sy=RV.H-1;
    while(RV.rocks.size<cfg[2]){ const x=Math.floor(Math.random()*RV.W), y=Math.floor(Math.random()*RV.H); if(!(x===sx&&y===sy)) RV.rocks.add(x+","+y); }
    const seen=new Set([sx+","+sy]), q=[[sx,sy]];
    while(q.length){ const [x,y]=q.pop(); [[1,0],[-1,0],[0,1],[0,-1]].forEach(([a,b])=>{ const nx=x+a, ny=y+b, key=nx+","+ny; if(nx>=0&&ny>=0&&nx<RV.W&&ny<RV.H&&!RV.rocks.has(key)&&!seen.has(key)){ seen.add(key); q.push([nx,ny]); } }); }
    seen.delete(sx+","+sy); if(seen.size>=cfg[3]+2){ RV.samples=new Set(shuffle([...seen]).slice(0,cfg[3])); break; }
  }
  RV.x=RV.dx=0; RV.y=RV.dy=RV.H-1; RV.got=0; RV.total=cfg[3]; RV.busy=false;
  const w=Math.min(440,viewW(60)); RV.cell=Math.floor(w/RV.W); const cv=$("#rvCv"); RV.c=setupCanvas(cv,RV.cell*RV.W,RV.cell*RV.H);
  $("#rvLvl").textContent="Nivo "+RV.level; rvCount(); rvMsg("Pomeraj rover!");
}
function rvCount(){ $("#rvCnt").textContent=`💎 ${RV.got} / ${RV.total}`; }
function rvMsg(t){ $("#rvMsg").textContent=t; }
function rvMove(d){
  if(RV.busy) return; const [a,b]={u:[0,-1],d:[0,1],l:[-1,0],r:[1,0]}[d], nx=RV.x+a, ny=RV.y+b;
  if(nx<0||ny<0||nx>=RV.W||ny>=RV.H){ rvMsg("Tu je kraj mape. Idi drugim putem!"); sfx.no(); RV.bump=1; return; }
  if(RV.rocks.has(nx+","+ny)){ rvMsg("Kamen! Zaobiđi ga."); sfx.no(); RV.bump=1; return; }
  RV.x=nx; RV.y=ny; sfx.tap();
  const key=nx+","+ny;
  if(RV.samples.has(key)){ RV.samples.delete(key); RV.got++; rvCount(); sfx.ok(); rvMsg(RVF[Math.floor(Math.random()*RVF.length)]);
    if(RV.got>=RV.total){ RV.busy=true; rvMsg("🎉 Bravo! Skupio si sve uzorke!"); award("rover"); setTimeout(()=>{ if(current==="rovers"){ RV.level++; rvGen(); } },2200); } }
  else rvMsg("");
}
function rvDraw(){
  const c=RV.c, s=RV.cell, W=RV.W, H=RV.H; if(!c) return;
  const g=c.createLinearGradient(0,0,0,s*H); g.addColorStop(0,"#c96a3c"); g.addColorStop(1,"#9a4524"); c.fillStyle=g; c.fillRect(0,0,s*W,s*H);
  const R=rnd(RV.level*17+3); c.fillStyle="rgba(90,30,10,.18)"; for(let i=0;i<30;i++){ c.beginPath(); c.ellipse(R()*s*W,R()*s*H,3+R()*9,2+R()*5,R()*3,0,7); c.fill(); }
  c.strokeStyle="rgba(255,255,255,.07)"; c.lineWidth=1; for(let i=1;i<W;i++){ c.beginPath(); c.moveTo(i*s,0); c.lineTo(i*s,s*H); c.stroke(); } for(let j=1;j<H;j++){ c.beginPath(); c.moveTo(0,j*s); c.lineTo(s*W,j*s); c.stroke(); }
  RV.rocks.forEach(k=>{ const [x,y]=k.split(",").map(Number), cx=x*s+s/2, cy=y*s+s/2; const rr=rnd(x*31+y*7+1);
    c.fillStyle="rgba(40,15,5,.3)"; c.beginPath(); c.ellipse(cx+3,cy+s*.3,s*.38,s*.12,0,0,7); c.fill();
    c.fillStyle="#7c7f90"; c.beginPath(); for(let i=0;i<8;i++){ const a=i/8*6.283, r=s*(.3+rr()*.12); i?c.lineTo(cx+Math.cos(a)*r,cy+Math.sin(a)*r*.85):c.moveTo(cx+Math.cos(a)*r,cy+Math.sin(a)*r*.85); } c.closePath(); c.fill();
    c.fillStyle="rgba(255,255,255,.2)"; c.beginPath(); c.ellipse(cx-s*.08,cy-s*.1,s*.14,s*.08,-.5,0,7); c.fill(); });
  RV.samples.forEach(k=>{ const [x,y]=k.split(",").map(Number), cx=x*s+s/2, cy=y*s+s/2, pulse=1+.08*Math.sin(RV.wheel*5+x);
    const gl=c.createRadialGradient(cx,cy,2,cx,cy,s*.5); gl.addColorStop(0,"rgba(120,220,255,.55)"); gl.addColorStop(1,"rgba(120,220,255,0)"); c.fillStyle=gl; c.fillRect(cx-s/2,cy-s/2,s,s);
    c.fillStyle="#7be0ff"; c.strokeStyle="#e8fbff"; c.lineWidth=1.5; c.beginPath(); c.moveTo(cx,cy-s*.26*pulse); c.lineTo(cx+s*.18*pulse,cy); c.lineTo(cx,cy+s*.26*pulse); c.lineTo(cx-s*.18*pulse,cy); c.closePath(); c.fill(); c.stroke(); });
  const rx=RV.dx*s+s/2+Math.sin(RV.bump*20)*RV.bump*4, ry=RV.dy*s+s*.86;
  paintRover(c,rx,ry,s*.95,"big",RV.wheel);
}

/* ---------- Rakete ---------- */
const RK={ parts:0, order:["motori","rezervoar","kapsula"], dest:"iss", flying:false };
const DESTS={ iss:{n:"🛰️ Svemirska stanica",km:400,txt:"Do ISS-a stižeš za nekoliko sati, a raketa je u orbiti već posle oko 9 minuta – brzinom oko 28.000 km na sat!"},
  mesec:{n:"🌙 Mesec",km:384400,txt:"Do Meseca se putuje oko 3 dana. Mesec je udaljen 384.400 km."},
  mars:{n:"🔴 Mars",km:225000000,txt:"Do Marsa se putuje oko 7 meseci. Prosečno je udaljen oko 225 miliona km!"} };
const RKFACT=[[1,"Poleteli smo! 🎉"],[10,"Leteći iznad oblaka – više od aviona (oni lete na oko 10 km)."],[100,"100 km! Ovde počinje svemir – nema vazduha, nebo je crno."],[400,"Na 400 km kruži Međunarodna svemirska stanica."],[384400,"Stižemo do Meseca!"],[5e6,"Zemlja je odavde samo mala plava tačka."]];
VIEWS.rockets=function(){
  RK.parts=0; RK.flying=false; $("#rkBuild").hidden=false; $("#rkFlight").hidden=true; $("#rkDest").hidden=true; $("#rkMsg").textContent="";
  const cv=$("#rkCv"), c=setupCanvas(cv,Math.min(340,viewW(60)),Math.min(340,viewW(60))*330/340);
  const drawBuild=()=>{ const w=cv.clientWidth||340, k=w/340; c.setTransform(c._dpr*k,0,0,c._dpr*k,0,0); c.clearRect(0,0,340,330);
    const g=c.createLinearGradient(0,0,0,330); g.addColorStop(0,"#5aa9ff"); g.addColorStop(1,"#bfe6ff"); c.fillStyle=g; c.fillRect(0,0,340,330);
    c.fillStyle="rgba(255,255,255,.9)"; [[60,60],[250,90],[150,40]].forEach(([x,y])=>{ c.beginPath(); c.ellipse(x,y,34,12,0,0,7); c.ellipse(x+20,y-8,22,12,0,0,7); c.fill(); });
    c.fillStyle="#6fa35a"; c.fillRect(0,290,340,40); c.fillStyle="#8a8fa8"; c.fillRect(100,282,140,12); c.fillStyle="#5b6080"; c.fillRect(230,150,12,140); c.fillRect(230,150,40,8);
    paintRocket(c,170,284,250,RK.parts,false,0);
    if(RK.parts<3){ c.setLineDash([6,6]); c.strokeStyle="rgba(255,255,255,.9)"; c.lineWidth=2; const y0=[284,200,150][RK.parts], h=[0,0,0][RK.parts]; c.strokeRect(132,RK.parts===0?250:RK.parts===1?160:70,76,RK.parts===0?34:RK.parts===1?90:86); c.setLineDash([]); } };
  drawBuild(); RK.draw=drawBuild;
  const box=$("#rkParts"); box.innerHTML="";
  const names={motori:"🔥 Motori",rezervoar:"⛽ Rezervoar goriva",kapsula:"👨‍🚀 Kapsula"}, hint=["Prvo ide ono što gura raketu: motori!","Sad gorivo – motorima treba hrana!","Na vrh ide kapsula u kojoj sede astronauti."];
  shuffle(RK.order).forEach(n=>{ const b=document.createElement("button"); b.className="chip"; b.textContent=names[n]; b.dataset.n=n;
    b.onclick=()=>{ if(RK.order[RK.parts]===n){ RK.parts++; b.disabled=true; b.style.opacity=.4; sfx.ok(); $("#rkMsg").textContent=["Motori su na mestu!","Gorivo je napunjeno!","Kapsula je gore – raketa je spremna!"][RK.parts-1]; drawBuild(); if(RK.parts===3){ $("#rkDest").hidden=false; } }
      else { sfx.no(); $("#rkMsg").textContent=hint[RK.parts]; b.classList.remove("shake"); void b.offsetWidth; b.classList.add("shake"); } };
    box.appendChild(b); });
  const dc=$("#rkDestChips"); dc.innerHTML="";
  Object.entries(DESTS).forEach(([id,d])=>{ const b=document.createElement("button"); b.className="chip"+(id===RK.dest?" on":""); b.textContent=d.n; b.onclick=()=>{ RK.dest=id; $$(".chip",dc).forEach(x=>x.classList.toggle("on",x===b)); sfx.tap(); }; dc.appendChild(b); });
  $("#rkGo").onclick=launch; $("#rkAgain").onclick=()=>VIEWS.rockets();
  buildShuttle(); buildShips();
};
function launch(){
  $("#rkBuild").hidden=true; $("#rkFlight").hidden=false; $("#rkAgain").hidden=true; $("#rkFact").textContent=""; $("#rkAlt").textContent="";
  const w=Math.min(340,viewW(60)), h=Math.round(w*420/340), k=w/340, cv=$("#rkFlCv"), c=setupCanvas(cv,w,h), cd=$("#rkCd"), dest=DESTS[RK.dest];
  window.scrollTo({top:$("#rkFlight").offsetTop-80,behavior:"smooth"});
  let n=5; cd.textContent=n; sfx.beep();
  const tick=setInterval(()=>{ n--; if(n>0){ cd.textContent=n; sfx.beep(); } else { clearInterval(tick); cd.textContent="🔥 Poletimo!"; start(); } },900);
  RK.timer=tick;
  const R=rnd(77);
  const clouds=Array.from({length:6},()=>[R()*340,R()*420,24+R()*26]);
  function start(){
    award("raketa"); rumble(10); let u=0, T=11, shown=-1; const logMax=Math.log10(dest.km);
    runLoop(dt=>{
      u=Math.min(1,u+dt/T); 
      const km=Math.max(0.02,Math.pow(dest.km,u)), f=clamp(Math.log10(km+1)/2,0,1);
      c.setTransform(c._dpr*k,0,0,c._dpr*k,0,0);
      const top=`rgb(${Math.round(70*(1-f)+4*f)},${Math.round(150*(1-f)+6*f)},${Math.round(255*(1-f)+24*f)})`, bot=`rgb(${Math.round(190*(1-f)+8*f)},${Math.round(225*(1-f)+10*f)},${Math.round(255*(1-f)+34*f)})`;
      const g=c.createLinearGradient(0,0,0,420); g.addColorStop(0,top); g.addColorStop(1,bot); c.fillStyle=g; c.fillRect(0,0,340,420);
      if(f>.25) paintStars(c,340,420,5,90,u*900,f);
      if(f<.9){ c.fillStyle=`rgba(255,255,255,${.9*(1-f)})`; clouds.forEach(cl=>{ cl[1]+=dt*(60+u*400); if(cl[1]>470) { cl[1]=-40; cl[0]=R()*340; } c.beginPath(); c.ellipse(cl[0],cl[1],cl[2],cl[2]*.38,0,0,7); c.ellipse(cl[0]+cl[2]*.6,cl[1]-6,cl[2]*.6,cl[2]*.3,0,0,7); c.fill(); }); }
      if(u<.06){ c.fillStyle="#6fa35a"; c.fillRect(0,360+u*3000,340,60); c.fillStyle="#8a8fa8"; c.fillRect(110,352+u*3000,120,10); }
      if(RK.dest==="iss"&&u>.82){ const a=(u-.82)/.18; paintSat(c,170,90-(1-a)*80,60*Math.min(1,a*1.2),"iss",0); }
      if(RK.dest!=="iss"&&u>.72){ const a=(u-.72)/.28; paintPlanet(c,170,70,Math.max(2,48*a),RK.dest==="mars"?"mars":"merkur"); if(RK.dest==="mesec") paintMoon(c,170,70,Math.max(2,48*a),"mesec"); }
      if(u<.5){ const e=Math.max(0,1-u*2.2); c.fillStyle="#2f6fcb"; c.beginPath(); c.arc(170,420+330-u*200,300*e+10,0,7); if(e>.05) c.fill(); }
      else if(RK.dest==="iss"||u<.8){ c.fillStyle="#2f6fcb"; c.beginPath(); c.arc(170,900-Math.min(1,(u-.5)*2)*80+(u>.8?(u-.8)*600:0),500,0,7); c.fill(); c.strokeStyle="rgba(140,200,255,.6)"; c.lineWidth=4; c.stroke(); }
      paintRocket(c,170,330,150,3,true,performance.now()/1000);
      const shownKm=km<10?km.toFixed(1):Math.round(km);
      $("#rkAlt").textContent=`Visina / daljina: ${Number(shownKm).toLocaleString("sr-RS")} km`;
      RKFACT.forEach(([kk,t],idx)=>{ if(km>=kk&&idx>shown&&(kk<=dest.km)){ shown=idx; $("#rkFact").textContent=t; sfx.pop(); } });
      if(u>=1){ stopLoop(); $("#rkFact").textContent="🎉 Stigli smo! "+dest.txt; $("#rkAgain").hidden=false; sfx.win(); }
    });
  }
}
function buildShuttle(){
  $("#shuttle").innerHTML=`<svg viewBox="0 0 300 270" role="img" aria-label="Svemirski šatl na rampi">
   <rect width="300" height="270" rx="18" fill="#a9d6ff"/><rect y="236" width="300" height="34" fill="#6fa35a"/><rect x="70" y="228" width="160" height="10" fill="#8a8fa8"/>
   <g class="part" tabindex="0" data-p="tank"><rect x="118" y="38" width="64" height="192" rx="30" fill="#e8873a"/><rect x="118" y="120" width="64" height="8" fill="#c96d24"/></g>
   <g class="part" tabindex="0" data-p="boost"><rect x="94" y="64" width="20" height="164" rx="9" fill="#f6f7ff" stroke="#9aa3c0"/><path d="M94 74 q10-34 20 0z" fill="#b9bfd8"/><rect x="186" y="64" width="20" height="164" rx="9" fill="#f6f7ff" stroke="#9aa3c0"/><path d="M186 74 q10-34 20 0z" fill="#b9bfd8"/></g>
   <g class="part" tabindex="0" data-p="orbiter"><path d="M150 40 q-18 40-18 100 v76 h36 v-76 q0-60-18-100z" fill="#f6f7ff" stroke="#9aa3c0"/><path d="M150 40 q-9 18-12 40 h24 q-3-22-12-40z" fill="#2b2f52"/><path d="M132 190 l-30 40 h30z M168 190 l30 40 h-30z" fill="#e1e5f4" stroke="#9aa3c0"/><rect x="140" y="88" width="20" height="8" rx="3" fill="#2c4fa3"/><path d="M150 150 l-6 24 h12z" fill="#ff6b6b"/></g>
   <g class="part" tabindex="0" data-p="engines"><rect x="130" y="216" width="40" height="12" rx="5" fill="#7d86a8"/></g>
   <text x="150" y="258" text-anchor="middle" font-size="13" fill="#fff" font-weight="700">Dodirni deo</text></svg>`;
  const info={ tank:["Narandžasti rezervoar","Sadrži gorivo (tečni vodonik i kiseonik) za glavne motore šatla. To je jedini deo koji se posle leta ne koristi ponovo – odbaci se i izgori u vazduhu."],
    boost:["Dva bela pojačivača","Daju najveći deo snage prvih oko 2 minuta leta. Posle toga se odvoje, spuste na padobranima u more, i koriste se ponovo!"],
    orbiter:["Letelica (orbiter)","Ovo je pravi „šatl“ sa krilima, kabinom za astronaute i velikim teretnim prostorom. Posle misije se vrati na Zemlju i sleće kao avion – bez motora! Šatlovi su se zvali Kolumbija, Čelendžer, Diskaveri, Atlantis i Endevor."],
    engines:["Glavni motori","Tri snažna motora na zadnjem delu letelice. Rade samo dok je rezervoar pun – oko 8 i po minuta."] };
  $$(".part",$("#shuttle")).forEach(g=>{ const f=()=>{ const [t,x]=info[g.dataset.p]; openSheet(`<h2>🚀 ${esc(t)}</h2><p>${esc(x)}</p><div class="fun">💡 Šatlovi su leteli od 1981. do 2011. godine i obavili su 135 letova. Jedan od njih je u orbitu ponio i teleskop Habl!</div>`); };
    g.onclick=f; g.onkeydown=e=>{ if(e.key==="Enter"||e.key===" ") f(); }; });
}
function buildShips(){
  const L=[["Vostok 1 (1961)","Prvi čovek u svemiru","12. aprila 1961. Jurij Gagarin je obišao Zemlju jednom za 108 minuta. Prva žena u svemiru, Valentina Tereškova, poletela je 1963."],
    ["Saturn V i Apolo 11 (1969)","Raketa za Mesec","Saturn V je bila visoka oko 111 metara. Nil Armstrong i Baz Oldrin hodali su po Mesecu 20. jula 1969, a Majkl Kolins ih je čekao u orbiti."],
    ["Svemirski šatl (1981–2011)","Višekratna letelica","Poleteo je 135 puta. Isporučivao je delove stanice i popravljao Habl."],
    ["Sojuz","Ruska letelica","Već više od pola veka vozi astronaute do svemirske stanice."],
    ["Rakete koje se vraćaju","Savremene rakete","Savremene rakete umeju da se spuste uspravno na zemlju i da lete ponovo – tako je svemir jeftiniji."]];
  const box=$("#shipList"); box.innerHTML="";
  L.forEach(([t,s,x],i)=>{ const b=document.createElement("button"); b.className="item"; const cv=document.createElement("canvas"); b.appendChild(cv); const c=setupCanvas(cv,60,76); paintRocket(c,30,72,68,3,false,0);
    b.insertAdjacentHTML("beforeend",`<b>${esc(t)}</b><small>${esc(s)}</small>`); b.onclick=()=>openSheet(`<h2>🚀 ${esc(t)}</h2><p>${esc(x)}</p>`); box.appendChild(b); });
}

/* ---------- Igre ---------- */
const GAMES=[["jump","🦘","Skok na planetama","Gde skačeš najviše?"],["order","🔢","Poredaj planete","Od Sunca nadalje"],["quiz","❓","Svemirski kviz","18 pitanja"]];
VIEWS.games=function(){
  const box=$("#gameTiles"); box.innerHTML=GAMES.map(g=>`<button class="tile" data-g="${g[0]}" style="min-height:120px"><span style="font-size:2.4rem">${g[1]}</span><b>${g[2]}</b><small>${g[3]}</small></button>`).join("");
  $$(".tile",box).forEach(b=>b.onclick=()=>{ ({jump:gameJump,order:gameOrder,quiz:gameQuiz})[b.dataset.g](); $("#gameArea").scrollIntoView({behavior:"smooth",block:"start"}); sfx.tap(); });
  if(!$("#gameArea").innerHTML.trim()) $("#gameArea").innerHTML=`<p class="lead center">Izaberi igru gore.</p>`;
};
/* --- skok --- */
const WORLDS=[{id:"mesec",name:"Mesec",g:MOON_G,sky:["#04050e","#1c1d38"],ground:"#9c9ca8"},
  ...PLANETS.map(p=>({id:p.id,name:p.name,g:p.g,sky:{merkur:["#07070c","#2a2a30"],venera:["#8a5a1a","#f0c070"],zemlja:["#4aa3ff","#cfeeff"],mars:["#7a3a2a","#f0a577"],jupiter:["#9a6a3e","#f3dcb0"],saturn:["#a3894e","#f6ebc4"],uran:["#3a9aa6","#c9f5f2"],neptun:["#14246e","#6a8cf0"]}[p.id],
    ground:{merkur:"#7d7570",venera:"#a8742a",zemlja:"#5da35f",mars:"#b4562f",jupiter:"#b07a4a",saturn:"#b99a58",uran:"#7fc4c8",neptun:"#4766d8"}[p.id]}))];
const JP={ id:"zemlja", y:0, T:1, u:1, best:0, air:false };
function gameJump(pre){
  if(pre) JP.id=pre;
  const area=$("#gameArea"); area.innerHTML=`<div class="card"><h3>🦘 Skok na planetama</h3>
   <p class="lead" style="margin:0">Izaberi svet pa dodirni SKOČI! Što je gravitacija slabija, skok je viši.</p>
   <div class="chips" id="jpChips"></div><canvas id="jpCv"></canvas>
   <div class="row" style="justify-content:center;margin-top:8px"><button class="btn" id="jpBtn">🦘 SKOČI!</button></div>
   <p class="msg" id="jpMsg"></p>
   <label>Tvoja težina na Zemlji: <b id="jpKgV"></b> kg</label><input type="range" id="jpKg" min="10" max="60" value="${S.kg}" aria-label="Težina">
   <p class="center"><b id="jpW"></b></p></div>`;
  const w=Math.min(340,viewW(60)), H=300, k=w/340, cv=$("#jpCv"), c=setupCanvas(cv,w,Math.round(H*k));
  const chips=$("#jpChips"); WORLDS.forEach(wd=>{ const b=document.createElement("button"); b.className="chip"+(wd.id===JP.id?" on":""); b.textContent=wd.name; b.onclick=()=>{ JP.id=wd.id; JP.u=1; JP.air=false; $$(".chip",chips).forEach(x=>x.classList.toggle("on",x===b)); info(); sfx.tap(); }; chips.appendChild(b); });
  const world=()=>WORLDS.find(x=>x.id===JP.id);
  const info=()=>{ const g=world().g; $("#jpKgV").textContent=S.kg; $("#jpW").textContent=`Na ovom svetu vaga ti pokazuje ${fmt(S.kg*g)} kg. Gravitacija: ${fmt(g,2)} × Zemljina.`; $("#jpMsg").textContent=`Na Zemlji skočiš oko 40 cm, ovde oko ${Math.round(40/g)} cm.`; };
  $("#jpKg").oninput=e=>{ S.kg=+e.target.value; store.set("kg",S.kg); info(); }; info();
  const PPM=55, GY=262;
  $("#jpBtn").onclick=()=>{ if(JP.air) return; const g=world().g; JP.h=.4/g; JP.T=.9/Math.sqrt(g); JP.u=0; JP.air=true; sfx.tap();
    if(!S.jumped.has(JP.id)){ S.jumped.add(JP.id); store.set("jumped",[...S.jumped]); if(S.jumped.size>=4) award("skok"); } };
  runLoop(dt=>{
    const wd=world(); if(JP.air){ JP.u+=dt/JP.T; if(JP.u>=1){ JP.u=1; JP.air=false; $("#jpMsg").textContent=`Skočio si ${Math.round(JP.h*100)} cm! ${JP.h>.6?"Mnogo više nego na Zemlji!":JP.h>.42?"Malo više nego na Zemlji.":JP.h>.38?"Isto kao na Zemlji.":JP.h>.25?"Malo niže nego na Zemlji.":"Mnogo niže nego na Zemlji!"}`; sfx.ok(); } }
    const y=JP.air?JP.h*4*JP.u*(1-JP.u):0;
    c.setTransform(c._dpr*k,0,0,c._dpr*k,0,0); const g=c.createLinearGradient(0,0,0,H); g.addColorStop(0,wd.sky[0]); g.addColorStop(1,wd.sky[1]); c.fillStyle=g; c.fillRect(0,0,340,H);
    if(["mesec","merkur","neptun","uran"].includes(wd.id)) paintStars(c,340,GY,8,40,0,.8);
    c.fillStyle=wd.ground; c.fillRect(0,GY,340,H-GY);
    c.strokeStyle="rgba(255,255,255,.4)"; c.fillStyle="rgba(255,255,255,.8)"; c.font="11px Trebuchet MS, sans-serif"; c.textAlign="left"; c.lineWidth=1;
    for(let m=0;m<=4.01;m+=.5){ const yy=GY-m*PPM; c.beginPath(); c.moveTo(0,yy); c.lineTo(m%1===0?16:9,yy); c.stroke(); if(m%1===0&&m>0) c.fillText(m+" m",20,yy+4); }
    c.setLineDash([5,5]); c.strokeStyle="rgba(255,255,255,.6)"; const ey=GY-.4*PPM; c.beginPath(); c.moveTo(60,ey); c.lineTo(340,ey); c.stroke(); c.setLineDash([]); c.textAlign="right"; c.fillText("Zemlja: 40 cm",334,ey-4);
    if(JP.best||JP.h){ const hy=GY-(JP.h||0)*PPM; c.strokeStyle="#ffd54a"; c.setLineDash([2,4]); c.beginPath(); c.moveTo(60,hy); c.lineTo(340,hy); c.stroke(); c.setLineDash([]); }
    paintAstronaut(c,170,GY-y*PPM,72,JP.air?1:0);
    c.fillStyle="rgba(255,255,255,.9)"; c.font="700 14px Trebuchet MS, sans-serif"; c.textAlign="center"; c.fillText(wd.name,170,22);
  });
}
/* --- poredaj planete --- */
const OR={ next:0, wrong:0 };
function gameOrder(){
  OR.next=0; OR.wrong=0; const area=$("#gameArea");
  area.innerHTML=`<div class="card"><h3>🔢 Poredaj planete</h3><p class="lead" style="margin:0">Dodiruj planete redom – od one koja je najbliža Suncu do najdalje.</p>
    <div class="row" style="justify-content:center;margin-top:8px"><canvas id="orSun" width="60" height="60"></canvas></div>
    <div class="slots" id="orSlots"></div><p class="msg" id="orMsg">Koja je prva od Sunca?</p><div class="row" style="justify-content:center" id="orPool"></div></div>`;
  const sc=setupCanvas($("#orSun"),60,60); paintSun(sc,30,30,12,0);
  $("#orSlots").innerHTML=PLANETS.map((p,i)=>`<div class="slot" id="sl${i}">${i+1}.</div>`).join("");
  const pool=$("#orPool");
  shuffle(PLANETS).forEach(p=>{ const b=document.createElement("button"); b.className="bub"; const cv=document.createElement("canvas"); b.appendChild(cv);
    const c=setupCanvas(cv,64,56), r=p.id==="saturn"?15:p.id==="jupiter"?23:Math.max(8,p.rel*8+6); paintPlanet(c,32,28,Math.min(r,24),p.id); b.insertAdjacentHTML("beforeend",esc(p.name));
    b.onclick=()=>{
      if(p.idx===OR.next){ sfx.ok(); const sl=$("#sl"+OR.next); sl.classList.add("f"); sl.innerHTML=`<canvas></canvas>${esc(p.name)}`; const c2=setupCanvas($("canvas",sl),44,40); paintPlanet(c2,22,20,Math.min(p.id==="saturn"?10:p.id==="jupiter"?16:Math.max(6,p.rel*5+4),17),p.id);
        b.remove(); OR.next++; $$(".bub",pool).forEach(x=>x.classList.remove("hint"));
        if(OR.next>=8){ $("#orMsg").innerHTML=`🎉 Bravo! Redosled: Merkur, Venera, Zemlja, Mars, Jupiter, Saturn, Uran, Neptun.<br><small style="color:var(--mute)">Pomoć za pamćenje: <b>M</b>ali <b>V</b>uk <b>Z</b>aliva <b>M</b>ladu <b>J</b>abuku <b>S</b>a <b>U</b>žitkom <b>N</b>ajviše.</small><br><button class="btn alt" id="orAgain" style="margin-top:8px">Igraj ponovo</button>`; $("#orAgain").onclick=gameOrder; award("poredak"); }
        else $("#orMsg").textContent=`Tačno! A koja je ${OR.next+1}. od Sunca?`; }
      else { sfx.no(); OR.wrong++; b.classList.remove("shake"); void b.offsetWidth; b.classList.add("shake");
        const nxt=PLANETS[OR.next]; $("#orMsg").textContent=OR.wrong>=2?`Pomoć: sledeća je ${nxt.name}.`:"Ovo nije sledeća planeta. Probaj opet!"; if(OR.wrong>=2){ $$(".bub",pool).forEach(x=>x.classList.toggle("hint",x.textContent===nxt.name)); } } };
    pool.appendChild(b); });
}
/* --- kviz --- */
const QZ={ i:0, score:0, done:false, opts:[] };
function gameQuiz(){ QZ.i=0; QZ.score=0; renderQ(); }
function renderQ(){
  const area=$("#gameArea");
  if(QZ.i>=QUIZ.length){ const stars=QZ.score>=15?3:QZ.score>=10?2:1; award("kviz");
    area.innerHTML=`<div class="card center"><h3>🏆 Kraj kviza!</h3><div class="stars">${"⭐".repeat(stars)}${"☆".repeat(3-stars)}</div><p>Tačnih odgovora: <b>${QZ.score} od ${QUIZ.length}</b></p>
      <p class="lead">${stars===3?"Pravi svemirski stručnjak!":stars===2?"Odlično! Još malo istraživanja pa si stručnjak.":"Dobar početak! Istraži planete pa probaj opet."}</p><button class="btn" id="qzAgain">Igraj ponovo</button></div>`; $("#qzAgain").onclick=gameQuiz; sfx.win(); return; }
  const q=QUIZ[QZ.i]; QZ.done=false; QZ.opts=shuffle(q.o.map((t,i)=>({t,ok:i===q.a})));
  area.innerHTML=`<div class="card"><div class="row" style="justify-content:space-between"><b>${LEVELS[q.lv]}</b><span>${QZ.i+1} / ${QUIZ.length}</span></div>
    <div class="bar" style="margin:8px 0 14px"><i style="width:${QZ.i/QUIZ.length*100}%"></i></div>
    <h3>${esc(q.q)}</h3><div id="qzO">${QZ.opts.map((o,i)=>`<button class="opt" data-i="${i}">${esc(o.t)}</button>`).join("")}</div>
    <div id="qzF"></div></div>`;
  $$("#qzO .opt").forEach(b=>b.onclick=()=>{ if(QZ.done) return; QZ.done=true; const o=QZ.opts[+b.dataset.i];
    $$("#qzO .opt").forEach((x,i)=>{ if(QZ.opts[i].ok) x.classList.add("good"); });
    if(o.ok){ QZ.score++; sfx.ok(); } else { b.classList.add("bad"); sfx.no(); }
    $("#qzF").innerHTML=`<p><b>${o.ok?"✅ Tačno!":"Skoro!"}</b> ${esc(q.e)}</p><button class="btn alt" id="qzN">${QZ.i+1>=QUIZ.length?"Završi":"Sledeće pitanje →"}</button>`;
    $("#qzN").onclick=()=>{ QZ.i++; renderQ(); }; });
}

/* ---------- start ---------- */
go("home");
