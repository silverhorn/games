ZVRK – digitalna igraona za malu decu
Raspakuj zip i otvori index.html u pregledaču (ne treba server ni internet, radi i offline osim fontova).
Jedan samostalan fajl: index.html.
Igračke: Vrt (gajenje cveća), Muzička kutija (ksilofon), Slagalica (prevuci oblike), Akvarijum (nahrani ribice).
Bez naloga, bez plaćanja, bez roditeljske kapije – čisto besplatna igraona.
