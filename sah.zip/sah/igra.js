/* ŠAH ŠKOLA – partije: protiv računara (5 nivoa), sa nekim na istom ekranu, na daljinu (preko koda) i vežba završnica. */
(function () {
  "use strict";
  var $ = A.$, esc = A.esc, E = window.ChessEngine;
  var START = E.START;
  var WIN_XP = [40, 60, 80, 110, 150];
  var ENDGAMES = [
    { id: "kq", ime: "Mat damom", opis: "Kralj i dama protiv samog kralja. Matiraj ga!", fen: "8/8/8/4k3/8/8/8/Q3K3 w - - 0 1", ikona: "q", savet: "Dama sama ne može da matira – dovedi i svog kralja! Zatvaraj crnog kralja kao u kutiju, pa se približi svojim kraljem. Pazi na <em>pat</em>!" },
    { id: "kr", ime: "Mat topom", opis: "Kralj i top protiv kralja. Malo teže!", fen: "8/8/8/4k3/8/8/8/R3K3 w - - 0 1", ikona: "r", savet: "Top ograničava kralja redom ili kolonom. Približavaj svog kralja, pa top menja stranu i daje mat na ivici table." },
    { id: "krr", ime: "Dva topa – lestvica", opis: "Dva topa matiraju kao lestvica, red po red.", fen: "8/8/8/4k3/8/8/8/R3K2R w - - 0 1", ikona: "r", savet: "Jedan top daje šah i tera kralja nazad, a drugi top skače korak niže. Tako se penješ kao uz lestvicu, red po red, do mata." },
    { id: "kp", ime: "Pešak postaje dama", opis: "Dovedi pešaka do kraja uz pomoć kralja.", fen: "4k3/8/4K3/4P3/8/8/8/8 w - - 0 1", ikona: "p", savet: "Kralj ide ispred pešaka i čisti mu put! Kad pešak postane dama, matiraj." }
  ];

  /* ───────── računar koji razmišlja (u pozadini, da se ekran ne zaledi) ───────── */
  function Thinker() {
    var self = this; this.id = 0; this.cbs = {}; this.reqs = {}; this.worker = null; this.url = null;
    try {
      var src = "var E=(" + buildChessEngine.toString() + ")();onmessage=function(e){var d=e.data,r=null,err=null;try{r=E.pickMove(d.fen,d.level,d.hist);}catch(x){err=String(x);}postMessage({id:d.id,r:r,err:err});};";
      this.url = URL.createObjectURL(new Blob([src], { type: "text/javascript" }));
      this.worker = new Worker(this.url);
      this.worker.onmessage = function (e) {
        var d = e.data, cb = self.cbs[d.id], rq = self.reqs[d.id]; delete self.cbs[d.id]; delete self.reqs[d.id];
        if (!cb) return;
        if (d.err) { try { cb(E.pickMove(rq.fen, rq.level, rq.hist)); } catch (x) { cb(null); } } else cb(d.r);
      };
      this.worker.onerror = function () { self.fallback(); };
    } catch (x) { this.worker = null; }
    window.__thinkMode = this.worker ? "worker" : "main";
  }
  Thinker.prototype.fallback = function () {
    var self = this; this.worker = null; window.__thinkMode = "main";
    Object.keys(this.cbs).forEach(function (id) { var cb = self.cbs[id], rq = self.reqs[id]; delete self.cbs[id]; delete self.reqs[id]; setTimeout(function () { var r = null; try { r = E.pickMove(rq.fen, rq.level, rq.hist); } catch (x) {} cb(r); }, 20); });
  };
  Thinker.prototype.ask = function (fen, level, hist, cb) {
    var self = this, id = ++this.id; this.cbs[id] = cb; this.reqs[id] = { fen: fen, level: level, hist: hist };
    if (this.worker) {
      try {
        this.worker.postMessage({ id: id, fen: fen, level: level, hist: hist });
        setTimeout(function () { if (self.cbs[id] && self.worker) self.fallback(); }, 9000);
        return;
      } catch (x) { this.worker = null; }
    }
    setTimeout(function () { var r = null; try { r = E.pickMove(fen, level, hist); } catch (x) {} delete self.cbs[id]; delete self.reqs[id]; cb(r); }, 30);
  };
  Thinker.prototype.stop = function () { this.cbs = {}; this.reqs = {}; if (this.worker) { try { this.worker.terminate(); } catch (x) {} this.worker = null; } if (this.url) { try { URL.revokeObjectURL(this.url); } catch (x) {} } };

  /* ───────── pomoćne ───────── */
  function other(c) { return c === "w" ? "b" : "w"; }
  function nm(t) { return PIECES.NAMES[t].toLowerCase(); }
  function acc(t) { return PIECES.NAMES_ACC[t]; }
  function tvoj(t) { return t === "q" ? "tvoju damu" : "tvog " + acc(t); }
  function Tvoj(t) { return t === "q" ? "Tvoja dama" : "Tvoj " + nm(t); }
  function ga(t) { return t === "q" ? "je" : "ga"; }
  function pts(t) { return PIECES.VALUE[t]; }
  function randId() { var s = "", c = "abcdefghjkmnpqrstuvwxyz23456789"; for (var i = 0; i < 4; i++) s += c[Math.floor(Math.random() * c.length)]; return s; }
  var INIT = { p: 8, n: 2, b: 2, r: 2, q: 1 };

  function trays(g) {
    var cnt = { w: { p: 0, n: 0, b: 0, r: 0, q: 0 }, b: { p: 0, n: 0, b: 0, r: 0, q: 0 } }, sc = { w: 0, b: 0 };
    g.pieceList().forEach(function (p) { if (p.type !== "k") { cnt[p.color][p.type]++; sc[p.color] += pts(p.type); } });
    function cap(of) { // figure boje 'of' koje su pojedene
      var out = [], t; ["q", "r", "b", "n", "p"].forEach(function (t) { var miss = Math.max(0, INIT[t] - cnt[of][t]); for (var i = 0; i < miss; i++) out.push(t); }); return out;
    }
    return { w: cap("w"), b: cap("b"), diff: sc.w - sc.b };
  }
  function moveHtml(v) {
    var s = "";
    if (v.castle) s = v.castle === "k" ? "O-O" : "O-O-O";
    else s = (v.piece !== "p" ? PIECES.icon(v.piece, v.color) : "") + (v.captured ? "×" : "") + v.to + (v.promotion ? "=" + PIECES.icon(v.promotion, v.color) : "");
    var end = v.san ? v.san.slice(-1) : "";
    return '<span class="mv">' + s + (end === "#" ? "<b>#</b>" : end === "+" ? "+" : "") + "</span>";
  }
  function explain(g, v) {
    var us = v.color, opp = other(us);
    if (v.san && v.san.slice(-1) === "#") return "<b>Možeš da daš MAT!</b> " + PIECES.NAMES[v.piece] + " na " + v.to + ".";
    if (v.castle) return "<b>Rokiraj!</b> Tvoj kralj ide na sigurno, a top izlazi u igru.";
    if (v.promotion) return "<b>Pešak stiže do kraja</b> i postaje " + nm(v.promotion) + "!";
    var hw = g.hanging(us);
    if (hw.length && hw[0].square === v.from) return Tvoj(hw[0].type) + " na " + v.from + " je napadnut! <b>Spasi " + ga(hw[0].type) + "</b> – pomeri " + ga(hw[0].type) + " na " + v.to + ".";
    if (v.captured) {
      var ha = g.hanging(opp).filter(function (h) { return h.square === v.to; });
      return ha.length ? "Možeš da pojedeš <b>nezaštićenog " + acc(v.captured) + "</b> na " + v.to + "! Besplatan plen." : "Možeš da pojedeš " + acc(v.captured) + " na " + v.to + " (" + pts(v.captured) + (pts(v.captured) === 1 ? " poen" : " poena") + ").";
    }
    if (v.san && v.san.slice(-1) === "+") return PIECES.NAMES[v.piece] + " na " + v.to + " daje <b>šah</b> i tera kralja da pobegne.";
    if (g.history().length < 14) {
      if (v.piece === "n" || v.piece === "b") return "<b>Izvedi " + acc(v.piece) + " u igru</b> – figure treba da izađu pre nego što napadaš.";
      if (v.piece === "p" && "cdef".indexOf(v.to[0]) >= 0) return "Pešak ka <b>sredini table</b> je dobar potez.";
    }
    return "Dobar potez: " + PIECES.NAMES[v.piece] + " na " + v.to + ".";
  }

  /* ───────── izbor igre ───────── */
  A.reg("igra", "Igraj", function (root, a, b) {
    if (a === "pc") { var cf = pcCfg(b); if (cf.bad) { A.go("igra"); return null; } return runGame(root, cf); }
    if (a === "dvoje") return runGame(root, { mode: "two" });
    if (a === "daljina") return remoteMenu(root, b);
    if (a === "daljina-igra") return runGame(root, remoteCfg());
    if (a === "zavrsnice") return endMenu(root);
    if (a === "zav") return runGame(root, endCfg(b));
    return menu(root);
  });

  function pcCfg(b) {
    var s = A.S.saved;
    if (b === "saved") {
      if (s && s.mode === "pc") return { mode: "pc", level: s.level, human: s.human, moves: s.moves };
      return { mode: "pc", level: 1, human: "w", moves: [], bad: true };
    }
    var lv = parseInt(b, 10) || 1, col = (b || "").slice(-1);
    if (col === "r") col = Math.random() < 0.5 ? "w" : "b";
    return { mode: "pc", level: Math.max(1, Math.min(5, lv)), human: col === "b" ? "b" : "w", moves: [] };
  }
  function endCfg(id) {
    var e = ENDGAMES.filter(function (x) { return x.id === id; })[0] || ENDGAMES[0];
    return { mode: "end", level: 4, human: "w", fen: e.fen, eg: e };
  }
  function remoteCfg() {
    var r = A.S.remote; if (!r) { A.go("igra/daljina"); return { mode: "two" }; }
    return { mode: "remote", remote: r, human: r.my, moves: r.moves.slice() };
  }

  function menu(root) {
    var S = A.S, sv = S.saved, rm = S.remote, col = S.set.col || "w", nxt = HOME.nextLesson(), done = HOME.lessonsDone();
    var h = "";
    if (done < 6) h += '<div class="card hint-card"><div class="peko" id="mp"></div><a class="btn go sm" href="#/skola">Idi u školu ▶</a></div>';
    if (sv && sv.mode === "pc") {
      var L = E.LEVELS[sv.level - 1];
      h += '<div class="card resume"><div><b>Nedovršena partija</b><br><span class="muted">Protiv: ' + esc(L.ime) + " · igraš " + (sv.human === "w" ? "belim" : "crnim") + " · " + Math.ceil(sv.moves.length / 2) + ". potez</span></div>" +
        '<div class="row"><a class="btn go" href="#/igra/pc/saved">Nastavi ▶</a><button class="btn ghost sm" id="svdel">Obriši</button></div></div>';
    }
    h += '<div class="sec"><h2>Igraj protiv računara</h2></div>' +
      '<div class="row colpick"><b>Biram:</b>' + ["w", "b", "r"].map(function (c) { return '<button class="seg' + (col === c ? " on" : "") + '" data-c="' + c + '">' + (c === "w" ? PIECES.icon("p", "w") + " Bele" : c === "b" ? PIECES.icon("p", "b") + " Crne" : "🎲 Nasumično") + "</button>"; }).join("") + "</div>" +
      '<div class="lvls">';
    E.LEVELS.forEach(function (L) {
      var w = S.stat.lv[L.id] ? S.stat.lv[L.id].w : 0;
      h += '<button class="lvl" data-l="' + L.id + '"><span class="lvic">' + PIECES.icon(["p", "n", "b", "r", "q"][L.id - 1], "w", true) + '</span><div><h3>Nivo ' + L.id + ": " + esc(L.ime) + "</h3><p>" + esc(L.opis) + "</p></div>" +
        '<span class="lvst">' + (w ? "🏆 " + w : "") + "</span></button>";
    });
    h += '</div><div class="sec"><h2>Još načina da igraš</h2></div><div class="tiles2">' +
      mini("#/igra/dvoje", "👫", "Sa nekim", "Dvoje na istom ekranu", "var(--sky)") +
      mini("#/igra/daljina", "🌍", "Na daljinu", "Sa drugom/drugarom, preko koda", "var(--pink)") +
      mini("#/igra/zavrsnice", "🏁", "Završnice", "Vežbaj mat damom, topom…", "#c3b3ff") + "</div>";
    root.innerHTML = h;
    if ($("#mp", root)) { var pk = new UI.Peko($("#mp", root)); pk.say("Savet: završi bar prvih nekoliko lekcija u <em>školi</em>. Ali možeš i odmah da igraš – nema zabrane!"); }
    A.$$(".seg", root).forEach(function (b) { b.onclick = function () { S.set.col = b.getAttribute("data-c"); A.save(); A.sfx.tap(); A.$$(".seg", root).forEach(function (x) { x.classList.toggle("on", x === b); }); }; });
    A.$$(".lvl", root).forEach(function (b) { b.onclick = function () { A.sfx.tap(); A.go("igra/pc/" + b.getAttribute("data-l") + (S.set.col || "w")); }; });
    var d = $("#svdel", root); if (d) d.onclick = function () { S.saved = null; A.save(); A.go("igra"); window.dispatchEvent(new Event("hashchange")); };
  }
  function mini(href, emoji, t, d, c) { return '<a class="mini" href="' + href + '" style="--tc:' + c + '"><span class="me">' + emoji + "</span><div><b>" + t + "</b><small>" + d + "</small></div></a>"; }

  function endMenu(root) {
    var h = '<p class="lead">Završnica je kraj partije kad je ostalo malo figura. Ovde vežbaš da matiraš. Ti igraš belim, računar brani crnog kralja.</p><div class="pgrid">';
    ENDGAMES.forEach(function (e) {
      var d = A.S.vez[e.id];
      h += '<a class="pack" href="#/igra/zav/' + e.id + '" style="--tc:' + (d ? "#bff0dc" : "#c3b3ff") + '"><span class="pic">' + PIECES.icon(e.ikona, "w", true) + "</span><div><h3>" + esc(e.ime) + "</h3><p>" + esc(e.opis) + "</p><small>" + (d ? "✔ matirao si!" : "Još nisi matirao") + "</small></div></a>";
    });
    root.innerHTML = h + "</div>";
  }

  /* ───────── daljina: izbor ───────── */
  function remoteMenu(root) {
    var r = A.S.remote;
    var h = '<p class="lead">Igraj sa drugarom koji je na drugom uređaju! Nije potreban internet u igri – kodove sa potezima šalješ porukom (Viber, WhatsApp, SMS…).</p>' +
      '<div class="card rem-how"><b>Kako ide:</b><ol><li>Ti počneš partiju i odigraš potez.</li><li>Igra ti da <em>kod</em>. Kopiraj ga i pošalji drugaru.</li><li>Drugar otvori ovu igru, izabere „Nastavi iz koda“, zalepi kod i odigra svoj potez.</li><li>On ti pošalje svoj kod, ti ga zalepiš – i tako redom!</li></ol></div>';
    if (r) h += '<div class="card resume"><div><b>Poslednja partija na daljinu</b><br><span class="muted">Igraš ' + (r.my === "w" ? "belim" : "crnim") + " · " + Math.ceil(r.moves.length / 2) + ". potez</span></div><a class=\"btn go\" href=\"#/igra/daljina-igra\">Nastavi ▶</a></div>";
    h += '<div class="sec"><h2>Nova partija</h2></div><div class="row"><button class="btn big" id="rw">Igram belim</button><button class="btn big soft" id="rb">Igram crnim</button></div>' +
      '<div class="sec"><h2>Nastavi iz koda</h2></div><div class="card"><p class="muted">Zalepi kod koji ti je poslao drugar:</p><textarea id="rcode" class="code" rows="3" placeholder="SAH1.…"></textarea><div class="row" style="margin-top:8px"><button class="btn go" id="rload">Učitaj partiju</button></div><p id="rerr" class="err"></p></div>';
    root.innerHTML = h;
    function start(c) { A.S.remote = { id: randId(), creator: c, my: c, moves: [] }; A.save(); A.go("igra/daljina-igra"); }
    $("#rw", root).onclick = function () { start("w"); }; $("#rb", root).onclick = function () { start("b"); };
    $("#rload", root).onclick = function () {
      var p = parseCode($("#rcode", root).value);
      if (p.err) { $("#rerr", root).textContent = p.err; return; }
      A.S.remote = { id: p.id, creator: p.creator, my: other(p.creator), moves: p.moves }; A.save(); A.go("igra/daljina-igra");
    };
  }
  function makeCode(r) { return "SAH1." + r.id + "." + r.creator + "." + r.moves.join(","); }
  function parseCode(txt) {
    var t = String(txt || "").replace(/\s+/g, " "), mvre = "[a-h][1-8][a-h][1-8][qrbn]?",
      m = t.match(new RegExp("SAH1\\.([a-z0-9]{4})\\.([wb])\\.?((?:" + mvre + "(?:," + mvre + ")*)?)", "i"));
    if (!m) return { err: "Ovo ne liči na kod iz ove igre. Kod počinje sa SAH1. Zalepi ceo kod." };
    var mv = m[3] ? m[3].toLowerCase().split(",").filter(Boolean) : [], g = new E.Game(START), i, x;
    for (i = 0; i < mv.length; i++) { x = g.move({ from: mv[i].slice(0, 2), to: mv[i].slice(2, 4), promotion: mv[i].slice(4, 5) || null }); if (!x) return { err: "Kod nije ispravan: potez broj " + (i + 1) + " nije dozvoljen. Zatraži od drugara da ga pošalje ponovo." }; }
    return { id: m[1].toLowerCase(), creator: m[2].toLowerCase(), moves: mv };
  }

  /* ───────── tabla za igru ───────── */
  function runGame(root, cfg) {
    var mode = cfg.mode, human = cfg.human || "w", level = cfg.level || 1, g = new E.Game(cfg.fen || START), board = null, peko = null, thinker = null;
    var over = false, thinking = false, busy = false, alive = true, timers = [], review = null, pendingWarn = null, lost = 0, flipAuto = !!A.S.set.flip, hintMove = null, hintFen = "", hintBusy = false, uci = [], startFen = g.fen();
    var isComp = mode === "pc" || mode === "end";
    var title = mode === "pc" ? "Nivo " + level + ": " + E.LEVELS[level - 1].ime : mode === "two" ? "Dvoje igraju" : mode === "remote" ? "Na daljinu" : cfg.eg.ime;
    $("#ttl").textContent = mode === "pc" ? "Partija" : mode === "two" ? "Sa nekim" : mode === "remote" ? "Na daljinu" : "Završnica";

    root.innerHTML =
      '<div class="gm"><div class="gm-main"><div class="gm-board">' +
      '<div class="pbar pt" id="ptop"></div><div id="gb"></div><div class="pbar pb" id="pbot"></div></div>' +
      '<div class="gm-side"><div class="peko" id="gp"></div><div class="gm-stat" id="gs"></div>' +
      '<div class="row gm-btns" id="gbtn"></div><div id="gres"></div>' +
      '<div class="gm-moves" id="gmv" aria-label="Potezi"></div><div id="grem"></div></div></div></div>';

    peko = new UI.Peko($("#gp", root));
    var orient = mode === "two" ? "w" : human;
    board = new Board($("#gb", root), {
      orient: orient, coords: A.S.set.coords,
      canGrab: function (sq) { if (over || busy || thinking || review !== null) return false; var p = g.get(sq); if (!p || p.color !== g.turnColor()) return false; if (isComp && p.color !== human) return false; if (mode === "remote" && p.color !== human) return false; return true; },
      getTargets: function (sq) { return g.moves({ square: sq }).map(function (m) { return { to: m.to, cap: !!m.captured }; }); },
      onMove: function (f, t) { if (over || busy || thinking || review !== null) return false; clearWarn(); return UI.tryMove(board, g, f, t, humanAttempt); }
    });
    board.setPieces(g.pieceList(), false);

    function later(fn, ms) { var t = setTimeout(function () { if (alive) fn(); }, ms); timers.push(t); return t; }

    /* ——— učitaj sačuvane poteze ——— */
    (cfg.moves || []).forEach(function (u) { var v = g.move({ from: u.slice(0, 2), to: u.slice(2, 4), promotion: u.slice(4, 5) || null }); if (v) { uci.push(u); if (isComp && v.captured && v.color !== human && v.captured !== "p") lost++; } });
    if (uci.length) { board.setPieces(g.pieceList(), false); var lh = g.history(), lv = lh[lh.length - 1]; if (lv) board.setLast(lv.from, lv.to); }
    if (isComp) thinker = new Thinker();

    /* ——— prikaz ——— */
    function pbarHtml(color) {
      var T = trays(g), caps = T[other(color)], ahead = color === "w" ? T.diff : -T.diff, name;
      if (mode === "end") { caps = []; ahead = 0; }
      if (mode === "pc" || mode === "end") name = color === human ? "Ti" : (mode === "end" ? "Računar" : esc(E.LEVELS[level - 1].ime));
      else if (mode === "remote") name = color === human ? "Ti" : "Drugar";
      else name = color === "w" ? "Beli" : "Crni";
      var think = (isComp && color !== human && thinking) ? '<span class="think"><i></i><i></i><i></i></span>' : "";
      var turn = !over && g.turnColor() === color ? " turn" : "";
      return '<span class="pa' + turn + '">' + PIECES.icon("p", color, true) + "</span><b>" + name + "</b>" + think + '<span class="trayc">' + caps.map(function (t) { return PIECES.icon(t, other(color)); }).join("") + (ahead > 0 ? "<em>+" + ahead + "</em>" : "") + "</span>";
    }
    function paint() {
      var o = board.orient, top = other(o), bot = o;
      $("#ptop", root).innerHTML = pbarHtml(top); $("#pbot", root).innerHTML = pbarHtml(bot);
      var h = g.history(), mh = "", i;
      for (i = 0; i < h.length; i += 2) mh += '<div class="mr"><span class="mn">' + (i / 2 + 1) + ".</span>" + moveHtml(h[i]) + (h[i + 1] ? moveHtml(h[i + 1]) : "") + "</div>";
      var ml = $("#gmv", root); ml.innerHTML = mh || '<span class="muted">Ovde će se pojaviti potezi.</span>'; ml.scrollTop = ml.scrollHeight;
      var st = "";
      if (!over) {
        var c = g.turnColor(), who = isComp ? (c === human ? "Tvoj potez" : "Računar igra") : mode === "remote" ? (c === human ? "Tvoj potez" : "Čekaš drugara") : (c === "w" ? "Beli je na potezu" : "Crni je na potezu");
        st = '<span class="sdot ' + c + '"></span>' + who + (g.inCheck() ? ' <b class="chk">ŠAH!</b>' : "");
      }
      $("#gs", root).innerHTML = st;
      var b = $("#gbtn", root);
      if (!over) {
        b.innerHTML = '<button class="btn ghost sm" id="bh">💡 Savet</button>' +
          '<button class="btn ghost sm" id="bu">↶ Vrati potez</button>' +
          (mode === "two" ? '<button class="btn ghost sm" id="bf">🔄 Okreni</button><button class="btn ghost sm' + (flipAuto ? " on" : "") + '" id="ba" title="Tabla se sama okreće posle svakog poteza">⟳ Auto</button>' : isComp ? "" : '<button class="btn ghost sm" id="bf">🔄 Okreni</button>') +
          '<button class="btn ghost sm" id="br">🏳 Predaj</button>';
        $("#bh", root).onclick = onHint; $("#bu", root).onclick = onUndo; $("#br", root).onclick = onResign;
        if ($("#bf", root)) $("#bf", root).onclick = function () { board.setOrient(other(board.orient)); paint(); };
        if ($("#ba", root)) $("#ba", root).onclick = function () { flipAuto = !flipAuto; A.S.set.flip = flipAuto; A.save(); this.classList.toggle("on", flipAuto); };
        var undoBtn = $("#bu", root); if (undoBtn) undoBtn.disabled = !canUndo();
      } else b.innerHTML = "";
      if (mode === "remote") remoteBox();
    }
    function canUndo() {
      if (thinking || busy || over) return false;
      var n = g.history().length;
      if (isComp) return g.turnColor() === human && n >= (human === "w" ? 2 : 3);
      if (mode === "remote") return false;
      return n >= 1;
    }
    function setCheck() { board.setCheck(g.inCheck() ? g.kingSquare(g.turnColor()) : null); }
    function save() {
      if (mode === "pc") { A.S.saved = { mode: "pc", level: level, human: human, moves: uci.slice() }; A.save(); }
      if (mode === "remote") { A.S.remote.moves = uci.slice(); A.save(); }
    }

    /* ——— upozorenja ——— */
    function clearWarn() { pendingWarn = null; }
    function warnFor(f, t, p) {
      if (!A.S.set.warn || mode === "two" || mode === "remote") return null;
      var us = g.turnColor(), opp = other(us), v = g.move({ from: f, to: t, promotion: p });
      if (!v) return null;
      var res = null;
      if (g.isCheckmate()) { g.undo(); return null; }
      if (g.isStalemate()) { res = "To je <b>PAT</b> – protivnik nema nijedan potez, ali nije u šahu. Partija bi bila <b>nerešena</b>. Želiš li ipak taj potez?"; g.undo(); return res; }
      var oppMate = g.mateIn1Moves().length > 0, hang = g.hanging(us), cap = v.captured ? E.VAL[{ p: 1, n: 2, b: 3, r: 4, q: 5 }[v.captured]] : 0;
      g.undo();
      if (oppMate) return "Pazi! Posle ovog poteza protivnik može da ti da <b>mat</b>. Želiš li ipak taj potez?";
      if (hang.length) {
        var top = hang[0], net = cap - top.gain;
        if (net <= -150) {
          var moved = top.square === t;
          return "Pazi! Posle ovog poteza protivnik može da pojede " + tvoj(top.type) + " na <b>" + top.square + "</b> (" + pts(top.type) + (pts(top.type) === 1 ? " poen" : " poena") + ")" + (moved ? " – ne čuva " + ga(top.type) + " niko." : ".") + " Želiš li ipak taj potez?";
        }
      }
      return null;
    }
    function showWarn(msg, f, t, p) {
      board.snap(f); pendingWarn = { f: f, t: t, p: p };
      peko.say(msg + '<div class="row wrow"><button class="btn sm" id="w1">Promeni potez</button><button class="btn ghost sm" id="w2">Ipak igraj</button></div>', "sad");
      $("#w1", root).onclick = function () { pendingWarn = null; peko.say("Dobro, pogledaj tablu još jednom i pomeri drugu figuru."); board.flash(f, "hint", 900); };
      $("#w2", root).onclick = function () { var w = pendingWarn; pendingWarn = null; if (w) execute(w.f, w.t, w.p, "human"); };
    }

    /* ——— potezi ——— */
    function humanAttempt(f, t, p) {
      if (over || busy || thinking) { board.snap(f); return; }
      var w = warnFor(f, t, p);
      if (w) { showWarn(w, f, t, p); return; }
      execute(f, t, p, "human");
    }
    function execute(f, t, p, who) {
      var mover = g.turnColor(), v = g.move({ from: f, to: t, promotion: p });
      if (!v) { board.snap(f); return; }
      uci.push(f + t + (p || "")); hintMove = null; board.clearArrows();
      A.moveSound(v); board.setLast(f, t); board.setCheck(null); busy = true;
      if (v.captured && v.color !== human && isComp && v.captured !== "p") lost++;
      board.animateMove(v, function () {
        busy = false;
        if (flipAuto && mode === "two") board.setOrient(g.turnColor());
        afterMove(v, who);
      });
    }
    function afterMove(v, who) {
      setCheck(); save(); paint();
      var end = g.endReason();
      if (end) { finish(end); return; }
      var msg = null;
      if (g.inCheck()) {
        if (isComp) msg = who === "comp" ? "<b>Šah!</b> Tvoj kralj je napadnut. Pomeri ga, blokiraj napad ili pojedi napadača." : "<b>Šah!</b> Računar mora da spase kralja.";
        else msg = "<b>Šah!</b> " + (g.turnColor() === "w" ? "Beli" : "Crni") + " mora da spase kralja.";
      } else if (isComp && who === "comp" && A.S.set.warn) {
        var h = g.hanging(human).filter(function (x) { return x.gain >= 300; });
        if (h.length) msg = "Pazi! " + Tvoj(h[0].type) + " na <b>" + h[0].square + "</b> je napadnut. Pomeri " + ga(h[0].type) + " ili " + ga(h[0].type) + " zaštiti.";
      }
      if (!msg && isComp && who === "human" && v.captured && v.captured !== "p") msg = "Dobro! Pojeo si " + acc(v.captured) + ".";
      if (!msg && v.castle) msg = "Rokada! Kralj je na sigurnom.";
      if (!msg && v.promotion) msg = "Pešak je postao " + nm(v.promotion) + "!";
      if (msg) peko.say(msg);
      nextTurn();
    }
    function nextTurn() {
      if (over) return;
      if (isComp && g.turnColor() !== human) compMove();
    }
    function compMove() {
      thinking = true; paint(); var t0 = Date.now();
      thinker.ask(g.fen(), level, g.keys.slice(), function (r) {
        if (!alive) return;
        later(function () {
          thinking = false;
          if (!r) { paint(); return; }
          execute(r.from, r.to, r.promotion, "comp");
        }, Math.max(0, (level <= 2 ? 500 : 350) - (Date.now() - t0)));
      });
    }

    /* ——— dugmad ——— */
    function onHint() {
      A.sfx.tap(); if (over || thinking || busy) return;
      if ((isComp || mode === "remote") && g.turnColor() !== human) return;
      var fen = g.fen();
      if (hintMove && hintFen === fen) { showHint(hintMove); return; }
      var mm = g.mateIn1Moves();
      if (mm.length) { hintMove = { from: mm[0].from, to: mm[0].to, promotion: mm[0].promotion || null }; hintFen = fen; showHint(hintMove); return; }
      if (hintBusy) return; hintBusy = true; peko.say("Razmišljam…");
      var th = thinker || (thinker = new Thinker());
      th.ask(fen, 4, g.keys.slice(), function (r) { hintBusy = false; if (!alive || !r || fen !== g.fen()) return; hintMove = r; hintFen = fen; showHint(r); });
    }
    function showHint(r) {
      board.clearArrows(); board.arrow(r.from, r.to, "ar"); board.flash(r.from, "hint", 1600);
      var v = g.moves({ square: r.from }).filter(function (m) { return m.to === r.to && (!r.promotion || m.promotion === r.promotion); })[0];
      if (v) { g.move({ from: v.from, to: v.to, promotion: v.promotion }); var h = g.history(), last = h[h.length - 1]; g.undo(); v.san = last.san; }
      peko.say("💡 " + (v ? explain(g, v) : "Pogledaj strelicu."));
    }
    function onUndo() {
      A.sfx.tap(); if (!canUndo()) return;
      var k = isComp ? 2 : 1; for (var i = 0; i < k; i++) { g.undo(); uci.pop(); }
      hintMove = null; board.clearAllMarks(); board.setPieces(g.pieceList(), false);
      var h = g.history(), last = h[h.length - 1]; if (last) board.setLast(last.from, last.to);
      setCheck(); save(); paint(); peko.say("Vratio sam potez. Pokušaj nešto bolje!");
    }
    var resignArmed = false;
    function onResign() {
      var b = $("#br", root);
      if (!resignArmed) { resignArmed = true; b.textContent = "Sigurno? Dodirni opet"; later(function () { resignArmed = false; if ($("#br", root)) $("#br", root).textContent = "🏳 Predaj"; }, 3000); return; }
      finish("predaja");
    }

    /* ——— kraj partije ——— */
    function finish(reason) {
      if (over) return; over = true; thinking = false; board.clearArrows(); setCheck();
      var turn = g.turnColor(), res, title, text, mood;
      var winner = reason === "mat" ? other(turn) : reason === "predaja" ? other(isComp || mode === "remote" ? human : turn) : null;
      var why = { mat: "Šah-mat! Kralj nema izlaz.", pat: "Pat – kralj nije u šahu, ali nema nijedan potez.", materijal: "Nema dovoljno figura da bi neko matirao.", ponavljanje: "Ista pozicija se ponovila tri puta.", pedeset: "50 poteza bez jedenja i pomeranja pešaka.", predaja: "Predaja." }[reason];
      var xp = 0, xpTxt = "";
      if (isComp) {
        res = winner ? (winner === human ? "win" : "loss") : "draw";
        if (mode === "pc") {
          var S = A.S, lv = S.stat.lv[level] = S.stat.lv[level] || { w: 0, l: 0, d: 0 };
          if (res === "win") { S.stat.w++; lv.w++; xp = WIN_XP[level - 1]; if (human === "b") S.stat.blackWin++; if (!lost) A.award("pazljiv"); }
          else if (res === "draw") { S.stat.d++; lv.d++; xp = Math.round(WIN_XP[level - 1] / 2); }
          else { S.stat.l++; lv.l++; xp = 8; }
          S.saved = null; A.save();
        } else {
          if (res === "win") { if (!A.S.vez[cfg.eg.id]) { A.S.vez[cfg.eg.id] = 1; xp = 40; } A.award("krajnja"); A.save(); }
        }
        title = res === "win" ? "Pobeda! 🎉" : res === "loss" ? "Ovaj put nije uspelo" : "Remi – nerešeno";
        text = res === "win" ? (reason === "mat" ? "Matirao si računar! Bravo, šampione!" : "Pobedio si!") : res === "loss" ? (reason === "predaja" ? "Predao si partiju. Nema veze – probaj ponovo!" : "Računar je ovaj put bio bolji. Nema veze – tako se uči! Probaj opet.") : "Niko nije pobedio. " + why;
        mood = res === "win" ? "happy" : res === "loss" ? "sad" : null;
        if (res === "win") { A.sfx.win(); A.confetti(110); } else if (res === "loss") A.sfx.lose(); else A.sfx.tap();
        if (mode === "end" && res !== "win") text = res === "draw" ? "Nerešeno: " + why + " Probaj opet – pazi da ne daš pat!" : text;
      } else {
        title = winner ? (winner === "w" ? "Beli je pobedio! 🎉" : "Crni je pobedio! 🎉") : "Remi – nerešeno";
        if (mode === "remote" && winner) title = winner === human ? "Pobedio si! 🎉" : "Drugar je pobedio";
        text = winner ? (reason === "mat" ? "Šah-mat! Bravo za pobednika, a pobeđeni – sledeći put će biti bolje." : "Partija je završena predajom.") : "Niko nije pobedio. " + why;
        var firstEnd = !(mode === "remote" && A.S.remote && A.S.remote.done);
        if (firstEnd) {
          A.S.stat.friend++; if (mode === "remote" && A.S.remote) A.S.remote.done = true;
          A.save(); A.sfx.win(); if (winner) A.confetti(90); xp = 25;
        }
        mood = "happy";
      }
      if (xp) A.addXP(xp);
      A.checkBadges();
      paint(); peko.say(text, mood);
      var rb = '<div class="card gres"><h2>' + title + "</h2><p>" + text + "</p>" + (xp ? '<p class="lend-xp">+' + xp + " poena</p>" : "") +
        '<div class="row">' + (mode === "remote" ? '<a class="btn go" href="#/igra/daljina">Nova partija</a>' : '<button class="btn go" id="rnew">Nova partija</button>') +
        '<button class="btn ghost" id="rrev">◀ ▶ Pregled</button>' + '<a class="btn ghost" href="#/igra' + (mode === "end" ? "/zavrsnice" : "") + '">' + (mode === "pc" ? "Izbor nivoa" : "Nazad") + "</a></div></div>";
      $("#gres", root).innerHTML = rb;
      if ($("#rnew", root)) $("#rnew", root).onclick = newGame;
      $("#rrev", root).onclick = startReview;
    }
    function newGame() {
      A.sfx.tap();
      if (mode === "pc" && !/pc\/\d[wbr]$/.test(location.hash)) location.hash = "#/igra/pc/" + level + human;
      else window.dispatchEvent(new Event("hashchange"));
    }
    function fens() { var h = g.history(), a = [], i; for (i = 0; i < h.length; i++) a.push(h[i].fenBefore); a.push(g.fen()); return a; }
    function startReview() {
      A.sfx.tap(); var F = fens(); review = F.length - 1;
      var h = g.history();
      function show() {
        board.clearAllMarks(); board.setPieces(new E.Game(F[review]).pieceList(), false);
        var mv = h[review - 1]; board.setLast(mv ? mv.from : null, mv ? mv.to : null);
        var gg = new E.Game(F[review]); board.setCheck(gg.inCheck() ? gg.kingSquare(gg.turnColor()) : null);
        $("#rpos", root).textContent = review + " / " + (F.length - 1);
        A.$$("#gmv .mv", root).forEach(function (x, i) { x.classList.toggle("cur", i === review - 1); });
      }
      $("#gres", root).innerHTML = '<div class="card gres"><h3>Pregled partije</h3><div class="row c"><button class="btn ghost" id="r0">⏮</button><button class="btn ghost" id="r1">◀</button><b id="rpos"></b><button class="btn ghost" id="r2">▶</button><button class="btn ghost" id="r3">⏭</button></div>' +
        '<div class="row c" style="margin-top:10px">' + (mode === "remote" ? '<a class="btn go" href="#/igra/daljina">Nova partija</a>' : '<button class="btn go" id="rnew2">Nova partija</button>') + "</div></div>";
      $("#r0", root).onclick = function () { review = 0; show(); }; $("#r1", root).onclick = function () { review = Math.max(0, review - 1); show(); };
      $("#r2", root).onclick = function () { review = Math.min(F.length - 1, review + 1); show(); }; $("#r3", root).onclick = function () { review = F.length - 1; show(); };
      if ($("#rnew2", root)) $("#rnew2", root).onclick = newGame;
      show();
    }

    /* ——— daljina: kod i uvoz ——— */
    function remoteBox() {
      var r = A.S.remote; if (!r) return;
      var el = $("#grem", root), code = makeCode(r), myTurn = !over && g.turnColor() === human, h = "", prev = $("#inc", root) ? $("#inc", root).value : "";
      var played = uci.length, mineLast = g.turnColor() !== human && (over ? played > 0 : true);
      h += '<div class="card rem"><b>Partija ' + r.id + " · igraš " + (human === "w" ? "belim" : "crnim") + "</b>";
      if (over) h += mineLast ? "<p>Partija je gotova. Pošalji drugaru ovaj kod da i on vidi kraj:</p>" : "<p>Partija je gotova.</p>";
      else if (myTurn) h += "<p>Na tebi je red! Odigraj potez na tabli.</p>";
      else if (played > 0) h += "<p>Tvoj potez je odigran. Kopiraj kod i pošalji ga drugaru:</p>";
      else h += "<p>Pošalji drugaru ovaj kod da bi počeo da igra:</p>";
      if (mineLast) h += '<textarea class="code" readonly rows="2" id="mycode">' + esc(code) + '</textarea><div class="row"><button class="btn go sm" id="cp">📋 Kopiraj kod</button></div>';
      if (!over && !myTurn) h += '<p class="muted" style="margin-top:12px">Kad drugar odgovori, zalepi njegov kod ovde:</p><textarea class="code" rows="2" id="inc" placeholder="SAH1.…">' + esc(prev) + '</textarea><div class="row"><button class="btn sm" id="ld">Učitaj potez</button></div><p class="err" id="rerr"></p>';
      h += "</div>";
      el.innerHTML = h;
      if ($("#cp", root)) $("#cp", root).onclick = function () {
        var ta = $("#mycode", root), b = this;
        function ok() { b.textContent = "✔ Kopirano!"; A.sfx.ok(); setTimeout(function () { b.textContent = "📋 Kopiraj kod"; }, 1600); }
        try { navigator.clipboard.writeText(ta.value).then(ok, function () { ta.select(); document.execCommand("copy"); ok(); }); } catch (e) { ta.select(); try { document.execCommand("copy"); ok(); } catch (x) {} }
      };
      if ($("#ld", root)) $("#ld", root).onclick = function () {
        var p = parseCode($("#inc", root).value), er = $("#rerr", root);
        if (p.err) { er.textContent = p.err; return; }
        if (p.id !== r.id) { er.textContent = "Ovo je kod iz druge partije (" + p.id + "). Ova partija je " + r.id + "."; return; }
        if (p.moves.length <= uci.length) { er.textContent = "U ovom kodu nema novih poteza. Čekaš da drugar odigra."; return; }
        for (var i = 0; i < uci.length; i++) if (p.moves[i] !== uci[i]) { er.textContent = "Ovaj kod se ne poklapa sa tvojom partijom."; return; }
        er.textContent = ""; var nw = p.moves.slice(uci.length);
        if (nw.length === 1) execute(nw[0].slice(0, 2), nw[0].slice(2, 4), nw[0].slice(4, 5) || null, "remote");
        else { nw.forEach(function (u) { g.move({ from: u.slice(0, 2), to: u.slice(2, 4), promotion: u.slice(4, 5) || null }); uci.push(u); }); board.setPieces(g.pieceList(), false); setCheck(); save(); paint(); var e2 = g.endReason(); if (e2) finish(e2); }
      };
    }

    window.__gm = { g: g, board: board, human: human, mode: mode, level: level, over: function () { return over; }, thinking: function () { return thinking || busy; } };
    /* ——— početak ——— */
    paint();
    var intro = "";
    if (mode === "pc") intro = human === "w" ? "Igraš <em>belim</em> – beli igra prvi! Dodirni figuru, pa polje gde želiš da ide. Ja ću paziti na tebe." : "Igraš <em>crnim</em>. Računar igra prvi – sačekaj njegov potez.";
    else if (mode === "end") intro = "<b>" + esc(cfg.eg.ime) + ".</b> " + cfg.eg.savet;
    else if (mode === "two") intro = "Dvoje igraju na istom ekranu. Beli igra prvi. Tabla može da se okreće dugmetom 🔄.";
    else intro = human === "w" ? "Igraš belim. Odigraj potez, pa pošalji kod drugaru." : "Igraš crnim. Drugar igra prvi – sačekaj njegov kod.";
    if (uci.length) intro = "Nastavljamo partiju! Na potezu je " + (g.turnColor() === "w" ? "beli" : "crni") + ".";
    peko.say(intro);
    if (g.endReason()) finish(g.endReason()); else nextTurn();

    return function () { alive = false; timers.forEach(clearTimeout); if (thinker) thinker.stop(); board.destroy(); A.stopSpeak(); };
  }
})();
