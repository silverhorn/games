/* ŠAH ŠKOLA – činovi i značke. */
window.RANGOVI = [
  { od: 0, ime: "Mali pešak", t: "p" },
  { od: 80, ime: "Hrabri skakač", t: "n" },
  { od: 230, ime: "Mudri lovac", t: "b" },
  { od: 470, ime: "Jaki top", t: "r" },
  { od: 820, ime: "Moćna dama", t: "q" },
  { od: 1300, ime: "Šahovski kralj", t: "k" }
];

window.OPIS_FIGURA = {
  k: "Ovo je <em>Kralj</em>. Najvažnija figura! Ako ga matiraju, partija je gotova. Ide samo jedan korak.",
  q: "Ovo je <em>Dama</em>, najjača figura! Ide kao top i lovac zajedno.",
  r: "Ovo je <em>Top</em>. Ide pravo – napred, nazad i u stranu – koliko god polja hoće.",
  b: "Ovo je <em>Lovac</em>. Ide koso, po dijagonali, i uvek ostaje na polju svoje boje.",
  n: "Ovo je <em>Skakač</em>. Skače u obliku slova L i jedini može da preskoči druge figure!",
  p: "Ovo je <em>Pešak</em>. Ide napred, a jede koso. Pešaka ima najviše!"
};

window.ZNACKE = [
  { id: "prva", emoji: "🌱", ime: "Prvi korak", opis: "Završi prvu lekciju." },
  { id: "tabla", emoji: "🗺️", ime: "Znam tablu", opis: "Završi lekciju o tabli." },
  { id: "top", emoji: "🏰", ime: "Prijatelj topa", opis: "Nauči kako se kreće top." },
  { id: "skakac", emoji: "🐴", ime: "Skakač skakuće", opis: "Nauči kako se kreće skakač." },
  { id: "pesak", emoji: "🌟", ime: "Mali pešak", opis: "Nauči sve o pešaku." },
  { id: "rokada", emoji: "🛡️", ime: "Rokada", opis: "Nauči rokadu." },
  { id: "skola", emoji: "🎓", ime: "Završena škola", opis: "Završi sve lekcije." },
  { id: "zad10", emoji: "🧩", ime: "Deset zadataka", opis: "Reši 10 zadataka." },
  { id: "zad25", emoji: "🔥", ime: "Majstor zadataka", opis: "Reši 25 zadataka." },
  { id: "zadSve", emoji: "💎", ime: "Svi zadaci", opis: "Reši sve zadatke." },
  { id: "mat1", emoji: "🎯", ime: "Lovac na mat", opis: "Reši zadatak „mat u jednom potezu“." },
  { id: "partija1", emoji: "♟️", ime: "Prva partija", opis: "Odigraj celu partiju." },
  { id: "pobeda1", emoji: "🏆", ime: "Prva pobeda", opis: "Pobedi računar." },
  { id: "pobeda5", emoji: "🥇", ime: "Pet pobeda", opis: "Pobedi računar pet puta." },
  { id: "crni", emoji: "🌙", ime: "Crni pobednik", opis: "Pobedi igrajući crnim figurama." },
  { id: "prijatelj", emoji: "🤝", ime: "Igra sa drugom", opis: "Odigraj partiju sa nekim." },
  { id: "nivo1", emoji: "🐣", ime: "Mali pešak (nivo 1)", opis: "Pobedi nivo 1." },
  { id: "nivo2", emoji: "🐎", ime: "Veseli skakač (nivo 2)", opis: "Pobedi nivo 2." },
  { id: "nivo3", emoji: "🦉", ime: "Pametni lovac (nivo 3)", opis: "Pobedi nivo 3." },
  { id: "nivo4", emoji: "🦁", ime: "Jaki top (nivo 4)", opis: "Pobedi nivo 4." },
  { id: "nivo5", emoji: "👑", ime: "Majstor (nivo 5)", opis: "Pobedi nivo 5." },
  { id: "krajnja", emoji: "🏁", ime: "Majstor završnice", opis: "Matiraj računar u vežbi završnice." },
  { id: "pazljiv", emoji: "🔍", ime: "Pažljiv igrač", opis: "Pobedi računar bez ijedne izgubljene figure (pešaci ne važe)." },
  { id: "pamet", emoji: "💡", ime: "Pametna glava", opis: "Pogodi 5 pitanja zaredom u školi." }
];
