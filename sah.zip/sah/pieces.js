/* ŠAH – figure nacrtane kao SVG (sopstveni, deblji i prijateljski stil). */
(function () {
  "use strict";
  var base = function (x, y, w, h) { return '<rect class="f" x="' + x + '" y="' + y + '" width="' + w + '" height="' + h + '" rx="5"/>'; };

  var SHAPES = {
    p: function () {
      return '<path class="f" d="M41 50 C41 62 35 72 28 80 H72 C65 72 59 62 59 50 Z"/>' +
        '<rect class="f" x="35" y="43" width="30" height="9" rx="4.5"/>' +
        '<circle class="f" cx="50" cy="29" r="14"/>' +
        base(24, 80, 52, 11) +
        '<path class="d" d="M43 22 C45 19 48 18 51 18"/>';
    },
    r: function () {
      return '<path class="f" d="M30 52 H70 L74 78 H26 Z"/>' +
        '<path class="f" d="M32 40 H68 L70 52 H30 Z"/>' +
        '<path class="f" d="M27 17 H38 V26 H45 V17 H55 V26 H62 V17 H73 V40 H27 Z"/>' +
        base(21, 78, 58, 12) +
        '<path class="d" d="M35 60 V72 M36 28 V34"/>';
    },
    b: function () {
      return '<path class="f" d="M43 66 L37 80 H63 L57 66 Z"/>' +
        '<path class="f" d="M50 20 C68 31 71 47 62 58 C60 61 58 63 58 66 H42 C42 63 40 61 38 58 C29 47 32 31 50 20 Z"/>' +
        '<circle class="f" cx="50" cy="15" r="6.5"/>' +
        '<rect class="f" x="33" y="65" width="34" height="8" rx="4"/>' +
        base(22, 80, 56, 11) +
        '<path class="d" d="M47 37 L58 48 M44 28 C41 31 39 35 39 40"/>';
    },
    n: function () {
      return '<path class="f" d="M28 80 C27 62 36 55 45 45 C39 45 33 49 27 55 L19 49 C21 38 32 24 45 19 L49 10 L56 18 C72 21 82 37 79 56 C78 66 77 73 77 80 Z"/>' +
        base(23, 80, 56, 11) +
        '<circle class="e" cx="50" cy="31" r="3.6"/>' +
        '<circle class="e" cx="24" cy="51" r="2.2"/>' +
        '<path class="d" d="M58 24 C68 30 72 42 70 56 M46 62 C52 60 58 62 62 68"/>';
    },
    q: function () {
      return '<path class="f" d="M22 29 L31 58 L35 24 L43 56 L50 20 L57 56 L65 24 L69 58 L78 29 L74 70 H26 Z"/>' +
        '<circle class="f" cx="21" cy="26" r="5"/><circle class="f" cx="35" cy="21" r="5"/><circle class="f" cx="50" cy="16" r="5.5"/><circle class="f" cx="65" cy="21" r="5"/><circle class="f" cx="79" cy="26" r="5"/>' +
        '<rect class="f" x="28" y="68" width="44" height="9" rx="4.5"/>' +
        base(21, 77, 58, 13) +
        '<path class="d" d="M38 62 L36 36 M62 62 L64 36"/>';
    },
    k: function () {
      return '<path class="f" d="M30 38 C28 30 40 26 50 32 C60 26 72 30 70 38 C72 52 67 58 63 64 L68 74 H32 L37 64 C33 58 28 52 30 38 Z"/>' +
        '<path class="f" d="M46 6 H54 V13 H61 V21 H54 V28 H46 V21 H39 V13 H46 Z"/>' +
        '<rect class="f" x="28" y="70" width="44" height="9" rx="4.5"/>' +
        base(21, 79, 58, 12) +
        '<path class="d" d="M38 40 C37 46 40 52 44 56"/>';
    }
  };

  // lice (samo za lekcije): [y očiju, razmak, veličina]
  var FACES = { p: [29, 6.5, 2.7], r: [58, 9, 3.6], b: [40, 7, 3.2], q: [52, 9, 3.6], k: [46, 8.5, 3.6], n: null };
  function face(t) {
    var f = FACES[t]; if (!f) return "";
    var y = f[0], d = f[1], r = f[2];
    return '<g class="face"><circle cx="' + (50 - d) + '" cy="' + y + '" r="' + r + '"/><circle cx="' + (50 + d) + '" cy="' + y + '" r="' + r + '"/>' +
      '<circle cx="' + (50 - d + r * .35) + '" cy="' + (y - r * .35) + '" r="' + (r * .38) + '" class="sp"/><circle cx="' + (50 + d + r * .35) + '" cy="' + (y - r * .35) + '" r="' + (r * .38) + '" class="sp"/>' +
      '<path d="M' + (50 - d * .7) + " " + (y + r * 2.1) + " Q50 " + (y + r * 3.6) + " " + (50 + d * .7) + " " + (y + r * 2.1) + '" fill="none"/></g>';
  }

  window.PIECES = {
    NAMES: { p: "Pešak", n: "Skakač", b: "Lovac", r: "Top", q: "Dama", k: "Kralj" },
    NAMES_ACC: { p: "pešaka", n: "skakača", b: "lovca", r: "topa", q: "damu", k: "kralja" },
    VALUE: { p: 1, n: 3, b: 3, r: 5, q: 9, k: 0 },
    // tip: "p","n"... ; boja: "w" ili "b"; face: crtaj lice (za lekcije)
    svg: function (type, color, withFace) {
      return '<svg class="pcsvg" viewBox="0 0 100 100" aria-hidden="true">' + SHAPES[type]() + (withFace ? face(type) : "") + "</svg>";
    },
    html: function (type, color, withFace) {
      return '<div class="pc ' + color + " t-" + type + '">' + window.PIECES.svg(type, color, withFace) + "</div>";
    },
    // jednostavna ikona (za liste, značke)
    icon: function (type, color, withFace) {
      return '<span class="pi ' + (color || "w") + '">' + window.PIECES.svg(type, color || "w", withFace) + "</span>";
    }
  };
})();
