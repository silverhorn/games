/* ŠAH – tabla: crtanje, dodir i prevlačenje figura, označavanje polja, strelice, animacije. */
(function () {
  "use strict";
  var FILES = "abcdefgh";
  var PROMO_ORDER = ["q", "r", "b", "n"];

  function Board(root, opts) {
    this.root = root;
    this.o = opts || {};
    this.orient = this.o.orient || "w";
    this.coords = this.o.coords !== false;
    this.pcs = {};
    this.marks = {};
    this.sel = null; this.tgts = []; this.drag = null; this.timers = [];
    this.build();
    this.bind();
  }

  Board.prototype.build = function () {
    var root = this.root, self = this;
    root.classList.add("bdwrap");
    root.innerHTML = '<div class="bd' + (this.coords ? "" : " nocoords") + '"><div class="bd-sq"></div><svg class="bd-ar" viewBox="0 0 8 8" aria-hidden="true"></svg><div class="bd-pc"></div><div class="bd-pop" hidden></div></div>';
    this.bd = root.querySelector(".bd");
    this.sqBox = root.querySelector(".bd-sq");
    this.pcBox = root.querySelector(".bd-pc");
    this.arBox = root.querySelector(".bd-ar");
    this.pop = root.querySelector(".bd-pop");
    this.buildSquares();
  };

  Board.prototype.buildSquares = function () {
    var h = "", row, col, file, rank, name, dark;
    this.sqEls = {};
    for (row = 0; row < 8; row++) for (col = 0; col < 8; col++) {
      file = this.orient === "w" ? col : 7 - col; rank = this.orient === "w" ? 7 - row : row;
      name = FILES[file] + (rank + 1); dark = (file + rank) % 2 === 0;
      h += '<div class="sq ' + (dark ? "d" : "l") + '" data-sq="' + name + '">' +
        (col === 0 ? '<b class="co r">' + (rank + 1) + "</b>" : "") + (row === 7 ? '<b class="co f">' + FILES[file] + "</b>" : "") + "</div>";
    }
    this.sqBox.innerHTML = h;
    var els = this.sqBox.children, i;
    for (i = 0; i < els.length; i++) this.sqEls[els[i].getAttribute("data-sq")] = els[i];
    this.reapplyMarks();
  };

  Board.prototype.pos = function (name) {
    var f = name.charCodeAt(0) - 97, r = name.charCodeAt(1) - 49;
    return this.orient === "w" ? { col: f, row: 7 - r } : { col: 7 - f, row: r };
  };
  Board.prototype.place = function (el, name) {
    var p = this.pos(name);
    el.style.transform = "translate(" + p.col * 100 + "%," + p.row * 100 + "%)";
  };
  Board.prototype.sqAt = function (x, y) {
    var r = this.bd.getBoundingClientRect();
    var col = Math.floor((x - r.left) / r.width * 8), row = Math.floor((y - r.top) / r.height * 8);
    if (col < 0 || col > 7 || row < 0 || row > 7) return null;
    var f = this.orient === "w" ? col : 7 - col, rk = this.orient === "w" ? 7 - row : row;
    return FILES[f] + (rk + 1);
  };
  Board.prototype.center = function (name) { var p = this.pos(name); return { x: p.col + 0.5, y: p.row + 0.5 }; };

  /* ───────── figure ───────── */
  // list: [{square,type,color}]
  Board.prototype.setPieces = function (list, face) {
    var i, p, el, self = this;
    this.pcBox.innerHTML = ""; this.pcs = {};
    list.forEach(function (p) {
      var d = document.createElement("div"); d.innerHTML = PIECES.html(p.type, p.color, face);
      el = d.firstChild; el.setAttribute("data-sq", p.square);
      self.place(el, p.square); self.pcBox.appendChild(el); self.pcs[p.square] = el;
    });
  };
  Board.prototype.pieceEl = function (sq) { return this.pcs[sq] || null; };
  Board.prototype.setOrient = function (o) {
    if (o === this.orient) return;
    this.orient = o; this.buildSquares();
    var sq; for (sq in this.pcs) this.place(this.pcs[sq], sq);
    this.clearArrows();
  };
  Board.prototype.setCoords = function (on) { this.coords = on; this.bd.classList.toggle("nocoords", !on); };

  Board.prototype.later = function (fn, ms) { var self = this, t = setTimeout(function () { fn(); }, ms); this.timers.push(t); return t; };
  Board.prototype.destroy = function () { this.timers.forEach(clearTimeout); this.timers = []; this.unbind(); };

  // v: potez iz motora (from,to,piece,color,promotion,ep,castle). Animira i pomera figure.
  Board.prototype.animateMove = function (v, cb) {
    var self = this, el = this.pcs[v.from], capSq = v.ep ? v.to[0] + v.from[1] : v.to, capEl = this.pcs[capSq];
    if (!el) { if (cb) cb(); return; }
    delete this.pcs[v.from];
    if (capEl && capEl !== el) { delete this.pcs[capSq]; capEl.classList.add("cap"); this.later(function () { capEl.remove(); }, 320); }
    el.classList.remove("drag"); el.classList.add("moving");
    this.place(el, v.to); el.setAttribute("data-sq", v.to); this.pcs[v.to] = el;
    if (v.castle) {
      var rank = v.from[1], rf = v.castle === "k" ? "h" : "a", rt = v.castle === "k" ? "f" : "d", rook = this.pcs[rf + rank];
      if (rook) { delete this.pcs[rf + rank]; this.place(rook, rt + rank); rook.setAttribute("data-sq", rt + rank); this.pcs[rt + rank] = rook; }
    }
    if (v.promotion) {
      this.later(function () {
        var d = document.createElement("div"); d.innerHTML = PIECES.html(v.promotion, v.color);
        el.innerHTML = d.firstChild.innerHTML; el.className = "pc " + v.color + " t-" + v.promotion + " moving";
      }, 200);
    }
    this.later(function () { el.classList.remove("moving"); if (cb) cb(); }, 260);
  };
  Board.prototype.snap = function (sq) {
    var el = this.pcs[sq]; if (!el) return;
    el.classList.remove("drag"); this.place(el, sq);
  };
  Board.prototype.removePiece = function (sq) { var el = this.pcs[sq]; if (el) { delete this.pcs[sq]; el.classList.add("cap"); this.later(function () { el.remove(); }, 300); } };
  Board.prototype.addPiece = function (sq, type, color, face) {
    var d = document.createElement("div"); d.innerHTML = PIECES.html(type, color, face);
    var el = d.firstChild; el.setAttribute("data-sq", sq); this.place(el, sq); el.classList.add("pop");
    this.pcBox.appendChild(el); this.pcs[sq] = el; return el;
  };
  Board.prototype.movePieceTo = function (from, to) {
    var el = this.pcs[from]; if (!el) return;
    delete this.pcs[from]; this.place(el, to); el.setAttribute("data-sq", to); this.pcs[to] = el;
  };

  /* ───────── označavanje ───────── */
  Board.prototype.mark = function (sq, cls) {
    (this.marks[cls] = this.marks[cls] || {})[sq] = 1;
    if (this.sqEls[sq]) this.sqEls[sq].classList.add(cls);
  };
  Board.prototype.unmark = function (cls) {
    var m = this.marks[cls], sq; if (!m) return;
    for (sq in m) if (this.sqEls[sq]) this.sqEls[sq].classList.remove(cls);
    delete this.marks[cls];
  };
  Board.prototype.reapplyMarks = function () {
    var cls, sq; for (cls in this.marks) for (sq in this.marks[cls]) if (this.sqEls[sq]) this.sqEls[sq].classList.add(cls);
    this.restoreStars();
  };
  Board.prototype.clearAllMarks = function () { var c; for (c in this.marks) this.unmark(c); this.clearStars(); this.clearArrows(); this.clearSel(); };
  Board.prototype.setLast = function (from, to) { this.unmark("lm"); if (from) { this.mark(from, "lm"); this.mark(to, "lm"); } };
  Board.prototype.setCheck = function (sq) { this.unmark("chk"); if (sq) this.mark(sq, "chk"); };
  Board.prototype.setTargets = function (list) {
    this.unmark("tg"); this.unmark("tgc"); var self = this;
    this.tgts = (list || []).map(function (t) { self.mark(t.to, t.cap ? "tgc" : "tg"); return t.to; });
  };
  Board.prototype.select = function (sq) {
    this.unmark("sel"); this.sel = sq;
    if (sq) { this.mark(sq, "sel"); this.setTargets(this.o.getTargets ? this.o.getTargets(sq) : []); } else this.setTargets([]);
  };
  Board.prototype.clearSel = function () { this.select(null); };
  Board.prototype.flash = function (sq, cls, ms) {
    var el = this.sqEls[sq]; if (!el) return; cls = cls || "flash"; el.classList.remove(cls); void el.offsetWidth; el.classList.add(cls);
    this.later(function () { el.classList.remove(cls); }, ms || 900);
  };
  Board.prototype.wobble = function (sq) {
    var el = this.pcs[sq]; if (!el) return; el.classList.remove("wob"); void el.offsetWidth; el.classList.add("wob");
    this.later(function () { el.classList.remove("wob"); }, 500);
  };

  // zvezdice (ciljevi u lekcijama)
  Board.prototype.setStars = function (list) {
    this.starList = list.slice(); this.clearStarEls();
    var self = this; list.forEach(function (sq) { self.addStarEl(sq); });
  };
  Board.prototype.addStarEl = function (sq) {
    var el = this.sqEls[sq]; if (!el || el.querySelector(".star")) return;
    var i = document.createElement("i"); i.className = "star"; i.textContent = "★"; el.appendChild(i);
  };
  Board.prototype.clearStarEls = function () { var s = this.sqBox.querySelectorAll(".star"), i; for (i = 0; i < s.length; i++) s[i].remove(); };
  Board.prototype.restoreStars = function () { if (this.starList) { var self = this; this.starList.forEach(function (sq) { self.addStarEl(sq); }); } };
  Board.prototype.removeStar = function (sq) {
    if (this.starList) this.starList = this.starList.filter(function (s) { return s !== sq; });
    var el = this.sqEls[sq], st = el && el.querySelector(".star"); if (st) { st.classList.add("got"); this.later(function () { st.remove(); }, 400); }
  };
  Board.prototype.clearStars = function () { this.starList = []; this.clearStarEls(); };

  // strelice (jedinice polja)
  Board.prototype.arrow = function (from, to, cls) {
    var a = this.center(from), b = this.center(to), dx = b.x - a.x, dy = b.y - a.y, len = Math.hypot(dx, dy), ux = dx / len, uy = dy / len;
    var head = 0.42, w = 0.13, sx = a.x + ux * 0.22, sy = a.y + uy * 0.22, ex = b.x - ux * 0.12, ey = b.y - uy * 0.12, bx = ex - ux * head, by = ey - uy * head;
    var nx = -uy, ny = ux;
    var d = "M" + (sx + nx * w) + " " + (sy + ny * w) + " L" + (bx + nx * w) + " " + (by + ny * w) + " L" + (bx + nx * head * 0.55) + " " + (by + ny * head * 0.55) +
      " L" + ex + " " + ey + " L" + (bx - nx * head * 0.55) + " " + (by - ny * head * 0.55) + " L" + (bx - nx * w) + " " + (by - ny * w) + " L" + (sx - nx * w) + " " + (sy - ny * w) + " Z";
    this.arBox.insertAdjacentHTML("beforeend", '<path class="' + (cls || "ar") + '" d="' + d + '"/>');
  };
  Board.prototype.clearArrows = function () { this.arBox.innerHTML = ""; };

  /* ───────── promocija pešaka ───────── */
  Board.prototype.askPromotion = function (color, cb) {
    var self = this, h = '<div class="promo"><b>Izaberi figuru</b><div class="promo-row">';
    PROMO_ORDER.forEach(function (t) { h += '<button class="promo-b" data-t="' + t + '">' + PIECES.icon(t, color) + "<span>" + PIECES.NAMES[t] + "</span></button>"; });
    h += "</div></div>";
    this.pop.innerHTML = h; this.pop.hidden = false;
    this.pop.onclick = function (e) {
      var b = e.target.closest(".promo-b");
      if (!b && e.target.closest(".promo")) return;
      self.pop.hidden = true; self.pop.innerHTML = ""; self.pop.onclick = null;
      cb(b ? b.getAttribute("data-t") : null);
    };
  };

  /* ───────── dodir i prevlačenje ───────── */
  Board.prototype.bind = function () {
    var self = this, bd = this.bd;
    this._down = function (e) {
      if (self.o.interactive === false || (e.button && e.button !== 0)) return;
      if (!self.pop.hidden) return;
      var sq = self.sqAt(e.clientX, e.clientY); if (!sq) return;
      e.preventDefault();
      var can = self.o.canGrab ? self.o.canGrab(sq) : false;
      self.drag = { sq: sq, x: e.clientX, y: e.clientY, moved: false, can: can, id: e.pointerId };
      try { bd.setPointerCapture(e.pointerId); } catch (x) {}
      if (can && self.sel !== sq && !(self.sel && self.tgts.indexOf(sq) >= 0)) { self.select(sq); self.drag.selectedNow = true; }
    };
    this._move = function (e) {
      var d = self.drag; if (!d) return;
      if (!d.moved && d.can && Math.hypot(e.clientX - d.x, e.clientY - d.y) > 7) {
        d.moved = true; d.el = self.pcs[d.sq]; if (d.el) d.el.classList.add("drag");
        if (self.o.onGrab) self.o.onGrab(d.sq);
      }
      if (d.moved && d.el) {
        var r = bd.getBoundingClientRect(), s = r.width / 8, touch = e.pointerType === "touch";
        d.el.style.transform = "translate(" + (e.clientX - r.left - s / 2) + "px," + (e.clientY - r.top - s / 2 - (touch ? s * 0.45 : 0)) + "px) scale(1.14)";
        var over = self.sqAt(e.clientX, e.clientY - (touch ? s * 0.45 : 0));
        if (over !== d.over) { self.unmark("over"); if (over && self.tgts.indexOf(over) >= 0) self.mark(over, "over"); d.over = over; }
      }
    };
    this._up = function (e) {
      var d = self.drag; if (!d) return; self.drag = null;
      try { bd.releasePointerCapture(d.id); } catch (x) {}
      self.unmark("over");
      var r = bd.getBoundingClientRect(), s = r.width / 8, touch = e.pointerType === "touch";
      if (d.moved) {
        var to = self.sqAt(e.clientX, e.clientY - (touch ? s * 0.45 : 0));
        if (to && to !== d.sq && self.tgts.indexOf(to) >= 0) self.commit(d.sq, to, true);
        else { self.snap(d.sq); if (self.o.onDrop) self.o.onDrop(d.sq, to); }
        return;
      }
      var sq = self.sqAt(e.clientX, e.clientY); if (!sq) return;
      if (self.o.onSquare && self.o.onSquare(sq, e)) { return; }
      if (self.sel && self.sel !== sq && self.tgts.indexOf(sq) >= 0) { self.commit(self.sel, sq, false); return; }
      if (d.can) { if (self.sel === sq && !d.selectedNow) self.clearSel(); else if (self.sel !== sq) self.select(sq); }
      else if (self.sel) { self.clearSel(); }
    };
    this._cancel = function () { var d = self.drag; self.drag = null; if (d && d.moved) self.snap(d.sq); self.unmark("over"); };
    bd.addEventListener("pointerdown", this._down);
    bd.addEventListener("pointermove", this._move);
    bd.addEventListener("pointerup", this._up);
    bd.addEventListener("pointercancel", this._cancel);
  };
  Board.prototype.unbind = function () {
    var bd = this.bd; if (!bd) return;
    bd.removeEventListener("pointerdown", this._down); bd.removeEventListener("pointermove", this._move);
    bd.removeEventListener("pointerup", this._up); bd.removeEventListener("pointercancel", this._cancel);
  };
  Board.prototype.commit = function (from, to, dragged) {
    this.clearSel();
    var ok = this.o.onMove ? this.o.onMove(from, to, dragged) : false;
    if (!ok) this.snap(from);
  };

  window.Board = Board;
})();
