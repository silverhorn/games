/* ŠAH ŠKOLA – zadaci (svaki je proveren šahovskim motorom). */
window.ZADACI = [
 {
  "id": "mat1",
  "naslov": "Mat u jednom potezu",
  "opis": "Nađi potez kojim matiraš crnog kralja.",
  "ikona": "q",
  "boja": "var(--sun)",
  "tip": "mat1",
  "xp": 12,
  "upit": "Beli je na potezu. Nađi <em>mat u jednom potezu</em>!",
  "zadaci": [
   {
    "id": "mat1-1",
    "fen": "R7/8/5K1k/8/8/8/8/8 w - - 0 1"
   },
   {
    "id": "mat1-2",
    "fen": "8/8/8/1N6/8/8/R7/1k1K4 w - - 0 1"
   },
   {
    "id": "mat1-3",
    "fen": "8/8/8/8/2K5/8/2Q5/3N1k2 w - - 0 1"
   },
   {
    "id": "mat1-4",
    "fen": "K3R3/8/8/8/8/8/6R1/k7 w - - 0 1"
   },
   {
    "id": "mat1-5",
    "fen": "8/7K/8/7k/5Q2/8/4N3/8 w - - 0 1"
   },
   {
    "id": "mat1-6",
    "fen": "6k1/3R4/8/8/Q5K1/8/8/8 w - - 0 1"
   },
   {
    "id": "mat1-7",
    "fen": "8/8/2Q5/k7/8/4B3/8/6K1 w - - 0 1"
   },
   {
    "id": "mat1-8",
    "fen": "8/1K6/8/8/1R6/8/2Q5/6k1 w - - 0 1"
   },
   {
    "id": "mat1-9",
    "fen": "8/8/8/2R5/7B/4K3/8/3k1B2 w - - 0 1"
   },
   {
    "id": "mat1-10",
    "fen": "3Q4/8/5K2/3Q4/k7/8/8/8 w - - 0 1"
   },
   {
    "id": "mat1-11",
    "fen": "4k2N/5R2/6R1/8/8/8/4K3/8 w - - 0 1"
   }
  ]
 },
 {
  "id": "free",
  "naslov": "Besplatan plen",
  "opis": "Pojedi figuru koju niko ne čuva.",
  "ikona": "b",
  "boja": "var(--mint)",
  "tip": "free",
  "xp": 10,
  "upit": "Beli je na potezu. Pojedi <em>figuru koju protivnik ne čuva</em>! Pazi na zaštićene figure.",
  "zadaci": [
   {
    "id": "free-1",
    "fen": "1k6/8/8/7r/2b2R1b/8/1P1K4/8 w - - 0 1",
    "sol": [
     "f4c4"
    ],
    "sq": "c4"
   },
   {
    "id": "free-2",
    "fen": "8/3k4/1r1p4/1p1N4/1B6/8/1K6/8 w - - 0 1",
    "sol": [
     "d5b6"
    ],
    "sq": "b6"
   },
   {
    "id": "free-3",
    "fen": "7k/2p5/8/2p3N1/4n3/8/8/K5Q1 w - - 0 1",
    "sol": [
     "g5e4"
    ],
    "sq": "e4"
   },
   {
    "id": "free-4",
    "fen": "5k2/3bp3/8/2N2b2/B7/8/K4R2/8 w - - 0 1",
    "sol": [
     "a4d7",
     "c5d7"
    ],
    "sq": "d7"
   },
   {
    "id": "free-5",
    "fen": "1k6/4p3/3p4/3n4/2N5/4N3/6K1/2N5 w - - 0 1",
    "sol": [
     "e3d5"
    ],
    "sq": "d5"
   },
   {
    "id": "free-6",
    "fen": "8/2k5/2p4n/1pP5/8/3BB3/7K/8 w - - 0 1",
    "sol": [
     "e3h6"
    ],
    "sq": "h6"
   },
   {
    "id": "free-7",
    "fen": "8/kp6/2p1n3/Np6/8/1B6/K7/8 w - - 0 1",
    "sol": [
     "b3e6"
    ],
    "sq": "e6"
   },
   {
    "id": "free-8",
    "fen": "1n6/k2n4/5p2/1Q6/1b6/8/N1N5/6K1 w - - 0 1",
    "sol": [
     "a2b4",
     "c2b4",
     "b5b4"
    ],
    "sq": "b4"
   }
  ]
 },
 {
  "id": "fork",
  "naslov": "Vilica",
  "opis": "Jednim potezom napadni dve figure odjednom.",
  "ikona": "n",
  "boja": "#9ad0ff",
  "tip": "fork",
  "xp": 14,
  "upit": "Beli je na potezu. Nađi potez koji <em>napada dve figure odjednom</em> – protivnik može da spase samo jednu!",
  "zadaci": [
   {
    "id": "fork-1",
    "fen": "8/2kp4/8/2N5/1r6/8/8/K7 w - - 0 1",
    "sol": [
     "c5a6"
    ]
   },
   {
    "id": "fork-2",
    "fen": "8/1q3q1k/8/8/8/7N/2K5/8 w - - 0 1",
    "sol": [
     "h3g5"
    ]
   },
   {
    "id": "fork-3",
    "fen": "8/4k3/1p5b/8/7N/8/4K3/8 w - - 0 1",
    "sol": [
     "h4f5"
    ]
   },
   {
    "id": "fork-4",
    "fen": "8/4n1k1/3q4/r7/8/8/1N6/7K w - - 0 1",
    "sol": [
     "b2c4"
    ]
   },
   {
    "id": "fork-5",
    "fen": "7k/8/8/3R1n2/6q1/8/3K4/3N4 w - - 0 1",
    "sol": [
     "d1e3"
    ]
   },
   {
    "id": "fork-6",
    "fen": "4n3/6k1/8/8/3r4/6B1/K7/8 w - - 0 1",
    "sol": [
     "g3e5"
    ]
   }
  ]
 },
 {
  "id": "save",
  "naslov": "Spasi figuru",
  "opis": "Tvoja figura je napadnuta – spasi je!",
  "ikona": "r",
  "boja": "#ffb0cf",
  "tip": "save",
  "xp": 10,
  "upit": "Beli je na potezu. <em>Jedna tvoja figura je u opasnosti!</em> Spasi je. Crvena polja napada protivnik.",
  "zadaci": [
   {
    "id": "save-1",
    "fen": "8/5k2/8/3r3N/3r4/8/8/2KR4 w - - 0 1",
    "sq": "h5"
   },
   {
    "id": "save-2",
    "fen": "3k4/8/8/3p4/2b5/8/7K/5BN1 w - - 0 1",
    "sq": "f1"
   },
   {
    "id": "save-3",
    "fen": "1k6/8/1b6/3p4/4N3/8/2K1P3/8 w - - 0 1",
    "sq": "e4"
   },
   {
    "id": "save-4",
    "fen": "8/k1bb4/8/8/8/6N1/1R6/4K3 w - - 0 1",
    "sq": "g3"
   },
   {
    "id": "save-5",
    "fen": "k7/2r5/7p/6R1/8/8/5P2/5K2 w - - 0 1",
    "sq": "g5"
   },
   {
    "id": "save-6",
    "fen": "5k2/8/3p4/2R1p3/n7/8/4B3/2K5 w - - 0 1",
    "sq": "c5"
   }
  ]
 },
 {
  "id": "mat2",
  "naslov": "Mat u dva poteza",
  "opis": "Prvi potez, protivnik odgovori, pa mat.",
  "ikona": "k",
  "boja": "#c3b3ff",
  "tip": "mat2",
  "xp": 20,
  "upit": "Beli je na potezu. Nađi <em>mat u dva poteza</em>: prvo odigraj pravi potez, pa kad protivnik odgovori – daj mat!",
  "zadaci": [
   {
    "id": "mat2-1",
    "fen": "8/5Q2/8/8/2K5/8/8/4k3 w - - 0 1"
   },
   {
    "id": "mat2-2",
    "fen": "7k/5Q2/B7/8/8/8/8/4K3 w - - 0 1"
   },
   {
    "id": "mat2-3",
    "fen": "6k1/8/6B1/8/8/8/5Q2/2K5 w - - 0 1"
   },
   {
    "id": "mat2-4",
    "fen": "8/2K5/8/7k/5Q2/8/8/1R6 w - - 0 1"
   },
   {
    "id": "mat2-5",
    "fen": "8/4R3/8/8/2R5/1K6/7k/4B3 w - - 0 1"
   },
   {
    "id": "mat2-6",
    "fen": "kB4R1/8/8/8/6KR/8/8/8 w - - 0 1"
   }
  ]
 }
];
window.ZADACI_UKUPNO = 37;
