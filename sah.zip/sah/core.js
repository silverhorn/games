/* ŠAH ŠKOLA – jezgro: stanje igre, poeni, značke, zvuk, glasno čitanje, ruter. */
(function () {
  "use strict";
  var KEY = "sah_skola_v1";

  function fresh() {
    return { xp: 0, lessons: {}, puz: {}, vez: {}, badges: {}, stat: { w: 0, l: 0, d: 0, lv: {}, friend: 0, blackWin: 0, mates: 0 }, sound: true, set: { coords: true, warn: true, read: false }, saved: null };
  }
  function load() {
    try {
      var j = JSON.parse(localStorage.getItem(KEY));
      if (j && typeof j === "object") {
        var f = fresh(); for (var k in j) f[k] = j[k];
        f.set = Object.assign({ coords: true, warn: true, read: false }, j.set || {});
        f.stat = Object.assign(fresh().stat, j.stat || {});
        return f;
      }
    } catch (e) { /* localStorage nije dostupan */ }
    return fresh();
  }
  var S = load();
  function save() { try { localStorage.setItem(KEY, JSON.stringify(S)); } catch (e) {} }

  function $(sel, root) { return (root || document).querySelector(sel); }
  function $$(sel, root) { return Array.prototype.slice.call((root || document).querySelectorAll(sel)); }
  function esc(s) { return String(s).replace(/[&<>"]/g, function (c) { return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]; }); }
  function shuffle(a) { a = a.slice(); for (var i = a.length - 1; i > 0; i--) { var j = Math.floor(Math.random() * (i + 1)), t = a[i]; a[i] = a[j]; a[j] = t; } return a; }
  var reduce = window.matchMedia && matchMedia("(prefers-reduced-motion: reduce)").matches;

  /* ───────── zvuk ───────── */
  var ac = null;
  function tone(f, d, type, vol, delay, slide) {
    if (!S.sound) return;
    try {
      ac = ac || new (window.AudioContext || window.webkitAudioContext)();
      if (ac.state === "suspended") ac.resume();
      var o = ac.createOscillator(), g = ac.createGain(), t0 = ac.currentTime + (delay || 0);
      o.type = type || "sine"; o.frequency.setValueAtTime(f, t0);
      if (slide) o.frequency.exponentialRampToValueAtTime(slide, t0 + d);
      g.gain.setValueAtTime(0.0001, t0); g.gain.exponentialRampToValueAtTime(vol || 0.08, t0 + 0.012); g.gain.exponentialRampToValueAtTime(0.0001, t0 + d);
      o.connect(g); g.connect(ac.destination); o.start(t0); o.stop(t0 + d + 0.05);
    } catch (e) {}
  }
  var sfx = {
    tap: function () { tone(660, 0.05, "triangle", 0.05); },
    move: function () { tone(210, 0.07, "triangle", 0.16, 0, 120); tone(900, 0.02, "square", 0.02); },
    capture: function () { tone(160, 0.12, "triangle", 0.2, 0, 70); tone(1100, 0.03, "square", 0.04); tone(130, 0.1, "sawtooth", 0.05, 0.03); },
    check: function () { tone(740, 0.1, "square", 0.05); tone(988, 0.16, "square", 0.05, 0.1); },
    castle: function () { tone(200, 0.06, "triangle", 0.15, 0, 110); tone(240, 0.06, "triangle", 0.15, 0.1, 130); },
    ok: function () { tone(523, 0.12, "triangle", 0.09); tone(659, 0.12, "triangle", 0.09, 0.1); tone(784, 0.22, "triangle", 0.09, 0.2); },
    no: function () { tone(240, 0.16, "sine", 0.06); tone(200, 0.2, "sine", 0.05, 0.12); },
    win: function () { [523, 659, 784, 1047, 1319].forEach(function (f, i) { tone(f, 0.2, "triangle", 0.09, i * 0.11); }); },
    lose: function () { [392, 330, 262].forEach(function (f, i) { tone(f, 0.28, "sine", 0.07, i * 0.2); }); },
    pop: function () { tone(880, 0.05, "square", 0.025); }
  };
  function moveSound(v) {
    if (!v) return;
    if (v.san && /[#+]$/.test(v.san)) sfx.check();
    else if (v.castle) sfx.castle();
    else if (v.captured) sfx.capture();
    else sfx.move();
  }

  /* ───────── glasno čitanje ───────── */
  function speak(text) {
    if (!("speechSynthesis" in window)) return;
    try {
      speechSynthesis.cancel();
      var u = new SpeechSynthesisUtterance(String(text).replace(/<[^>]+>/g, " ").replace(/[★✔✓→←]/g, " "));
      var vs = speechSynthesis.getVoices() || [], v = null, i, want = ["sr", "hr", "bs", "sl"];
      for (var w = 0; w < want.length && !v; w++) for (i = 0; i < vs.length; i++) if ((vs[i].lang || "").toLowerCase().indexOf(want[w]) === 0) { v = vs[i]; break; }
      if (v) { u.voice = v; u.lang = v.lang; } else u.lang = "sr-RS";
      u.rate = 0.9; speechSynthesis.speak(u);
    } catch (e) {}
  }
  function stopSpeak() { try { if ("speechSynthesis" in window) speechSynthesis.cancel(); } catch (e) {} }
  var canSpeak = "speechSynthesis" in window;

  /* ───────── obaveštenja i konfeti ───────── */
  function toast(html, cls, ms) {
    var box = $("#toasts"); if (!box) return;
    var t = document.createElement("div"); t.className = "toast " + (cls || ""); t.innerHTML = html; box.appendChild(t);
    setTimeout(function () { t.classList.add("out"); setTimeout(function () { t.remove(); }, 350); }, ms || 3200);
  }
  function confetti(n) {
    if (reduce) return;
    var cv = $("#confetti"); if (!cv) return;
    var ctx = cv.getContext("2d"), W = cv.width = window.innerWidth, H = cv.height = window.innerHeight;
    var cols = ["#ff6b57", "#ffc93c", "#5ed6a7", "#62b9ff", "#8b6df0", "#ff9ac1"], ps = [], i;
    for (i = 0; i < (n || 70); i++) ps.push({ x: W / 2 + (Math.random() - 0.5) * 140, y: H * 0.4, vx: (Math.random() - 0.5) * 12, vy: -Math.random() * 12 - 3, s: Math.random() * 7 + 4, c: cols[i % cols.length], r: Math.random() * 6, vr: (Math.random() - 0.5) * 0.4 });
    var t0 = performance.now();
    (function frame(t) {
      var dt = t - t0; ctx.clearRect(0, 0, W, H);
      ps.forEach(function (p) { p.vy += 0.3; p.x += p.vx; p.y += p.vy; p.r += p.vr; ctx.save(); ctx.translate(p.x, p.y); ctx.rotate(p.r); ctx.fillStyle = p.c; ctx.globalAlpha = Math.max(0, 1 - dt / 2300); ctx.fillRect(-p.s / 2, -p.s / 3, p.s, p.s / 1.6); ctx.restore(); });
      if (dt < 2300) requestAnimationFrame(frame); else ctx.clearRect(0, 0, W, H);
    })(t0);
  }

  /* ───────── poeni, činovi, značke ───────── */
  function rankOf(xp) { var r = RANGOVI[0]; for (var i = 0; i < RANGOVI.length; i++) if (xp >= RANGOVI[i].od) r = RANGOVI[i]; return r; }
  function nextRank(xp) { for (var i = 0; i < RANGOVI.length; i++) if (xp < RANGOVI[i].od) return RANGOVI[i]; return null; }
  function addXP(n) {
    if (!n) return;
    var before = rankOf(S.xp).ime; S.xp += n; save(); updateHeader();
    var chip = $("#xp"); if (chip && !reduce) { chip.classList.remove("bump"); void chip.offsetWidth; chip.classList.add("bump"); }
    var r = rankOf(S.xp);
    if (r.ime !== before) { toast('<span class="tb">' + PIECES.icon(r.t, "w") + "</span> Novi čin: <b>" + r.ime + "</b>!", "rank", 4200); confetti(90); sfx.win(); }
  }
  function updateHeader() {
    var n = $("#xpn"), r = $("#rank"), s = $("#snd"), ic = $("#rankic");
    if (n) n.textContent = S.xp;
    var rk = rankOf(S.xp);
    if (r) r.textContent = rk.ime;
    if (ic) ic.innerHTML = PIECES.icon(rk.t, "w");
    if (s) s.textContent = S.sound ? "🔊" : "🔇";
  }
  function award(id) {
    if (S.badges[id]) return false;
    var b = null; for (var i = 0; i < ZNACKE.length; i++) if (ZNACKE[i].id === id) b = ZNACKE[i];
    if (!b) return false;
    S.badges[id] = Date.now(); save();
    toast('<span class="tb">' + b.emoji + "</span> Nova značka: <b>" + esc(b.ime) + "</b>", "badge", 4200);
    confetti(60); sfx.win();
    return true;
  }
  function puzCount() { return Object.keys(S.puz).filter(function (k) { return k.charAt(0) !== "_"; }).length; }
  function checkBadges() {
    var nl = Object.keys(S.lessons).filter(function (k) { return S.lessons[k] && S.lessons[k].done; }).length;
    if (nl >= LEKCIJE.length) award("skola");
    var np = puzCount();
    if (np >= 10) award("zad10"); if (np >= 25) award("zad25"); if (np >= window.ZADACI_UKUPNO) award("zadSve");
    if (S.stat.w + S.stat.l + S.stat.d >= 1) award("partija1");
    if (S.stat.w >= 1) award("pobeda1");
    if (S.stat.w >= 5) award("pobeda5");
    if (S.stat.blackWin >= 1) award("crni");
    if (S.stat.friend >= 1) award("prijatelj");
    for (var l = 1; l <= 5; l++) if (S.stat.lv[l] && S.stat.lv[l].w >= 1) award("nivo" + l);
  }

  /* ───────── ruter ───────── */
  var views = {}, meta = {}, cleanup = null, cur = { name: "home", a: "", b: "" };
  function reg(name, title, fn) { views[name] = fn; meta[name] = title; }
  function go(path) { location.hash = "#/" + (path || ""); }
  function route() {
    var h = location.hash.replace(/^#\/?/, ""), p = h.split("/"), name = p[0] || "home";
    if (!views[name]) name = "home";
    if (cleanup) { try { cleanup(); } catch (e) {} cleanup = null; }
    stopSpeak();
    cur = { name: name, a: p[1] || "", b: p[2] || "", c: p[3] || "" };
    var app = $("#app"); app.innerHTML = "";
    var root = document.createElement("div"); root.className = "view v-" + name; app.appendChild(root);
    window.scrollTo(0, 0);
    var t = meta[name] || "Šah škola";
    $("#ttl").textContent = t; $("#back").hidden = name === "home";
    document.title = (name === "home" ? "" : t + " · ") + "Šah škola";
    try { cleanup = views[name](root, cur.a, cur.b, cur.c) || null; }
    catch (e) { root.innerHTML = '<div class="card"><h2>Ups!</h2><p>Nešto nije u redu. Vrati se na početak.</p><a class="btn" href="#/">Početna</a></div>'; if (window.console) console.error(e); }
  }
  function backTarget() {
    var n = cur.name, a = cur.a;
    if (n === "skola" && a) return "#/skola";
    if (n === "zadaci" && a) return "#/vezbe";
    if (n === "vezba" && a) return "#/vezbe";
    if (n === "igra" && a) return "#/igra";
    return "#/";
  }
  function init() {
    $("#back").addEventListener("click", function () { sfx.tap(); location.hash = backTarget(); });
    $("#snd").addEventListener("click", function () { S.sound = !S.sound; save(); updateHeader(); if (S.sound) sfx.tap(); });
    $("#xp").addEventListener("click", function () { location.hash = "#/znacke"; });
    window.addEventListener("hashchange", route);
    window.addEventListener("resize", function () { var c = $("#confetti"); if (c) { c.width = innerWidth; c.height = innerHeight; } });
    updateHeader(); route();
  }

  window.A = {
    S: S, save: save, $: $, $$: $$, esc: esc, shuffle: shuffle, reduce: reduce, sfx: sfx, moveSound: moveSound, tone: tone,
    speak: speak, stopSpeak: stopSpeak, canSpeak: canSpeak, toast: toast, confetti: confetti,
    puzCount: puzCount, addXP: addXP, award: award, checkBadges: checkBadges, rankOf: rankOf, nextRank: nextRank, updateHeader: updateHeader,
    reg: reg, go: go, init: init,
    resetAll: function () { try { localStorage.removeItem(KEY); } catch (e) {} location.hash = "#/"; location.reload(); }
  };
})();
