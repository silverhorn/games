/* ŠAH ŠKOLA – zadaci: mat u 1, besplatan plen, vilica, spasi figuru, mat u 2. */
(function () {
  "use strict";
  var $ = A.$, esc = A.esc, E = window.ChessEngine;
  var PRAISE = ["Bravo!", "Odlično!", "Tačno!", "Sjajno!", "Super!", "Majstorski!"];
  function praise() { return PRAISE[Math.floor(Math.random() * PRAISE.length)]; }
  function pack(id) { for (var i = 0; i < ZADACI.length; i++) if (ZADACI[i].id === id) return ZADACI[i]; return null; }
  function solved(id) { return !!A.S.puz[id]; }
  function packDone(p) { return p.zadaci.filter(function (z) { return solved(z.id); }).length; }

  A.reg("vezbe", "Zadaci", function (root) {
    var h = '<p class="lead">Zadaci su kratke zagonetke. Reši ih i zaradi poene! Ako zapneš, dodirni <b>Savet</b>.</p><div class="pgrid">';
    ZADACI.forEach(function (p) {
      var d = packDone(p), n = p.zadaci.length;
      h += '<a class="pack" href="#/zadaci/' + p.id + '" style="--tc:' + p.boja + '">' +
        '<span class="pic">' + PIECES.icon(p.ikona, "w", true) + "</span><div><h3>" + esc(p.naslov) + "</h3><p>" + esc(p.opis) + "</p>" +
        '<div class="bar"><i style="width:' + Math.round(d / n * 100) + '%"></i></div><small>' + d + " od " + n + " rešeno" + (d === n ? " ✔" : "") + "</small></div></a>";
    });
    h += "</div>";
    root.innerHTML = h;
  });

  A.reg("zadaci", "Zadaci", function (root, packId, num) {
    var P = pack(packId); if (!P) { A.go("vezbe"); return null; }
    var n = +num; if (!n || n < 1 || n > P.zadaci.length) { n = 1; for (var q = 0; q < P.zadaci.length; q++) if (!solved(P.zadaci[q].id)) { n = q + 1; break; } }
    return run(root, P, n - 1);
  });

  function run(root, P, idx) {
    var Z = P.zadaci[idx], g = new E.Game(Z.fen), done = solved(Z.id), busy = false, alive = true, wrong = 0, stage = 0, timers = [], key = null;
    $("#ttl").textContent = P.naslov;
    var chips = P.zadaci.map(function (z, i) { return '<a class="zc' + (solved(z.id) ? " ok" : "") + (i === idx ? " cur" : "") + '" href="#/zadaci/' + P.id + "/" + (i + 1) + '">' + (i + 1) + "</a>"; }).join("");
    root.innerHTML =
      '<div class="lsn zd"><div class="lsn-top"><div class="zchips">' + chips + "</div></div>" +
      '<div class="lsn-main"><div class="lsn-board"><div id="zb"></div></div>' +
      '<div class="lsn-side"><div class="zhead"><b>Zadatak ' + (idx + 1) + " od " + P.zadaci.length + "</b><span>" + (done ? "✔ rešeno" : "+" + P.xp + " poena") + '</span></div>' +
      '<div class="peko" id="zp"></div>' +
      '<div class="row lsn-act"><button class="btn ghost sm" id="zhint">💡 Savet</button><button class="btn ghost sm" id="zreset">↻ Ispočetka</button>' +
      (idx > 0 ? '<a class="btn ghost sm" href="#/zadaci/' + P.id + "/" + idx + '">◀</a>' : "") +
      '<button class="btn go" id="znext"' + (done ? "" : " disabled") + ">" + (idx === P.zadaci.length - 1 ? "Gotovo ✔" : "Sledeći ▶") + "</button></div></div></div></div>";
    var peko = new UI.Peko($("#zp", root)), btnNext = $("#znext", root);
    function later(fn, ms) { var t = setTimeout(function () { if (alive) fn(); }, ms); timers.push(t); }

    var board = new Board($("#zb", root), {
      orient: "w", coords: A.S.set.coords,
      canGrab: function (sq) { if (busy || finished) return false; var p = g.get(sq); return !!p && p.color === "w"; },
      getTargets: function (sq) { return g.moves({ square: sq }).map(function (m) { return { to: m.to, cap: !!m.captured }; }); },
      onMove: function (f, t) { if (busy || finished) return false; return UI.tryMove(board, g, f, t, attempt); }
    });
    var finished = false;
    board.setPieces(g.pieceList(), false);
    function refreshZone() { board.unmark("zone"); if (P.tip === "save") UI.attackedSquares(g, "b").forEach(function (sq) { var p = g.get(sq); if (p && p.color === "b") return; board.mark(sq, "zone"); }); }
    refreshZone();
    peko.say(P.upit);

    function peek(f, t, p) {
      var v = g.move({ from: f, to: t, promotion: p }); if (!v) return null;
      var r = { v: v, mate: g.isCheckmate(), stale: g.isStalemate(), check: g.inCheck(), hangW: g.hanging("w"), keyOk: false };
      g.undo(); return r;
    }
    // da li je potez "ključni" u mat-u-u-2: posle njega svaki odgovor crnog dozvoljava mat u 1
    function isKey(f, t, p) {
      var v = g.move({ from: f, to: t, promotion: p }); if (!v) return false;
      var ok = !g.isStalemate() && !g.isCheckmate() && g.moves().length > 0;
      if (ok) { var rep = g.moves(), i; for (i = 0; i < rep.length && ok; i++) { g.move({ from: rep[i].from, to: rep[i].to, promotion: rep[i].promotion }); if (!g.mateIn1Moves().length) ok = false; g.undo(); } }
      g.undo(); return ok;
    }
    function keyMoves() {
      if (g.mateIn1Moves().length) return [];
      return g.moves().filter(function (m) { return isKey(m.from, m.to, m.promotion); });
    }

    function exec(f, t, p, cb, keepTurn) {
      var v = g.move({ from: f, to: t, promotion: p }); if (!v) { board.snap(f); return; }
      A.moveSound(v); board.setLast(f, t); board.setCheck(null); busy = true;
      board.animateMove(v, function () { busy = false; if (v.check) board.setCheck(g.kingSquare(v.color === "w" ? "b" : "w")); refreshZone(); if (cb) cb(v); });
    }
    function bad(msg) { wrong++; A.sfx.no(); peko.say(msg, "sad"); if (wrong >= 2) hint(true); }
    function solvedNow(msg) {
      finished = true; A.sfx.ok();
      var first = !solved(Z.id);
      if (first) {
        A.S.puz[Z.id] = Date.now(); A.save(); A.addXP(P.xp);
        if (P.tip === "mat1") A.award("mat1");
        var d = packDone(P);
        if (d === P.zadaci.length && !A.S.puz["_p_" + P.id]) { A.S.puz["_p_" + P.id] = 1; A.save(); A.addXP(30); A.toast("🎉 Završen paket: <b>" + esc(P.naslov) + "</b> (+30)", "badge", 4200); A.confetti(100); }
        A.checkBadges();
      }
      peko.say('<span class="ok">' + praise() + "</span> " + msg + (first ? " <b>+" + P.xp + " poena</b>" : ""), "happy");
      A.confetti(40);
      btnNext.disabled = false; $(".zhead span", root).textContent = "✔ rešeno";
      var chip = A.$$(".zc", root)[idx]; if (chip) chip.classList.add("ok");
    }

    function attempt(f, t, p) {
      var T = P.tip, mv = g.moves({ square: f }).filter(function (m) { return m.to === t && (!p || m.promotion === p); })[0];
      if (!mv) { board.snap(f); return; }
      var uci = f + t;
      if (T === "mat1" || (T === "mat2" && stage === 1)) {
        var r = peek(f, t, p);
        if (r.mate) exec(f, t, p, function () { solvedNow("<b>ŠAH-MAT!</b> " + PIECES.NAMES[mv.piece] + " na " + t + " matira kralja – nema izlaza."); });
        else { board.snap(f); bad(r.stale ? "To je <b>PAT</b> – nerešeno! Kralj nije u šahu, a nema poteza. Probaj drugi potez." : r.check ? "To je šah, ali kralj ima izlaz. Traži potez posle kojeg nema izlaza." : "To nije ni šah. Traži potez koji napada kralja tako da on nema izlaz."); }
      } else if (T === "free") {
        if (Z.sol.indexOf(uci) >= 0) exec(f, t, p, function () { solvedNow("Ta figura nije imala zaštitu – besplatan plen!"); });
        else {
          board.snap(f); var r2 = peek(f, t, p);
          if (mv.captured) bad(r2.hangW.some(function (h) { return h.square === t; }) ? "Ta figura je <b>zaštićena</b>. Ako je pojedeš, protivnik će pojesti tvoju figuru. Traži figuru koju niko ne čuva!" : "Možeš to da pojedeš, ali ima bolji plen. Traži figuru koju niko ne čuva!");
          else bad("Ovo nije jedenje. Traži crnu figuru koju možeš da pojedeš besplatno.");
        }
      } else if (T === "fork") {
        if (Z.sol.indexOf(uci) >= 0) exec(f, t, p, function () { solvedNow(PIECES.NAMES[mv.piece] + " na " + t + " napada dve figure odjednom. Protivnik može da spase samo jednu!"); });
        else { board.snap(f); bad("Taj potez ne napada dve figure odjednom. Traži polje sa kojeg figura gleda u dve crne figure."); }
      } else if (T === "save") {
        var r3 = peek(f, t, p);
        if (!r3.hangW.length) exec(f, t, p, function () { solvedNow("Nijedna tvoja figura nije više u opasnosti. Dobro si pazio!"); });
        else { board.snap(f); bad("Ta tvoja figura je još uvek u opasnosti (ili si ostavio drugu bez zaštite). Pogledaj crvena polja!"); }
      } else if (T === "mat2" && stage === 0) {
        if (isKey(f, t, p)) {
          stage = 1; wrong = 0;
          exec(f, t, p, function () {
            peko.say("Dobar potez! Pogledaj šta crni odgovara…");
            busy = true;
            later(function () {
              var rep = g.moves(), pick = rep[Math.floor(Math.random() * rep.length)], v = g.move({ from: pick.from, to: pick.to, promotion: pick.promotion });
              A.moveSound(v); board.setLast(v.from, v.to);
              board.animateMove(v, function () { busy = false; refreshZone(); peko.say("Sada daj <em>mat</em>!"); });
            }, 700);
          });
        } else { board.snap(f); bad("Posle tog poteza crni može da se spase. Traži potez posle kojeg, šta god crni odigra, ti matiraš sledećim potezom."); }
      } else board.snap(f);
    }

    function hint(auto) {
      board.clearArrows(); var T = P.tip, sq, to;
      if (T === "mat1" || (T === "mat2" && stage === 1)) { var m = g.mateIn1Moves()[0]; if (m) { sq = m.from; to = m.to; } }
      else if (T === "free" || T === "fork") { sq = Z.sol[0].slice(0, 2); to = Z.sol[0].slice(2, 4); }
      else if (T === "save") { var h = g.hanging("w")[0]; sq = h && h.square; }
      else if (T === "mat2") { var k = keyMoves()[0]; if (k) { sq = k.from; to = k.to; } }
      if (sq) board.flash(sq, "hint", 1800);
      if (!auto && to && wrong >= 1) board.arrow(sq, to, "ar");
      if (!auto) peko.say(T === "save" ? "Pogledaj figuru koja treperi. Koja je opasnost? Pomeri je ili je zaštiti." : "Pogledaj figuru koja treperi – ona treba da odigra potez." + (wrong >= 1 ? " Strelica pokazuje i gde." : " Ako zapneš, dodirni Savet još jednom."));
    }
    $("#zhint", root).onclick = function () { A.sfx.tap(); wrong = Math.max(wrong, 1); hint(false); };
    $("#zreset", root).onclick = function () { A.sfx.tap(); window.dispatchEvent(new Event("hashchange")); };
    btnNext.onclick = function () { A.sfx.tap(); if (idx < P.zadaci.length - 1) A.go("zadaci/" + P.id + "/" + (idx + 2)); else A.go("vezbe"); };

    return function () { alive = false; timers.forEach(clearTimeout); board.destroy(); A.stopSpeak(); };
  }
})();
