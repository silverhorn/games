ŠAH ŠKOLA – šah za decu 7–10 godina: prvo učenje, pa igra
Raspakuj zip i otvori index.html u pregledaču (ne treba server ni internet).
Fajlovi: index.html, style.css, ekrani.css, engine.js, pieces.js, board.js, data_osnova.js, data_lekcije.js, data_zadaci.js, core.js, common.js, home.js, skola.js, zadaci.js, igra.js – sve ostaje u istom folderu.

Šta je u igri:
- Škola (18 lekcija): tabla i polja, kako se kreće svaka figura (top, lovac, dama, skakač, kralj, pešak), vrednost figura, šah, mat, pat, rokada, promocija, en passant, prvi potezi u partiji i kako da ne ostaviš figuru bez zaštite. Svaka lekcija se radi na pravoj tabli: Peško objašnjava, a dete samo pomera figure. Za svaku lekciju se dobijaju zvezdice.
- Zadaci (37 zagonetki): mat u 1, besplatan plen, vilica, spasi figuru i mat u 2. Ima Savet, a pogrešan potez dobija objašnjenje zašto nije dobar.
- Partija protiv računara: 5 nivoa (od „Mali pešak“ koji greši, do „Majstor“ koji igra pažljivo). Može se birati bele, crne ili nasumično. Peško upozori kad dete krene da ostavi figuru bez zaštite ili da da mat (može da se isključi na početnoj strani), dugme Savet pokazuje dobar potez i objašnjava ga, može da se vrati potez, partija se čuva i nastavlja kasnije, a posle partije se potezi pregledaju korak po korak.
- Sa nekim: dvoje igraju na istom ekranu (tabla može da se okreće, i sama posle svakog poteza).
- Na daljinu: igra sa drugarom na drugom uređaju bez interneta u igri – posle svakog poteza igra napravi kratak kod koji se pošalje porukom (Viber, WhatsApp, SMS), a drugar ga zalepi u svoju igru.
- Završnice: vežba mat damom, mat topom, dva topa i pešak koji postaje dama (računar se brani).
- Poeni, 6 činova (od Malog pešaka do Šahovskog kralja) i 24 značke.
- Sve može da se čita naglas (dugme 🔊 kod Peška), a na početnoj strani se uključuju čitanje, oznake polja i upozorenja.

Napredak se čuva u pregledaču (localStorage). Dugme „Počni sve iznova“ je na ekranu sa značkama.
Napomena: ako se igra otvori iz pregledača koji blokira lokalne fajlove, računar i dalje radi (samo razmišlja bez pozadinske niti).
