/* ŠAH ŠKOLA – početni ekran i ekran sa značkama. */
(function () {
  "use strict";
  var $ = A.$, esc = A.esc;

  function lessonsDone() { return LEKCIJE.filter(function (l) { return A.S.lessons[l.id] && A.S.lessons[l.id].done; }).length; }
  function nextLesson() { for (var i = 0; i < LEKCIJE.length; i++) if (!(A.S.lessons[LEKCIJE[i].id] && A.S.lessons[LEKCIJE[i].id].done)) return LEKCIJE[i]; return null; }
  function puzDone() { return A.puzCount(); }

  A.reg("home", "Šah škola", function (root) {
    var done = lessonsDone(), nxt = nextLesson(), xp = A.S.xp, rk = A.rankOf(xp), nr = A.nextRank(xp);
    var pct = nr ? Math.round((xp - rk.od) / (nr.od - rk.od) * 100) : 100;
    var go, goTxt;
    if (nxt) { go = "#/skola/" + nxt.id; goTxt = done === 0 ? "Počni učenje" : "Nastavi: " + nxt.naslov; }
    else { go = "#/igra"; goTxt = "Odigraj partiju"; }

    root.innerHTML =
      '<section class="hero">' +
        '<div class="hero-text">' +
          '<h2>' + (done === 0 && xp === 0 ? "Hajde da učimo šah!" : "Opet si tu, " + esc(rk.ime.toLowerCase()) + "!") + "</h2>" +
          '<div class="peko" id="hp"></div>' +
          '<div class="rankbox"><div class="rk"><span>' + A.rankOf(xp).ime + "</span><span>" + xp + " ★</span></div>" +
            '<div class="bar"><i style="width:' + pct + '%"></i></div>' +
            "<small>" + (nr ? "Još " + (nr.od - xp) + " poena do čina „" + nr.ime + "“" : "Najviši čin! Bravo!") + "</small></div>" +
          '<a class="btn big go" id="hgo" href="' + go + '">' + esc(goTxt) + "</a>" +
        "</div>" +
        '<div class="hero-board"><div id="hb"></div></div>' +
      "</section>" +

      '<div class="sec"><h2>Tvoj put</h2><span class="muted">Prvo uči, zatim vežbaj, pa igraj!</span></div>' +
      '<div class="steps3">' +
        tile("#/skola", "1", "Uči", "Škola šaha", "Lekcije sa Peškom: tabla, figure i pravila.", done + " od " + LEKCIJE.length + " lekcija", done / LEKCIJE.length, "var(--sun)") +
        tile("#/vezbe", "2", "Vežbaj", "Zadaci", "Nađi mat, pojedi nezaštićenu figuru, napravi vilicu.", puzDone() + " od " + ZADACI_UKUPNO + " zadataka", puzDone() / ZADACI_UKUPNO, "var(--mint)") +
        tile("#/igra", "3", "Igraj", "Prava partija", "Protiv računara na 5 nivoa, ili sa nekim drugim.", A.S.stat.w + " pobeda", Math.min(1, A.S.stat.w / 5), "var(--tang)") +
      "</div>" +

      '<div class="tiles2">' +
        mini("#/igra/dvoje", "👫", "Igraj sa nekim", "Dvoje na istom ekranu", "var(--sky)") +
        mini("#/igra/daljina", "🌍", "Igraj na daljinu", "Sa drugom decom, preko koda", "var(--pink)") +
        mini("#/igra/zavrsnice", "🏁", "Završnice", "Vežbaj mat damom i topom", "#c3b3ff") +
        mini("#/znacke", "🏅", "Značke", Object.keys(A.S.badges).length + " od " + ZNACKE.length, "#ffd9a8") +
      "</div>" +

      '<div class="sec"><h2>Podešavanja</h2></div>' +
      '<div class="card sets" id="sets"></div>';

    // živa tabla sa figurama koje pričaju
    var pk = new UI.Peko($("#hp", root), {});
    pk.say("Ja sam <em>Peško</em>, tvoj vodič kroz šah! Dodirni neku figuru na tabli i pomeri je.");
    var g = new ChessEngine.Game("8/8/8/3Q4/5B2/1N6/4P1P1/R3K3 w - - 0 1");
    var board = new Board($("#hb", root), {
      orient: "w", coords: A.S.set.coords,
      canGrab: function (sq) { var p = g.get(sq); return !!p && p.color === "w"; },
      getTargets: function (sq) { return g.moves({ square: sq }).map(function (m) { return { to: m.to, cap: !!m.captured }; }); },
      onGrab: function (sq) { introduce(sq); },
      onSquare: function (sq) { if (g.get(sq)) introduce(sq); return false; },
      onMove: function (from, to) {
        return UI.tryMove(board, g, from, to, function (f, t, pr) {
          var v = g.move({ from: f, to: t, promotion: pr }); g.setTurn("w");
          A.moveSound(v); board.setLast(f, t); board.animateMove(v);
        });
      }
    });
    board.setPieces(g.pieceList(), true);
    function introduce(sq) {
      var p = g.get(sq); if (!p) return; A.sfx.tap();
      pk.say(OPIS_FIGURA[p.type] + " Kuda sme da ide? Pogledaj tačkice.");
    }

    // podešavanja
    function sets() {
      var s = A.S.set;
      $("#sets", root).innerHTML =
        sw("read", "🔊 Peško čita naglas", s.read) + sw("coords", "🔤 Slova i brojevi na tabli", s.coords) + sw("warn", "⚠️ Upozori me na greške u partiji", s.warn);
      A.$$(".sw", root).forEach(function (b) {
        b.onclick = function () {
          var k = b.getAttribute("data-k"); s[k] = !s[k]; A.save(); A.sfx.tap();
          if (k === "coords") board.setCoords(s.coords);
          if (k === "read" && s.read) A.speak("Peško sada čita naglas.");
          if (k === "read" && !s.read) A.stopSpeak();
          sets();
        };
      });
    }
    function sw(k, t, on) { return '<button class="sw ' + (on ? "on" : "") + '" data-k="' + k + '" aria-pressed="' + on + '"><i></i><span>' + t + "</span></button>"; }
    sets();
    return function () { board.destroy(); };
  });

  function tile(href, num, kicker, title, desc, prog, frac, color) {
    return '<a class="step3" href="' + href + '" style="--tc:' + color + '"><span class="n">' + num + "</span><div><small>" + kicker + "</small><h3>" + title + "</h3><p>" + desc + "</p></div>" +
      '<div class="pg"><div class="bar"><i style="width:' + Math.round((frac || 0) * 100) + '%"></i></div><b>' + prog + "</b></div></a>";
  }
  function mini(href, emoji, t, d, c) {
    return '<a class="mini" href="' + href + '" style="--tc:' + c + '"><span class="me">' + emoji + "</span><div><b>" + t + "</b><small>" + d + "</small></div></a>";
  }

  /* ───────── značke ───────── */
  A.reg("znacke", "Značke i poeni", function (root) {
    var S = A.S, rk = A.rankOf(S.xp), nr = A.nextRank(S.xp), n = Object.keys(S.badges).length;
    var h = '<div class="card znhead"><div class="zr"><span class="zi">' + PIECES.icon(rk.t, "w") + "</span><div><h2>" + rk.ime + "</h2><p class=\"lead\">" + S.xp + " poena" + (nr ? " · još " + (nr.od - S.xp) + " do čina „" + nr.ime + "“" : "") + "</p></div></div>" +
      '<div class="ranks">' + RANGOVI.map(function (r) { return '<span class="rkp' + (S.xp >= r.od ? " on" : "") + '" title="' + r.ime + '">' + PIECES.icon(r.t, "w") + "<i>" + r.ime + "</i></span>"; }).join("") + "</div></div>";
    h += '<div class="sec"><h2>Značke</h2><span class="muted">' + n + " od " + ZNACKE.length + "</span></div><div class=\"badges\">";
    ZNACKE.forEach(function (b) {
      var got = !!S.badges[b.id];
      h += '<div class="bdg ' + (got ? "got" : "") + '"><span class="be">' + (got ? b.emoji : "🔒") + "</span><b>" + esc(b.ime) + "</b><small>" + esc(b.opis) + "</small></div>";
    });
    h += "</div>";
    h += '<div class="sec"><h2>Tvoji rezultati</h2></div><div class="card stats">' +
      stat(S.stat.w, "pobeda") + stat(S.stat.d, "remija") + stat(S.stat.l, "poraza") + stat(done(), "lekcija") + stat(A.puzCount(), "zadataka") + "</div>";
    h += '<div class="row c" style="margin-top:26px"><button class="btn ghost sm" id="rst">Počni sve iznova</button></div>';
    root.innerHTML = h;
    function done() { return lessonsDone(); }
    function stat(v, l) { return '<div class="st"><b>' + v + "</b><span>" + l + "</span></div>"; }
    $("#rst", root).onclick = function () {
      this.textContent = "Dodirni još jednom da obrišeš sve";
      this.onclick = function () { A.resetAll(); };
    };
  });

  window.HOME = { lessonsDone: lessonsDone, nextLesson: nextLesson };
})();
