/* ŠAH ŠKOLA – škola: spisak lekcija i pokretač lekcija (Peško vodi dete korak po korak). */
(function () {
  "use strict";
  var $ = A.$, esc = A.esc, E = window.ChessEngine;
  var PRAISE = ["Bravo!", "Odlično!", "Tako je!", "Super!", "Sjajno!", "Bravo, tako treba!", "Savršeno!"];
  function praise() { return PRAISE[Math.floor(Math.random() * PRAISE.length)]; }
  function findL(id) { for (var i = 0; i < LEKCIJE.length; i++) if (LEKCIJE[i].id === id) return LEKCIJE[i]; return null; }
  function isDone(id) { return !!(A.S.lessons[id] && A.S.lessons[id].done); }
  var streak = 0; // tačnih odgovora zaredom (za značku)
  function good() { streak++; if (streak >= 5) A.award("pamet"); }
  function bad() { streak = 0; }

  A.reg("skola", "Škola šaha", function (root, id) {
    var L = id && findL(id);
    return L ? runLesson(root, L) : menu(root);
  });

  /* ───────── spisak lekcija ───────── */
  function menu(root) {
    var nxt = HOME.nextLesson(), groups = [], seen = {}, h = '<p class="lead">Dodirni lekciju. Peško će te voditi korak po korak. Najbolje je da ideš redom!</p>';
    LEKCIJE.forEach(function (l) { if (!seen[l.grupa]) { seen[l.grupa] = 1; groups.push(l.grupa); } });
    groups.forEach(function (gr) {
      h += '<div class="sec"><h2>' + esc(gr) + '</h2></div><div class="lgrid">';
      LEKCIJE.forEach(function (l, i) {
        if (l.grupa !== gr) return;
        var d = isDone(l.id), r = d ? A.S.lessons[l.id].r || 1 : 0;
        h += '<a class="lcard' + (d ? " done" : "") + (nxt && nxt.id === l.id ? " next" : "") + '" href="#/skola/' + l.id + '">' +
          '<span class="lno">' + (i + 1) + '</span><span class="lic">' + PIECES.icon(l.ikona || "p", "w", true) + "</span>" +
          "<div><h3>" + esc(l.naslov) + "</h3><p>" + esc(l.opis) + "</p></div>" +
          '<span class="lst">' + (d ? "★★★".slice(0, r) + '<s>' + "★★★".slice(r) + "</s>" : (nxt && nxt.id === l.id ? "▶ Sledeća" : "")) + "</span></a>";
      });
      h += "</div>";
    });
    root.innerHTML = h;
  }

  /* ───────── pokretač lekcije ───────── */
  function runLesson(root, L) {
    var steps = L.koraci, idx = 0, mistakes = 0, step = null, st = null, g = null, side = "w", mode = "none", busy = false, alive = true, timers = [], startFen = "";

    root.innerHTML =
      '<div class="lsn"><div class="lsn-top"><div class="dots" id="ld"></div></div>' +
      '<div class="lsn-main"><div class="lsn-board"><div id="lb"></div></div>' +
      '<div class="lsn-side"><div class="peko" id="lp"></div><div class="lsn-task" id="lt"></div>' +
      '<div class="row lsn-act"><button class="btn ghost sm" id="lhint">💡 Pomoć</button><button class="btn ghost sm" id="lreset" hidden>↻ Ispočetka</button><button class="btn go" id="lnext" disabled>Dalje ▶</button></div></div></div></div>';

    var peko = new UI.Peko($("#lp", root)), task = $("#lt", root), btnNext = $("#lnext", root), btnHint = $("#lhint", root), btnReset = $("#lreset", root);
    var board = new Board($("#lb", root), {
      orient: "w", coords: A.S.set.coords, interactive: false,
      canGrab: function (sq) { if (mode !== "move" || busy || !g) return false; var p = g.get(sq); return !!p && p.color === side && (!step.only || step.only.indexOf(p.type) >= 0); },
      getTargets: function (sq) { return g.moves({ square: sq }).map(function (m) { return { to: m.to, cap: !!m.captured }; }); },
      onMove: function (from, to) {
        if (busy || mode !== "move") return false;
        return UI.tryMove(board, g, from, to, attempt);
      },
      onSquare: function (sq) { return onTap(sq); }
    });
    function fmt(t) { return String(t || "").replace("{{vals}}", UI.vals()); }
    function later(fn, ms) { var t = setTimeout(function () { if (alive) fn(); }, ms); timers.push(t); return t; }
    function clearTimers() { timers.forEach(clearTimeout); timers = []; }

    // točkice napretka
    var dotsEl = $("#ld", root);
    dotsEl.innerHTML = steps.map(function () { return '<i class="dot"></i>'; }).join("");
    function paintDots() { A.$$(".dot", dotsEl).forEach(function (d, i) { d.className = "dot" + (i < idx ? " on" : "") + (i === idx ? " cur" : ""); }); }

    /* ——— ulazak u korak ——— */
    function enter(i) {
      clearTimers(); idx = i; step = steps[i]; busy = false; mode = "none";
      st = { done: false, n: 0, wrong: 0, stage: 0, left: (step.stars || []).slice(), seen: {}, found: {}, fi: 0, hints: 0 };
      side = step.side || "w";
      var T = step.t || "say";
      g = new E.Game(step.fen || (g ? g.fen() : E.START));
      startFen = g.fen();
      var face = step.face !== undefined ? step.face : L.face !== false;
      board.setOrient(step.orient || "w");
      board.setCoords(step.coords !== undefined ? step.coords : A.S.set.coords);
      board.clearAllMarks(); board.setCheck(null); board.setLast(null);
      board.setPieces(g.pieceList(), face);
      board.o.interactive = true;
      task.innerHTML = "";
      btnReset.hidden = true; btnHint.hidden = false; btnReset.textContent = "↻ Ispočetka";
      paintDots(); refreshNav();

      var m = step.marks, k;
      if (m) for (k in m) m[k].forEach(function (sq) { board.mark(sq, k); });
      (step.arrows || []).forEach(function (a) { board.arrow(a[0], a[1], a[2]); });
      if (step.stars) board.setStars(step.stars);
      refreshZone();

      var intro = function () {
        switch (T) {
          case "say": mode = "none"; st.done = true; break;
          case "moves": mode = "move"; btnReset.hidden = false; counter(); break;
          case "stars": mode = "move"; btnReset.hidden = false; counter(); break;
          case "play": case "mate": case "escape": case "fix": mode = "move"; btnReset.hidden = false; break;
          case "finds": mode = "tap"; nextFind(true); break;
          case "tap": mode = "tap"; counter(); break;
          case "hang": mode = "tap"; counter(); break;
          case "meet": mode = "tap"; counter(); break;
          case "choose": mode = "none"; renderChoose(); break;
        }
        refreshNav();
      };
      if (T !== "finds") peko.say(fmt(step.say), step.mood);
      if (step.pre || step.demo) {
        busy = true; mode = "none"; btnHint.hidden = true;
        runScript(step.pre || step.demo, function () { busy = false; btnHint.hidden = false; if (step.afterPre) peko.say(fmt(step.afterPre)); if (T === "say") { btnReset.hidden = false; btnReset.textContent = "↻ Ponovi"; } intro(); });
      } else intro();
      if (T === "say" && !step.demo) btnReset.hidden = true;
    }

    function runScript(list, done) {
      var i = 0;
      (function nxt() {
        if (i >= list.length) { if (done) done(); return; }
        var m = list[i++];
        later(function () {
          var f = m.from || m[0], t = m.to || m[1], p = m.promotion || m[2] || null;
          var v = g.move({ from: f, to: t, promotion: p });
          if (!v) { nxt(); return; }
          A.moveSound(v); board.setLast(f, t); board.animateMove(v, function () {
            board.setCheck(v.check ? g.kingSquare(g.turnColor()) : null); nxt();
          });
        }, 700);
      })();
    }

    function refreshNav() {
      btnNext.disabled = !st.done;
      btnNext.textContent = idx === steps.length - 1 ? "Završi ✔" : "Dalje ▶";
      btnNext.classList.toggle("pulse", st.done);
    }
    function refreshZone() {
      board.unmark("zone");
      if (!step.zone) return;
      UI.attackedSquares(g, step.zone).forEach(function (sq) {
        var p = g.get(sq); if (p && p.color === step.zone) return; board.mark(sq, "zone");
      });
    }
    function counter(extra) {
      var T = step.t, total = 0, now = 0, label = "";
      if (T === "moves") { total = step.need || 3; now = Math.min(st.n, total); label = "Potezi"; }
      else if (T === "stars") { total = (step.stars || []).length; now = total - st.left.length; label = "Zvezdice"; }
      else if (T === "tap") { total = tapTargets().length; now = Object.keys(st.found).length; label = "Pronađeno"; }
      else if (T === "hang") { total = hangTargets().length; now = Object.keys(st.found).length; label = "Pronađeno"; }
      else if (T === "meet") { total = step.need || 6; now = Object.keys(st.seen).length; label = "Upoznao si"; }
      task.innerHTML = '<div class="cnt"><b>' + label + "</b>" + dots(now, total) + "<span>" + now + " / " + total + "</span></div>";
    }
    function dots(n, t) { var s = ""; for (var i = 0; i < t; i++) s += '<i class="' + (i < n ? "on" : "") + '">★</i>'; return '<span class="cs">' + s + "</span>"; }

    function complete(msg) {
      if (st.done) return; st.done = true; A.sfx.ok();
      peko.say(msg || '<span class="ok">' + praise() + "</span>", "happy");
      refreshNav();
      if (step.stars) board.clearStars();
      btnNext.focus && btnNext.focus({ preventScroll: true });
    }
    function wrong(msg) {
      mistakes++; st.wrong++; bad(); A.sfx.no();
      peko.say(msg, "sad");
    }

    /* ——— izvršavanje poteza ——— */
    function exec(f, t, p, cb, keepTurn) {
      var v = g.move({ from: f, to: t, promotion: p });
      if (!v) { board.snap(f); return null; }
      var opp = v.color === "w" ? "b" : "w";
      A.moveSound(v); board.setLast(f, t); board.setCheck(null); busy = true;
      if (!keepTurn) g.setTurn(side);
      board.animateMove(v, function () {
        busy = false;
        if (v.check) board.setCheck(g.kingSquare(opp));
        refreshZone();
        if (cb) cb(v);
      });
      return v;
    }
    // prethodna provera: šta bi se desilo posle poteza (pa se potez poništi)
    function peek(f, t, p) {
      var v = g.move({ from: f, to: t, promotion: p }); if (!v) return null;
      var r = { v: v, mate: g.isCheckmate(), stale: g.isStalemate(), check: g.inCheck(), hang: g.hanging(v.color).length, legal: g.moves().length };
      g.undo(); return r;
    }

    function attempt(f, t, p) {
      var T = step.t || "say";
      var cand = g.moves({ square: f }).filter(function (m) { return m.to === t && (!p || m.promotion === p); })[0];
      if (!cand) { board.snap(f); return; }

      if (T === "moves") {
        exec(f, t, p, function () { st.n++; counter(); if (st.n >= (step.need || 3)) complete(step.ok); else if (st.n === 1 && step.first) peko.say(step.first); });
      } else if (T === "stars") {
        exec(f, t, p, function (v) {
          var k = st.left.indexOf(v.to);
          if (k >= 0) { st.left.splice(k, 1); board.removeStar(v.to); A.sfx.pop(); counter(); }
          if (!st.left.length) complete(step.ok);
          else if (k >= 0) peko.say("Zvezdica! Još " + st.left.length + (st.left.length === 1 ? " do kraja." : " da skupiš."));
        });
      } else if (T === "play") {
        playMove(f, t, p);
      } else if (T === "mate") {
        var r = peek(f, t, p);
        if (r.mate) { exec(f, t, p, function () { complete(step.ok || '<span class="ok">ŠAH-MAT!</span> Kralj nema kuda. Pobedio si!'); }, true); }
        else {
          board.snap(f);
          wrong(r.stale ? "To je <b>PAT</b> – kralj nije u šahu, ali nema nijedan potez. Partija bi bila nerešena! Probaj drugi potez." :
            r.check ? "To je šah, ali kralj ima kuda da pobegne. Traži potez posle koga kralj nema izlaz." :
            "Ovo nije ni šah. Traži potez kojim napadaš kralja tako da on nema izlaz.");
          if (st.wrong >= 2) board.flash(f, "hint", 1200);
        }
      } else if (T === "escape") {
        var cls = cand.piece === "k" && !cand.captured ? "king" : (cand.captured ? "capture" : "block");
        if (step.must && cls !== step.must) {
          board.snap(f); wrong(step.no || "To je dobar potez, ali ovde probaj drugi način: " + ({ king: "pomeri kralja.", block: "stavi figuru između.", capture: "pojedi napadača." }[step.must]));
          return;
        }
        exec(f, t, p, function () { complete(step.ok || { king: "Kralj je pobegao sa napadnutog polja!", block: "Blokirao si napad – figura je stala između!", capture: "Pojeo si napadača!" }[cls]); }, true);
      } else if (T === "fix") {
        var q = peek(f, t, p);
        if (q.hang > 0) { board.snap(f); wrong(step.no || "Ta figura je i dalje u opasnosti! Pogledaj crvenu zonu – ko napada koga?"); }
        else exec(f, t, p, function () { complete(step.ok); });
      } else { exec(f, t, p); }
    }

    /* korak po korak, uz odgovore protivnika */
    function stageList() { return step.stages || [{ want: step.want, ok: step.ok, reply: step.reply, no: step.no }]; }
    function wants(s, f, t, p) {
      return (s.want || []).some(function (w) { return w === f + t || (p && w === f + t + p); });
    }
    function playMove(f, t, p) {
      var list = stageList(), s = list[st.stage];
      if (!wants(s, f, t, p)) {
        board.snap(f); wrong(s.no || step.no || "Ne baš. Probaj da uradiš ono što Peško traži.");
        if (st.wrong >= 2) { var w = s.want[0]; board.arrow(w.slice(0, 2), w.slice(2, 4), "ar"); }
        return;
      }
      board.clearArrows();
      var reply = s.reply, okMsg = typeof s.ok === "function" ? s.ok(f, t, p) : s.ok;
      exec(f, t, p, function () {
        function next() {
          st.stage++;
          if (st.stage >= list.length) { complete((okMsg ? okMsg + " " : "") + (step.done || "")); }
          else { peko.say((okMsg ? okMsg + "<p>" : "<p>") + fmt(list[st.stage].say) + "</p>"); }
        }
        if (reply) {
          busy = true;
          later(function () {
            var rf = reply.slice(0, 2), rt = reply.slice(2, 4), v = g.move({ from: rf, to: rt, promotion: reply.slice(4, 5) || null });
            if (v) { A.moveSound(v); board.setLast(rf, rt); board.animateMove(v, function () { busy = false; if (v.check) board.setCheck(g.kingSquare("w")); next(); }); }
            else { busy = false; next(); }
          }, 600);
        } else next();
      }, !!reply);
      if (!reply) { /* turn već vraćen u exec */ }
    }

    /* ——— dodiri na tablu (pitanja, traženje polja…) ——— */
    function tapTargets() {
      if (step.squares) return step.squares;
      return g.moves({ square: step.from }).map(function (m) { return m.to; });
    }
    function hangTargets() { return g.hanging(side).filter(function (h) { return h.gain > 0; }).map(function (h) { return h.square; }); }

    function nextFind(first) {
      var f = step.finds[st.fi];
      if (!f) { complete(step.ok); return; }
      task.innerHTML = '<div class="cnt"><b>Pitanje</b>' + dots(st.fi, step.finds.length) + "<span>" + (st.fi + 1) + " / " + step.finds.length + "</span></div>";
      peko.say((first && step.say ? step.say + "<p>" : "<p>") + f.q + "</p>");
      if (f.coords !== undefined) board.setCoords(f.coords);
      st.wrongRun = 0;
    }

    function onTap(sq) {
      var T = step.t || "say";
      if (mode !== "tap" || busy) return false;
      if (T === "finds") {
        var f = step.finds[st.fi]; if (!f) return true;
        var ok = [].concat(f.sq).indexOf(sq) >= 0;
        if (ok) {
          good(); A.sfx.pop(); board.unmark("good"); board.mark(sq, "good"); st.fi++;
          later(function () { board.unmark("good"); }, 700);
          if (st.fi >= step.finds.length) { complete(step.ok); task.innerHTML = '<div class="cnt"><b>Pitanja</b>' + dots(st.fi, step.finds.length) + "<span>" + st.fi + " / " + step.finds.length + "</span></div>"; }
          else { task.innerHTML = ""; peko.say('<span class="ok">' + praise() + "</span><p>" + step.finds[st.fi].q + "</p>"); nextFindTask(); }
        } else {
          st.wrongRun++; mistakes++; bad(); A.sfx.no(); board.flash(sq, "bad", 600); board.mark(sq, "bad"); later(function () { board.unmark("bad"); }, 600);
          var pq = g.get(sq);
          peko.say(f.no ? f.no(sq, pq) : (pq ? "Tu stoji " + PIECES.NAMES[pq.type].toLowerCase() + ". Pokušaj opet!" : "To je polje <b>" + sq + "</b>. Pokušaj opet!"), "sad");
          if (st.wrongRun >= 2) { board.flash([].concat(f.sq)[0], "hint", 1400); if (!board.coords) board.setCoords(true); }
        }
        return true;
      }
      if (T === "tap") {
        var tg = tapTargets();
        if (st.found[sq]) return true;
        if (tg.indexOf(sq) >= 0) {
          st.found[sq] = 1; board.mark(sq, "good"); A.sfx.pop(); good(); counter();
          if (Object.keys(st.found).length >= tg.length) complete(step.ok);
        } else {
          mistakes++; bad(); A.sfx.no(); board.mark(sq, "bad"); later(function () { board.unmark("bad"); }, 600);
          var pp = g.get(sq);
          peko.say(step.no ? step.no(sq, pp) : "Na polje <b>" + sq + "</b> ta figura ne može da ide. Pokušaj opet!", "sad");
        }
        return true;
      }
      if (T === "hang") {
        var hs = hangTargets(), p2 = g.get(sq);
        if (!p2 || p2.color !== side) { peko.say("Dodirni neku od svojih (belih) figura.", "sad"); return true; }
        if (st.found[sq]) return true;
        if (hs.indexOf(sq) >= 0) { st.found[sq] = 1; board.mark(sq, "bad"); A.sfx.pop(); good(); counter(); if (Object.keys(st.found).length >= hs.length) complete(step.ok); }
        else {
          mistakes++; bad(); A.sfx.no(); board.wobble(sq);
          var atk = g.attackers(sq, side === "w" ? "b" : "w").length;
          peko.say(atk ? "Ovu figuru neko napada, ali je <b>zaštićena</b>: ako je pojede, biće pojeden. To nije besplatan plen. Traži drugu!" : "Ovu figuru niko ne napada. Traži onu koju neko može da pojede!", "sad");
        }
        return true;
      }
      if (T === "meet") {
        var q = g.get(sq); if (!q) return true;
        A.sfx.tap(); board.unmark("sel"); board.mark(sq, "sel"); board.wobble(sq);
        st.seen[q.type] = 1; counter();
        peko.say(OPIS_FIGURA[q.type] + (Object.keys(st.seen).length >= (step.need || 6) ? "" : "<p>Dodirni sledeću figuru!</p>"));
        if (Object.keys(st.seen).length >= (step.need || 6)) complete('<span class="ok">Upoznao si svih šest vrsta figura!</span> Sada znaš ko je ko.');
        return true;
      }
      return false;
    }
    function nextFindTask() { var f = step.finds[st.fi]; if (f && f.coords !== undefined) board.setCoords(f.coords); st.wrongRun = 0; task.innerHTML = '<div class="cnt"><b>Pitanje</b>' + dots(st.fi, step.finds.length) + "<span>" + (st.fi + 1) + " / " + step.finds.length + "</span></div>"; }

    /* ——— pitanja sa ponuđenim odgovorima ——— */
    function renderChoose() {
      var h = '<div class="qt">' + step.q + '</div><div class="opts">';
      step.opts.forEach(function (o, i) {
        var t = typeof o === "string" ? { t: o } : o;
        h += '<button class="opt" data-i="' + i + '">' + (t.p ? PIECES.icon(t.p, t.c || "w", true) : "") + "<span>" + t.t + "</span></button>";
      });
      task.innerHTML = h + "</div>";
      A.$$(".opt", task).forEach(function (b) {
        b.onclick = function () {
          if (st.done) return;
          var i = +b.getAttribute("data-i");
          if (i === step.ans) {
            A.$$(".opt", task).forEach(function (x) { x.disabled = true; }); b.classList.add("ok"); good();
            complete('<span class="ok">' + praise() + "</span> " + (step.why || ""));
          } else {
            b.classList.add("no"); b.disabled = true; wrong((step.wrong && step.wrong[i]) || "Ne baš. Probaj još jednom!");
          }
        };
      });
    }

    /* ——— dugmad ——— */
    btnNext.onclick = function () { A.sfx.tap(); if (idx < steps.length - 1) enter(idx + 1); else finish(); };
    btnReset.onclick = function () { A.sfx.tap(); enter(idx); };
    btnHint.onclick = function () {
      A.sfx.tap(); st.hints++;
      var T = step.t || "say";
      if (T === "stars" && st.left.length) { board.flash(st.left[0], "hint", 1600); peko.say(step.hint || "Zvezdica čeka na polju <b>" + st.left[0] + "</b>. Kako da stigneš do nje?"); }
      else if (T === "finds") { var f = step.finds[st.fi]; if (f) { board.flash([].concat(f.sq)[0], "hint", 1800); peko.say("Pogledaj polje koje treperi."); } }
      else if (T === "tap") { var rest = tapTargets().filter(function (s) { return !st.found[s]; }); if (rest.length) board.flash(rest[0], "hint", 1600); peko.say(step.hint || "Jedno od polja treperi. Probaj da ga dodirneš."); }
      else if (T === "play") { var s = stageList()[st.stage], w = s && s.want[0]; if (w) { board.arrow(w.slice(0, 2), w.slice(2, 4), "ar"); board.flash(w.slice(0, 2), "hint", 1600); } if (s && s.hint) peko.say(s.hint); }
      else if (T === "mate") { var mm = g.mateIn1Moves()[0]; if (mm) { board.arrow(mm.from, mm.to, "ar"); board.flash(mm.from, "hint", 1600); } peko.say(step.hint || "Strelica pokazuje potez. Zašto je to mat? Kralj nema kuda!"); }
      else if (T === "choose") {
        var wrongs = A.$$(".opt:not(:disabled)", task).filter(function (b) { return +b.getAttribute("data-i") !== step.ans; });
        if (wrongs.length > 1) { wrongs[0].disabled = true; wrongs[0].classList.add("no"); }
        peko.say(step.hint || "Izbacio sam jedan netačan odgovor. Probaj sada!");
      }
      else peko.say(step.hint || "Pročitaj još jednom šta Peško kaže. Možeš i da dodirneš zvučnik da ti pročita naglas.");
    };

    /* ——— kraj lekcije ——— */
    function finish() {
      clearTimers(); mode = "none";
      var first = !isDone(L.id), rating = mistakes <= 1 ? 3 : (mistakes <= 4 ? 2 : 1), prev = A.S.lessons[L.id];
      A.S.lessons[L.id] = { done: true, r: Math.max(rating, prev && prev.r || 0) };
      var xp = first ? (L.xp || 30) + (mistakes === 0 ? 10 : 0) : 0;
      A.save();
      if (xp) A.addXP(xp);
      A.award("prva"); if (L.znacka) A.award(L.znacka);
      A.checkBadges(); A.confetti(90); A.sfx.win();
      var nxt = HOME.nextLesson();
      var h = '<div class="lend"><div class="lend-fig">' + PIECES.icon(L.ikona || "p", "w", true) + '</div><h2>Lekcija završena!</h2><p class="lead">' + esc(L.naslov) + "</p>" +
        '<div class="lend-st">' + "★★★".slice(0, rating) + "<s>" + "★★★".slice(rating) + "</s></div>" +
        (xp ? '<p class="lend-xp">+' + xp + " poena" + (mistakes === 0 ? " (bez greške!)" : "") + "</p>" : '<p class="lend-xp muted">Ovu lekciju si već ranije završio.</p>') +
        (L.nauci ? '<div class="card lend-l"><b>Šta si naučio:</b><ul>' + L.nauci.map(function (x) { return "<li>" + x + "</li>"; }).join("") + "</ul></div>" : "") +
        '<div class="row c">' + (nxt && nxt.id !== L.id ? '<a class="btn big go" href="#/skola/' + nxt.id + '">Sledeća lekcija ▶</a>' : '<a class="btn big go" href="#/igra">Idemo da igramo! ▶</a>') +
        '<a class="btn ghost" href="#/skola">Sve lekcije</a><a class="btn ghost" href="#/skola/' + L.id + '" id="again">Ponovi</a></div></div>';
      root.innerHTML = h;
      $("#again", root).onclick = function (e) { e.preventDefault(); window.dispatchEvent(new Event("hashchange")); };
    }

    function cleanup() { alive = false; clearTimers(); board.destroy(); A.stopSpeak(); }
    window.__lsn = { get: function () { return { L: L, idx: idx, step: step, st: st, g: g, board: board, mode: mode, busy: busy, mistakes: mistakes }; }, next: function () { btnNext.click(); } };
    enter(0);
    return cleanup;
  }
})();
