/* ŠAH ŠKOLA – lekcije. Svaka lekcija je niz koraka koje vodi Peško (vidi skola.js za tipove koraka). */
(function () {
  "use strict";
  function sqs(f) { var o = [], a, r; for (a = 0; a < 8; a++) for (r = 0; r < 8; r++) if (f(a, r)) o.push("abcdefgh"[a] + (r + 1)); return o; }
  var DARK = sqs(function (a, r) { return (a + r) % 2 === 0; });
  var EMPTY = "8/8/8/8/8/8/8/8 w - - 0 1";
  var START = "rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1";
  var RED = "ar red";

  window.LEKCIJE = [

    /* ═════════ POČETAK ═════════ */
    {
      id: "tabla", naslov: "Šahovska tabla", opis: "Polja, redovi, kolone i imena polja.", grupa: "Početak", ikona: "p", xp: 30, znacka: "tabla",
      nauci: ["Tabla ima 64 polja – svetla i tamna.", "Kolone su slova od a do h, a redovi brojevi od 1 do 8.", "Svako polje ima ime, na primer <b>e4</b>.", "Svetlo polje je uvek dole desno."],
      koraci: [
        { fen: EMPTY, coords: true, say: "Zdravo! Ja sam <em>Peško</em>, mali pešak. Biću tvoj vodič kroz šah. Ovo je <em>šahovska tabla</em>. Ima 64 polja – svetla i tamna, jedno pored drugog." },
        { say: "Polja su poređana u <em>kolone</em>. Ovo je jedna kolona – ide odozdo naviše. Kolone imaju <em>slova</em>: a, b, c, d, e, f, g, h.", marks: { blue: ["e1", "e2", "e3", "e4", "e5", "e6", "e7", "e8"] } },
        { say: "A ovo je jedan <em>red</em> – ide s leva na desno. Redovi imaju <em>brojeve</em> od 1 do 8.", marks: { blue: ["a4", "b4", "c4", "d4", "e4", "f4", "g4", "h4"] } },
        { say: "Ime polja čine <em>slovo kolone</em> i <em>broj reda</em>. Polje gde se ukrštaju ova kolona i ovaj red zove se <em>e4</em>.", marks: { blue: ["e1", "e2", "e3", "e5", "e6", "e7", "e8", "a4", "b4", "c4", "d4", "f4", "g4", "h4"], hint: ["e4"] } },
        {
          t: "finds", say: "Hajde da vežbamo! Pronađi polja koja ti kažem.",
          finds: [{ q: "Dodirni polje <em>a1</em>.", sq: "a1" }, { q: "Dodirni polje <em>h1</em>.", sq: "h1" }, { q: "Dodirni polje <em>e4</em>.", sq: "e4" }, { q: "Dodirni polje <em>d5</em>.", sq: "d5" }, { q: "Dodirni polje <em>g7</em>.", sq: "g7" }],
          ok: "Svih pet pronađeno! Bravo, već znaš da čitaš tablu."
        },
        { say: "Zapamti pravilo: tabla se uvek postavlja tako da je <em>svetlo polje dole desno</em>.", marks: { hint: ["h1"] } },
        {
          t: "finds", say: "Sada malo teže – bez slova i brojeva! Ako zapneš, pomoćiću ti.", coords: false,
          finds: [{ q: "Dodirni polje <em>f3</em>.", sq: "f3", coords: false }, { q: "Dodirni polje <em>b7</em>.", sq: "b7", coords: false }, { q: "Dodirni polje <em>c2</em>.", sq: "c2", coords: false }],
          ok: "Odlično! Ti si pravi istraživač table."
        },
        { t: "choose", say: "Još jedno pitanje.", q: "Koliko polja ima šahovska tabla?", opts: ["32", "64", "100"], ans: 1, why: "8 kolona puta 8 redova je 64 polja – polovina svetlih, polovina tamnih." }
      ]
    },

    {
      id: "figure", naslov: "Figure i početni raspored", opis: "Upoznaj svih šest vrsta figura.", grupa: "Početak", ikona: "k", xp: 30,
      nauci: ["Svaki igrač ima 16 figura: 8 pešaka i 8 većih figura.", "Figure su: kralj, dama, top, lovac, skakač i pešak.", "Beli igra prvi.", "Dama voli svoju boju."],
      koraci: [
        { fen: START, say: "Ovo je početni raspored. Svaki igrač ima <em>16 figura</em>: 8 pešaka i 8 većih figura. Beli su dole, a crni gore. <em>Beli uvek igra prvi.</em>" },
        { t: "meet", need: 6, say: "Upoznaj figure! Dodirni po jednu iz svake vrste i čućeš ko je ko. Treba da upoznaš svih šest." },
        {
          t: "finds", say: "Hajde da proverimo šta si zapamtio.",
          finds: [
            { q: "Dodirni <em>belu damu</em>.", sq: "d1" }, { q: "Dodirni <em>crnog kralja</em>.", sq: "e8" },
            { q: "Dodirni jednog <em>belog skakača</em>.", sq: ["b1", "g1"] }, { q: "Dodirni jednog <em>crnog lovca</em>.", sq: ["c8", "f8"] },
            { q: "Dodirni jednog <em>belog topa</em>.", sq: ["a1", "h1"] }, { q: "Dodirni jednog <em>crnog pešaka</em>.", sq: ["a7", "b7", "c7", "d7", "e7", "f7", "g7", "h7"] }
          ],
          ok: "Sve si pogodio! Poznaješ svih šest figura."
        },
        { say: "Zapamti: <em>dama voli svoju boju</em>. Bela dama stoji na svetlom polju, a crna na tamnom. Kralj stoji pored nje.", marks: { hint: ["d1", "d8"] } },
        { t: "choose", say: "Još jedno pitanje za kraj.", q: "Koliko pešaka ima svaki igrač na početku?", opts: ["6", "8", "16"], ans: 1, why: "Osam pešaka – po jedan ispred svake figure." }
      ]
    },

    /* ═════════ KAKO SE KREĆU FIGURE ═════════ */
    {
      id: "top", naslov: "Top", opis: "Ide pravo – napred, nazad i u stranu.", grupa: "Kako se kreću figure", ikona: "r", xp: 35, znacka: "top",
      nauci: ["Top ide <b>pravo</b>: napred, nazad, levo i desno.", "Može da pređe koliko god polja hoće.", "Jede tako što stane na polje protivničke figure.", "Ne može da preskače figure."],
      koraci: [
        { fen: "8/8/8/8/3R4/8/8/8 w - - 0 1", say: "Ovo je <em>Top</em>. Izgleda kao kula na dvorcu. Top ide <em>pravo</em>: napred, nazad, levo i desno – koliko god polja hoće.", arrows: [["d4", "d8", "ar"], ["d4", "d1", "ar"], ["d4", "a4", "ar"], ["d4", "h4", "ar"]] },
        { t: "moves", need: 3, say: "Probaj! Dodirni topa i pomeri ga na neko polje sa tačkicom. Možeš i da ga prevučeš prstom.", first: "Vidiš? Top ide pravo, bez obzira koliko je daleko.", ok: "Odlično! Top je brz i jak." },
        { t: "stars", fen: "8/8/8/8/8/8/8/R7 w - - 0 1", stars: ["h1", "h8", "a8"], say: "Skupi sve tri zvezdice! Top treba da stane na svaku.", hint: "Top ide pravo. Prvo idi desno do polja h1.", ok: "Tri zvezdice u samo tri poteza!" },
        { t: "stars", fen: "8/3p2p1/8/8/3R4/8/8/8 w - - 0 1", stars: ["d7", "g7"], say: "Top <em>jede</em> tako što stane na polje protivničke figure. Pojedi oba crna pešaka!", hint: "Top ide pravo naviše do d7. Posle toga ide desno do g7.", ok: "Mljac! Oba pešaka su pojedena." },
        { t: "stars", fen: "8/8/8/8/8/P7/8/R7 w - - 0 1", only: "r", stars: ["a7"], say: "Top ne može da preskače figure – ni svoje. Njegov pešak mu je na putu. Stigni do zvezdice na a7 zaobilaznim putem!", hint: "Prvo pređi u b kolonu (b1), pa idi naviše do b7, pa ulevo do a7.", ok: "Zaobišao si prepreku! Tako se to radi." },
        { t: "choose", say: "Još jedno pitanje.", q: "Kako ide top?", opts: ["Pravo – napred, nazad, levo i desno", "Koso", "U obliku slova L"], ans: 0, why: "Top ide samo pravo." }
      ]
    },

    {
      id: "lovac", naslov: "Lovac", opis: "Ide koso i ostaje na svojoj boji.", grupa: "Kako se kreću figure", ikona: "b", xp: 35,
      nauci: ["Lovac ide <b>koso</b> (po dijagonali).", "Uvek ostaje na polju iste boje.", "Svaki igrač ima jednog lovca za svetla i jednog za tamna polja."],
      koraci: [
        { fen: "8/8/8/8/3B4/8/8/8 w - - 0 1", say: "Ovo je <em>Lovac</em>. On ide <em>koso</em>, po dijagonali, koliko god polja hoće.", arrows: [["d4", "a7", "ar"], ["d4", "h8", "ar"], ["d4", "a1", "ar"], ["d4", "g1", "ar"]] },
        { t: "moves", need: 3, say: "Probaj da ga pomeriš. Samo koso!", first: "Lovac se kreće samo po dijagonalama.", ok: "Super! Lovac je pravi lovac na dijagonale." },
        { say: "Lovac uvek ostaje na polju <em>iste boje</em> – ceo život! Ovaj lovac je na tamnom polju, pa će hodati samo po <em>plavo označenim</em> tamnim poljima.", marks: { blue: DARK } },
        { t: "choose", fen: "8/8/8/8/2B5/8/8/8 w - - 0 1", say: "Ovaj lovac stoji na svetlom polju.", q: "Na kojim poljima lovac može da bude posle 10 poteza?", opts: ["Samo na svetlim poljima", "Na bilo kom polju", "Samo na tamnim poljima"], ans: 0, why: "Lovac nikad ne menja boju polja. Zato svaki igrač ima dva lovca – jednog za svetla, jednog za tamna polja." },
        { t: "stars", fen: "8/8/8/8/8/8/8/2B5 w - - 0 1", stars: ["h6", "f8", "a3"], say: "Skupi tri zvezdice! Lovac ide samo koso, ali može da se okrene i u drugu stranu.", hint: "Prvo idi od c1 do h6, pa nazad koso do f8, pa do a3.", ok: "Tri poteza i sve zvezdice! Bravo." },
        { t: "stars", fen: "8/8/1p6/8/3B4/8/5p2/8 w - - 0 1", stars: ["b6", "f2"], say: "Lovac jede tako što stane na polje figure. Pojedi oba crna pešaka!", hint: "Prvo pojedi pešaka na b6, pa se vrati koso preko d4 do f2.", ok: "Mljac, mljac! Oba su pojedena." },
        { t: "choose", say: "Pitanje za kraj.", q: "Lovac je na svetlom polju. Može li da pojede figuru koja stoji na tamnom polju?", opts: ["Ne, nikad", "Da, ako je blizu", "Da, ako je dama"], ans: 0, why: "Tačno! Lovac nikad ne dolazi na polje druge boje. Zato je važno imati oba lovca." }
      ]
    },

    {
      id: "dama", naslov: "Dama", opis: "Najjača figura: top i lovac zajedno.", grupa: "Kako se kreću figure", ikona: "q", xp: 35,
      nauci: ["Dama ide kao <b>top i lovac zajedno</b>: pravo i koso.", "Najjača je figura (vredi 9 poena).", "Ne izlaži je bez potrebe."],
      koraci: [
        { fen: "8/8/8/8/3Q4/8/8/8 w - - 0 1", say: "Ovo je <em>Dama</em> – najjača figura! Ona ide kao <em>top i lovac zajedno</em>: pravo i koso, koliko god polja hoće.", arrows: [["d4", "d8", "ar"], ["d4", "d1", "ar"], ["d4", "a4", "ar"], ["d4", "h4", "ar"], ["d4", "a7", "ar"], ["d4", "h8", "ar"], ["d4", "a1", "ar"], ["d4", "g1", "ar"]] },
        { t: "moves", need: 4, say: "Probaj nekoliko poteza. Vidi koliko polja dama kontroliše!", first: "Dama ima najviše tačkica – zato je tako jaka.", ok: "Sjajno! Dama može skoro svuda." },
        { t: "stars", fen: "8/8/8/8/8/8/8/Q7 w - - 0 1", stars: ["h8", "h1", "a8"], say: "Skupi tri zvezdice! Koristi i koso i pravo kretanje.", hint: "Prvo koso od a1 do h8. Posle toga pravo naniže do h1, pa koso do a8.", ok: "Tri poteza! Dama je prava šampionka." },
        { t: "stars", fen: "8/p2p2p1/8/8/3Q2p1/8/8/8 w - - 0 1", stars: ["a7", "d7", "g7", "g4"], say: "Dama jede sve što stigne! Pojedi sva četiri crna pešaka.", hint: "Počni koso od d4 do a7. Posle idi pravo udesno: d7, pa g7, pa naniže do g4.", ok: "Četiri pešaka u četiri poteza! Dama je stvarno moćna." },
        { say: "Ali pazi! Dama je <em>veoma vredna</em> – vredi 9 poena. Ne izvodi je rano u partiju i ne ostavljaj je tamo gde je neko može pojesti. Zato je čuvaj!" },
        { t: "choose", say: "Pitanje za kraj.", q: "Kako ide dama?", opts: ["Kao top i lovac zajedno", "U obliku slova L", "Samo jedno polje"], ans: 0, why: "Dama ima sve snage topa i lovca – zato je najjača." }
      ]
    },

    {
      id: "skakac", naslov: "Skakač", opis: "Skače u obliku slova L i preskače figure.", grupa: "Kako se kreću figure", ikona: "n", xp: 40, znacka: "skakac",
      nauci: ["Skakač skače u obliku slova <b>L</b>: dva polja pravo i jedno u stranu.", "Jedini <b>preskače</b> druge figure.", "Uvek menja boju polja na kojem stoji."],
      koraci: [
        { fen: "8/8/8/8/3N4/8/8/8 w - - 0 1", say: "Ovo je <em>Skakač</em> – konjić. On <em>skače</em> u obliku slova <em>L</em>: dva polja pravo, pa jedno u stranu.", arrows: [["d4", "e6", "ar"], ["d4", "f5", "ar"]] },
        { t: "tap", from: "d4", say: "Dodirni <em>sva polja</em> na koja skakač može da skoči. Pomaže ako zamisliš slovo L!", ok: "Pronašao si svih osam polja!", hint: "Dva polja pravo (gore, dole, levo, desno) pa jedno u stranu.", no: function (sq) { return "Skakač ne može na <b>" + sq + "</b>. Zamisli slovo L: dva polja pravo, jedno u stranu." } },
        { t: "moves", need: 3, say: "Sada ga pomeri! Skoči nekoliko puta.", first: "Lepo skače! Samo na poljima gde se završava slovo L.", ok: "Skakač je pravi akrobata!" },
        { t: "stars", fen: START, only: "n", stars: ["c3", "f3"], say: "Skakač je jedina figura koja <em>preskače</em> druge figure! Izvuci oba skakača iz zatvorenog reda – ne treba da pomeraš pešake.", hint: "Dodirni skakača na b1 i skoči preko pešaka na c3. Onda drugim skakačem (g1) na f3.", ok: "Preskočili su sve! Tako skakač izlazi u igru." },
        { t: "stars", fen: "8/8/8/8/8/8/8/6N1 w - - 0 1", stars: ["f3", "e5", "d7"], say: "Skupi tri zvezdice! Skakač mora da skoči tačno na svaku.", hint: "Prvo idi na f3. Odatle skoči na e5, pa na d7.", ok: "Tri skoka – tri zvezdice!" },
        { t: "stars", fen: "8/8/4p3/6p1/3N4/5p2/8/8 w - - 0 1", stars: ["e6", "g5", "f3"], say: "Skakač jede tako što skoči na polje figure. Pojedi sva tri crna pešaka!", hint: "Skoči na e6, pa na g5, pa na f3.", ok: "Sva tri pešaka su pojedena!" },
        { t: "choose", say: "Pitanje za kraj.", q: "Koja figura može da preskoči druge figure?", opts: [{ t: "Skakač", p: "n" }, { t: "Top", p: "r" }, { t: "Lovac", p: "b" }], ans: 0, why: "Skakač je jedini koji skače preko drugih figura." }
      ]
    },

    {
      id: "kralj", naslov: "Kralj", opis: "Jedan korak, ali nikad u opasnost.", grupa: "Kako se kreću figure", ikona: "k", xp: 35,
      nauci: ["Kralj ide <b>jedno polje</b> u svim pravcima.", "Ne sme da stane na polje koje protivnik napada.", "Dva kralja ne smeju da stoje jedan pored drugog.", "Kralj može da pojede nezaštićenog napadača."],
      koraci: [
        { fen: "8/8/8/8/4K3/8/8/8 w - - 0 1", say: "Ovo je <em>Kralj</em> – najvažnija figura! Ako ga izgubiš, gubiš partiju. Kralj ide samo <em>jedno polje</em>, ali u svim pravcima." },
        { t: "tap", from: "e4", say: "Dodirni sva polja na koja kralj može da ide.", ok: "Tačno, osam polja oko kralja!", no: function (sq) { return "Kralj ne može na <b>" + sq + "</b>. On ide samo jedno polje." } },
        { t: "moves", need: 3, zone: "b", fen: "8/8/8/r7/4K3/8/8/8 w - - 0 1", say: "Na ovoj tabli ima crni top. <em>Crvena polja</em> su ona koja top napada. Probaj da kralja odvedeš na crveno polje!", first: "Vidiš? Kralj ne može na crveno – to polje je pod napadom!", ok: "Kralj nikad ne sme da stane na polje koje napada protivnik." },
        { t: "stars", fen: "8/8/8/r7/4K3/8/8/8 w - - 0 1", zone: "b", stars: ["d3", "b4"], say: "Skupi zvezdice, ali drži se dalje od crvenog!", hint: "Prvo siđi na d3. Posle idi levo po redu 4: d4, c4, b4.", ok: "Zaobišao si opasnost. Bravo!" },
        { t: "moves", need: 2, zone: "b", fen: "8/8/8/8/8/3k4/8/4K3 w - - 0 1", say: "I dva kralja <em>ne smeju da stoje jedan pored drugog</em>. Crveno su polja koja crni kralj čuva. Pokušaj da pomeriš belog kralja!", first: "Kralj ne može blizu drugog kralja.", ok: "Kraljevi se drže na odstojanju." },
        { t: "stars", fen: "8/8/8/4r3/4K3/8/8/8 w - - 0 1", stars: ["e5"], marks: { chk: ["e4"] }, say: "Ovaj crni top napada tvog kralja – to je šah! Ali top nije zaštićen. Kralj može da ga <em>pojede</em>!", hint: "Kralj ide jedno polje – gore, na polje e5.", ok: "Kralj je pojeo napadača. Nije bio zaštićen!" },
        { t: "choose", say: "Pitanje za kraj.", q: "Koliko polja kralj sme da pređe u jednom potezu?", opts: ["Jedno", "Dva", "Koliko hoće"], ans: 0, why: "Kralj je spor, ali zato ga čuvamo!" }
      ]
    },

    {
      id: "pesak", naslov: "Pešak", opis: "Ide napred, a jede koso.", grupa: "Kako se kreću figure", ikona: "p", xp: 40, znacka: "pesak",
      nauci: ["Pešak ide <b>napred</b>, jedno polje.", "Iz početnog položaja sme i dva polja.", "Jede <b>koso</b>, jedno polje napred levo ili desno.", "Ako mu je neko ispred, pešak je blokiran."],
      koraci: [
        { fen: "8/8/8/8/8/8/4P3/8 w - - 0 1", say: "Ovo je <em>Pešak</em>. On je najmanja figura, ali ih ima najviše. Pešak ide samo <em>napred</em>. Iz početnog polja sme <em>jedno ili dva polja</em>.", marks: { blue: ["e3", "e4"] } },
        { t: "stars", fen: "8/8/8/8/8/8/4P3/8 w - - 0 1", stars: ["e4", "e5", "e6"], say: "Odvedi pešaka do zvezdica! Posle prvog poteza pešak ide samo jedno polje.", hint: "Prvi potez može da bude dva polja (e4). Posle toga polako: e5, pa e6.", ok: "Pešak ide polako, ali sigurno." },
        { t: "stars", fen: "8/8/2p5/3p4/4P3/8/8/8 w - - 0 1", stars: ["d5", "c6"], say: "Pešak ide pravo, ali <em>jede koso</em> – jedno polje napred levo ili desno. Pojedi dva crna pešaka!", hint: "Pešak sa e4 jede koso na d5. Zatim jede opet koso na c6.", ok: "Pešak je pojeo dva pešaka – koso!" },
        { t: "stars", fen: "8/8/8/3p4/3PP3/8/8/8 w - - 0 1", stars: ["d5"], say: "Pešak ne može da pojede figuru koja mu je <em>pravo ispred</em> – tada je <em>blokiran</em>. Pokušaj da pomeriš pešaka sa d4, pa onda sa e4!", hint: "Pešak d4 je blokiran. Pešak e4 jede koso na d5.", ok: "Pešak na e4 je pojeo koso!" },
        { t: "choose", say: "Dva pitanja za kraj.", q: "Kako pešak jede?", opts: ["Koso, jedno polje napred", "Pravo napred", "Levo i desno"], ans: 0, why: "Pešak ide pravo, a jede koso. To je jedina figura kojoj se kretanje razlikuje od jedenja." },
        { t: "choose", q: "Pešak je na početnom polju. Koliko polja sme da pređe u prvom potezu?", opts: ["Jedno ili dva", "Samo jedno", "Tri"], ans: 0, why: "Prvi potez može biti jedan ili dva polja. Posle toga samo jedno." }
      ]
    },

    /* ═════════ PRAVILA IGRE ═════════ */
    {
      id: "vrednost", naslov: "Hvatanje i vrednost figura", opis: "Koliko koja figura vredi i šta se isplati pojesti.", grupa: "Pravila igre", ikona: "q", xp: 35,
      nauci: ["Pešak 1, skakač 3, lovac 3, top 5, dama 9.", "Kralj nema cenu – on je neprocenjiv.", "Pojedi vrednije, a ne gubi vrednije.", "Pazi na zaštićene figure."],
      koraci: [
        { fen: START, say: "Svaka figura vredi određen broj <em>poena</em>. Tako lako vidimo da li je zamena dobra. Evo koliko vrede:<p>{{vals}}</p><p>Kralj nema cenu – on je neprocenjiv!</p>" },
        { t: "choose", say: "Hajde da probamo.", q: "Šta vredi više?", opts: [{ t: "Skakač (3 poena)", p: "n" }, { t: "Pešak (1 poen)", p: "p" }], ans: 0, why: "Skakač vredi tri pešaka." },
        { t: "choose", q: "Šta vredi više?", opts: [{ t: "Dama (9 poena)", p: "q" }, { t: "Top (5 poena)", p: "r" }, { t: "Lovac (3 poena)", p: "b" }], ans: 0, why: "Dama je najvrednija figura koja se može izgubiti." },
        {
          t: "play", fen: "8/3p4/1n6/8/3Q2r1/8/8/4K3 w - - 0 1", say: "Tvoja dama može da pojede tri crne figure, a nijedna nije zaštićena. Pojedi <em>onu koja najviše vredi</em>!",
          want: ["d4g4"], hint: "Pešak vredi 1, skakač 3, a top 5. Koji je najvredniji?",
          no: "Ta figura je dobar plen, ali ima i vrednija! Pogledaj poene: pešak 1, skakač 3, top 5.", ok: "Top vredi 5 poena – to je najbolji plen!"
        },
        { t: "choose", fen: "8/8/2p5/3p4/8/8/8/3R4 w - - 0 1", arrows: [["c6", "d5", RED]], say: "Pazi na <em>zaštićene</em> figure. Crveni pešak na c6 <em>čuva</em> pešaka na d5.", q: "Da li se isplati da topom (5) pojedeš zaštićenog pešaka (1)?", opts: ["Da, pojeo sam pešaka", "Ne – pešak sa c6 će pojesti mog topa"], ans: 1, why: "Top bi dobio 1 poen, a izgubio 5. To je loša zamena. Pre jedenja uvek pogledaj ko čuva figuru!" }
      ]
    },

    {
      id: "sah", naslov: "Šah – kralj je napadnut", opis: "Tri načina da spasiš kralja.", grupa: "Pravila igre", ikona: "k", xp: 40,
      nauci: ["<b>Šah</b> je kad je kralj napadnut.", "Kralj mora odmah da se spase.", "Tri načina: pomeri kralja, blokiraj napad ili pojedi napadača.", "Ne smeš da ostaviš kralja u šahu."],
      koraci: [
        { fen: "4r3/8/8/8/8/8/8/4K3 w - - 0 1", face: true, marks: { chk: ["e1"] }, arrows: [["e8", "e1", RED]], say: "Kad se kralj napadne, to se zove <em>ŠAH</em>! Crni top napada belog kralja. Crveno polje pokazuje da je kralj u opasnosti." },
        { say: "Kralj <em>mora odmah da se spase</em>. Imaš tri načina:<ol><li>pomeri kralja,</li><li>stavi figuru između,</li><li>pojedi napadača.</li></ol>Hajde da probamo sva tri!", marks: { chk: ["e1"] } },
        { t: "escape", must: "king", fen: "4r3/8/8/8/8/8/8/4K3 w - - 0 1", marks: { chk: ["e1"] }, say: "Prvi način: <em>pomeri kralja</em> na polje koje nije napadnuto. Izaberi pravo polje!", ok: "Kralj je pobegao sa napadnutog polja. Prvi način!" },
        { t: "escape", must: "block", fen: "4r3/8/8/8/R7/8/8/4K3 w - - 0 1", marks: { chk: ["e1"] }, say: "Drugi način: <em>blokiraj</em>. Stavi neku figuru između topa i kralja. Tvoj top na a4 može da pomogne!", hint: "Top sa a4 ide udesno na e4 – tačno između.", ok: "Blokirao si napad! Drugi način." },
        { t: "escape", must: "capture", fen: "8/8/8/8/8/5n2/6P1/4K3 w - - 0 1", marks: { chk: ["e1"] }, arrows: [["f3", "e1", RED]], say: "Treći način: <em>pojedi napadača</em>. Skakač daje šah, a skakač se ne može blokirati jer preskače. Pojedi ga pešakom!", hint: "Pešak sa g2 jede koso na f3.", ok: "Napadač je pojeden! Treći način." },
        { t: "choose", say: "Pitanje za kraj.", q: "Šta NIJE način da spasiš kralja od šaha?", opts: ["Pomeriti kralja", "Staviti figuru između", "Pojesti napadača", "Pomeriti neku drugu figuru i ostaviti kralja u šahu"], ans: 3, why: "Kralj mora odmah da bude spasen. Ne smeš da završiš potez a da ti je kralj u šahu." }
      ]
    },

    {
      id: "mat", naslov: "Mat – kraj partije", opis: "Kad kralj nema izlaz, partija je gotova.", grupa: "Pravila igre", ikona: "k", xp: 45, znacka: "mat1",
      nauci: ["<b>Mat</b> je šah iz kojeg kralj ne može da se spase.", "Ko da mat, pobeđuje.", "Cilj igre nije pojesti sve figure, nego matirati kralja."],
      koraci: [
        { fen: "7k/6Q1/5K2/8/8/8/8/8 b - - 0 1", marks: { chk: ["h8"], zone: ["g8", "h7"] }, arrows: [["g7", "h8", RED]], say: "Ako je kralj u šahu i <em>ne može da se spase</em>, to je <em>ŠAH-MAT</em>! Crni kralj na h8 je u šahu od dame. Polja g8 i h7 su napadnuta (crvena), a damu čuva beli kralj. Nema izlaza!" },
        { say: "Ko da mat – <em>pobeđuje</em>! Zato je cilj igre da matiraš protivničkog kralja, a ne da pojedeš što više figura.", marks: { chk: ["h8"] } },
        { t: "mate", fen: "k7/8/1K6/8/8/8/8/7R w - - 0 1", say: "Tvoj red! Nađi <em>mat u jednom potezu</em>. Beli top je na h1. Crni kralj stoji u uglu, a beli kralj mu zatvara polja a7 i b7.", hint: "Top ide do poslednjeg reda, na istu liniju sa crnim kraljem.", ok: "<span class=\"ok\">ŠAH-MAT!</span> Kralj nema kuda: a7 i b7 čuva beli kralj, a b8 top." },
        { t: "mate", fen: "6k1/5ppp/8/8/8/8/8/R3K3 w - - 0 1", say: "Još jedan mat! Crni kralj je zatvoren iza svojih pešaka. Nađi mat u jednom potezu.", hint: "Top na a1 ide do poslednjeg reda.", ok: "<span class=\"ok\">ŠAH-MAT!</span> Kralj je zarobljen iza svojih pešaka – ovo se zove mat na poslednjem redu." },
        { t: "mate", fen: "k7/8/1K6/8/8/8/8/6Q1 w - - 0 1", say: "Poslednji mat u ovoj lekciji! Nađi pravi potez damom.", hint: "Dama ide uz g kolonu do poslednjeg reda.", ok: "<span class=\"ok\">ŠAH-MAT!</span> Dama drži ceo osmi red, a kralj drži a7 i b7." },
        { say: "Ali pazi! Nekad si tako blizu pobede da napraviš grešku – <em>pat</em>. O tome ću ti pričati u sledećoj lekciji." }
      ]
    },

    {
      id: "pat", naslov: "Pat i remi", opis: "Kad niko ne pobeđuje.", grupa: "Pravila igre", ikona: "k", xp: 40,
      nauci: ["<b>Pat</b>: igrač nema potez, a kralj nije u šahu – remi.", "Remi je i kad nema dovoljno figura za mat.", "Pazi da ne daš pat kad si blizu pobede!"],
      koraci: [
        { fen: "7k/5Q2/6K1/8/8/8/8/8 b - - 0 1", marks: { zone: ["g8", "g7", "h7"] }, say: "Ponekad niko ne pobeđuje. To je <em>remi</em> (nerešeno). Jedan način je <em>PAT</em>. Crni je na potezu. Kralj <em>nije u šahu</em>, ali nema nijedan dozvoljen potez – sva polja oko njega su napadnuta (crvena)." },
        { t: "choose", q: "Crni nije u šahu, a nema nijedan potez. Kako se to zove?", opts: ["Mat – crni gubi", "Pat – remi", "Šah"], ans: 1, why: "Pat! Kad nema šaha, a nema ni poteza, partija je nerešena." },
        { t: "mate", fen: "7k/8/5K2/8/8/8/8/6Q1 w - - 0 1", say: "Sada ti nađi mat u jednom potezu. <em>Ali pazi na pat!</em> Jedan potez damom je mat, a drugi je pat.", hint: "Dama treba da napadne kralja, a da ga ipak zatvori. Pomaže beli kralj na f6.", ok: "<span class=\"ok\">ŠAH-MAT!</span> Dama je napadnuta, ali je čuva kralj. Bravo, izbegao si pat!" },
        { fen: "8/8/8/4k3/8/8/4K3/8 w - - 0 1", say: "Remi može biti i ovako: ostala su samo <em>dva kralja</em>. Niko ne može da matira, pa je partija nerešena. Remi je i kad se <em>ista pozicija ponovi tri puta</em> ili kad se igrači dogovore." },
        { t: "choose", q: "Na tabli su samo dva kralja. Ko pobeđuje?", opts: ["Beli", "Crni", "Niko – remi"], ans: 2, why: "Ni jedan kralj ne može da matira drugog. Remi!" }
      ]
    },

    {
      id: "rokada", naslov: "Rokada", opis: "Poseban potez: kralj i top zajedno.", grupa: "Pravila igre", ikona: "r", xp: 40, znacka: "rokada",
      nauci: ["Rokada je jedan potez u kojem se pomeraju <b>kralj i top</b>.", "Kralj ide dva polja prema topu, top skoči preko njega.", "Mala rokada (sa topom h) i velika rokada (sa topom a).", "Ne sme se kad je kralj u šahu ili ako su se kralj ili top već pomerali."],
      koraci: [
        { fen: "4k3/8/8/8/8/8/8/R3K2R w KQ - 0 1", say: "<em>Rokada</em> je poseban potez: pomeraju se <em>dve figure</em> odjednom – kralj i top! Kralj ode na sigurno, a top izađe u igru." },
        { t: "play", fen: "4k3/8/8/8/8/8/8/R3K2R w KQ - 0 1", want: ["e1g1"], say: "Probaj <em>malu rokadu</em>: pomeri kralja <em>dva polja</em> prema topu na h1. Top će skočiti na drugu stranu kralja.", hint: "Kralj ide sa e1 na g1.", no: "Za rokadu treba da pomeriš kralja dva polja udesno, na g1.", ok: "Mala rokada! Kralj je na g1, a top na f1." },
        { t: "play", fen: "4k3/8/8/8/8/8/8/R3K2R w KQ - 0 1", want: ["e1c1"], say: "A sada <em>veliku rokadu</em>: kralj ide dva polja ka topu na a1.", hint: "Kralj ide sa e1 na c1.", no: "Za veliku rokadu pomeri kralja dva polja ulevo, na c1.", ok: "Velika rokada! Kralj je na c1, a top na d1." },
        { say: "Rokada je dozvoljena <em>samo ako</em>:<ul><li>kralj i taj top se još <em>nisu pomerali</em>,</li><li>između njih <em>nema figura</em>,</li><li>kralj <em>nije u šahu</em> i ne prelazi preko napadnutog polja.</li></ul>" },
        { t: "choose", fen: "4r3/8/8/8/8/8/8/R3K2R w KQ - 0 1", marks: { chk: ["e1"] }, say: "Pogledaj ovu tablu. Crni top daje šah.", q: "Smeš li da rokiraš dok ti je kralj u šahu?", opts: ["Da", "Ne"], ans: 1, why: "Iz šaha nema rokade. Prvo moraš da spaseš kralja." },
        { t: "play", fen: "r1bqk2r/ppp2ppp/2np1n2/2b1p3/2B1P3/2NP1N2/PPP2PPP/R1BQK2R w KQkq - 0 1", face: false, want: ["e1g1"], say: "Ovo je prava partija. Tvoj kralj je još u sredini, što je opasno. Skakač i lovac su izašli, pa je put slobodan. <em>Rokiraj!</em>", hint: "Kralj ide sa e1 na g1.", no: "Rokiraj: pomeri kralja dva polja udesno, na g1.", ok: "Odlično! Kralj je sada iza pešaka, a top je u igri." }
      ]
    },

    {
      id: "promocija", naslov: "Promocija pešaka", opis: "Pešak stiže do kraja i postaje dama.", grupa: "Pravila igre", ikona: "p", xp: 40,
      nauci: ["Pešak koji stigne do poslednjeg reda <b>postaje druga figura</b>.", "Najčešće se bira dama – najjača.", "Ne može postati kralj ni ostati pešak."],
      koraci: [
        { fen: "7k/4P3/8/8/8/8/8/4K3 w - - 0 1", marks: { hint: ["e8"] }, say: "Pešak je hrabar! Kad stigne do <em>poslednjeg reda</em> table, postaje <em>druga figura</em>. To se zove <em>promocija</em>." },
        { t: "play", fen: "7k/4P3/8/8/8/8/8/4K3 w - - 0 1", want: ["e7e8"], say: "Pomeri pešaka na poslednje polje i izaberi u šta ćeš ga pretvoriti!", hint: "Pešak ide jedno polje napred, na e8.", ok: function (f, t, p) { var n = { q: "damu", r: "topa", b: "lovca", n: "skakača" }[p] || "figuru"; return "Pešak je postao " + n + "! " + (p === "q" ? "Dama je najjača – najčešće se bira ona." : "Najčešće se bira dama jer je najjača, ali i ovo je dozvoljeno."); } },
        { t: "play", fen: "7r/6P1/8/8/8/8/8/4K1k1 w - - 0 1", want: ["g7h8"], say: "Pešak može i da <em>jede</em> dok promoviše! Crni top čuva polje g8. Pojedi topa koso i postani dama!", hint: "Pešak jede koso: sa g7 na h8.", no: "Na g8 bi top pojeo tvoju novu figuru. Pojedi topa na h8, koso!", ok: function (f, t, p) { return "Pojeo si topa i napravio novu figuru. Dvostruko dobar potez!"; } },
        { t: "choose", say: "Pitanje za kraj.", q: "U šta pešak NE može da se pretvori?", opts: [{ t: "Dama", p: "q" }, { t: "Top", p: "r" }, { t: "Kralj", p: "k" }, { t: "Skakač", p: "n" }], ans: 2, why: "Kralj može da bude samo jedan, pa pešak ne može da postane kralj. Sve ostalo može." }
      ]
    },

    {
      id: "prolaz", naslov: "En passant – u prolazu", opis: "Najčudniji potez u šahu.", grupa: "Pravila igre", ikona: "p", xp: 40,
      nauci: ["En passant je jedino jedenje pešaka „u prolazu“.", "Može samo <b>odmah</b> posle dvostrukog poteza susednog pešaka.", "Pešak jede kao da je protivnik stao na jedno polje."],
      koraci: [
        {
          t: "play", fen: "4k3/3p4/8/4P3/8/8/8/4K3 b - - 0 1", pre: [["d7", "d5"]], want: ["e5d6"], face: true,
          say: "Ovo je najčudniji potez u šahu: <em>en passant</em>, na srpskom <em>„u prolazu“</em>. Gledaj šta crni pešak radi!",
          afterPre: "Crni pešak je skočio dva polja i <em>prošao pored tvog pešaka</em>. Sada ga možeš pojesti <em>kao da je stao samo na d6</em>. Pojedi ga: e5 na d6!",
          hint: "Tvoj pešak sa e5 ide koso na d6.", no: "Ovde je jedini potez koji hoćemo: pešak sa e5 jede koso na d6, „u prolazu“.",
          ok: "<em>En passant!</em> Pojeo si pešaka u prolazu."
        },
        { say: "Pazi: ova šansa traje <em>samo jedan potez</em>. Ako je ne iskoristiš odmah, nestaje." },
        {
          t: "play", fen: "4k3/8/8/8/3p4/8/4P3/4K3 w - - 0 1", side: "b", pre: [["e2", "e4"]], want: ["d4e3"], face: true,
          say: "Hajde još jednom, ali sada je tvoj pešak crni! Gledaj šta beli radi.",
          afterPre: "Beli pešak je skočio dva polja pored tvog pešaka. Pojedi ga <em>u prolazu</em>: d4 na e3!",
          hint: "Crni pešak ide naniže koso, na e3.", no: "Pešak sa d4 treba da pojede koso, na e3.", ok: "Opet <em>en passant</em>! Sad si majstor."
        },
        { t: "choose", say: "Pitanje za kraj.", q: "Kad je moguć en passant?", opts: ["Odmah posle što protivnički pešak skoči dva polja pored mog pešaka", "Uvek, u bilo kom trenutku", "Samo kad igram crnim figurama"], ans: 0, why: "Tačno! Samo odmah, u sledećem potezu." }
      ]
    },

    /* ═════════ PRVI KORACI U PARTIJI ═════════ */
    {
      id: "otvaranje", naslov: "Kako početi partiju", opis: "Četiri zlatna pravila otvaranja.", grupa: "Prvi koraci u partiji", ikona: "n", xp: 45, face: false,
      nauci: ["Kontroliši <b>sredinu</b> table pešacima.", "Izvedi <b>skakače i lovce</b> u igru.", "Rokiraj da kralj bude na sigurnom.", "Damu ne izvodi rano."],
      koraci: [
        { fen: START, say: "Kako početi partiju? Imam <em>četiri zlatna pravila</em>:<ol><li>kontroliši <em>sredinu</em> pešacima,</li><li>izvedi <em>skakače i lovce</em>,</li><li><em>rokiraj</em> kralja,</li><li>damu ne izvodi rano.</li></ol>" },
        { t: "choose", fen: START, say: "Hajde da probamo prvo pravilo.", q: "Koji je dobar prvi potez za belog?", opts: ["e2–e4 (pešak ide u sredinu)", "Dama d1–h5", "h2–h3 (pešak sa ivice)"], ans: 0, why: "Pešak na e4 gleda u sredinu table i otvara put lovcu i dami." },
        {
          t: "play", fen: START, face: false, say: "Sad odigraj pravi početak partije! Ja ću igrati crne.",
          stages: [
            { want: ["e2e4"], say: "Pomeri pešaka u sredinu: <em>e2–e4</em>.", ok: "Dobro! Pešak gleda u sredinu.", reply: "e7e5", hint: "Pešak sa e2 ide na e4." },
            { want: ["g1f3"], say: "Izvedi skakača <em>g1–f3</em>. Skakači izlaze pre lovaca!", ok: "Skakač je u igri i napada pešaka.", reply: "b8c6", hint: "Skakač sa g1 skače na f3." },
            { want: ["f1c4", "f1e2", "f1b5"], say: "Sada izvedi lovca: <em>f1–c4</em> (ili e2, b5).", ok: "Lovac gleda ka sredini.", reply: "g8f6", hint: "Lovac sa f1 ide koso na c4." },
            { want: ["e1g1"], say: "Sada <em>rokiraj</em> – kralj ide dva polja udesno, na g1.", ok: "Kralj je na sigurnom.", hint: "Kralj ide sa e1 na g1." }
          ],
          done: "Odigrao si savršen početak: sredina, skakač, lovac, rokada!"
        },
        { t: "choose", say: "Pitanje za kraj.", q: "Šta NIJE dobro u otvaranju?", opts: ["Izvoditi damu rano i pomerati je stalno", "Izvesti skakače", "Rokirati kralja"], ans: 0, why: "Dama je jaka, ali ako izađe rano, protivnik je teraće svojim figurama i gubićeš vreme." }
      ]
    },

    {
      id: "cuvaj", naslov: "Čuvaj svoje figure!", opis: "Nezaštićena figura je besplatan plen.", grupa: "Prvi koraci u partiji", ikona: "b", xp: 45, face: false,
      nauci: ["Nezaštićena figura koju neko napada je <b>besplatan plen</b>.", "Pre svakog poteza pogledaj: ko napada moje figure? Ko ih čuva?", "Ako je figura napadnuta: pomeri je ili je zaštiti."],
      koraci: [
        { fen: "3rk3/8/8/8/3N1B2/8/8/4K3 w - - 0 1", arrows: [["d8", "d4", RED]], say: "Najčešća greška: figura ostane <em>bez zaštite</em> i protivnik je pojede <em>besplatno</em>! Pre svakog poteza pitaj: <em>ko napada moje figure? ko ih čuva?</em> Ovde crni top napada skakača." },
        { t: "hang", fen: "3rk3/8/8/8/3N1B2/8/8/4K3 w - - 0 1", say: "Dodirni belu figuru koju crni može da pojede <em>besplatno</em>.", ok: "Tačno! Skakač je napadnut, a niko ga ne čuva.", hint: "Pogledaj strelicu – koga napada crni top?" },
        { t: "hang", fen: "4k3/8/5n2/8/4P1R1/3B4/8/4K3 w - - 0 1", arrows: [["f6", "e4", RED], ["f6", "g4", RED], ["d3", "e4", "ar"]], say: "Crni skakač napada <em>dve</em> bele figure: pešaka e4 i topa g4. Zeleno je zaštita: lovac čuva pešaka. Koju figuru crni može da pojede besplatno?", ok: "Top na g4! Pešaka e4 čuva lovac, pa ga skakač ne bi pojeo besplatno.", hint: "Koju figuru niko ne čuva?" },
        { t: "fix", fen: "3rk3/8/8/8/3N1B2/8/8/4K3 w - - 0 1", zone: "b", say: "Sada ti spasi skakača! Odigraj potez posle koga nijedna tvoja figura nije u opasnosti. Možeš da ga pomeriš ili da ga zaštitiš nekom drugom figurom.", hint: "Lovac sa f4 može da ode na e3 i tako zaštiti skakača. Ili pomeri skakača.", no: "Ta figura je još u opasnosti! Pogledaj crvena polja i strelicu.", ok: "Spasio si figuru! Dobro razmišljaš." },
        { t: "choose", say: "Pitanje za kraj.", q: "Tvoja figura je napadnuta, a nije zaštićena. Šta radiš?", opts: ["Pomerim je ili je zaštitim", "Ništa, možda je neće pojesti", "Napadnem nešto drugo i nadam se"], ans: 0, why: "Tako je! Ne ostavljaj figure bez zaštite." }
      ]
    },

    {
      id: "spremni", naslov: "Spremni za partiju!", opis: "Nekoliko saveta pre prve partije.", grupa: "Prvi koraci u partiji", ikona: "q", xp: 30, face: false,
      nauci: ["Cilj igre je mat.", "Pre poteza proveri ko koga napada.", "Gubiti je u redu – tako se uči."],
      koraci: [
        { fen: START, say: "Sad znaš skoro sve! Evo još nekoliko saveta pre tvoje prve partije." },
        { say: "<ol><li><em>Beli igra prvi</em>, pa se smenjuju.</li><li>Pre svakog poteza pogledaj: <em>ko napada mene</em> i <em>koga ja mogu da napadnem</em>?</li><li>Posle protivnikovog poteza zapitaj se: šta on hoće?</li><li>Ne žuri! Misli polako.</li><li>Kad izgubiš – nema veze. Svako ko igra šah gubi i uči!</li></ol>" },
        { t: "choose", q: "Šta je cilj igre?", opts: ["Pojesti što više figura", "Matirati protivničkog kralja", "Pomeriti sve pešake"], ans: 1, why: "Cilj je mat. Figure su samo pomoć na tom putu." },
        { t: "choose", q: "Protivnik ti je rekao „šah“. Šta radiš?", opts: ["Spasem kralja", "Nastavim kao da se ništa nije desilo"], ans: 0, why: "Tačno, uvek prvo spasiš kralja." },
        { say: "Spreman si! Idi u <em>Igraj</em>. Prvi nivo je lak i računar greši. Svaki put kad pobediš, dobijaćeš poene i značke. Srećno, šampione!", mood: "happy" }
      ]
    }

  ];
})();
