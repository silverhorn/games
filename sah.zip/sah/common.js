/* ŠAH ŠKOLA – zajednički delovi: Peško (vodič sa oblačićem), pokušaj poteza, pomoćne funkcije. */
(function () {
  "use strict";
  var E = window.ChessEngine;

  /* Peško – mali pešak koji priča. root: element u koji se ubacuje. */
  function Peko(root, o) {
    o = o || {};
    root.classList.add("peko");
    root.innerHTML = '<div class="peko-fig">' + PIECES.icon("p", "w", true) + '</div><div class="bubble"></div>' +
      (A.canSpeak ? '<button class="rd" aria-label="Pročitaj naglas" title="Pročitaj naglas">🔊</button>' : "");
    this.root = root;
    this.bub = root.querySelector(".bubble");
    this.text = "";
    var self = this, rd = root.querySelector(".rd");
    if (rd) rd.addEventListener("click", function () { A.speak(self.text); });
    root.querySelector(".peko-fig").addEventListener("click", function () { self.jump(); A.sfx.pop(); });
  }
  Peko.prototype.say = function (html, mood) {
    this.bub.innerHTML = html;
    this.text = this.bub.textContent;
    this.bub.classList.remove("pop"); void this.bub.offsetWidth; this.bub.classList.add("pop");
    this.root.classList.remove("sad");
    if (mood === "happy") this.jump();
    if (mood === "sad") this.root.classList.add("sad");
    if (A.S.set.read) A.speak(this.text);
  };
  Peko.prototype.jump = function () {
    var r = this.root; r.classList.remove("jump"); void r.offsetWidth; r.classList.add("jump");
    setTimeout(function () { r.classList.remove("jump"); }, 600);
  };

  /* Pokušaj poteza na tabli. Ako je promocija, pita za figuru. done(from,to,promo). Vraća true ako je potez prihvaćen. */
  function tryMove(board, g, from, to, done) {
    var c = g.moves({ square: from }).filter(function (m) { return m.to === to; });
    if (!c.length) return false;
    if (c[0].promotion) {
      board.snap(from);
      board.askPromotion(c[0].color, function (t) { if (t) done(from, to, t); });
      return true;
    }
    done(from, to, null);
    return true;
  }

  // sva polja koja napada boja c (prazna ili ne) – za crvenu zonu
  function attackedSquares(g, c) {
    var out = [], f, r, n;
    for (f = 0; f < 8; f++) for (r = 1; r <= 8; r++) { n = "abcdefgh"[f] + r; if (g.isAttacked(n, c)) out.push(n); }
    return out;
  }

  function vals() {
    var t = ["p", "n", "b", "r", "q"], v = PIECES.VALUE;
    return '<span class="vals">' + t.map(function (x) { return '<span class="val">' + PIECES.icon(x, "w") + "<b>" + v[x] + "</b></span>"; }).join("") + "</span>";
  }

  function material(g) {
    var m = g.material(); return { w: m.w, b: m.b };
  }

  // ime potega za čoveka: "Skakač na f3"
  function nice(v) {
    if (v.castle) return v.castle === "k" ? "Mala rokada" : "Velika rokada";
    return PIECES.NAMES[v.piece] + (v.captured ? " jede na " : " na ") + v.to;
  }

  window.UI = { Peko: Peko, tryMove: tryMove, attackedSquares: attackedSquares, vals: vals, nice: nice, material: material };
})();
