/* ŠAH – motor: sva pravila (rokada, en passant, promocija, remi) i računar sa nivoima.
   Sve je u jednoj funkciji da bi se isti kod mogao pokrenuti i u radniku (Web Worker) bez posebnog fajla. */
function buildChessEngine() {
  "use strict";
  var P = 1, N = 2, B = 3, R = 4, Q = 5, K = 6;
  var WHITE = 0, BLACK = 1;
  var CAP = 1, EP = 2, CASTLE = 4, DOUBLE = 8;
  var VAL = [0, 100, 320, 330, 500, 900, 20000];
  var FILES = "abcdefgh";
  var TCH = ".pnbrqk";
  var PCH = ["", "P", "N", "B", "R", "Q", "K", "", "", "p", "n", "b", "r", "q", "k"];
  var N_OFF = [14, 18, 31, 33, -14, -18, -31, -33];
  var K_OFF = [1, -1, 16, -16, 15, 17, -15, -17];
  var B_OFF = [15, 17, -15, -17];
  var R_OFF = [1, -1, 16, -16];
  var START = "rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1";
  var MATE = 30000, INF = 32000;

  var CR = []; (function () { for (var i = 0; i < 128; i++) CR[i] = 15; CR[4] = 12; CR[0] = 13; CR[7] = 14; CR[116] = 3; CR[112] = 7; CR[119] = 11; })();

  function sqName(s) { return FILES[s & 7] + ((s >> 4) + 1); }
  function sqIdx(n) { return (n.charCodeAt(1) - 49) * 16 + (n.charCodeAt(0) - 97); }

  /* ───────── tabele vrednosti polja ───────── */
  var PST = [null,
    [0, 0, 0, 0, 0, 0, 0, 0, 50, 50, 50, 50, 50, 50, 50, 50, 10, 10, 20, 30, 30, 20, 10, 10, 5, 5, 10, 25, 25, 10, 5, 5, 0, 0, 0, 20, 20, 0, 0, 0, 5, -5, -10, 0, 0, -10, -5, 5, 5, 10, 10, -20, -20, 10, 10, 5, 0, 0, 0, 0, 0, 0, 0, 0],
    [-50, -40, -30, -30, -30, -30, -40, -50, -40, -20, 0, 0, 0, 0, -20, -40, -30, 0, 10, 15, 15, 10, 0, -30, -30, 5, 15, 20, 20, 15, 5, -30, -30, 0, 15, 20, 20, 15, 0, -30, -30, 5, 10, 15, 15, 10, 5, -30, -40, -20, 0, 5, 5, 0, -20, -40, -50, -40, -30, -30, -30, -30, -40, -50],
    [-20, -10, -10, -10, -10, -10, -10, -20, -10, 0, 0, 0, 0, 0, 0, -10, -10, 0, 5, 10, 10, 5, 0, -10, -10, 5, 5, 10, 10, 5, 5, -10, -10, 0, 10, 10, 10, 10, 0, -10, -10, 10, 10, 10, 10, 10, 10, -10, -10, 5, 0, 0, 0, 0, 5, -10, -20, -10, -10, -10, -10, -10, -10, -20],
    [0, 0, 0, 0, 0, 0, 0, 0, 5, 10, 10, 10, 10, 10, 10, 5, -5, 0, 0, 0, 0, 0, 0, -5, -5, 0, 0, 0, 0, 0, 0, -5, -5, 0, 0, 0, 0, 0, 0, -5, -5, 0, 0, 0, 0, 0, 0, -5, -5, 0, 0, 0, 0, 0, 0, -5, 0, 0, 0, 5, 5, 0, 0, 0],
    [-20, -10, -10, -5, -5, -10, -10, -20, -10, 0, 0, 0, 0, 0, 0, -10, -10, 0, 5, 5, 5, 5, 0, -10, -5, 0, 5, 5, 5, 5, 0, -5, 0, 0, 5, 5, 5, 5, 0, -5, -10, 5, 5, 5, 5, 5, 0, -10, -10, 0, 5, 0, 0, 0, 0, -10, -20, -10, -10, -5, -5, -10, -10, -20],
    [-30, -40, -40, -50, -50, -40, -40, -30, -30, -40, -40, -50, -50, -40, -40, -30, -30, -40, -40, -50, -50, -40, -40, -30, -30, -40, -40, -50, -50, -40, -40, -30, -20, -30, -30, -40, -40, -30, -30, -20, -10, -20, -20, -20, -20, -20, -20, -10, 20, 20, 0, 0, 0, 0, 20, 20, 20, 30, 10, 0, 0, 10, 30, 20]
  ];
  var KING_EG = [-50, -40, -30, -20, -20, -30, -40, -50, -30, -20, -10, 0, 0, -10, -20, -30, -30, -10, 20, 30, 30, 20, -10, -30, -30, -10, 30, 40, 40, 30, -10, -30, -30, -10, 30, 40, 40, 30, -10, -30, -30, -10, 20, 30, 30, 20, -10, -30, -30, -30, 0, 0, 0, 0, -30, -30, -50, -30, -30, -30, -30, -30, -30, -50];

  /* ───────── igra ───────── */
  function Game(fen) { this.load(fen || START); }

  Game.prototype.load = function (fen) {
    var parts = String(fen).trim().split(/\s+/), rows = parts[0].split("/"), r, f, i, ch, s, c, t;
    this.b = []; for (i = 0; i < 128; i++) this.b[i] = 0;
    this.king = [-1, -1];
    for (r = 0; r < 8; r++) {
      f = 0;
      for (i = 0; i < (rows[r] || "").length; i++) {
        ch = rows[r][i];
        if (ch >= "1" && ch <= "8") f += +ch;
        else {
          c = ch === ch.toUpperCase() ? WHITE : BLACK; t = TCH.indexOf(ch.toLowerCase());
          if (t < 1) continue;
          s = (7 - r) * 16 + f; this.b[s] = t | (c << 3); if (t === K) this.king[c] = s; f++;
        }
      }
    }
    this.turn = parts[1] === "b" ? BLACK : WHITE;
    var cs = parts[2] || "-"; this.castle = 0;
    if (cs.indexOf("K") >= 0) this.castle |= 1; if (cs.indexOf("Q") >= 0) this.castle |= 2;
    if (cs.indexOf("k") >= 0) this.castle |= 4; if (cs.indexOf("q") >= 0) this.castle |= 8;
    this.ep = parts[3] && parts[3] !== "-" ? sqIdx(parts[3]) : -1;
    this.half = +parts[4] || 0; this.full = +parts[5] || 1;
    this.stack = []; this.hist = []; this.keys = [this._key()];
    this.startFen = this.fen();
    return this;
  };
  Game.prototype.reset = function () { return this.load(START); };

  Game.prototype._epCapturable = function () {
    if (this.ep < 0) return false;
    var us = this.turn, b = this.b, pawn = P | (us << 3), d = us === WHITE ? -16 : 16, s1 = this.ep + d - 1, s2 = this.ep + d + 1;
    return (!(s1 & 0x88) && b[s1] === pawn) || (!(s2 & 0x88) && b[s2] === pawn);
  };
  Game.prototype._key = function () {
    var s = "", i, p;
    for (i = 0; i < 128; i++) { if (i & 0x88) { i += 7; continue; } p = this.b[i]; s += p ? PCH[p] : "."; }
    return s + this.turn + this.castle + (this._epCapturable() ? this.ep : "-");
  };
  Game.prototype.fen = function () {
    var out = [], r, f, e, p, s;
    for (r = 7; r >= 0; r--) {
      e = 0; s = "";
      for (f = 0; f < 8; f++) { p = this.b[r * 16 + f]; if (!p) e++; else { if (e) { s += e; e = 0; } s += PCH[p]; } }
      if (e) s += e; out.push(s);
    }
    var cs = (this.castle & 1 ? "K" : "") + (this.castle & 2 ? "Q" : "") + (this.castle & 4 ? "k" : "") + (this.castle & 8 ? "q" : "");
    return out.join("/") + " " + (this.turn ? "b" : "w") + " " + (cs || "-") + " " + (this._epCapturable() ? sqName(this.ep) : "-") + " " + this.half + " " + this.full;
  };

  /* ───────── napadi ───────── */
  Game.prototype._attacked = function (sq, by) {
    var b = this.b, i, s, p, d, bi = B | (by << 3), ro = R | (by << 3), qu = Q | (by << 3), kn = N | (by << 3), kg = K | (by << 3);
    if (by === WHITE) {
      s = sq - 15; if (!(s & 0x88) && b[s] === P) return true;
      s = sq - 17; if (!(s & 0x88) && b[s] === P) return true;
    } else {
      s = sq + 15; if (!(s & 0x88) && b[s] === (P | 8)) return true;
      s = sq + 17; if (!(s & 0x88) && b[s] === (P | 8)) return true;
    }
    for (i = 0; i < 8; i++) {
      s = sq + N_OFF[i]; if (!(s & 0x88) && b[s] === kn) return true;
      s = sq + K_OFF[i]; if (!(s & 0x88) && b[s] === kg) return true;
    }
    for (i = 0; i < 4; i++) {
      d = B_OFF[i]; s = sq + d;
      while (!(s & 0x88)) { p = b[s]; if (p) { if (p === bi || p === qu) return true; break; } s += d; }
      d = R_OFF[i]; s = sq + d;
      while (!(s & 0x88)) { p = b[s]; if (p) { if (p === ro || p === qu) return true; break; } s += d; }
    }
    return false;
  };
  // polja figura boje "by" koje napadaju dato polje (bez x-zraka)
  Game.prototype._attackerList = function (sq, by) {
    var b = this.b, out = [], i, s, p, d;
    if (by === WHITE) {
      s = sq - 15; if (!(s & 0x88) && b[s] === P) out.push(s);
      s = sq - 17; if (!(s & 0x88) && b[s] === P) out.push(s);
    } else {
      s = sq + 15; if (!(s & 0x88) && b[s] === (P | 8)) out.push(s);
      s = sq + 17; if (!(s & 0x88) && b[s] === (P | 8)) out.push(s);
    }
    for (i = 0; i < 8; i++) {
      s = sq + N_OFF[i]; if (!(s & 0x88) && b[s] === (N | (by << 3))) out.push(s);
      s = sq + K_OFF[i]; if (!(s & 0x88) && b[s] === (K | (by << 3))) out.push(s);
    }
    for (i = 0; i < 4; i++) {
      d = B_OFF[i]; s = sq + d;
      while (!(s & 0x88)) { p = b[s]; if (p) { if ((p >> 3) === by && ((p & 7) === B || (p & 7) === Q)) out.push(s); break; } s += d; }
      d = R_OFF[i]; s = sq + d;
      while (!(s & 0x88)) { p = b[s]; if (p) { if ((p >> 3) === by && ((p & 7) === R || (p & 7) === Q)) out.push(s); break; } s += d; }
    }
    return out;
  };
  Game.prototype._attackerTypes = function (sq, by) {
    var b = this.b;
    return this._attackerList(sq, by).map(function (s) { return b[s] & 7; }).sort(function (x, y) { return VAL[x] - VAL[y]; });
  };
  Game.prototype._inCheck = function (c) { var k = this.king[c]; return k >= 0 && this._attacked(k, c ^ 1); };

  /* ───────── generisanje poteza ───────── */
  function pushPromos(out, from, to, fl) { out.push(from | (to << 7) | (Q << 14) | (fl << 17), from | (to << 7) | (R << 14) | (fl << 17), from | (to << 7) | (B << 14) | (fl << 17), from | (to << 7) | (N << 14) | (fl << 17)); }

  Game.prototype._gen = function (captOnly) {
    var b = this.b, us = this.turn, them = us ^ 1, out = [], s, p, t, i, to, q, d, dir, startRank, promoRank, c;
    for (s = 0; s < 128; s++) {
      if (s & 0x88) { s += 7; continue; }
      p = b[s]; if (!p || (p >> 3) !== us) continue;
      t = p & 7;
      if (t === P) {
        dir = us === WHITE ? 16 : -16; startRank = us === WHITE ? 1 : 6; promoRank = us === WHITE ? 7 : 0;
        to = s + dir;
        if (!(to & 0x88) && !b[to]) {
          if ((to >> 4) === promoRank) pushPromos(out, s, to, 0);
          else if (!captOnly) {
            out.push(s | (to << 7));
            if ((s >> 4) === startRank && !b[to + dir]) out.push(s | ((to + dir) << 7) | (DOUBLE << 17));
          }
        }
        for (c = -1; c <= 1; c += 2) {
          to = s + dir + c; if (to & 0x88) continue;
          q = b[to];
          if (q && (q >> 3) === them) { if ((to >> 4) === promoRank) pushPromos(out, s, to, CAP); else out.push(s | (to << 7) | (CAP << 17)); }
          else if (to === this.ep && !q) out.push(s | (to << 7) | ((EP | CAP) << 17));
        }
      } else if (t === N || t === K) {
        var offs = t === N ? N_OFF : K_OFF;
        for (i = 0; i < 8; i++) {
          to = s + offs[i]; if (to & 0x88) continue;
          q = b[to];
          if (!q) { if (!captOnly) out.push(s | (to << 7)); }
          else if ((q >> 3) === them) out.push(s | (to << 7) | (CAP << 17));
        }
      } else {
        var from4 = t === B ? 0 : t === R ? 4 : 0, count = t === Q ? 8 : 4;
        for (i = 0; i < count; i++) {
          d = t === Q ? (i < 4 ? B_OFF[i] : R_OFF[i - 4]) : t === B ? B_OFF[i] : R_OFF[i];
          to = s + d;
          while (!(to & 0x88)) {
            q = b[to];
            if (!q) { if (!captOnly) out.push(s | (to << 7)); }
            else { if ((q >> 3) === them) out.push(s | (to << 7) | (CAP << 17)); break; }
            to += d;
          }
        }
      }
    }
    if (!captOnly) {
      if (us === WHITE) {
        if (this.king[0] === 4 && (this.castle & 3) && !this._attacked(4, BLACK)) {
          if ((this.castle & 1) && !b[5] && !b[6] && b[7] === R && !this._attacked(5, BLACK)) out.push(4 | (6 << 7) | (CASTLE << 17));
          if ((this.castle & 2) && !b[3] && !b[2] && !b[1] && b[0] === R && !this._attacked(3, BLACK)) out.push(4 | (2 << 7) | (CASTLE << 17));
        }
      } else if (this.king[1] === 116 && (this.castle & 12) && !this._attacked(116, WHITE)) {
        if ((this.castle & 4) && !b[117] && !b[118] && b[119] === (R | 8) && !this._attacked(117, WHITE)) out.push(116 | (118 << 7) | (CASTLE << 17));
        if ((this.castle & 8) && !b[115] && !b[114] && !b[113] && b[112] === (R | 8) && !this._attacked(115, WHITE)) out.push(116 | (114 << 7) | (CASTLE << 17));
      }
    }
    return out;
  };

  Game.prototype._make = function (m) {
    var b = this.b, from = m & 127, to = (m >> 7) & 127, promo = (m >> 14) & 7, fl = m >> 17, us = this.turn, p = b[from], t = p & 7, cap = b[to], cs;
    if (fl & EP) { cs = to + (us === WHITE ? -16 : 16); cap = b[cs]; b[cs] = 0; }
    this.stack.push(m, cap, this.castle, this.ep, this.half);
    b[to] = promo ? (promo | (us << 3)) : p; b[from] = 0;
    if (t === K) {
      this.king[us] = to;
      if (fl & CASTLE) { if (to > from) { b[from + 1] = b[from + 3]; b[from + 3] = 0; } else { b[from - 1] = b[from - 4]; b[from - 4] = 0; } }
    }
    this.castle &= CR[from] & CR[to];
    this.ep = (fl & DOUBLE) ? (from + to) >> 1 : -1;
    this.half = (t === P || cap) ? 0 : this.half + 1;
    if (us === BLACK) this.full++;
    this.turn = us ^ 1;
  };
  Game.prototype._unmake = function () {
    var st = this.stack, n = st.length, b = this.b;
    this.half = st[n - 1]; this.ep = st[n - 2]; this.castle = st[n - 3]; var cap = st[n - 4], m = st[n - 5];
    st.length = n - 5;
    var from = m & 127, to = (m >> 7) & 127, promo = (m >> 14) & 7, fl = m >> 17, us = this.turn ^ 1, p = b[to];
    this.turn = us;
    if (promo) p = P | (us << 3);
    b[from] = p;
    if (fl & EP) { b[to] = 0; b[to + (us === WHITE ? -16 : 16)] = cap; } else b[to] = cap;
    if ((p & 7) === K) {
      this.king[us] = from;
      if (fl & CASTLE) { if (to > from) { b[from + 3] = b[from + 1]; b[from + 1] = 0; } else { b[from - 4] = b[from - 1]; b[from - 1] = 0; } }
    }
    if (us === BLACK) this.full--;
  };

  Game.prototype._legal = function () {
    var pl = this._gen(false), out = [], us = this.turn, i, k;
    for (i = 0; i < pl.length; i++) {
      this._make(pl[i]);
      k = this.king[us];
      if (k < 0 || !this._attacked(k, us ^ 1)) out.push(pl[i]);
      this._unmake();
    }
    return out;
  };

  Game.prototype._verbose = function (m) {
    var from = m & 127, to = (m >> 7) & 127, promo = (m >> 14) & 7, fl = m >> 17, p = this.b[from], cap = (fl & EP) ? P : (this.b[to] & 7);
    var o = { from: sqName(from), to: sqName(to), piece: TCH[p & 7], color: (p >> 3) ? "b" : "w", m: m };
    if (fl & CAP) o.captured = TCH[cap];
    if (promo) o.promotion = TCH[promo];
    o.flags = (fl & EP ? "e" : "") + (fl & CASTLE ? "c" : "") + (fl & DOUBLE ? "d" : "") + (fl & CAP ? "x" : "");
    o.ep = !!(fl & EP); o.castle = (fl & CASTLE) ? (to > from ? "k" : "q") : "";
    return o;
  };

  // opts: {square:"e2"} — samo potezi te figure
  Game.prototype.moves = function (opts) {
    var l = this._legal(), out = [], i, sq = opts && opts.square ? sqIdx(opts.square) : -1;
    for (i = 0; i < l.length; i++) { if (sq >= 0 && (l[i] & 127) !== sq) continue; out.push(this._verbose(l[i])); }
    return out;
  };

  Game.prototype._san = function (m, legal) {
    var b = this.b, from = m & 127, to = (m >> 7) & 127, promo = (m >> 14) & 7, fl = m >> 17, t = b[from] & 7, base = "", i, x, sameFile, sameRank, other;
    if (fl & CASTLE) base = to > from ? "O-O" : "O-O-O";
    else {
      if (t !== P) {
        base = "PNBRQK"[t - 1]; other = [];
        for (i = 0; i < legal.length; i++) { x = legal[i]; if (x !== m && (b[x & 127] & 7) === t && ((x >> 7) & 127) === to) other.push(x & 127); }
        if (other.length) {
          sameFile = false; sameRank = false;
          for (i = 0; i < other.length; i++) { if ((other[i] & 7) === (from & 7)) sameFile = true; if ((other[i] >> 4) === (from >> 4)) sameRank = true; }
          if (!sameFile) base += FILES[from & 7]; else if (!sameRank) base += ((from >> 4) + 1); else base += FILES[from & 7] + ((from >> 4) + 1);
        }
      }
      if (fl & CAP) { if (t === P) base += FILES[from & 7]; base += "x"; }
      base += sqName(to);
      if (promo) base += "=" + "PNBRQK"[promo - 1];
    }
    this._make(m);
    if (this._inCheck(this.turn)) base += this._legal().length ? "+" : "#";
    this._unmake();
    return base;
  };

  // o: {from,to,promotion} ili tekst (SAN, npr. "Nf3")
  Game.prototype.move = function (o) {
    var legal = this._legal(), i, found = -1, v, from, to, pr;
    if (typeof o === "string") {
      for (i = 0; i < legal.length; i++) if (this._san(legal[i], legal).replace(/[+#]/g, "") === o.replace(/[+#]/g, "")) { found = legal[i]; break; }
    } else {
      from = sqIdx(o.from); to = sqIdx(o.to); pr = o.promotion ? TCH.indexOf(o.promotion) : 0;
      for (i = 0; i < legal.length; i++) {
        if ((legal[i] & 127) !== from || ((legal[i] >> 7) & 127) !== to) continue;
        var lp = (legal[i] >> 14) & 7;
        if (lp && !pr && lp !== Q) continue;
        if (lp && pr && lp !== pr) continue;
        if (!lp && pr) continue;
        found = legal[i]; break;
      }
    }
    if (found < 0) return null;
    var san = this._san(found, legal); v = this._verbose(found); v.san = san; v.fenBefore = this.fen();
    this._make(found);
    this.hist.push(v); this.keys.push(this._key());
    v.check = this._inCheck(this.turn);
    return v;
  };
  Game.prototype.undo = function () {
    if (!this.hist.length) return null;
    var v = this.hist.pop(); this._unmake(); this.keys.pop();
    return v;
  };
  Game.prototype.history = function () { return this.hist.slice(); };
  Game.prototype.uciHistory = function () { return this.hist.map(function (h) { return h.from + h.to + (h.promotion || ""); }); };

  /* ───────── stanje partije ───────── */
  Game.prototype.turnColor = function () { return this.turn ? "b" : "w"; };
  Game.prototype.inCheck = function () { return this._inCheck(this.turn); };
  Game.prototype.isCheckmate = function () { return this._inCheck(this.turn) && this._legal().length === 0; };
  Game.prototype.isStalemate = function () { return !this._inCheck(this.turn) && this._legal().length === 0; };
  Game.prototype.isInsufficientMaterial = function () {
    var minors = [], i, p, t, bishopsColors = {}, onlyBishops = true;
    for (i = 0; i < 128; i++) {
      if (i & 0x88) { i += 7; continue; }
      p = this.b[i]; if (!p) continue; t = p & 7;
      if (t === P || t === R || t === Q) return false;
      if (t === N || t === B) { minors.push(t); if (t === B) bishopsColors[((i >> 4) + (i & 7)) & 1] = 1; else onlyBishops = false; }
    }
    if (minors.length <= 1) return true;
    if (onlyBishops && Object.keys(bishopsColors).length === 1) return true;
    return false;
  };
  Game.prototype.isThreefold = function () {
    var k = this.keys[this.keys.length - 1], n = 0, i;
    for (i = 0; i < this.keys.length; i++) if (this.keys[i] === k) n++;
    return n >= 3;
  };
  Game.prototype.isFiftyMoves = function () { return this.half >= 100; };
  Game.prototype.isDraw = function () { return this.isStalemate() || this.isInsufficientMaterial() || this.isThreefold() || this.isFiftyMoves(); };
  Game.prototype.isGameOver = function () { return this._legal().length === 0 || this.isInsufficientMaterial() || this.isThreefold() || this.isFiftyMoves(); };
  // razlog kraja: "mat" | "pat" | "materijal" | "ponavljanje" | "pedeset" | null
  Game.prototype.endReason = function () {
    var n = this._legal().length;
    if (n === 0) return this._inCheck(this.turn) ? "mat" : "pat";
    if (this.isInsufficientMaterial()) return "materijal";
    if (this.isThreefold()) return "ponavljanje";
    if (this.isFiftyMoves()) return "pedeset";
    return null;
  };

  /* ───────── pomoćne funkcije za interfejs ───────── */
  Game.prototype.get = function (name) { var p = this.b[sqIdx(name)]; return p ? { type: TCH[p & 7], color: (p >> 3) ? "b" : "w" } : null; };
  Game.prototype.put = function (piece, name) {
    var s = sqIdx(name), old = this.b[s];
    if (old && (old & 7) === K) this.king[old >> 3] = -1;
    this.b[s] = TCH.indexOf(piece.type) | (piece.color === "b" ? 8 : 0);
    if (piece.type === "k") this.king[piece.color === "b" ? 1 : 0] = s;
    this.keys = [this._key()]; return this;
  };
  Game.prototype.remove = function (name) {
    var s = sqIdx(name), old = this.b[s];
    if (old && (old & 7) === K) this.king[old >> 3] = -1;
    this.b[s] = 0; this.keys = [this._key()]; return this;
  };
  Game.prototype.setTurn = function (c) { this.turn = c === "b" ? BLACK : WHITE; this.ep = -1; this.keys = [this._key()]; return this; };
  Game.prototype.kingSquare = function (c) { var k = this.king[c === "b" ? 1 : 0]; return k >= 0 ? sqName(k) : null; };
  Game.prototype.isAttacked = function (name, byColor) { return this._attacked(sqIdx(name), byColor === "b" ? BLACK : WHITE); };
  Game.prototype.attackers = function (name, byColor) {
    return this._attackerList(sqIdx(name), byColor === "b" ? BLACK : WHITE).map(sqName);
  };
  Game.prototype.material = function () {
    var m = [0, 0], i, p;
    for (i = 0; i < 128; i++) { if (i & 0x88) { i += 7; continue; } p = this.b[i]; if (p && (p & 7) !== K) m[p >> 3] += VAL[p & 7]; }
    return { w: m[0], b: m[1] };
  };
  Game.prototype.pieceList = function () {
    var out = [], i, p;
    for (i = 0; i < 128; i++) { if (i & 0x88) { i += 7; continue; } p = this.b[i]; if (p) out.push({ square: sqName(i), type: TCH[p & 7], color: (p >> 3) ? "b" : "w" }); }
    return out;
  };

  // koliko materijala (u pešacima ×100) napadač može da dobije hvatanjem na polju (SEE, bez x-zraka)
  Game.prototype._see = function (sq, attacker) {
    var p = this.b[sq]; if (!p) return 0;
    var def = attacker ^ 1, a = this._attackerTypes(sq, attacker), d = this._attackerTypes(sq, def);
    if (!a.length) return 0;
    var gain = [VAL[p & 7]], depth = 0, cur = a.shift(), side = 0;
    while (true) {
      depth++; gain[depth] = VAL[cur] - gain[depth - 1];
      var next = side === 0 ? (d.length ? d.shift() : 0) : (a.length ? a.shift() : 0);
      if (!next) break;
      cur = next; side ^= 1;
    }
    while (--depth) gain[depth - 1] = -Math.max(-gain[depth - 1], gain[depth]);
    return gain[0];
  };
  // najopasnije "viseće" figure boje c (koje protivnik može da dobije)
  Game.prototype.hanging = function (c) {
    var col = c === "b" ? BLACK : WHITE, out = [], i, p, g;
    for (i = 0; i < 128; i++) {
      if (i & 0x88) { i += 7; continue; }
      p = this.b[i]; if (!p || (p >> 3) !== col || (p & 7) === K) continue;
      g = this._see(i, col ^ 1);
      if (g > 0) out.push({ square: sqName(i), type: TCH[p & 7], gain: g });
    }
    out.sort(function (x, y) { return y.gain - x.gain; });
    return out;
  };
  Game.prototype.mateIn1Moves = function () {
    var l = this._legal(), out = [], i;
    for (i = 0; i < l.length; i++) {
      this._make(l[i]);
      var mate = this._inCheck(this.turn) && this._legal().length === 0;
      this._unmake();
      if (mate) out.push(this._verbose(l[i]));
    }
    return out;
  };
  Game.prototype.perft = function (depth) {
    if (depth === 0) return 1;
    var l = this._legal(), n = 0, i;
    if (depth === 1) return l.length;
    for (i = 0; i < l.length; i++) { this._make(l[i]); n += this.perft(depth - 1); this._unmake(); }
    return n;
  };
  Game.prototype.clone = function () { var g = new Game(this.fen()); g.keys = this.keys.slice(); return g; };

  /* ───────── procena i pretraga ───────── */
  function evaluate(g) {
    var b = g.b, s, p, t, c, idx, score = 0, mat = [0, 0], npm = 0, bish = [0, 0], kings = [-1, -1];
    for (s = 0; s < 128; s++) {
      if (s & 0x88) { s += 7; continue; }
      p = b[s]; if (!p) continue;
      t = p & 7; c = p >> 3;
      if (t === K) { kings[c] = s; continue; }
      idx = c === 0 ? (7 - (s >> 4)) * 8 + (s & 7) : (s >> 4) * 8 + (s & 7);
      var v = VAL[t] + PST[t][idx];
      mat[c] += VAL[t]; if (t !== P) npm += VAL[t]; if (t === B) bish[c]++;
      score += c === 0 ? v : -v;
    }
    var eg = npm <= 2600, i;
    for (c = 0; c < 2; c++) {
      if (kings[c] < 0) continue;
      s = kings[c]; idx = c === 0 ? (7 - (s >> 4)) * 8 + (s & 7) : (s >> 4) * 8 + (s & 7);
      var kv = eg ? KING_EG[idx] : PST[6][idx];
      score += c === 0 ? kv : -kv;
    }
    if (bish[0] >= 2) score += 30; if (bish[1] >= 2) score -= 30;
    if (eg && kings[0] >= 0 && kings[1] >= 0) {
      var diff = mat[0] - mat[1];
      if (diff >= 300) score += mopup(kings[0], kings[1]);
      else if (diff <= -300) score -= mopup(kings[1], kings[0]);
    }
    return g.turn === WHITE ? score : -score;
  }
  function mopup(win, lose) {
    var lf = lose & 7, lr = lose >> 4, cd = Math.max(3 - lf, lf - 4) + Math.max(3 - lr, lr - 4);
    var md = Math.abs((win & 7) - lf) + Math.abs((win >> 4) - lr);
    return cd * 12 + (14 - md) * 5;
  }

  var nodes = 0, deadline = 0, stopped = false, killers = [];
  function moveScore(g, m, ply) {
    var fl = m >> 17, promo = (m >> 14) & 7, sc = 0;
    if (fl & CAP) { var victim = (fl & EP) ? P : (g.b[(m >> 7) & 127] & 7), att = g.b[m & 127] & 7; sc = 10000 + VAL[victim] * 10 - att; }
    else if (killers[ply] === m) sc = 9000;
    if (promo) sc += 8000 + VAL[promo];
    return sc;
  }
  function order(g, ms, ply) {
    var sc = [], i; for (i = 0; i < ms.length; i++) sc.push(moveScore(g, ms[i], ply));
    var idx = ms.map(function (_, k) { return k; }).sort(function (x, y) { return sc[y] - sc[x]; });
    return idx.map(function (k) { return ms[k]; });
  }
  function tick() { nodes++; if ((nodes & 1023) === 0 && deadline && Date.now() > deadline) stopped = true; }

  function qsearch(g, alpha, beta, ply) {
    tick(); if (stopped) return 0;
    var stand = evaluate(g);
    if (stand >= beta) return beta;
    if (stand > alpha) alpha = stand;
    if (ply > 24) return stand;
    var ms = order(g, g._gen(true), ply), i, us = g.turn, k, sc;
    for (i = 0; i < ms.length; i++) {
      g._make(ms[i]);
      k = g.king[us];
      if (k >= 0 && g._attacked(k, us ^ 1)) { g._unmake(); continue; }
      sc = -qsearch(g, -beta, -alpha, ply + 1);
      g._unmake();
      if (stopped) return 0;
      if (sc >= beta) return beta;
      if (sc > alpha) alpha = sc;
    }
    return alpha;
  }
  function negamax(g, depth, alpha, beta, ply) {
    if (stopped) return 0;
    if (g.half >= 100) return 0;
    var us = g.turn, inChk = g._inCheck(us);
    if (inChk && ply < 20) depth++;
    if (depth <= 0) return qsearch(g, alpha, beta, ply);
    tick(); if (stopped) return 0;
    var ms = order(g, g._gen(false), ply), i, legal = 0, best = -INF, sc, k;
    for (i = 0; i < ms.length; i++) {
      g._make(ms[i]);
      k = g.king[us];
      if (k >= 0 && g._attacked(k, us ^ 1)) { g._unmake(); continue; }
      legal++;
      sc = -negamax(g, depth - 1, -beta, -alpha, ply + 1);
      g._unmake();
      if (stopped) return 0;
      if (sc > best) { best = sc; if (sc > alpha) { alpha = sc; if (alpha >= beta) { if (!(ms[i] >> 17 & CAP)) killers[ply] = ms[i]; break; } } }
    }
    if (!legal) return inChk ? -MATE + ply : 0;
    return best;
  }

  var LEVELS = [
    { id: 1, ime: "Mali pešak", opis: "Tek uči da igra. Često pogreši.", mode: "random" },
    { id: 2, ime: "Veseli skakač", opis: "Vidi jednostavne pretnje, ali greši.", depth: 1, noise: 130, ms: 300 },
    { id: 3, ime: "Pametni lovac", opis: "Igra pažljivo i retko greši.", depth: 2, noise: 45, ms: 600 },
    { id: 4, ime: "Jaki top", opis: "Dobro računa. Teško ga je prevariti.", depth: 4, noise: 12, ms: 900 },
    { id: 5, ime: "Majstor", opis: "Najjači. Za prave šampione!", depth: 7, noise: 0, ms: 1200 }
  ];

  function rootScores(g, depth, ms, noiseMode, history) {
    var legal = g._legal(), us = g.turn, i, res = [], sc;
    legal = order(g, legal, 0);
    for (i = 0; i < legal.length; i++) {
      g._make(legal[i]);
      if (history) { var key = g._key(), c = 0, j; for (j = 0; j < history.length; j++) if (history[j] === key) c++; if (c >= 2) { g._unmake(); res.push({ m: legal[i], s: 0 }); continue; } }
      if (g._legal().length === 0) sc = g._inCheck(g.turn) ? MATE : 0;
      else sc = -negamax(g, depth - 1, -INF, INF, 1);
      g._unmake();
      if (stopped) return null;
      res.push({ m: legal[i], s: sc });
    }
    return res;
  }

  // vraća {from,to,promotion,score}
  function pickMove(fen, level, history) {
    var g = new Game(fen), cfg = LEVELS[Math.max(0, Math.min(4, (level || 3) - 1))], legal = g._legal(), i;
    if (!legal.length) return null;
    killers = []; nodes = 0; stopped = false;
    if (legal.length === 1) return out1(g, legal[0], 0);
    // mat u jednom potezu — uvek ga odigraj (osim najlakšeg nivoa u 35% slučajeva)
    var mates = g.mateIn1Moves();
    if (mates.length && (cfg.mode !== "random" || Math.random() < 0.65)) return out1(g, mates[0].m, MATE);
    if (cfg.mode === "random") {
      var caps = [];
      for (i = 0; i < legal.length; i++) {
        if (legal[i] >> 17 & CAP) {
          g._make(legal[i]);
          var to = (legal[i] >> 7) & 127, bad = g._attacked(to, g.turn);
          g._unmake();
          if (!bad) caps.push(legal[i]);
        }
      }
      if (caps.length && Math.random() < 0.7) return out1(g, caps[Math.floor(Math.random() * caps.length)], 0);
      return out1(g, legal[Math.floor(Math.random() * legal.length)], 0);
    }
    deadline = Date.now() + cfg.ms;
    var bestMove = legal[0], bestScore = -INF, d;
    if (cfg.noise > 0) {
      stopped = false;
      var sc = rootScores(g, cfg.depth, cfg.ms, true, history);
      if (!sc) { return out1(g, legal[Math.floor(Math.random() * legal.length)], 0); }
      var top = -INF; for (i = 0; i < sc.length; i++) if (sc[i].s > top) top = sc[i].s;
      var pool = sc.filter(function (x) { return x.s >= top - cfg.noise; });
      var pick = pool[Math.floor(Math.random() * pool.length)];
      return out1(g, pick.m, pick.s);
    }
    // iterativno produbljivanje
    var ordered = order(g, legal, 0);
    for (d = 1; d <= cfg.depth; d++) {
      var alpha = -INF, curBest = null, curScore = -INF, aborted = false;
      for (i = 0; i < ordered.length; i++) {
        g._make(ordered[i]);
        var sc2;
        if (history) { var key = g._key(), c = 0, j; for (j = 0; j < history.length; j++) if (history[j] === key) c++; }
        if (history && c >= 2) sc2 = 0;
        else if (g._legal().length === 0) sc2 = g._inCheck(g.turn) ? MATE : 0;
        else sc2 = -negamax(g, d - 1, -INF, -alpha, 1);
        g._unmake();
        if (stopped) { aborted = true; break; }
        if (sc2 > curScore) { curScore = sc2; curBest = ordered[i]; if (sc2 > alpha) alpha = sc2; }
      }
      if (aborted) break;
      bestMove = curBest; bestScore = curScore;
      ordered = [bestMove].concat(ordered.filter(function (x) { return x !== bestMove; }));
      if (bestScore >= MATE - 50) break;
      if (Date.now() > deadline) break;
    }
    return out1(g, bestMove, bestScore);
  }
  function out1(g, m, score) {
    var v = g._verbose(m);
    return { from: v.from, to: v.to, promotion: v.promotion || null, score: score };
  }

  return { Game: Game, pickMove: pickMove, LEVELS: LEVELS, START: START, sqName: sqName, sqIdx: sqIdx, VAL: VAL, evaluate: evaluate };
}

if (typeof window !== "undefined") window.ChessEngine = buildChessEngine();
if (typeof module !== "undefined" && module.exports) module.exports = buildChessEngine;
