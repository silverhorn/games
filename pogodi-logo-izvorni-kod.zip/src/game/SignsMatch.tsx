import { useMemo, useState } from 'react';
import confetti from 'canvas-confetti';
import { ArrowLeft, Home, RotateCcw, Star, Trophy } from 'lucide-react';
import { SIGNS, SignArt, type Sign } from './signs';
import { sounds } from './sound';
import { getBest, setBest } from './quiz';
import type { Dict, Lang } from './i18n';

const BEST_KEY = 'signs-match';
const ROUND_SIZE = 6;

interface Props {
  t: Dict;
  lang: Lang;
  onBack: () => void;
}

function shuffled<T>(arr: T[]): T[] {
  return [...arr].sort(() => Math.random() - 0.5);
}

export default function SignsMatch({ t, lang, onBack }: Props) {
  const [round, setRound] = useState(0);
  const signs = useMemo(() => shuffled(SIGNS).slice(0, ROUND_SIZE), [round]);
  const meanings = useMemo(() => shuffled(signs), [signs]);

  const [pickedSign, setPickedSign] = useState<string | null>(null);
  const [matched, setMatched] = useState<Set<string>>(new Set());
  const [mistakes, setMistakes] = useState(0);
  const [wrongFlash, setWrongFlash] = useState<{ sign: string; meaning: string } | null>(null);

  const done = matched.size === ROUND_SIZE;
  const score = Math.max(0, ROUND_SIZE * 100 - mistakes * 25);
  const [isRecord, setIsRecord] = useState(false);

  function pickSign(id: string) {
    if (matched.has(id)) return;
    sounds.click();
    setPickedSign(id === pickedSign ? null : id);
  }

  function pickMeaning(id: string) {
    if (matched.has(id) || !pickedSign) return;
    if (id === pickedSign) {
      const next = new Set(matched).add(id);
      setMatched(next);
      setPickedSign(null);
      sounds.correct();
      if (next.size === ROUND_SIZE) {
        sounds.fanfare();
        setIsRecord(setBest(BEST_KEY, score));
        confetti({
          particleCount: 160,
          spread: 90,
          origin: { y: 0.4 },
          colors: ['#ffed9b', '#f0a208', '#974292', '#6bcb77', '#7fc2ec'],
          disableForReducedMotion: true,
        });
      }
    } else {
      setMistakes((m) => m + 1);
      setWrongFlash({ sign: pickedSign, meaning: id });
      sounds.wrong();
      setTimeout(() => setWrongFlash(null), 500);
    }
  }

  function restart() {
    sounds.click();
    setRound((r) => r + 1);
    setPickedSign(null);
    setMatched(new Set());
    setMistakes(0);
    setWrongFlash(null);
  }

  const best = getBest(BEST_KEY);
  const stars = mistakes === 0 ? 3 : mistakes <= 3 ? 2 : 1;

  return (
    <div className="mx-auto flex min-h-dvh w-full max-w-3xl flex-col px-4 py-5">
      <div className="flex flex-wrap items-center gap-3">
        <button type="button" onClick={() => { sounds.click(); onBack(); }} className="push-btn h-11 gap-2 px-4 font-extrabold">
          <ArrowLeft className="h-5 w-5" /> {t.back}
        </button>
        <h1 className="font-display text-2xl text-white drop-shadow-[0_3px_0_var(--navy)] sm:text-3xl">{t.matchTitle}</h1>
        <span className="chip ml-auto">{t.mistakes(mistakes)}</span>
      </div>
      <p className="mt-3 text-base font-extrabold text-[var(--navy)]">{t.matchHow}</p>

      <div className="mt-4 grid grid-cols-[auto_1fr] items-start justify-center gap-3 sm:gap-8">
        {/* Znakovi */}
        <div className="grid gap-3">
          {signs.map((s) => {
            const isMatched = matched.has(s.id);
            const isPicked = pickedSign === s.id;
            const isWrong = wrongFlash?.sign === s.id;
            return (
              <button
                key={s.id}
                type="button"
                disabled={isMatched}
                onClick={() => pickSign(s.id)}
                aria-pressed={isPicked}
                className={`push-btn h-[76px] w-[76px] !rounded-2xl p-1.5 sm:h-[88px] sm:w-[88px] ${
                  isMatched ? 'push-btn-leaf !opacity-70' : isPicked ? 'push-btn-sun' : ''
                } ${isWrong ? 'animate-shake bg-[var(--berry)]' : ''}`}
              >
                <SignArt sign={s} size={64} />
              </button>
            );
          })}
        </div>
        {/* Značenja */}
        <div className="grid gap-3">
          {meanings.map((s) => (
            <MeaningButton
              key={s.id}
              sign={s}
              lang={lang}
              isMatched={matched.has(s.id)}
              isWrong={wrongFlash?.meaning === s.id}
              onPick={() => pickMeaning(s.id)}
            />
          ))}
        </div>
      </div>

      {/* Kraj runde */}
      {done && (
        <div className="sticker-card animate-bounce-in mx-auto mt-6 w-full max-w-md p-6 text-center">
          <div className="flex items-center justify-center gap-2" aria-label={t.starsAria(stars)}>
            {[0, 1, 2].map((i) => (
              <Star
                key={i}
                className={`animate-star-pop h-10 w-10 ${i < stars ? 'fill-[var(--gold)] text-[var(--gold)]' : 'fill-black/10 text-black/20'}`}
                style={{ animationDelay: `${200 + i * 200}ms` }}
              />
            ))}
          </div>
          <p className="font-display mt-2 text-2xl">{t.matchDone}</p>
          <p className="font-display mt-1 text-5xl text-[var(--grape-deep)]">{score}</p>
          <p className="text-lg font-extrabold">{t.points}</p>
          {best > 0 && (
            <p className="mt-1 flex items-center justify-center gap-1 text-sm font-extrabold opacity-70">
              <Trophy className="h-4 w-4" /> {best}
            </p>
          )}
          {isRecord && <p className="chip mx-auto mt-2 w-fit bg-[var(--sun)]">{t.newRecord}</p>}
          <div className="mt-4 flex flex-col items-center justify-center gap-3 sm:flex-row">
            <button type="button" onClick={restart} className="push-btn push-btn-sun px-6 py-3 text-lg">
              <RotateCcw className="h-5 w-5" /> {t.playAgain}
            </button>
            <button type="button" onClick={() => { sounds.click(); onBack(); }} className="push-btn px-6 py-3 text-lg">
              <Home className="h-5 w-5" /> {t.mainMenu}
            </button>
          </div>
        </div>
      )}
    </div>
  );
}

function MeaningButton({
  sign, lang, isMatched, isWrong, onPick,
}: {
  sign: Sign;
  lang: Lang;
  isMatched: boolean;
  isWrong: boolean;
  onPick: () => void;
}) {
  return (
    <button
      type="button"
      disabled={isMatched}
      onClick={onPick}
      className={`push-btn min-h-[76px] px-4 py-2 text-left text-sm font-extrabold leading-snug sm:min-h-[88px] sm:text-base ${
        isMatched ? 'push-btn-leaf !opacity-70' : ''
      } ${isWrong ? 'animate-shake bg-[var(--berry)] text-white' : ''}`}
    >
      <span>
        <span className="font-display mr-1">{sign.name[lang]}.</span>
        {sign.meaning[lang]}
      </span>
    </button>
  );
}
