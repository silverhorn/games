import { Car, Flag, GraduationCap, Languages, Octagon, Route, Trophy, Volume2, VolumeX } from 'lucide-react';
import { getBest, type Tier } from './quiz';
import { logoUrl } from './quiz';
import type { Dict, Lang } from './i18n';

const HERO_LOGOS = ['ferrari', 'bmw', 'tesla', 'porsche', 'lamborghini', 'volkswagen'];

interface Props {
  t: Dict;
  lang: Lang;
  onLangToggle: () => void;
  onPlay: (tier: Tier) => void;
  onLearn: () => void;
  onFlags: () => void;
  onStreet: () => void;
  onMatch: () => void;
  soundOn: boolean;
  onToggleSound: () => void;
}

export default function HomeScreen({ t, lang, onLangToggle, onPlay, onLearn, onFlags, onStreet, onMatch, soundOn, onToggleSound }: Props) {
  const tierBlurbs: Record<Tier, string> = { 1: t.tierEasyBlurb, 2: t.tierMidBlurb, 3: t.tierHardBlurb };
  const tierLabels: Record<Tier, string> = { 1: t.tierEasy, 2: t.tierMid, 3: t.tierHard };

  return (
    <div className="relative mx-auto flex min-h-dvh w-full max-w-3xl flex-col items-center px-4 py-8">
      {/* Plutajuća oblačna dekoracija */}
      <div aria-hidden className="pointer-events-none absolute inset-0 overflow-hidden">
        <div className="animate-float-slow absolute -left-10 top-16 h-16 w-40 rounded-full bg-white/60" />
        <div className="animate-float-slower absolute right-0 top-40 h-12 w-32 rounded-full bg-white/50" />
        <div className="animate-float-slow absolute bottom-24 left-1/4 h-10 w-24 rounded-full bg-white/40" />
      </div>

      <div className="absolute right-4 top-4 flex gap-2">
        <button
          type="button"
          onClick={onLangToggle}
          aria-label={lang === 'lat' ? 'Ћирилица' : 'Latinica'}
          className="push-btn h-12 gap-1 px-3 font-display text-sm"
        >
          <Languages className="h-5 w-5" />
          {lang === 'lat' ? 'Ћ' : 'A'}
        </button>
        <button
          type="button"
          onClick={onToggleSound}
          aria-label={soundOn ? t.soundOn : t.soundOff}
          className="push-btn h-12 w-12 !rounded-full"
        >
          {soundOn ? <Volume2 className="h-5 w-5" /> : <VolumeX className="h-5 w-5" />}
        </button>
      </div>

      {/* Naslov */}
      <div className="animate-pop-in mt-12 flex flex-col items-center text-center">
        <div className="animate-wiggle sticker-card mb-5 flex h-24 w-24 items-center justify-center !rounded-[2rem] bg-[var(--sun)]">
          <Car className="h-14 w-14" strokeWidth={2.4} />
        </div>
        <h1 className="font-display text-5xl leading-tight tracking-tight text-white drop-shadow-[0_4px_0_var(--navy)] sm:text-6xl">
          {t.titleBig}
        </h1>
        <p className="mt-3 max-w-md text-lg font-extrabold text-[var(--navy)]">{t.subtitle}</p>
      </div>

      {/* Traka sa logoiма */}
      <div className="animate-pop-in mt-7 flex flex-wrap items-center justify-center gap-3" style={{ animationDelay: '120ms' }}>
        {HERO_LOGOS.map((slug) => (
          <div key={slug} className="sticker-card flex h-16 w-16 items-center justify-center !rounded-2xl p-2 sm:h-20 sm:w-20">
            <img src={logoUrl(slug)} alt="" className="max-h-full max-w-full object-contain" draggable={false} />
          </div>
        ))}
      </div>

      {/* Marke automobila */}
      <h2 className="font-display mt-10 self-start text-xl text-white drop-shadow-[0_3px_0_var(--navy)]">{t.sectionCars}</h2>
      <div className="mt-3 grid w-full gap-4">
        {([1, 2, 3] as Tier[]).map((tier, i) => {
          const best = getBest(tier);
          const colors = ['push-btn-leaf', 'push-btn-sun', 'push-btn-coral'][i];
          return (
            <button
              key={tier}
              type="button"
              onClick={() => onPlay(tier)}
              className={`push-btn ${colors} w-full flex-col !items-stretch gap-1 px-6 py-4 text-left`}
            >
              <span className="flex items-center justify-between gap-3">
                <span className="font-display text-2xl">{tierLabels[tier]}</span>
                {best > 0 && (
                  <span className="chip !border-[2px] !py-1 text-sm">
                    <Trophy className="h-4 w-4" /> {best}
                  </span>
                )}
              </span>
              <span className="text-sm font-bold opacity-80">{tierBlurbs[tier]}</span>
            </button>
          );
        })}
        <button type="button" onClick={onLearn} className="push-btn push-btn-grape px-8 py-4 text-xl">
          <GraduationCap className="h-6 w-6" />
          {t.learn}
        </button>
      </div>

      {/* Zastave */}
      <h2 className="font-display mt-8 self-start text-xl text-white drop-shadow-[0_3px_0_var(--navy)]">{t.sectionFlags}</h2>
      <div className="mt-3 grid w-full gap-4">
        <button
          type="button"
          onClick={onFlags}
          className="push-btn w-full flex-col !items-stretch gap-1 bg-[#b79ce0] px-6 py-4 text-left"
        >
          <span className="flex items-center justify-between gap-3">
            <span className="font-display flex items-center gap-2 text-2xl">
              <Flag className="h-6 w-6" /> {t.flagsTitle}
            </span>
            {getBest('flags') > 0 && (
              <span className="chip !border-[2px] !py-1 text-sm">
                <Trophy className="h-4 w-4" /> {getBest('flags')}
              </span>
            )}
          </span>
          <span className="text-sm font-bold opacity-80">{t.flagsBlurb}</span>
        </button>
      </div>

      {/* Saobraćajni znaci */}
      <h2 className="font-display mt-8 self-start text-xl text-white drop-shadow-[0_3px_0_var(--navy)]">{t.sectionSigns}</h2>
      <div className="mb-8 mt-3 grid w-full gap-4 sm:grid-cols-2">
        <button type="button" onClick={onStreet} className="push-btn push-btn-sun flex-col !items-start gap-1 px-6 py-4 text-left">
          <span className="font-display flex items-center gap-2 text-xl">
            <Route className="h-6 w-6" /> {t.streetTitle}
          </span>
          <span className="text-sm font-bold opacity-80">{t.streetBlurb}</span>
        </button>
        <button type="button" onClick={onMatch} className="push-btn push-btn-coral flex-col !items-start gap-1 px-6 py-4 text-left">
          <span className="font-display flex items-center gap-2 text-xl">
            <Octagon className="h-6 w-6" /> {t.matchTitle}
          </span>
          <span className="text-sm font-bold opacity-80">{t.matchBlurb}</span>
          {getBest('signs-match') > 0 && (
            <span className="chip !border-[2px] !py-1 text-sm">
              <Trophy className="h-4 w-4" /> {getBest('signs-match')}
            </span>
          )}
        </button>
      </div>

      <p className="pb-4 text-sm font-bold text-[var(--navy)]/70">387 {t.brandsCount}</p>
    </div>
  );
}
