import { useMemo, useState } from 'react';
import confetti from 'canvas-confetti';
import { ArrowRight, Flame, Home, Lightbulb, Star } from 'lucide-react';
import { BRANDS, type Brand } from './brands';
import { COUNTRIES, flagUrl, type Country } from './countries';
import { logoUrl } from './quiz';
import { sounds } from './sound';
import type { Dict, Lang } from './i18n';

interface Props {
  t: Dict;
  lang: Lang;
  onFinish: (score: number, correct: number, total: number, bestStreak: number) => void;
  onQuit: () => void;
}

type Phase = 'pick' | 'reveal';

interface FlagQuestion {
  kind: 'flag-to-brand' | 'brand-to-flag';
  country: Country;
  brand: Brand; // tačna marka
  brandOptions?: Brand[]; // za flag-to-brand
  countryOptions?: Country[]; // za brand-to-flag
}

const BRAND_MAP = new Map(BRANDS.map((b) => [b.slug, b]));
const ALL_COUNTRY_BRANDS = COUNTRIES.flatMap((c) => c.brands);

function shuffled<T>(arr: T[]): T[] {
  return [...arr].sort(() => Math.random() - 0.5);
}

function makeQuestions(count: number): FlagQuestion[] {
  const qs: FlagQuestion[] = [];
  const usedBrands = new Set<string>();
  while (qs.length < count) {
    const kind: FlagQuestion['kind'] = Math.random() < 0.5 ? 'flag-to-brand' : 'brand-to-flag';
    const country = COUNTRIES[Math.floor(Math.random() * COUNTRIES.length)];
    const brandSlug = country.brands[Math.floor(Math.random() * country.brands.length)];
    if (usedBrands.has(brandSlug)) continue;
    usedBrands.add(brandSlug);
    const brand = BRAND_MAP.get(brandSlug)!;

    if (kind === 'flag-to-brand') {
      const distractors = shuffled(ALL_COUNTRY_BRANDS.filter((s) => !country.brands.includes(s) && !usedBrands.has(s)))
        .slice(0, 3)
        .map((s) => BRAND_MAP.get(s)!);
      qs.push({ kind, country, brand, brandOptions: shuffled([brand, ...distractors]) });
    } else {
      const distractors = shuffled(COUNTRIES.filter((c) => c.code !== country.code)).slice(0, 3);
      qs.push({ kind, country, brand, countryOptions: shuffled([country, ...distractors]) });
    }
  }
  return qs;
}

export default function FlagsQuiz({ t, lang, onFinish, onQuit }: Props) {
  const [questions] = useState(() => makeQuestions(10));
  const [idx, setIdx] = useState(0);
  const [phase, setPhase] = useState<Phase>('pick');
  const [selected, setSelected] = useState<string | null>(null);
  const [score, setScore] = useState(0);
  const [streak, setStreak] = useState(0);
  const [bestStreak, setBestStreak] = useState(0);
  const [correctCount, setCorrectCount] = useState(0);
  const [hintsLeft, setHintsLeft] = useState(3);
  const [eliminated, setEliminated] = useState<string[]>([]);
  const [earned, setEarned] = useState<number | null>(null);
  const [praise, setPraise] = useState(t.praise[0]);

  const q = questions[idx];
  const total = questions.length;
  const isLast = idx === total - 1;
  const progress = useMemo(() => Math.round(((idx + (phase === 'reveal' ? 1 : 0)) / total) * 100), [idx, phase, total]);

  const correctKey = q.kind === 'flag-to-brand' ? q.brand.slug : q.country.code;

  function pick(key: string) {
    if (phase !== 'pick' || eliminated.includes(key)) return;
    const isCorrect = key === correctKey;
    setSelected(key);
    setPhase('reveal');
    if (isCorrect) {
      const pts = 100 + Math.min(streak, 10) * 10;
      setScore((s) => s + pts);
      setEarned(pts);
      setCorrectCount((c) => c + 1);
      const ns = streak + 1;
      setStreak(ns);
      setBestStreak((b) => Math.max(b, ns));
      setPraise(t.praise[Math.floor(Math.random() * t.praise.length)]);
      sounds.correct();
      confetti({
        particleCount: ns >= 4 ? 140 : 70,
        spread: 75,
        origin: { y: 0.6 },
        colors: ['#ffed9b', '#f0a208', '#974292', '#6bcb77', '#7fc2ec'],
        disableForReducedMotion: true,
      });
    } else {
      setStreak(0);
      sounds.wrong();
    }
  }

  function next() {
    if (phase !== 'reveal') return;
    sounds.click();
    if (isLast) {
      onFinish(score, correctCount, total, bestStreak);
    } else {
      setIdx((i) => i + 1);
      setPhase('pick');
      setSelected(null);
      setEliminated([]);
      setEarned(null);
    }
  }

  function useHint() {
    if (hintsLeft <= 0 || phase !== 'pick') return;
    const keys = q.kind === 'flag-to-brand' ? q.brandOptions!.map((b) => b.slug) : q.countryOptions!.map((c) => c.code);
    const wrong = keys.filter((k) => k !== correctKey && !eliminated.includes(k));
    const toRemove = wrong.sort(() => Math.random() - 0.5).slice(0, 2);
    setEliminated((e) => [...e, ...toRemove]);
    setHintsLeft((h) => h - 1);
    sounds.hint();
  }

  const revealText =
    phase === 'reveal'
      ? selected === correctKey
        ? `${praise} ${q.brand.name} — ${q.country.name[lang]}`
        : `${t.wrongWas(q.brand.name)} (${q.country.name[lang]})`
      : '';

  return (
    <div className="mx-auto flex min-h-dvh w-full max-w-2xl flex-col px-4 py-5">
      {/* Gornja traka */}
      <div className="flex items-center gap-3">
        <button type="button" onClick={onQuit} aria-label={t.backToMenu} className="push-btn h-11 w-11 shrink-0 !rounded-full">
          <Home className="h-5 w-5" />
        </button>
        <div className="h-5 flex-1 overflow-hidden rounded-full border-[3px] border-[var(--navy)] bg-white shadow-[0_3px_0_0_var(--navy)]">
          <div className="h-full rounded-full bg-[var(--leaf)] transition-all duration-300" style={{ width: `${progress}%` }} />
        </div>
        <span className="chip shrink-0 text-sm">{t.questionOf(idx + 1, total)}</span>
      </div>

      <div className="mt-3 flex items-center justify-between gap-2">
        <span className="chip relative text-base">
          <Star className="h-5 w-5 fill-[var(--gold)] text-[var(--gold)]" />
          {score}
          {earned !== null && phase === 'reveal' && (
            <span key={`${idx}-${earned}`} className="animate-score-float absolute -top-1 right-2 font-display text-lg text-[var(--leaf-deep)]">
              +{earned}
            </span>
          )}
        </span>
        <span className={`chip text-base transition-opacity ${streak >= 2 ? '' : 'opacity-50'}`}>
          <Flame className={`h-5 w-5 ${streak >= 2 ? 'fill-[var(--coral)] text-[var(--coral)]' : ''}`} />
          {t.streak} {streak}
        </span>
        <button
          type="button"
          onClick={useHint}
          disabled={hintsLeft <= 0 || phase !== 'pick'}
          className="push-btn push-btn-sun h-11 gap-2 px-4 text-base font-extrabold"
          aria-label={t.hintAria(hintsLeft)}
        >
          <Lightbulb className="h-5 w-5" />
          {t.hint} <span className="rounded-full bg-[var(--navy)] px-2 py-0.5 text-xs text-white">{hintsLeft}</span>
        </button>
      </div>

      {/* Pitanje */}
      <div key={`${idx}`} className={`sticker-card animate-pop-in mt-5 flex items-center justify-center p-8 sm:p-10 ${phase === 'reveal' && selected !== correctKey ? 'animate-shake' : ''}`}>
        {q.kind === 'flag-to-brand' ? (
          <img
            src={flagUrl(q.country.code)}
            alt={t.flagAlt}
            className="h-36 rounded-xl border-[3px] border-[var(--navy)] object-contain sm:h-44"
            draggable={false}
          />
        ) : (
          <img
            src={logoUrl(q.brand.slug)}
            alt={q.brand.name}
            className="h-36 w-full max-w-md object-contain sm:h-44"
            draggable={false}
          />
        )}
      </div>

      <p className="mt-4 text-center text-lg font-extrabold text-[var(--navy)]">
        {q.kind === 'flag-to-brand' ? t.flagToBrand : t.brandToFlag}
      </p>

      {/* Odgovori */}
      <div className="mt-3 grid grid-cols-2 gap-3">
        {q.kind === 'flag-to-brand'
          ? q.brandOptions!.map((b) => {
              const isCorrectOpt = b.slug === correctKey;
              const isSelected = b.slug === selected;
              const isGone = eliminated.includes(b.slug);
              let cls = '';
              if (phase === 'reveal') {
                if (isCorrectOpt) cls = 'push-btn-leaf !opacity-100';
                else if (isSelected) cls = 'bg-[var(--berry)] !opacity-100';
                else cls = 'opacity-50';
              } else if (isGone) cls = 'opacity-30';
              return (
                <button
                  key={b.slug}
                  type="button"
                  disabled={phase !== 'pick' || isGone}
                  onClick={() => pick(b.slug)}
                  className={`push-btn ${cls} min-h-[92px] flex-col gap-1 px-3 py-3`}
                >
                  <img src={logoUrl(b.slug)} alt="" className="h-12 max-w-full object-contain" draggable={false} />
                  <span className="font-display text-sm leading-tight sm:text-base">{b.name}</span>
                </button>
              );
            })
          : q.countryOptions!.map((c) => {
              const isCorrectOpt = c.code === correctKey;
              const isSelected = c.code === selected;
              const isGone = eliminated.includes(c.code);
              let cls = '';
              if (phase === 'reveal') {
                if (isCorrectOpt) cls = 'push-btn-leaf !opacity-100';
                else if (isSelected) cls = 'bg-[var(--berry)] !opacity-100';
                else cls = 'opacity-50';
              } else if (isGone) cls = 'opacity-30';
              return (
                <button
                  key={c.code}
                  type="button"
                  disabled={phase !== 'pick' || isGone}
                  onClick={() => pick(c.code)}
                  className={`push-btn ${cls} min-h-[92px] flex-col gap-1 px-3 py-3`}
                >
                  <img src={flagUrl(c.code)} alt="" className="h-9 rounded border-2 border-[var(--navy)]/20 object-contain" draggable={false} />
                  <span className="font-display text-sm leading-tight sm:text-base">{c.name[lang]}</span>
                </button>
              );
            })}
      </div>

      {/* Povratna informacija + Dalje */}
      <div className="mt-5 flex min-h-[92px] flex-col items-center justify-center">
        {phase === 'reveal' && (
          <div className="animate-bounce-in flex w-full flex-col items-center gap-3">
            <p className="text-center font-display text-2xl text-white drop-shadow-[0_3px_0_var(--navy)]">{revealText}</p>
            <button type="button" onClick={next} className="push-btn push-btn-grape px-8 py-3 text-xl">
              {isLast ? t.seeResult : t.next}
              <ArrowRight className="h-6 w-6" />
            </button>
          </div>
        )}
      </div>
    </div>
  );
}
