// Mali WebAudio sintisajzer — zvukovi igre bez eksternih fajlova.

let ctx: AudioContext | null = null;
let muted = false;

export function setMuted(value: boolean) {
  muted = value;
}
export function isMuted() {
  return muted;
}

function getCtx(): AudioContext | null {
  if (muted) return null;
  if (!ctx) {
    const AC = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
    if (!AC) return null;
    ctx = new AC();
  }
  if (ctx.state === 'suspended') void ctx.resume();
  return ctx;
}

function tone(
  freqStart: number,
  freqEnd: number,
  duration: number,
  type: OscillatorType,
  volume: number,
  delay = 0,
) {
  const ac = getCtx();
  if (!ac) return;
  const t0 = ac.currentTime + delay;
  const osc = ac.createOscillator();
  const gain = ac.createGain();
  osc.type = type;
  osc.frequency.setValueAtTime(freqStart, t0);
  osc.frequency.exponentialRampToValueAtTime(Math.max(freqEnd, 1), t0 + duration);
  gain.gain.setValueAtTime(0.0001, t0);
  gain.gain.exponentialRampToValueAtTime(volume, t0 + 0.015);
  gain.gain.exponentialRampToValueAtTime(0.0001, t0 + duration);
  osc.connect(gain).connect(ac.destination);
  osc.start(t0);
  osc.stop(t0 + duration + 0.05);
}

export const sounds = {
  click() {
    tone(700, 500, 0.07, 'square', 0.08);
  },
  correct() {
    tone(523, 523, 0.12, 'triangle', 0.22);
    tone(659, 659, 0.12, 'triangle', 0.22, 0.09);
    tone(784, 988, 0.22, 'triangle', 0.24, 0.18);
  },
  wrong() {
    tone(220, 130, 0.28, 'sawtooth', 0.14);
    tone(160, 100, 0.3, 'sawtooth', 0.1, 0.06);
  },
  hint() {
    tone(880, 1320, 0.12, 'sine', 0.16);
    tone(1320, 1760, 0.14, 'sine', 0.14, 0.1);
  },
  fanfare() {
    const seq = [523, 659, 784, 1047];
    seq.forEach((f, i) => tone(f, f, 0.16, 'triangle', 0.22, i * 0.12));
    tone(1047, 1568, 0.4, 'triangle', 0.2, seq.length * 0.12);
  },
};
