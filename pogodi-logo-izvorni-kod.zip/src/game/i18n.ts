export type Lang = 'lat' | 'cyr';

const LANG_KEY = 'pogodi-logo-lang';

export function getLang(): Lang {
  try {
    return localStorage.getItem(LANG_KEY) === 'cyr' ? 'cyr' : 'lat';
  } catch {
    return 'lat';
  }
}

export function saveLang(lang: Lang) {
  try {
    localStorage.setItem(LANG_KEY, lang);
  } catch {
    /* ignore */
  }
}

const lat = {
  title: 'Pogodi Logo',
  titleBig: 'POGODI LOGO',
  subtitle: 'Auto kviz za male vozače — prepoznaj marku po znaku!',
  sectionCars: 'Marke automobila',
  sectionSigns: 'Saobraćajni znakovi',
  sectionFlags: 'Zastave sveta',
  tierEasy: 'Lako',
  tierEasyBlurb: 'Poznate marke koje viđaš na ulici',
  tierMid: 'Srednje',
  tierMidBlurb: 'Za male zaljubljenike u automobile',
  tierHard: 'Teško',
  tierHardBlurb: 'Pravi izazov — sve marke sveta!',
  learn: 'Uči logoe',
  brandsCount: 'marki automobila · za uzrast 7–10 godina',
  soundOn: 'Isključi zvuk',
  soundOff: 'Uključi zvuk',
  backToMenu: 'Nazad na meni',
  back: 'Nazad',
  questionOf: (i: number, t: number) => `${i} / ${t}`,
  streak: 'serija',
  hint: '50:50',
  hintAria: (n: number) => `Pomoć pola-pola, preostalo ${n}`,
  whoseLogo: 'Čiji je ovo logo?',
  next: 'Dalje',
  seeResult: 'Vidi rezultat',
  correctPraise: (brand: string) => `To je ${brand}!`,
  wrongWas: (brand: string) => `Netačno! To je bio ${brand}.`,
  level: 'Nivo',
  result: 'Rezultat',
  points: 'poena',
  newRecord: 'Novi rekord!',
  correctOf: (c: number, t: number) => `${c} / ${t} tačnih`,
  msg3: 'Neverovatno! Pravi si auto-šampion!',
  msg2: 'Odličan rezultat! Još malo do vrha!',
  msg1: 'Dobro je! Vežbaj pa ponovo!',
  msg0: 'Nema veze — svaki šampion je nekada počinjao!',
  playAgain: 'Igraj ponovo',
  mainMenu: 'Glavni meni',
  learnTitle: 'Uči logoe',
  allBrands: 'Sve marke',
  shown: (n: number) => `Prikazano: ${n} marki`,
  searchPlaceholder: 'Traži marku…',
  searchAria: 'Pretraga marke',
  noResults: 'Nema te marke — probaj neko drugo slovo!',
  starsAria: (s: number) => `Osvojene zvezdice: ${s} od 3`,
  praise: ['Bravo!', 'Odlično!', 'Tako je!', 'Super si!', 'Fantastično!', 'Ti si šampion!'],
  // Zastave
  flagsTitle: 'Zastave i marke',
  flagsBlurb: 'Pogodi iz koje zemlje je marka',
  flagToBrand: 'Koja marka se pravi u ovoj zemlji?',
  brandToFlag: 'Iz koje zemlje je ova marka?',
  flagAlt: 'Zastava zemlje',
  // Znakovi
  streetTitle: 'Raskrsnica',
  streetBlurb: 'Istraži ulicu i dodirni znakove',
  streetHint: 'Dodirni znak da saznaš šta znači!',
  learned: (n: number, t: number) => `Naučeno: ${n} / ${t} znakova`,
  iUnderstand: 'Zapamtio sam!',
  matchTitle: 'Poveži znake',
  matchBlurb: 'Spoj znak sa njegovim značenjem',
  matchHow: 'Dodirni znak, pa onda njegovo značenje.',
  matchDone: 'Spojio si sve znakove!',
  mistakes: (n: number) => `Promašaji: ${n}`,
  newSigns: 'Nova runda',
};

const cyr: typeof lat = {
  title: 'Погоди Лого',
  titleBig: 'ПОГОДИ ЛОГО',
  subtitle: 'Ауто квиз за мале возаче — препознај марку по знаку!',
  sectionCars: 'Марке аутомобила',
  sectionSigns: 'Саобраћајни знакови',
  sectionFlags: 'Заставе света',
  tierEasy: 'Лако',
  tierEasyBlurb: 'Познате марке које виђаш на улици',
  tierMid: 'Средње',
  tierMidBlurb: 'За мале заљубљенике у аутомобиле',
  tierHard: 'Тешко',
  tierHardBlurb: 'Прави изазов — све марке света!',
  learn: 'Учи логое',
  brandsCount: 'марки аутомобила · за узраст 7–10 година',
  soundOn: 'Искључи звук',
  soundOff: 'Укључи звук',
  backToMenu: 'Назад на мени',
  back: 'Назад',
  questionOf: (i: number, t: number) => `${i} / ${t}`,
  streak: 'серија',
  hint: '50:50',
  hintAria: (n: number) => `Помоћ пола-пола, преостало ${n}`,
  whoseLogo: 'Чији је ово лого?',
  next: 'Даље',
  seeResult: 'Види резултат',
  correctPraise: (brand: string) => `То је ${brand}!`,
  wrongWas: (brand: string) => `Нетачно! То је био ${brand}.`,
  level: 'Ниво',
  result: 'Резултат',
  points: 'поена',
  newRecord: 'Нови рекорд!',
  correctOf: (c: number, t: number) => `${c} / ${t} тачних`,
  msg3: 'Невероватно! Прави си ауто-шампион!',
  msg2: 'Одличан резултат! Још мало до врха!',
  msg1: 'Добро је! Вежбај па поново!',
  msg0: 'Нема везе — сваки шампион је некада почињао!',
  playAgain: 'Играј поново',
  mainMenu: 'Главни мени',
  learnTitle: 'Учи логое',
  allBrands: 'Све марке',
  shown: (n: number) => `Приказано: ${n} марки`,
  searchPlaceholder: 'Тражи марку…',
  searchAria: 'Претрага марке',
  noResults: 'Нема те марке — пробај неко друго слово!',
  starsAria: (s: number) => `Освојене звездице: ${s} од 3`,
  praise: ['Браво!', 'Одлично!', 'Тако је!', 'Супер си!', 'Фантастично!', 'Ти си шампион!'],
  flagsTitle: 'Заставе и марке',
  flagsBlurb: 'Погоди из које земље је марка',
  flagToBrand: 'Која марка се прави у овој земљи?',
  brandToFlag: 'Из које земље је ова марка?',
  flagAlt: 'Застава земље',
  streetTitle: 'Раскрсница',
  streetBlurb: 'Истражи улицу и додирни знакове',
  streetHint: 'Додирни знак да сазнаш шта значи!',
  learned: (n: number, t: number) => `Научено: ${n} / ${t} знакова`,
  iUnderstand: 'Запамтио сам!',
  matchTitle: 'Повежи знаке',
  matchBlurb: 'Спој знак са његовим значењем',
  matchHow: 'Додирни знак, па онда његово значење.',
  matchDone: 'Спојио си све знакове!',
  mistakes: (n: number) => `Промашаји: ${n}`,
  newSigns: 'Нова рунда',
};

export type Dict = typeof lat;
export const STR: Record<Lang, Dict> = { lat, cyr };

export const TIER_LABEL: Record<Lang, Record<1 | 2 | 3, string>> = {
  lat: { 1: 'Lako', 2: 'Srednje', 3: 'Teško' },
  cyr: { 1: 'Лако', 2: 'Средње', 3: 'Тешко' },
};
