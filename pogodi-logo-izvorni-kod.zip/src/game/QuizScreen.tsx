import { useMemo, useState } from 'react';
import confetti from 'canvas-confetti';
import { ArrowRight, Flame, Home, Lightbulb, Star } from 'lucide-react';
import { generateQuestions, logoUrl, type Tier } from './quiz';
import { sounds } from './sound';
import type { Dict } from './i18n';

interface Props {
  t: Dict;
  tier: Tier;
  onFinish: (score: number, correct: number, total: number, bestStreak: number) => void;
  onQuit: () => void;
}

type Phase = 'pick' | 'reveal';

export default function QuizScreen({ t, tier, onFinish, onQuit }: Props) {
  const [questions] = useState(() => generateQuestions(tier, 10));
  const [idx, setIdx] = useState(0);
  const [phase, setPhase] = useState<Phase>('pick');
  const [selected, setSelected] = useState<string | null>(null);
  const [score, setScore] = useState(0);
  const [streak, setStreak] = useState(0);
  const [bestStreak, setBestStreak] = useState(0);
  const [correctCount, setCorrectCount] = useState(0);
  const [hintsLeft, setHintsLeft] = useState(3);
  const [eliminated, setEliminated] = useState<string[]>([]);
  const [earned, setEarned] = useState<number | null>(null);
  const [praise, setPraise] = useState(t.praise[0]);

  const q = questions[idx];
  const total = questions.length;
  const isLast = idx === total - 1;

  const progress = useMemo(() => Math.round(((idx + (phase === 'reveal' ? 1 : 0)) / total) * 100), [idx, phase, total]);

  function pick(slug: string) {
    if (phase !== 'pick' || eliminated.includes(slug)) return;
    const isCorrect = slug === q.brand.slug;
    setSelected(slug);
    setPhase('reveal');
    if (isCorrect) {
      const bonus = Math.min(streak, 10) * 10;
      const pts = 100 + bonus;
      setScore((s) => s + pts);
      setEarned(pts);
      setCorrectCount((c) => c + 1);
      const newStreak = streak + 1;
      setStreak(newStreak);
      setBestStreak((b) => Math.max(b, newStreak));
      setPraise(t.praise[Math.floor(Math.random() * t.praise.length)]);
      sounds.correct();
      confetti({
        particleCount: newStreak >= 4 ? 140 : 70,
        spread: 75,
        origin: { y: 0.6 },
        colors: ['#ffed9b', '#f0a208', '#974292', '#6bcb77', '#7fc2ec'],
        disableForReducedMotion: true,
      });
    } else {
      setStreak(0);
      sounds.wrong();
    }
  }

  function next() {
    if (phase !== 'reveal') return;
    sounds.click();
    if (isLast) {
      onFinish(score, correctCount, total, bestStreak);
    } else {
      setIdx((i) => i + 1);
      setPhase('pick');
      setSelected(null);
      setEliminated([]);
      setEarned(null);
    }
  }

  function useHint() {
    if (hintsLeft <= 0 || phase !== 'pick') return;
    const wrong = q.options.filter((o) => o.slug !== q.brand.slug && !eliminated.includes(o.slug));
    const toRemove = wrong.sort(() => Math.random() - 0.5).slice(0, 2).map((o) => o.slug);
    setEliminated((e) => [...e, ...toRemove]);
    setHintsLeft((h) => h - 1);
    sounds.hint();
  }

  return (
    <div className="mx-auto flex min-h-dvh w-full max-w-2xl flex-col px-4 py-5">
      {/* Gornja traka */}
      <div className="flex items-center gap-3">
        <button type="button" onClick={onQuit} aria-label={t.backToMenu} className="push-btn h-11 w-11 shrink-0 !rounded-full">
          <Home className="h-5 w-5" />
        </button>
        <div className="h-5 flex-1 overflow-hidden rounded-full border-[3px] border-[var(--navy)] bg-white shadow-[0_3px_0_0_var(--navy)]">
          <div
            className="h-full rounded-full bg-[var(--leaf)] transition-all duration-300"
            style={{ width: `${progress}%` }}
          />
        </div>
        <span className="chip shrink-0 text-sm">{t.questionOf(idx + 1, total)}</span>
      </div>

      <div className="mt-3 flex items-center justify-between gap-2">
        <span className="chip relative text-base">
          <Star className="h-5 w-5 fill-[var(--gold)] text-[var(--gold)]" />
          {score}
          {earned !== null && phase === 'reveal' && (
            <span
              key={`${idx}-${earned}`}
              className="animate-score-float absolute -top-1 right-2 font-display text-lg text-[var(--leaf-deep)]"
            >
              +{earned}
            </span>
          )}
        </span>
        <span className={`chip text-base transition-opacity ${streak >= 2 ? '' : 'opacity-50'}`}>
          <Flame className={`h-5 w-5 ${streak >= 2 ? 'fill-[var(--coral)] text-[var(--coral)]' : ''}`} />
          {t.streak} {streak}
        </span>
        <button
          type="button"
          onClick={useHint}
          disabled={hintsLeft <= 0 || phase !== 'pick'}
          className="push-btn push-btn-sun h-11 gap-2 px-4 text-base font-extrabold"
          aria-label={t.hintAria(hintsLeft)}
        >
          <Lightbulb className="h-5 w-5" />
          {t.hint} <span className="rounded-full bg-[var(--navy)] px-2 py-0.5 text-xs text-white">{hintsLeft}</span>
        </button>
      </div>

      {/* Kartica sa logoom */}
      <div
        key={q.brand.slug}
        className={`sticker-card animate-pop-in mt-5 flex items-center justify-center p-8 sm:p-12 ${phase === 'reveal' && selected !== q.brand.slug ? 'animate-shake' : ''}`}
      >
        <img
          src={logoUrl(q.brand.slug)}
          alt="Logo automobilske marke"
          className="h-40 w-full max-w-md object-contain sm:h-52"
          draggable={false}
        />
      </div>

      <p className="mt-4 text-center text-lg font-extrabold text-[var(--navy)]">{t.whoseLogo}</p>

      {/* Odgovori */}
      <div className="mt-3 grid grid-cols-1 gap-3 sm:grid-cols-2">
        {q.options.map((opt) => {
          const isCorrectOpt = opt.slug === q.brand.slug;
          const isSelected = opt.slug === selected;
          const isGone = eliminated.includes(opt.slug);
          let cls = 'bg-white';
          if (phase === 'reveal') {
            if (isCorrectOpt) cls = 'push-btn-leaf !opacity-100';
            else if (isSelected) cls = 'bg-[var(--berry)] text-white !opacity-100';
            else cls = 'bg-white opacity-50';
          } else if (isGone) {
            cls = 'bg-white opacity-30 line-through';
          }
          return (
            <button
              key={opt.slug}
              type="button"
              disabled={phase !== 'pick' || isGone}
              onClick={() => pick(opt.slug)}
              className={`push-btn ${cls} min-h-[64px] px-4 py-3 font-display text-lg leading-snug sm:text-xl`}
            >
              {opt.name}
            </button>
          );
        })}
      </div>

      {/* Povratna informacija + Dalje */}
      <div className="mt-5 flex min-h-[92px] flex-col items-center justify-center">
        {phase === 'reveal' && (
          <div className="animate-bounce-in flex w-full flex-col items-center gap-3">
            <p className="text-center font-display text-2xl text-white drop-shadow-[0_3px_0_var(--navy)]">
              {selected === q.brand.slug ? `${praise} ${t.correctPraise(q.brand.name)}` : t.wrongWas(q.brand.name)}
            </p>
            <button type="button" onClick={next} className="push-btn push-btn-grape px-8 py-3 text-xl">
              {isLast ? t.seeResult : t.next}
              <ArrowRight className="h-6 w-6" />
            </button>
          </div>
        )}
      </div>
    </div>
  );
}
