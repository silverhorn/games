import { useEffect, useRef, useState } from 'react';
import confetti from 'canvas-confetti';
import { Flame, Home, Medal, RotateCcw, Star, Trophy } from 'lucide-react';
import { setBest } from './quiz';
import { sounds } from './sound';
import type { Dict } from './i18n';

interface Props {
  t: Dict;
  levelLabel: string;
  bestKey: string | number;
  score: number;
  correct: number;
  total: number;
  bestStreak: number;
  onReplay: () => void;
  onMenu: () => void;
}

export default function ResultScreen({ t, levelLabel, bestKey, score, correct, total, bestStreak, onReplay, onMenu }: Props) {
  const pct = correct / total;
  const stars = pct >= 0.9 ? 3 : pct >= 0.6 ? 2 : pct >= 0.3 ? 1 : 0;
  const [isRecord] = useState(() => setBest(bestKey, score));
  const fired = useRef(false);

  useEffect(() => {
    if (fired.current) return;
    fired.current = true;
    if (correct > 0) {
      sounds.fanfare();
      confetti({
        particleCount: 180,
        spread: 100,
        origin: { y: 0.4 },
        colors: ['#ffed9b', '#f0a208', '#974292', '#6bcb77', '#7fc2ec', '#f2979b'],
        disableForReducedMotion: true,
      });
    }
  }, [correct]);

  const message = stars === 3 ? t.msg3 : stars === 2 ? t.msg2 : stars === 1 ? t.msg1 : t.msg0;

  return (
    <div className="mx-auto flex min-h-dvh w-full max-w-xl flex-col items-center justify-center px-4 py-8">
      <div className="sticker-card animate-pop-in w-full p-8 text-center">
        <div className="animate-wiggle mx-auto -mt-20 mb-4 flex h-24 w-24 items-center justify-center rounded-full border-[3px] border-[var(--navy)] bg-[var(--sun)] shadow-[0_6px_0_0_var(--navy)]">
          <Trophy className="h-12 w-12" />
        </div>

        <p className="text-sm font-extrabold uppercase tracking-widest text-[var(--grape)]">
          {t.level}: {levelLabel}
        </p>
        <h2 className="font-display mt-1 text-3xl sm:text-4xl">{t.result}</h2>

        {/* Zvezdice */}
        <div className="mt-4 flex items-center justify-center gap-2" aria-label={t.starsAria(stars)}>
          {[0, 1, 2].map((i) => (
            <Star
              key={i}
              className={`animate-star-pop h-12 w-12 ${i < stars ? 'fill-[var(--gold)] text-[var(--gold)]' : 'fill-black/10 text-black/20'}`}
              style={{ animationDelay: `${300 + i * 250}ms` }}
            />
          ))}
        </div>

        <p className="font-display mt-4 text-6xl text-[var(--grape-deep)]">{score}</p>
        <p className="mt-1 text-lg font-extrabold">{t.points}</p>

        {isRecord && score > 0 && (
          <p className="animate-bounce-in chip mx-auto mt-3 w-fit bg-[var(--sun)]">
            <Medal className="h-5 w-5" /> {t.newRecord}
          </p>
        )}

        <div className="mx-auto mt-5 grid max-w-xs grid-cols-2 gap-3 text-left">
          <div className="chip w-full justify-center">{t.correctOf(correct, total)}</div>
          <div className="chip w-full justify-center">
            <Flame className="h-4 w-4 fill-[var(--coral)] text-[var(--coral)]" /> {t.streak} {bestStreak}
          </div>
        </div>

        <p className="mt-5 text-lg font-bold">{message}</p>

        <div className="mt-6 flex flex-col items-center justify-center gap-3 sm:flex-row">
          <button type="button" onClick={onReplay} className="push-btn push-btn-sun w-full px-6 py-3 text-lg sm:w-auto">
            <RotateCcw className="h-5 w-5" /> {t.playAgain}
          </button>
          <button type="button" onClick={onMenu} className="push-btn w-full px-6 py-3 text-lg sm:w-auto">
            <Home className="h-5 w-5" /> {t.mainMenu}
          </button>
        </div>
      </div>
    </div>
  );
}
