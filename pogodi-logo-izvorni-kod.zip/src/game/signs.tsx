import type { ReactNode } from 'react';
import type { Lang } from './i18n';

export interface Sign {
  id: string;
  name: Record<Lang, string>;
  meaning: Record<Lang, string>;
  art: ReactNode;
}

// Pomoćni oblici
const warnTri = (children: ReactNode) => (
  <>
    <polygon points="50,8 96,88 4,88" fill="#fff" stroke="#d93425" strokeWidth="13" strokeLinejoin="round" />
    {children}
  </>
);
const prohibCircle = (children: ReactNode, fill = '#fff') => (
  <>
    <circle cx="50" cy="50" r="45" fill={fill} stroke="#d93425" strokeWidth="10" />
    {children}
  </>
);
const mandCircle = (children: ReactNode) => (
  <>
    <circle cx="50" cy="50" r="46" fill="#1a5fc1" stroke="#fff" strokeWidth="4" />
    {children}
  </>
);

export const SIGNS: Sign[] = [
  {
    id: 'stop',
    name: { lat: 'Stop', cyr: 'Стоп' },
    meaning: { lat: 'Stani! Obavezno zaustavi vozilo.', cyr: 'Стани! Обавезно заустави возило.' },
    art: (
      <>
        <polygon points="50,4 82,18 96,50 82,82 50,96 18,82 4,50 18,18" fill="#d93425" stroke="#fff" strokeWidth="5" strokeLinejoin="round" />
        <text x="50" y="62" textAnchor="middle" fontSize="26" fontWeight="900" fill="#fff" fontFamily="sans-serif">STOP</text>
      </>
    ),
  },
  {
    id: 'no-entry',
    name: { lat: 'Zabrana ulaska', cyr: 'Забрана уласка' },
    meaning: { lat: 'Ovuda se ne sme ući.', cyr: 'Овуда се не сме ући.' },
    art: prohibCircle(<rect x="22" y="41" width="56" height="18" rx="4" fill="#fff" />, '#d93425'),
  },
  {
    id: 'speed-50',
    name: { lat: 'Ograničenje brzine', cyr: 'Ограничење брзине' },
    meaning: { lat: 'Ne vozi brže od 50 na čas.', cyr: 'Не вози брже од 50 на час.' },
    art: prohibCircle(
      <text x="50" y="68" textAnchor="middle" fontSize="42" fontWeight="900" fill="#111" fontFamily="sans-serif">50</text>,
    ),
  },
  {
    id: 'no-parking',
    name: { lat: 'Zabrana parkiranja', cyr: 'Забрана паркирања' },
    meaning: { lat: 'Ovde se ne sme parkirati.', cyr: 'Овде се не сме паркирати.' },
    art: prohibCircle(
      <line x1="24" y1="76" x2="76" y2="24" stroke="#d93425" strokeWidth="9" />,
      '#1a5fc1',
    ),
  },
  {
    id: 'no-stopping',
    name: { lat: 'Zabrana zaustavljanja', cyr: 'Забрана заустављања' },
    meaning: { lat: 'Ovde se ne smeš ni zaustaviti.', cyr: 'Овде се не смеш ни зауставити.' },
    art: prohibCircle(
      <>
        <line x1="26" y1="26" x2="74" y2="74" stroke="#d93425" strokeWidth="9" />
        <line x1="74" y1="26" x2="26" y2="74" stroke="#d93425" strokeWidth="9" />
      </>,
      '#1a5fc1',
    ),
  },
  {
    id: 'priority',
    name: { lat: 'Prvenstvo prolaza', cyr: 'Првенство пролаза' },
    meaning: { lat: 'Ti imaš prednost na ovom putu.', cyr: 'Ти имаш предност на овом путу.' },
    art: (
      <>
        <polygon points="50,4 96,50 50,96 4,50" fill="#f7c948" stroke="#fff" strokeWidth="6" strokeLinejoin="round" />
        <polygon points="50,4 96,50 50,96 4,50" fill="none" stroke="#111" strokeWidth="2" strokeLinejoin="round" opacity="0.25" />
      </>
    ),
  },
  {
    id: 'mandatory-right',
    name: { lat: 'Obavezni smer desno', cyr: 'Обавезни смер десно' },
    meaning: { lat: 'Moraš skrenuti udesno.', cyr: 'Мораш скренути удесно.' },
    art: mandCircle(
      <path d="M28 50 h30 M46 34 l20 16 -20 16" fill="none" stroke="#fff" strokeWidth="10" strokeLinecap="round" strokeLinejoin="round" />,
    ),
  },
  {
    id: 'roundabout',
    name: { lat: 'Kružni tok', cyr: 'Кружни ток' },
    meaning: { lat: 'Vozila voze u krug oko ostrva.', cyr: 'Возила возе у круг око острва.' },
    art: mandCircle(
      <>
        <circle cx="50" cy="50" r="20" fill="none" stroke="#fff" strokeWidth="8" strokeDasharray="31 11" />
        <polygon points="50,22 42,36 58,36" fill="#fff" />
        <polygon points="26,62 41,60 33,72" fill="#fff" />
        <polygon points="74,62 67,72 59,60" fill="#fff" />
      </>,
    ),
  },
  {
    id: 'one-way',
    name: { lat: 'Jednosmerna ulica', cyr: 'Једносмерна улица' },
    meaning: { lat: 'Sva vozila idu istim smerom.', cyr: 'Сва возила иду истим смером.' },
    art: (
      <>
        <rect x="16" y="10" width="68" height="80" rx="8" fill="#1a5fc1" />
        <path d="M50 74 V32 M36 46 L50 28 L64 46" fill="none" stroke="#fff" strokeWidth="10" strokeLinecap="round" strokeLinejoin="round" />
      </>
    ),
  },
  {
    id: 'curve',
    name: { lat: 'Oštra krivina', cyr: 'Оштра кривина' },
    meaning: { lat: 'Uspori — dolazi oštra krivina.', cyr: 'Успори — долази оштра кривина.' },
    art: warnTri(
      <path d="M42 78 V58 Q42 46 54 46 H66 M58 38 l12 8 -12 8" fill="none" stroke="#111" strokeWidth="8" strokeLinecap="round" strokeLinejoin="round" />,
    ),
  },
  {
    id: 'lights',
    name: { lat: 'Semafor', cyr: 'Семафор' },
    meaning: { lat: 'Ispred su saobraćajna svetla.', cyr: 'Испред су саобраћајна светла.' },
    art: warnTri(
      <>
        <rect x="40" y="36" width="20" height="46" rx="6" fill="#111" />
        <circle cx="50" cy="46" r="5" fill="#e23b3b" />
        <circle cx="50" cy="59" r="5" fill="#f7c948" />
        <circle cx="50" cy="72" r="5" fill="#3fa34d" />
      </>,
    ),
  },
  {
    id: 'danger',
    name: { lat: 'Opasnost na putu', cyr: 'Опасност на путу' },
    meaning: { lat: 'Opasno mesto — budi pažljiv.', cyr: 'Опасно место — буди пажљив.' },
    art: warnTri(
      <>
        <rect x="45" y="38" width="10" height="26" rx="5" fill="#111" />
        <circle cx="50" cy="74" r="6" fill="#111" />
      </>,
    ),
  },
  {
    id: 'pedestrian',
    name: { lat: 'Pešački prelaz', cyr: 'Пешачки прелаз' },
    meaning: { lat: 'Ovde pešaci prelaze ulicu.', cyr: 'Овде пешаци прелазе улицу.' },
    art: warnTri(
      <>
        <circle cx="52" cy="44" r="5" fill="#111" />
        <path d="M52 50 L46 62 L38 78 M52 50 L58 62 L64 78 M46 56 L62 54 M52 50 L52 58" fill="none" stroke="#111" strokeWidth="6" strokeLinecap="round" strokeLinejoin="round" />
      </>,
    ),
  },
  {
    id: 'children',
    name: { lat: 'Deca na putu', cyr: 'Деца на путу' },
    meaning: { lat: 'Pazi — ovde se igraju i kreću deca.', cyr: 'Пази — овде се играју и крећу деца.' },
    art: warnTri(
      <>
        <circle cx="40" cy="46" r="5" fill="#111" />
        <path d="M40 52 L36 64 L30 78 M40 52 L45 64 L50 78 M36 58 L48 56" fill="none" stroke="#111" strokeWidth="5" strokeLinecap="round" />
        <circle cx="62" cy="42" r="6" fill="#111" />
        <path d="M62 48 L56 62 L50 76 M62 48 L68 60 L72 74 M56 54 L70 52" fill="none" stroke="#111" strokeWidth="6" strokeLinecap="round" />
      </>,
    ),
  },
  {
    id: 'roadwork',
    name: { lat: 'Radovi na putu', cyr: 'Радови на путу' },
    meaning: { lat: 'Radi se na putu — uspori.', cyr: 'Ради се на путу — успори.' },
    art: warnTri(
      <>
        <path d="M22 78 h56 l-10 -12 h-36 z" fill="#111" />
        <circle cx="44" cy="40" r="5" fill="#111" />
        <path d="M44 46 L40 62 M44 46 L52 58 M40 62 L34 74 M44 50 L58 44" fill="none" stroke="#111" strokeWidth="5" strokeLinecap="round" />
        <line x1="58" y1="44" x2="68" y2="70" stroke="#111" strokeWidth="5" strokeLinecap="round" />
      </>,
    ),
  },
  {
    id: 'railway',
    name: { lat: 'Železnički prelaz', cyr: 'Железнички прелаз' },
    meaning: { lat: 'Pazi na voz!', cyr: 'Пази на воз!' },
    art: warnTri(
      <>
        <rect x="34" y="42" width="32" height="24" rx="4" fill="#111" />
        <rect x="40" y="47" width="20" height="8" rx="2" fill="#fff" />
        <circle cx="42" cy="62" r="3" fill="#fff" />
        <circle cx="58" cy="62" r="3" fill="#fff" />
        <path d="M36 70 l-6 10 M64 70 l6 10 M32 74 h36" stroke="#111" strokeWidth="4" strokeLinecap="round" fill="none" />
      </>,
    ),
  },
  {
    id: 'bicycle',
    name: { lat: 'Biciklisti', cyr: 'Бициклисти' },
    meaning: { lat: 'Pazi na bicikliste.', cyr: 'Пази на бициклисте.' },
    art: warnTri(
      <>
        <circle cx="34" cy="68" r="9" fill="none" stroke="#111" strokeWidth="4" />
        <circle cx="66" cy="68" r="9" fill="none" stroke="#111" strokeWidth="4" />
        <path d="M34 68 L46 50 L62 50 M46 50 L52 68 L34 68 M62 50 L66 68 M42 44 h10" fill="none" stroke="#111" strokeWidth="4" strokeLinecap="round" strokeLinejoin="round" />
      </>,
    ),
  },
  {
    id: 'slippery',
    name: { lat: 'Klizav kolovoz', cyr: 'Клизав коловоз' },
    meaning: { lat: 'Kolovoz je klizav — uspori.', cyr: 'Коловоз је клизав — успори.' },
    art: warnTri(
      <>
        <rect x="34" y="42" width="32" height="14" rx="6" fill="#111" />
        <circle cx="42" cy="58" r="5" fill="#111" />
        <circle cx="58" cy="58" r="5" fill="#111" />
        <path d="M38 68 q6 4 0 10 M62 68 q-6 4 0 10 M50 68 q6 6 0 12" fill="none" stroke="#111" strokeWidth="4" strokeLinecap="round" />
      </>,
    ),
  },
];

export function SignArt({ sign, size = 100 }: { sign: Sign; size?: number }) {
  return (
    <svg viewBox="0 0 100 100" width={size} height={size} role="img" aria-label={sign.id}>
      {sign.art}
    </svg>
  );
}
