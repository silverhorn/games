import { useMemo, useState } from 'react';
import { ArrowLeft, Check, Lightbulb, Shuffle } from 'lucide-react';
import { SIGNS, SignArt, type Sign } from './signs';
import { sounds } from './sound';
import type { Dict } from './i18n';
import type { Lang } from './i18n';

interface Props {
  t: Dict;
  lang: Lang;
  onBack: () => void;
}

// Pozicije stubića na sceni (x, y = vrh znaka u viewBox 800x460)
const SPOTS: [number, number][] = [
  [120, 190], [300, 190], [600, 190], [730, 200],
  [150, 350], [310, 350], [590, 350],
  [360, 60], [560, 60], [700, 320],
];

export default function SignsExplore({ t, lang, onBack }: Props) {
  const [round, setRound] = useState(0);
  const sceneSigns = useMemo(() => {
    const s = [...SIGNS].sort(() => Math.random() - 0.5);
    return s.slice(0, SPOTS.length);
  }, [round]);
  const [learned, setLearned] = useState<Set<string>>(new Set());
  const [open, setOpen] = useState<Sign | null>(null);

  function openSign(sign: Sign) {
    sounds.click();
    setOpen(sign);
    setLearned((prev) => new Set(prev).add(sign.id));
  }

  return (
    <div className="mx-auto flex min-h-dvh w-full max-w-4xl flex-col px-4 py-5">
      <div className="flex flex-wrap items-center gap-3">
        <button
          type="button"
          onClick={() => { sounds.click(); onBack(); }}
          className="push-btn h-11 gap-2 px-4 font-extrabold"
        >
          <ArrowLeft className="h-5 w-5" /> {t.back}
        </button>
        <h1 className="font-display text-2xl text-white drop-shadow-[0_3px_0_var(--navy)] sm:text-3xl">{t.streetTitle}</h1>
        <span className="chip ml-auto">{t.learned(learned.size, SIGNS.length)}</span>
      </div>

      <p className="mt-3 flex items-center gap-2 text-base font-extrabold text-[var(--navy)]">
        <Lightbulb className="h-5 w-5 shrink-0" /> {t.streetHint}
      </p>

      {/* Scena raskrsnice */}
      <div className="sticker-card animate-pop-in mt-4 overflow-hidden !rounded-[1.6rem]">
        <svg viewBox="0 0 800 460" className="block w-full" role="img" aria-label={t.streetTitle}>
          {/* Nebo i trava */}
          <rect width="800" height="460" fill="#a8ddf0" />
          <rect y="300" width="800" height="160" fill="#8fd07f" />
          <circle cx="700" cy="70" r="34" fill="#ffed9b" stroke="#f0a208" strokeWidth="5" />
          {/* Zgrade */}
          <rect x="40" y="120" width="90" height="120" rx="6" fill="#f2979b" />
          <rect x="150" y="150" width="80" height="90" rx="6" fill="#b79ce0" />
          <rect x="620" y="140" width="110" height="100" rx="6" fill="#f0c060" />
          {[58, 86, 114].map((x) => [140, 180].map((y) => <rect key={`${x}-${y}`} x={x} y={y} width="18" height="22" rx="3" fill="#fff" opacity="0.85" />))}
          {[164, 192].map((x) => [168, 204].map((y) => <rect key={`${x}-${y}`} x={x} y={y} width="16" height="20" rx="3" fill="#fff" opacity="0.85" />))}
          {[640, 672, 704].map((x) => [158, 196].map((y) => <rect key={`${x}-${y}`} x={x} y={y} width="18" height="22" rx="3" fill="#fff" opacity="0.85" />))}
          {/* Trotroari */}
          <rect y="238" width="800" height="14" fill="#cfd4dc" />
          <rect y="330" width="800" height="14" fill="#cfd4dc" />
          <rect x="408" y="0" width="14" height="238" fill="#cfd4dc" />
          <rect x="530" y="0" width="14" height="238" fill="#cfd4dc" />
          <rect x="408" y="344" width="14" height="116" fill="#cfd4dc" />
          <rect x="530" y="344" width="14" height="116" fill="#cfd4dc" />
          {/* Kolovozi */}
          <rect y="252" width="800" height="78" fill="#4a4e5a" />
          <rect x="422" width="108" height="238" fill="#4a4e5a" />
          <rect x="422" y="344" width="108" height="116" fill="#4a4e5a" />
          {/* Isprekidane linije */}
          {Array.from({ length: 12 }, (_, i) => (
            <rect key={i} x={i * 72 + 10} y="287" width="38" height="6" rx="3" fill="#fff" />
          ))}
          {Array.from({ length: 3 }, (_, i) => (
            <rect key={`v${i}`} x="473" y={i * 72 + 356} width="6" height="38" rx="3" fill="#fff" />
          ))}
          {Array.from({ length: 3 }, (_, i) => (
            <rect key={`vt${i}`} x="473" y={i * 72 + 8} width="6" height="38" rx="3" fill="#fff" />
          ))}
          {/* Zebra prelazi */}
          {Array.from({ length: 6 }, (_, i) => (
            <rect key={`z${i}`} x={434 + i * 17} y="256" width="9" height="70" rx="2" fill="#fff" opacity="0.9" />
          ))}
          {/* Autić */}
          <g transform="translate(240 262)">
            <rect width="64" height="26" rx="12" fill="#ee5a5a" />
            <rect x="14" y="-10" width="36" height="16" rx="7" fill="#ee5a5a" />
            <rect x="20" y="-7" width="11" height="10" rx="2" fill="#bfe6fb" />
            <rect x="35" y="-7" width="11" height="10" rx="2" fill="#bfe6fb" />
            <circle cx="16" cy="26" r="7" fill="#222" /><circle cx="48" cy="26" r="7" fill="#222" />
          </g>
          {/* Znakovi na stubićima */}
          {sceneSigns.map((sign, i) => {
            const [x, y] = SPOTS[i];
            const isLearned = learned.has(sign.id);
            return (
              <g
                key={sign.id}
                transform={`translate(${x} ${y})`}
                onClick={() => openSign(sign)}
                style={{ cursor: 'pointer' }}
                role="button"
                aria-label={sign.name[lang]}
              >
                <rect x="-16" y="-16" width="82" height="112" fill="transparent" />
                <rect x="22" y="50" width="6" height="46" fill="#7a8194" />
                <g transform="scale(0.5)">{sign.art}</g>
                {isLearned && (
                  <g transform="translate(36 -8)">
                    <circle r="11" fill="#6bcb77" stroke="#161b32" strokeWidth="2.5" />
                    <path d="M-5 0 l4 4 7 -8" stroke="#fff" strokeWidth="3" fill="none" strokeLinecap="round" strokeLinejoin="round" />
                  </g>
                )}
              </g>
            );
          })}
        </svg>
      </div>

      <button
        type="button"
        onClick={() => { sounds.click(); setRound((r) => r + 1); }}
        className="push-btn push-btn-sun mx-auto mt-4 px-6 py-3 text-lg font-extrabold"
      >
        <Shuffle className="h-5 w-5" /> {t.newSigns}
      </button>

      {/* Prozorčić sa objašnjenjem */}
      {open && (
        <div
          className="fixed inset-0 z-40 flex items-center justify-center bg-black/45 p-4"
          onClick={() => setOpen(null)}
          role="presentation"
        >
          <div
            className="sticker-card animate-bounce-in w-full max-w-sm p-6 text-center"
            role="dialog"
            aria-modal="true"
            aria-label={open.name[lang]}
            onClick={(e) => e.stopPropagation()}
            onKeyDown={(e) => { if (e.key === 'Escape') setOpen(null); }}
          >
            <div className="mx-auto flex h-36 w-36 items-center justify-center">
              <SignArt sign={open} size={144} />
            </div>
            <h2 className="font-display mt-3 text-2xl">{open.name[lang]}</h2>
            <p className="mt-2 text-lg font-bold">{open.meaning[lang]}</p>
            <button
              type="button"
              autoFocus
              onClick={() => { sounds.correct(); setOpen(null); }}
              className="push-btn push-btn-leaf mx-auto mt-5 px-6 py-3 text-lg"
            >
              <Check className="h-5 w-5" /> {t.iUnderstand}
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
