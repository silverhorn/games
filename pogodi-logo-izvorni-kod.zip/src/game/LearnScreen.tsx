import { useMemo, useState } from 'react';
import { ArrowLeft, Search } from 'lucide-react';
import { BRANDS } from './brands';
import { logoUrl, type Tier } from './quiz';
import { TIER_LABEL, type Dict, type Lang } from './i18n';
import { sounds } from './sound';

interface Props {
  t: Dict;
  lang: Lang;
  onBack: () => void;
}

type Filter = 0 | Tier; // 0 = sve

export default function LearnScreen({ t, lang, onBack }: Props) {
  const [filter, setFilter] = useState<Filter>(0);
  const [query, setQuery] = useState('');

  const list = useMemo(() => {
    const q = query.trim().toLowerCase();
    return BRANDS.filter(
      (b) => (filter === 0 || b.tier === filter) && (q === '' || b.name.toLowerCase().includes(q)),
    );
  }, [filter, query]);

  return (
    <div className="mx-auto flex min-h-dvh w-full max-w-4xl flex-col px-4 py-5">
      <div className="flex flex-wrap items-center gap-3">
        <button
          type="button"
          onClick={() => {
            sounds.click();
            onBack();
          }}
          className="push-btn h-11 gap-2 px-4 font-extrabold"
        >
          <ArrowLeft className="h-5 w-5" /> {t.back}
        </button>
        <h1 className="font-display text-2xl text-white drop-shadow-[0_3px_0_var(--navy)] sm:text-3xl">{t.learnTitle}</h1>
      </div>

      <div className="mt-4 flex flex-wrap items-center gap-2">
        {([0, 1, 2, 3] as Filter[]).map((f) => (
          <button
            key={f}
            type="button"
            onClick={() => {
              setFilter(f);
              sounds.click();
            }}
            className={`push-btn px-4 py-2 text-sm font-extrabold ${filter === f ? 'push-btn-grape' : ''}`}
            aria-pressed={filter === f}
          >
            {f === 0 ? t.allBrands : TIER_LABEL[lang][f]}
          </button>
        ))}
        <label className="chip ml-auto flex items-center gap-2 !py-2">
          <Search className="h-4 w-4" aria-hidden />
          <span className="sr-only">{t.searchAria}</span>
          <input
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder={t.searchPlaceholder}
            className="w-36 bg-transparent font-bold outline-none placeholder:text-[var(--navy)]/50"
          />
        </label>
      </div>

      <p className="mt-3 text-sm font-bold text-[var(--navy)]/70">{t.shown(list.length)}</p>

      <div className="mt-3 grid grid-cols-2 gap-3 pb-10 sm:grid-cols-3 md:grid-cols-4">
        {list.map((b) => (
          <div key={b.slug} className="sticker-card flex flex-col items-center gap-2 p-4">
            <div className="flex h-20 w-full items-center justify-center">
              <img
                src={logoUrl(b.slug)}
                alt={`Logo marke ${b.name}`}
                loading="lazy"
                className="max-h-full max-w-full object-contain"
                draggable={false}
              />
            </div>
            <p className="text-center font-display text-sm leading-tight">{b.name}</p>
            <span
              className={`rounded-full border-2 border-[var(--navy)] px-2 py-0.5 text-[11px] font-extrabold ${
                b.tier === 1 ? 'bg-[var(--leaf)]' : b.tier === 2 ? 'bg-[var(--sun)]' : 'bg-[var(--coral)]'
              }`}
            >
              {TIER_LABEL[lang][b.tier]}
            </span>
          </div>
        ))}
      </div>

      {list.length === 0 && (
        <p className="mt-10 text-center text-lg font-extrabold">{t.noResults}</p>
      )}
    </div>
  );
}
