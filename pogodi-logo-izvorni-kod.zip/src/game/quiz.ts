import { BRANDS, type Brand } from './brands';

export type Tier = 1 | 2 | 3;

export interface Question {
  brand: Brand;
  options: Brand[];
}

export const TIER_META: Record<Tier, { label: string; blurb: string }> = {
  1: { label: 'Lako', blurb: 'Poznate marke koje viđaš na ulici' },
  2: { label: 'Srednje', blurb: 'Za male zaljubljenike u automobile' },
  3: { label: 'Teško', blurb: 'Pravi izazov — sve marke sveta!' },
};

export function poolForTier(tier: Tier): Brand[] {
  if (tier === 1) return BRANDS.filter((b) => b.tier === 1);
  if (tier === 2) return BRANDS.filter((b) => b.tier <= 2);
  return BRANDS;
}

function shuffled<T>(arr: T[]): T[] {
  const a = [...arr];
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [a[i], a[j]] = [a[j], a[i]];
  }
  return a;
}

export function generateQuestions(tier: Tier, count = 10): Question[] {
  const pool = poolForTier(tier);
  const picked = shuffled(pool).slice(0, Math.min(count, pool.length));
  return picked.map((brand) => {
    // Distraktori: nasumične marke iz istog nivoa, bez duplikata imena
    const distractors = shuffled(pool.filter((b) => b.slug !== brand.slug && b.name !== brand.name)).slice(0, 3);
    return { brand, options: shuffled([brand, ...distractors]) };
  });
}

export function logoUrl(slug: string): string {
  return `${import.meta.env.BASE_URL}logos/${slug}.png`;
}

const BEST_KEY = (key: string | number) => `pogodi-logo-best-${key}`;

export function getBest(key: string | number): number {
  try {
    return Number(localStorage.getItem(BEST_KEY(key)) ?? 0) || 0;
  } catch {
    return 0;
  }
}

export function setBest(key: string | number, score: number): boolean {
  const prev = getBest(key);
  if (score > prev) {
    try {
      localStorage.setItem(BEST_KEY(key), String(score));
    } catch {
      /* ignore */
    }
    return true;
  }
  return false;
}

const SOUND_KEY = 'pogodi-logo-sound';

export function getSoundOn(): boolean {
  try {
    return localStorage.getItem(SOUND_KEY) !== 'off';
  } catch {
    return true;
  }
}

export function setSoundOn(on: boolean) {
  try {
    localStorage.setItem(SOUND_KEY, on ? 'on' : 'off');
  } catch {
    /* ignore */
  }
}
