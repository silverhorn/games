import type { Lang } from './i18n';

export interface Country {
  code: string; // kod zastave (public/flags/<code>.png)
  name: Record<Lang, string>;
  brands: string[]; // slugovi iz BRANDS
}

export const COUNTRIES: Country[] = [
  { code: 'de', name: { lat: 'Nemačka', cyr: 'Немачка' }, brands: ['audi', 'bmw', 'mercedes-benz', 'volkswagen', 'porsche', 'opel', 'smart'] },
  { code: 'it', name: { lat: 'Italija', cyr: 'Италија' }, brands: ['ferrari', 'lamborghini', 'fiat', 'alfa-romeo', 'maserati', 'abarth', 'pagani', 'lancia'] },
  { code: 'fr', name: { lat: 'Francuska', cyr: 'Француска' }, brands: ['renault', 'peugeot', 'citroen', 'ds', 'bugatti'] },
  { code: 'jp', name: { lat: 'Japan', cyr: 'Јапан' }, brands: ['toyota', 'honda', 'nissan', 'mazda', 'subaru', 'mitsubishi', 'suzuki', 'lexus'] },
  { code: 'us', name: { lat: 'SAD', cyr: 'САД' }, brands: ['ford', 'chevrolet', 'tesla', 'dodge', 'jeep', 'cadillac', 'lincoln'] },
  { code: 'gb', name: { lat: 'Velika Britanija', cyr: 'Велика Британија' }, brands: ['jaguar', 'land-rover', 'bentley', 'rolls-royce', 'aston-martin', 'mini', 'mclaren', 'lotus'] },
  { code: 'se', name: { lat: 'Švedska', cyr: 'Шведска' }, brands: ['volvo', 'saab', 'koenigsegg'] },
  { code: 'cz', name: { lat: 'Češka', cyr: 'Чешка' }, brands: ['skoda', 'tatra'] },
  { code: 'kr', name: { lat: 'Južna Koreja', cyr: 'Јужна Кореја' }, brands: ['hyundai', 'kia', 'genesis'] },
  { code: 'es', name: { lat: 'Španija', cyr: 'Шпанија' }, brands: ['seat', 'cupra'] },
  { code: 'ro', name: { lat: 'Rumunija', cyr: 'Румунија' }, brands: ['dacia'] },
  { code: 'hr', name: { lat: 'Hrvatska', cyr: 'Хрватска' }, brands: ['rimac'] },
  { code: 'rs', name: { lat: 'Srbija', cyr: 'Србија' }, brands: ['zastava'] },
  { code: 'ru', name: { lat: 'Rusija', cyr: 'Русија' }, brands: ['lada'] },
  { code: 'nl', name: { lat: 'Holandija', cyr: 'Холандија' }, brands: ['spyker', 'daf'] },
];

export function flagUrl(code: string): string {
  return `${import.meta.env.BASE_URL}flags/${code}.png`;
}

export function countryOfBrand(slug: string): Country | undefined {
  return COUNTRIES.find((c) => c.brands.includes(slug));
}
