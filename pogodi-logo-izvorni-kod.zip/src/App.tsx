import { useState } from 'react';
import HomeScreen from './game/HomeScreen';
import QuizScreen from './game/QuizScreen';
import ResultScreen from './game/ResultScreen';
import LearnScreen from './game/LearnScreen';
import FlagsQuiz from './game/FlagsQuiz';
import SignsExplore from './game/SignsExplore';
import SignsMatch from './game/SignsMatch';
import { getSoundOn, setSoundOn as persistSound, type Tier } from './game/quiz';
import { getLang, saveLang, STR, TIER_LABEL, type Lang } from './game/i18n';
import { setMuted, sounds } from './game/sound';

type Screen =
  | { name: 'home' }
  | { name: 'quiz'; tier: Tier; round: number }
  | { name: 'result'; levelLabel: string; bestKey: string | number; score: number; correct: number; total: number; bestStreak: number; replay: () => void }
  | { name: 'learn' }
  | { name: 'flags'; round: number }
  | { name: 'street' }
  | { name: 'match' };

export default function App() {
  const [lang, setLang] = useState<Lang>(() => getLang());
  const t = STR[lang];
  const [screen, setScreen] = useState<Screen>({ name: 'home' });
  const [soundOn, setSoundState] = useState(() => {
    const on = getSoundOn();
    setMuted(!on);
    return on;
  });

  function toggleSound() {
    const on = !soundOn;
    setSoundState(on);
    setMuted(!on);
    persistSound(on);
    if (on) sounds.click();
  }

  function toggleLang() {
    const next: Lang = lang === 'lat' ? 'cyr' : 'lat';
    setLang(next);
    saveLang(next);
    sounds.click();
  }

  const goHome = () => {
    sounds.click();
    setScreen({ name: 'home' });
  };

  return (
    <div className="min-h-dvh" lang={lang === 'cyr' ? 'sr-Cyrl' : 'sr-Latn'}>
      {screen.name === 'home' && (
        <HomeScreen
          t={t}
          lang={lang}
          onLangToggle={toggleLang}
          soundOn={soundOn}
          onToggleSound={toggleSound}
          onLearn={() => {
            sounds.click();
            setScreen({ name: 'learn' });
          }}
          onPlay={(tier) => {
            sounds.click();
            setScreen({ name: 'quiz', tier, round: Date.now() });
          }}
          onFlags={() => {
            sounds.click();
            setScreen({ name: 'flags', round: Date.now() });
          }}
          onStreet={() => {
            sounds.click();
            setScreen({ name: 'street' });
          }}
          onMatch={() => {
            sounds.click();
            setScreen({ name: 'match' });
          }}
        />
      )}

      {screen.name === 'quiz' && (
        <QuizScreen
          key={screen.round}
          t={t}
          tier={screen.tier}
          onQuit={() => setScreen({ name: 'home' })}
          onFinish={(score, correct, total, bestStreak) =>
            setScreen({
              name: 'result',
              levelLabel: TIER_LABEL[lang][screen.tier],
              bestKey: screen.tier,
              score,
              correct,
              total,
              bestStreak,
              replay: () => setScreen({ name: 'quiz', tier: screen.tier, round: Date.now() }),
            })
          }
        />
      )}

      {screen.name === 'flags' && (
        <FlagsQuiz
          key={screen.round}
          t={t}
          lang={lang}
          onQuit={() => setScreen({ name: 'home' })}
          onFinish={(score, correct, total, bestStreak) =>
            setScreen({
              name: 'result',
              levelLabel: t.flagsTitle,
              bestKey: 'flags',
              score,
              correct,
              total,
              bestStreak,
              replay: () => setScreen({ name: 'flags', round: Date.now() }),
            })
          }
        />
      )}

      {screen.name === 'result' && (
        <ResultScreen
          t={t}
          levelLabel={screen.levelLabel}
          bestKey={screen.bestKey}
          score={screen.score}
          correct={screen.correct}
          total={screen.total}
          bestStreak={screen.bestStreak}
          onReplay={() => {
            sounds.click();
            screen.replay();
          }}
          onMenu={goHome}
        />
      )}

      {screen.name === 'learn' && <LearnScreen t={t} lang={lang} onBack={() => setScreen({ name: 'home' })} />}
      {screen.name === 'street' && <SignsExplore t={t} lang={lang} onBack={() => setScreen({ name: 'home' })} />}
      {screen.name === 'match' && <SignsMatch t={t} lang={lang} onBack={() => setScreen({ name: 'home' })} />}
    </div>
  );
}
