import { StrictMode } from 'react'
import { createRoot } from 'react-dom/client'
import { BrowserRouter } from 'react-router'
import '@fontsource/dela-gothic-one/400.css'
import '@fontsource/dela-gothic-one/latin-ext-400.css'
import '@fontsource/dela-gothic-one/cyrillic-400.css'
import '@fontsource/manrope/500.css'
import '@fontsource/manrope/latin-ext-500.css'
import '@fontsource/manrope/cyrillic-500.css'
import '@fontsource/manrope/800.css'
import '@fontsource/manrope/latin-ext-800.css'
import '@fontsource/manrope/cyrillic-800.css'
import './index.css'
import App from './App.tsx'

createRoot(document.getElementById('root')!).render(
  <StrictMode>
    <BrowserRouter>
      <App />
    </BrowserRouter>
  </StrictMode>,
)
