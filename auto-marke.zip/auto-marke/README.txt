POGODI AUTO-MARKU! (za decu 7-10 godina)

Kviz o poznatim automobilskim markama — BEZ kopiranja pravih logoa (zaštićeni
žigovi kompanija). Umesto loga, svako pitanje prikazuje originalnu, ručno
nacrtanu siluetu vozila (tip karoserije koji ta marka pravi) i tragove:
zemlju porekla, godinu osnivanja i poznati model.

Pokretanje: raspakuj zip i dvaput klikni na index.html.

DVA MODA:
- Sam igram: 10 pitanja, meri se rezultat i vreme, čuva se rekord (ime +
  bodovi) u pregledaču (localStorage).
- Takmičenje: dva igrača dobijaju isti krug od 10 pitanja, jedan za drugim
  (predaje se uređaj), pobeđuje ko ima više tačnih odgovora.

TIPOVI PITANJA (nasumično mešana):
- "Koja je ovo marka automobila?" — na osnovu siluete + zemlje/godine.
- "Koja marka pravi model X?" — poznati modeli.
- "Iz koje zemlje dolazi marka X?" — geografija brendova.

Posle svakog odgovora prikazuje se kratka zanimljivost o toj marki.

TEHNIČKI DETALJI:
- data/brands.js — činjenice o 24 marke (zemlja, godina, modeli, fun fact).
  Samo tekstualni podaci, bez ičega vizuelno preuzetog.
- data/shapes.js — originalni, parametarski SVG crtež siluete vozila (8
  tipova karoserije: limuzina, hečbek, SUV, terenac, pikap, sport, lima,
  gradski auto).
- app.js — tok kviza (solo + takmičenje za dvoje), bodovanje, rekordi.
