POGODI AUTO-MARKU! (za decu 7-10 godina)

Kviz o poznatim automobilskim markama — BEZ kopiranja pravih logoa (zaštićeni
žigovi kompanija). Umesto pravog loga, svaka marka ima originalni, izmišljeni
"amblem" (geometrijski oblik u boji marke sa prvim slovom imena) i tragove:
zemlju porekla, godinu osnivanja i poznati model.

42 marke, poređane od LAKŠIH (Toyota, Ford, BMW, Mercedes, Volkswagen, Audi...)
do TEŽIH i ređih (Maserati, Bentley, Aston Martin, Rolls-Royce...). Svaka runda
od 10 pitanja ide tim redosledom — prva pitanja su najpoznatije marke sa svim
tragovima, poslednja su ređe marke sa sve manje (ili nimalo) tragova.

Pokretanje: raspakuj zip i dvaput klikni na index.html.

TRI MODA:
- Sam igram: 10 pitanja, meri se rezultat i vreme, čuva se rekord (ime +
  bodovi) u pregledaču (localStorage).
- Takmičenje: dva igrača dobijaju isti krug od 10 pitanja, jedan za drugim
  (predaje se uređaj), pobeđuje ko ima više tačnih odgovora.
- Raskrsnica znakova: igra spajanja parova — na "raskrsnici" su amblemi
  marki u levoj koloni i imena marki u desnoj, pobacana. Klikneš amblem pa
  ime da ih spojiš. 3 nivoa (4, 6, pa 8 parova), na kraju zvezdice po broju
  grešaka i vremenu.

TIPOVI PITANJA (nasumično mešana):
- "Koja je ovo marka automobila?" — na osnovu amblema + tragova.
- "Koja marka pravi model X?" — poznati modeli.
- "Iz koje zemlje dolazi marka X?" — geografija brendova.

Posle svakog odgovora prikazuje se kratka zanimljivost o toj marki.

TEHNIČKI DETALJI:
- data/brands.js — činjenice o 42 marke (zemlja, godina, modeli, fun fact,
  rang poznatosti za redosled težine). Samo tekstualni podaci.
- data/badges.js — originalni, programski generisan "amblem" za svaku marku
  (6 geometrijskih oblika × boja marke × slovo) — nije ničiji pravi logo.
- app.js — tok kviza (solo + takmičenje za dvoje), redosled po težini,
  bodovanje, rekordi.
