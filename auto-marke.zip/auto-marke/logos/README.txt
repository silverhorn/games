Ubaci ovde slike logoa pod imenom marke (id) + .svg ili .png, npr. toyota.svg.
Ako slike nema, igra koristi originalni amblem.
ID-jevi: toyota ford bmw mercedes vw audi honda ferrari lambo nissan porsche jeep fiat tesla
hyundai chevrolet renault peugeot kia mazda volvo landrover mini citroen subaru mitsubishi
suzuki skoda opel seat dacia alfa jaguar lexus cadillac chrysler dodge infiniti maserati
bentley astonmartin rollsroyce
