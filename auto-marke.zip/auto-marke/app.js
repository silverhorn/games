(function () {
  'use strict';
  var app = document.getElementById('app');
  var BRANDS = window.BRANDS, BADGES = window.BADGES;
  var N_Q = 10;
  var PRAISE = ['Bravo! 🎉', 'Tačno! ⭐', 'Super! 👏', 'Odlično! 🌟', 'Tako se to radi! 💪'];
  var AVATARS = ['🚦', '🏁'];

  function shuffle(a) {
    a = a.slice();
    for (var i = a.length - 1; i > 0; i--) {
      var j = Math.floor(Math.random() * (i + 1));
      var t = a[i]; a[i] = a[j]; a[j] = t;
    }
    return a;
  }
  function esc(s) {
    return String(s).replace(/[&<>"]/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]; });
  }
  function sample(arr, n) { return shuffle(arr).slice(0, n); }
  function store(key, val) {
    try {
      if (val === undefined) return localStorage.getItem('auto_' + key);
      localStorage.setItem('auto_' + key, val);
    } catch (e) { return null; }
    return null;
  }
  function stars(score) { return score >= 9 ? 3 : score >= 7 ? 2 : score >= 4 ? 1 : 0; }
  function starText(n) { return '⭐'.repeat(n) + '☆'.repeat(3 - n); }
  function fmtTime(sec) { var m = Math.floor(sec / 60), s = sec % 60; return m + ':' + (s < 10 ? '0' : '') + s; }
  function getRec() { try { return JSON.parse(store('rec') || 'null'); } catch (e) { return null; } }
  function saveRec(name, s, t) { store('rec', JSON.stringify({ n: name, s: s, t: t })); }
  function beats(r, s, t) { return s > 0 && (!r || s > r.s || (s === r.s && t < r.t)); }
  function opts(correctHtml, wrongHtmls) {
    return shuffle([{ html: correctHtml, correct: true }].concat(wrongHtmls.map(function (w) { return { html: w, correct: false }; })));
  }
  function badgeImg(b) { return '<div class="badgewrap">' + BADGES.badgeSVG(b) + '</div>'; }
  function clueChips(b, hide) {
    hide = hide || {};
    var h = '<div class="clues">';
    if (!hide.country) h += '<span class="clue">' + b.flag + ' ' + esc(b.country) + '</span>';
    if (!hide.year) h += '<span class="clue">📅 od ' + b.founded + '.</span>';
    if (!hide.model) h += '<span class="clue">🚘 model: ' + esc(b.models[0]) + '</span>';
    h += '</div>';
    return h;
  }
  // amblem otkriva prvo slovo marke, pa po mogućstvu biramo pogrešne
  // ponuđene odgovore sa istim početnim slovom da slovo ne "odaje" odgovor
  function sameLetterOthers(b, pool, n) {
    var letter = b.name.charAt(0).toUpperCase();
    var rest = pool.filter(function (x) { return x.id !== b.id; });
    var same = rest.filter(function (x) { return x.name.charAt(0).toUpperCase() === letter; });
    var other = rest.filter(function (x) { return x.name.charAt(0).toUpperCase() !== letter; });
    var picked = sample(same, Math.min(n, same.length));
    if (picked.length < n) picked = picked.concat(sample(other, n - picked.length));
    return picked;
  }

  // ---------- generatori pitanja (level: 0 lakše, 1 srednje, 2 teže — manje tragova) ----------
  function qGuessBrand(b, pool, level) {
    var others = sameLetterOthers(b, pool, 3);
    var hide = level >= 2 ? { country: true, year: true, model: true } : level === 1 ? { year: true, model: true } : { model: true };
    return {
      big: badgeImg(b), clues: clueChips(b, hide),
      prompt: 'Koja je ovo marka automobila?', answerText: b.name, fact: b.fact,
      options: opts(esc(b.name), others.map(function (o) { return esc(o.name); }))
    };
  }
  function qGuessBrandByModel(b, pool, level) {
    var others = sameLetterOthers(b, pool, 3);
    return {
      big: badgeImg(b), clues: level >= 2 ? '' : clueChips(b, { country: true, year: true, model: true }),
      prompt: 'Koja marka pravi model „' + esc(b.models[0]) + '"?', answerText: b.name, fact: b.fact,
      options: opts(esc(b.name), others.map(function (o) { return esc(o.name); }))
    };
  }
  function qGuessCountry(b, pool, level) {
    var others = sample(pool.filter(function (x) { return x.country !== b.country; }), 3);
    var hide = level >= 1 ? { country: true, year: true, model: true } : { country: true, model: true };
    return {
      big: badgeImg(b), clues: clueChips(b, hide),
      prompt: 'Iz koje zemlje dolazi marka ' + esc(b.name) + '?', answerText: b.country, fact: b.fact,
      options: opts(b.flag + ' ' + esc(b.country), others.map(function (o) { return o.flag + ' ' + esc(o.country); }))
    };
  }
  var GENERATORS = [qGuessBrand, qGuessBrand, qGuessBrandByModel, qGuessCountry];

  // Pitanja idu od LAKŠEG ka NAJTEŽEM: marke su rangirane po poznatosti (fame),
  // runda se deli u N_Q "kofa" duž tog ranga, pa se iz svake kofe bira jedna
  // (slučajno unutar kofe, ali redosled kofa je uvek rastući po težini).
  function buildRound() {
    var sorted = BRANDS.slice().sort(function (a, b) { return a.fame - b.fame; });
    var buckets = [];
    for (var i = 0; i < N_Q; i++) buckets.push([]);
    sorted.forEach(function (b, i) { buckets[Math.min(N_Q - 1, Math.floor(i * N_Q / sorted.length))].push(b); });
    var third = Math.ceil(N_Q / 3);
    return buckets.map(function (bucket, i) {
      var b = bucket[Math.floor(Math.random() * bucket.length)] || sorted[sorted.length - 1];
      var level = Math.floor(i / third);
      var gen = GENERATORS[Math.floor(Math.random() * GENERATORS.length)];
      return gen(b, BRANDS, level);
    });
  }

  // ---------------- početni ekran ----------------
  function home() {
    state = null;
    var h = '<h1>🚗 Pogodi auto-marku!</h1>';
    h += '<p class="sub">Siluete automobila i tragovi (zemlja, godina, model) — pogodi koja je marka!</p>';
    var rec = getRec();
    if (rec) h += '<p class="recline" style="text-align:center">🏆 Rekord: <b>' + esc(rec.n) + '</b> — ' + rec.s + '/' + N_Q + ' (' + fmtTime(rec.t) + ')</p>';
    h += '<div class="modes">';
    h += '<button class="modecard" id="m-solo"><div class="emo">🏆</div><div class="name">Sam igram</div><div class="desc">Pokušaj da oboriš rekord</div></button>';
    h += '<button class="modecard" id="m-duel"><div class="emo">⚔️</div><div class="name">Takmičenje</div><div class="desc">Dva igrača, ista pitanja</div></button>';
    h += '</div>';
    app.innerHTML = h;
    document.getElementById('m-solo').addEventListener('click', startSolo);
    document.getElementById('m-duel').addEventListener('click', duelSetup);
  }

  // ---------------- solo kviz ----------------
  var state = null;

  function startSolo() {
    state = { duel: false, qs: buildRound(), i: 0, score: 0, t0: Date.now(), locked: false };
    question();
  }

  function question() {
    state.locked = false;
    var q = state.qs[state.i];
    var pct = Math.round((state.i / state.qs.length) * 100);
    var h = '<div class="top"><div class="progress"><i style="width:' + pct + '%"></i></div>' +
      '<div class="count">' + (state.i + 1) + ' / ' + state.qs.length + '</div></div>';
    h += '<section class="qcard">' + q.big + q.clues + '<h2>' + q.prompt + '</h2><div class="opts">';
    q.options.forEach(function (o, i) { h += '<button class="opt" data-i="' + i + '">' + o.html + '</button>'; });
    h += '</div><div class="fb" id="fb"></div><button class="btn next" id="next" hidden>Dalje ➜</button></section>';
    app.innerHTML = h;
    var btns = Array.prototype.slice.call(app.querySelectorAll('.opt'));
    btns.forEach(function (b, i) { b.addEventListener('click', function () { answer(q, btns, i); }); });
  }

  function answer(q, btns, idx) {
    if (state.locked) return;
    state.locked = true;
    var ok = q.options[idx].correct;
    btns.forEach(function (b, i) {
      b.disabled = true;
      if (q.options[i].correct) b.classList.add('good');
      else if (i === idx) b.classList.add('bad');
    });
    if (ok) {
      if (state.duel) state.players[state.p].score++; else state.score++;
    }
    var fb = document.getElementById('fb');
    fb.className = 'fb ' + (ok ? 'good' : 'bad');
    fb.innerHTML = (ok ? PRAISE[Math.floor(Math.random() * PRAISE.length)] : 'Skoro! Tačan odgovor je: ' + esc(q.answerText)) +
      (q.fact ? '<div class="fact">💡 ' + esc(q.fact) + '</div>' : '');
    var next = document.getElementById('next');
    next.hidden = false;
    next.textContent = state.i === state.qs.length - 1 ? 'Završi 🏁' : 'Dalje ➜';
    next.addEventListener('click', function () {
      state.i++;
      if (state.i >= state.qs.length) { state.duel ? duelTurnEnd() : finish(); } else question();
    });
    next.focus();
  }

  function finish() {
    state.t = Math.round((Date.now() - state.t0) / 1000);
    state.isRec = beats(getRec(), state.score, state.t);
    renderResult();
  }

  function renderResult() {
    var s = state.score, n = state.qs.length;
    var msg = s >= 9 ? 'Bravo, pravi poznavalac automobila! 🏆' : s >= 7 ? 'Odlično ti ide! 🎉' : s >= 4 ? 'Dobro! Još malo vežbe i biće sjajno. 💪' : 'Ništa zato — učiš dok igraš. Probaj ponovo! 🌱';
    var rec = getRec();
    var h = '<section class="qcard result"><div class="big">🏁</div>' +
      '<div class="stars">' + starText(stars(s)) + '</div>' +
      '<p class="score">' + s + ' od ' + n + '</p><h2>' + msg + '</h2>';
    if (state.isRec) {
      h += '<div class="newrec"><div>🎉 <b>Novi rekord!</b> Upiši svoje ime:</div>' +
        '<div class="rrow"><input id="rn" maxlength="14" placeholder="Ime" value="' + esc(store('lastname') || '') + '"><button class="btn next" id="saverec">Sačuvaj 🏆</button></div></div>';
    } else if (rec) {
      h += '<p class="recline">🏆 Rekord: <b>' + esc(rec.n) + '</b> — ' + rec.s + '/' + n + ' (' + fmtTime(rec.t) + ')</p>';
    }
    h += '<div class="row"><button class="btn next" id="again">🔁 Igraj ponovo</button><button class="btn" id="menu">🏠 Početak</button></div></section>';
    app.innerHTML = h;
    document.getElementById('again').addEventListener('click', startSolo);
    document.getElementById('menu').addEventListener('click', home);
    var sv = document.getElementById('saverec');
    if (sv) {
      var save = function () {
        var name = document.getElementById('rn').value.trim() || 'Igrač';
        store('lastname', name);
        saveRec(name, s, state.t);
        state.isRec = false;
        renderResult();
      };
      sv.addEventListener('click', save);
      document.getElementById('rn').addEventListener('keydown', function (e) { if (e.key === 'Enter') save(); });
    }
  }

  // ---------------- takmičenje za dvoje ----------------
  var lastDuel = { names: ['', ''] };

  function duelSetup() {
    state = null;
    var h = '<div class="top"><button class="btn" id="back">⬅ Nazad</button></div>';
    h += '<h1>⚔️ Takmičenje</h1><p class="sub">Oba igrača dobijaju ista pitanja, jedan za drugim. Pobeđuje ko ima više tačnih odgovora!</p>';
    h += '<section class="qcard setup">';
    h += '<label class="nm p0">' + AVATARS[0] + ' <input id="n0" maxlength="14" placeholder="Igrač 1" value="' + esc(lastDuel.names[0]) + '"></label>';
    h += '<label class="nm p1">' + AVATARS[1] + ' <input id="n1" maxlength="14" placeholder="Igrač 2" value="' + esc(lastDuel.names[1]) + '"></label>';
    h += '<button class="btn next" id="go">Počni! ▶</button></section>';
    app.innerHTML = h;
    document.getElementById('back').addEventListener('click', home);
    document.getElementById('go').addEventListener('click', function () {
      lastDuel.names = [document.getElementById('n0').value.trim(), document.getElementById('n1').value.trim()];
      duelStart(lastDuel.names[0] || 'Igrač 1', lastDuel.names[1] || 'Igrač 2');
    });
  }

  function duelStart(n0, n1) {
    state = { duel: true, qs: buildRound(), i: 0, p: 0, players: [{ name: n0, score: 0, t: 0 }, { name: n1, score: 0, t: 0 }] };
    duelTurnStart();
  }

  function duelTurnStart() {
    var pl = state.players[state.p];
    state.i = 0;
    app.innerHTML = '<section class="qcard result"><div class="big">' + AVATARS[state.p] + '</div>' +
      '<h2>' + (state.p === 0 ? 'Prvi na redu: ' : 'Sada je na redu: ') + esc(pl.name) + '!</h2>' +
      '<p class="sub">Tema: 🚗 Auto-marke</p>' +
      '<div class="row"><button class="btn next" id="ready">Spreman sam! ▶</button></div></section>';
    document.getElementById('ready').addEventListener('click', function () {
      state.t0 = Date.now();
      question();
    });
  }

  function duelTurnEnd() {
    var pl = state.players[state.p];
    pl.t = Math.round((Date.now() - state.t0) / 1000);
    if (state.p === 0) {
      state.p = 1;
      app.innerHTML = '<section class="qcard result"><div class="big">🎉</div><h2>Kraj kruga za ' + esc(pl.name) + '!</h2>' +
        '<p class="sub">Rezultat se otkriva na kraju. Predaj uređaj: ' + esc(state.players[1].name) + ' je na redu!</p>' +
        '<div class="row"><button class="btn next" id="cont">Nastavi ▶</button></div></section>';
      document.getElementById('cont').addEventListener('click', duelTurnStart);
    } else {
      duelResult();
    }
  }

  function duelResult() {
    var a = state.players[0], b = state.players[1], n = state.qs.length;
    var newRec = [a, b].map(function (p) {
      var ok = beats(getRec(), p.score, p.t);
      if (ok) saveRec(p.name, p.score, p.t);
      return ok;
    });
    var banner, win;
    if (a.score === b.score) { banner = '🤝 Nerešeno! Obojica imate ' + a.score + '.'; win = -1; }
    else { banner = '🏆 Pobednik je ' + esc(a.score > b.score ? a.name : b.name) + '!'; win = a.score > b.score ? 0 : 1; }
    var h = '<section class="qcard result"><h2 class="banner">' + banner + '</h2><div class="vs">';
    [a, b].forEach(function (p, i) {
      h += '<div class="pcard p' + i + (win === i ? ' win' : '') + '"><div class="big">' + AVATARS[i] + (win === i ? '👑' : '') + '</div>' +
        '<div class="pn">' + esc(p.name) + '</div><div class="score">' + p.score + ' / ' + n + '</div>' +
        '<div>' + starText(stars(p.score)) + '</div><div class="tm">⏱ ' + fmtTime(p.t) + '</div>' + (newRec[i] ? '<div class="newtag">🏆 Novi rekord!</div>' : '') + '</div>';
    });
    h += '</div><div class="row"><button class="btn next" id="rematch">🔁 Revanš</button><button class="btn" id="menu">🏠 Početak</button></div></section>';
    app.innerHTML = h;
    var names = [a.name, b.name];
    document.getElementById('rematch').addEventListener('click', function () { duelStart(names[0], names[1]); });
    document.getElementById('menu').addEventListener('click', home);
  }

  home();
})();
