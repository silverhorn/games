// Originalne, generičke siluete tipova vozila (bez loga, bez stvarnih modela) —
// jednostavan parametarski crtež iz pravougaonika/trapezoida/krugova.
(function () {
  'use strict';

  var TYPES = {
    sedan: { len: 150, bodyH: 26, roofH: 26, roofLen: 70, roofOff: 46, wheelR: 15, bed: false, nose: 10 },
    hatchback: { len: 128, bodyH: 26, roofH: 28, roofLen: 56, roofOff: 50, wheelR: 15, bed: false, nose: 8 },
    suv: { len: 150, bodyH: 34, roofH: 30, roofLen: 90, roofOff: 34, wheelR: 18, bed: false, nose: 10 },
    offroad: { len: 148, bodyH: 36, roofH: 30, roofLen: 86, roofOff: 32, wheelR: 20, bed: false, nose: 6, boxy: true },
    pickup: { len: 168, bodyH: 28, roofH: 26, roofLen: 58, roofOff: 20, wheelR: 17, bed: true, nose: 8 },
    sport: { len: 156, bodyH: 20, roofH: 18, roofLen: 60, roofOff: 52, wheelR: 15, bed: false, nose: 18, low: true },
    limo: { len: 190, bodyH: 26, roofH: 24, roofLen: 100, roofOff: 46, wheelR: 15, bed: false, nose: 10 },
    citycar: { len: 104, bodyH: 28, roofH: 32, roofLen: 60, roofOff: 22, wheelR: 14, bed: false, nose: 6, boxy: true }
  };

  function carSVG(bodyType, color, dark) {
    var t = TYPES[bodyType] || TYPES.sedan;
    dark = dark || shade(color, -28);
    var W = 210, H = 100, groundY = 78;
    var bx = (W - t.len) / 2, by = groundY - t.bodyH;
    var s = '<svg viewBox="0 0 ' + W + ' ' + H + '" xmlns="http://www.w3.org/2000/svg">';
    // put
    s += '<line x1="4" y1="' + groundY + '" x2="' + (W - 4) + '" y2="' + groundY + '" stroke="#c9b58a" stroke-width="3" stroke-linecap="round"/>';
    // karoserija (zaobljen pravougaonik)
    var rx = t.boxy ? 6 : 12;
    s += '<rect x="' + bx + '" y="' + by + '" width="' + t.len + '" height="' + t.bodyH + '" rx="' + rx + '" fill="' + color + '" stroke="' + dark + '" stroke-width="2.5"/>';
    // "nos" napred (blago zaobljen prednji deo)
    if (t.nose) {
      s += '<rect x="' + (bx + t.len - t.nose) + '" y="' + (by + 4) + '" width="' + t.nose + '" height="' + (t.bodyH - 8) + '" rx="6" fill="' + dark + '" opacity="0.35"/>';
    }
    // tovarni sanduk za pickup (niži zadnji deo)
    if (t.bed) {
      var bedLen = 46, bedH = t.bodyH * 0.55;
      s += '<rect x="' + bx + '" y="' + (by + t.bodyH - bedH) + '" width="' + bedLen + '" height="' + bedH + '" fill="none" stroke="' + dark + '" stroke-width="2.5"/>';
    }
    // krov/kabina (trapezoid)
    var rx1 = bx + t.roofOff, rx2 = rx1 + t.roofLen;
    var topY = by - t.roofH, slant = t.low ? 22 : 14;
    s += '<path d="M' + rx1 + ' ' + by + ' L' + (rx1 + slant) + ' ' + topY + ' L' + (rx2 - slant * 0.6) + ' ' + topY + ' L' + (rx2 + 6) + ' ' + by + ' Z" fill="' + color + '" stroke="' + dark + '" stroke-width="2.5"/>';
    // prozori
    var winY = topY + 7, winH = (by - topY) - 10;
    s += '<path d="M' + (rx1 + slant + 3) + ' ' + (topY + 4) + ' L' + (rx1 + slant + 10) + ' ' + winY + ' L' + (rx1 + t.roofLen * 0.42) + ' ' + winY + ' L' + (rx1 + t.roofLen * 0.42) + ' ' + (topY + 4) + ' Z" fill="#dff3fb" opacity="0.9"/>';
    s += '<path d="M' + (rx1 + t.roofLen * 0.52) + ' ' + (topY + 4) + ' L' + (rx1 + t.roofLen * 0.52) + ' ' + winY + ' L' + (rx2 - slant * 0.6 - 6) + ' ' + winY + ' L' + (rx2 - 4) + ' ' + (topY + 4) + ' Z" fill="#dff3fb" opacity="0.9"/>';
    // tockovi
    var w1x = bx + t.len * 0.26, w2x = bx + t.len * 0.78;
    [w1x, w2x].forEach(function (wx) {
      s += '<circle cx="' + wx + '" cy="' + groundY + '" r="' + t.wheelR + '" fill="#2b2b2b"/>';
      s += '<circle cx="' + wx + '" cy="' + groundY + '" r="' + (t.wheelR * 0.42) + '" fill="#9aa0a6"/>';
    });
    // far i stop svetlo
    s += '<circle cx="' + (bx + t.len - 5) + '" cy="' + (by + t.bodyH / 2) + '" r="3.2" fill="#fff6cf"/>';
    s += '<circle cx="' + (bx + 5) + '" cy="' + (by + t.bodyH / 2) + '" r="3" fill="#ff6b5e"/>';
    s += '</svg>';
    return s;
  }

  function shade(hex, amt) {
    var c = hex.replace('#', '');
    var num = parseInt(c, 16);
    var r = Math.max(0, Math.min(255, (num >> 16) + amt));
    var g = Math.max(0, Math.min(255, ((num >> 8) & 0xff) + amt));
    var b = Math.max(0, Math.min(255, (num & 0xff) + amt));
    return '#' + ((1 << 24) + (r << 16) + (g << 8) + b).toString(16).slice(1);
  }

  window.SHAPES = { carSVG: carSVG, TYPES: TYPES };
})();
