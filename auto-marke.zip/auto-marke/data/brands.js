// Podaci o auto-markama: samo činjenice (zemlja, godina, modeli, zanimljivost) —
// BEZ pravih logoa (zaštićeni žigovi). Siluete vozila su originalne (data/shapes.js).
(function () {
  'use strict';
  window.BRANDS = [
    { id: 'toyota', name: 'Toyota', country: 'Japan', flag: '🇯🇵', founded: 1937, models: ['Corolla', 'Yaris', 'RAV4'], fact: 'Najprodavanija auto-marka na svetu.', body: 'suv', color: '#c0392b' },
    { id: 'honda', name: 'Honda', country: 'Japan', flag: '🇯🇵', founded: 1948, models: ['Civic', 'CR-V', 'Jazz'], fact: 'Počela je praveći motocikle.', body: 'hatchback', color: '#2980b9' },
    { id: 'nissan', name: 'Nissan', country: 'Japan', flag: '🇯🇵', founded: 1933, models: ['Qashqai', 'Micra', 'GT-R'], fact: 'GT-R se zove i "Godzilla".', body: 'sport', color: '#2c3e50' },
    { id: 'ford', name: 'Ford', country: 'SAD', flag: '🇺🇸', founded: 1903, models: ['Fiesta', 'Mustang', 'F-150'], fact: 'Prvi je masovno proizvodio automobile na traci.', body: 'pickup', color: '#1a5276' },
    { id: 'chevrolet', name: 'Chevrolet', country: 'SAD', flag: '🇺🇸', founded: 1911, models: ['Camaro', 'Corvette', 'Spark'], fact: 'Corvette je čuveni sportski auto.', body: 'sport', color: '#f1c40f' },
    { id: 'tesla', name: 'Tesla', country: 'SAD', flag: '🇺🇸', founded: 2003, models: ['Model 3', 'Model Y', 'Model S'], fact: 'Pravi samo automobile na struju.', body: 'sedan', color: '#e74c3c' },
    { id: 'jeep', name: 'Jeep', country: 'SAD', flag: '🇺🇸', founded: 1941, models: ['Wrangler', 'Renegade', 'Compass'], fact: 'Nastao je za vojsku u Drugom svetskom ratu.', body: 'offroad', color: '#27ae60' },
    { id: 'vw', name: 'Volkswagen', country: 'Nemačka', flag: '🇩🇪', founded: 1937, models: ['Golf', 'Polo', 'Buba'], fact: 'Ime znači "auto za narod".', body: 'hatchback', color: '#2980b9' },
    { id: 'bmw', name: 'BMW', country: 'Nemačka', flag: '🇩🇪', founded: 1916, models: ['Serija 3', 'X5', 'i4'], fact: 'Prvo je pravio avionske motore.', body: 'sedan', color: '#2e4057' },
    { id: 'mercedes', name: 'Mercedes-Benz', country: 'Nemačka', flag: '🇩🇪', founded: 1926, models: ['Klasa C', 'Klasa E', 'G-klasa'], fact: 'Izumeli su prvi pravi automobil 1886.', body: 'limo', color: '#5d6d7e' },
    { id: 'audi', name: 'Audi', country: 'Nemačka', flag: '🇩🇪', founded: 1909, models: ['A4', 'Q5', 'TT'], fact: 'Poznat po pogonu na sva 4 točka (quattro).', body: 'sedan', color: '#7f8c8d' },
    { id: 'porsche', name: 'Porsche', country: 'Nemačka', flag: '🇩🇪', founded: 1931, models: ['911', 'Cayenne', 'Taycan'], fact: 'Model 911 se pravi skoro nepromenjen od 1963.', body: 'sport', color: '#d35400' },
    { id: 'fiat', name: 'Fiat', country: 'Italija', flag: '🇮🇹', founded: 1899, models: ['500', 'Panda', 'Tipo'], fact: 'Fiat 500 je ikona italijanskih gradskih uličica.', body: 'citycar', color: '#e67e22' },
    { id: 'ferrari', name: 'Ferrari', country: 'Italija', flag: '🇮🇹', founded: 1939, models: ['F8', 'Roma', 'SF90'], fact: 'Simbol marke je konjic (ne crtamo ga, ali ga znaš!).', body: 'sport', color: '#c0392b' },
    { id: 'lambo', name: 'Lamborghini', country: 'Italija', flag: '🇮🇹', founded: 1963, models: ['Huracán', 'Urus', 'Aventador'], fact: 'Osnivač je pre toga pravio traktore.', body: 'sport', color: '#f39c12' },
    { id: 'renault', name: 'Renault', country: 'Francuska', flag: '🇫🇷', founded: 1899, models: ['Clio', 'Megane', 'Twingo'], fact: 'Jedna od najstarijih auto-marki na svetu.', body: 'hatchback', color: '#f1c40f' },
    { id: 'peugeot', name: 'Peugeot', country: 'Francuska', flag: '🇫🇷', founded: 1810, models: ['208', '3008', '508'], fact: 'Počeli su praveći mlinove za kafu i bicikle.', body: 'hatchback', color: '#34495e' },
    { id: 'citroen', name: 'Citroën', country: 'Francuska', flag: '🇫🇷', founded: 1919, models: ['C3', 'C4', 'Berlingo'], fact: 'Prvi je u Evropi masovno pravio automobile.', body: 'citycar', color: '#8e44ad' },
    { id: 'volvo', name: 'Volvo', country: 'Švedska', flag: '🇸🇪', founded: 1927, models: ['XC60', 'XC90', 'V60'], fact: 'Izumeli su sigurnosni pojas kakav danas svi koriste.', body: 'suv', color: '#1f618d' },
    { id: 'skoda', name: 'Škoda', country: 'Češka', flag: '🇨🇿', founded: 1895, models: ['Octavia', 'Fabia', 'Kodiaq'], fact: 'Jedna od najstarijih fabrika automobila na svetu.', body: 'sedan', color: '#16a085' },
    { id: 'hyundai', name: 'Hyundai', country: 'Južna Koreja', flag: '🇰🇷', founded: 1967, models: ['i20', 'Tucson', 'Kona'], fact: 'Ime znači "savremenost" na korejskom.', body: 'suv', color: '#2980b9' },
    { id: 'kia', name: 'Kia', country: 'Južna Koreja', flag: '🇰🇷', founded: 1944, models: ['Sportage', 'Ceed', 'Picanto'], fact: 'Najstarija je korejska auto-marka.', body: 'citycar', color: '#c0392b' },
    { id: 'landrover', name: 'Land Rover', country: 'Velika Britanija', flag: '🇬🇧', founded: 1948, models: ['Defender', 'Discovery', 'Evoque'], fact: 'Dizajniran je po uzoru na vojni terenac.', body: 'offroad', color: '#145a32' },
    { id: 'mini', name: 'Mini', country: 'Velika Britanija', flag: '🇬🇧', founded: 1959, models: ['Cooper', 'Countryman'], fact: 'Napravljen je da bude što manji i da štedi benzin.', body: 'citycar', color: '#117a65' }
  ];
})();
