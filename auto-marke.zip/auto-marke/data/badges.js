// Originalni, izmišljeni amblemi za kviz (NISU pravi logoi marki — čisto
// geometrijski oblik + boja marke + slovo), tako da se "oseća" kao logo-kviz
// bez kopiranja ičijeg zaštićenog žiga.
(function () {
  'use strict';

  var SHAPES = ['circle', 'shield', 'diamond', 'hexagon', 'oval', 'square'];

  function hash(s) {
    var h = 0;
    for (var i = 0; i < s.length; i++) h = (h * 31 + s.charCodeAt(i)) >>> 0;
    return h;
  }

  function shade(hex, amt) {
    var c = hex.replace('#', '');
    var num = parseInt(c, 16);
    var r = Math.max(0, Math.min(255, (num >> 16) + amt));
    var g = Math.max(0, Math.min(255, ((num >> 8) & 0xff) + amt));
    var b = Math.max(0, Math.min(255, (num & 0xff) + amt));
    return '#' + ((1 << 24) + (r << 16) + (g << 8) + b).toString(16).slice(1);
  }

  function outline(shape) {
    var cx = 60, cy = 60;
    switch (shape) {
      case 'circle':
        return '<circle cx="' + cx + '" cy="' + cy + '" r="52"/>';
      case 'oval':
        return '<ellipse cx="' + cx + '" cy="' + cy + '" rx="54" ry="42"/>';
      case 'diamond':
        return '<path d="M60 6 L114 60 L60 114 L6 60 Z"/>';
      case 'hexagon':
        return '<path d="M60 6 L108 33 L108 87 L60 114 L12 87 L12 33 Z"/>';
      case 'square':
        return '<rect x="10" y="10" width="100" height="100" rx="18"/>';
      case 'shield':
      default:
        return '<path d="M60 6 L108 22 V58 C108 88 88 106 60 116 C32 106 12 88 12 58 V22 Z"/>';
    }
  }


  // tip karoserije po marki (za ilustraciju auta u amblemu)
  var BODY = { toyota:'suv', ford:'pickup', bmw:'sedan', mercedes:'limo', vw:'hatch', audi:'sedan', honda:'hatch',
    ferrari:'sport', lambo:'sport', nissan:'sport', porsche:'sport', jeep:'offroad', fiat:'city', tesla:'sedan',
    hyundai:'suv', chevrolet:'sport', renault:'hatch', peugeot:'hatch', kia:'city', mazda:'sport', volvo:'suv',
    landrover:'offroad', mini:'city', citroen:'city', subaru:'suv', mitsubishi:'suv', suzuki:'offroad', skoda:'sedan',
    opel:'hatch', seat:'hatch', dacia:'suv', alfa:'sport', jaguar:'sport', lexus:'suv', cadillac:'limo',
    chrysler:'limo', dodge:'sport', infiniti:'sedan', maserati:'sport', bentley:'limo', astonmartin:'sport', rollsroyce:'limo' };
  // jednostavna originalna silueta: [duzina, visina karoserije, visina krova, tockovi r, pickup]
  var T = { sedan:[64,12,12,7], hatch:[56,12,14,7], suv:[64,16,14,8], offroad:[62,17,14,9], pickup:[70,13,12,8,1],
    sport:[68,9,9,7], limo:[76,12,11,7], city:[48,14,15,6] };
  function carMini(body, fill) {
    var t = T[body] || T.sedan, L = t[0], bh = t[1], rh = t[2], wr = t[3];
    var x0 = 60 - L / 2, gy = 90, by = gy - bh, ty = by - rh;
    var s = '<rect x="' + x0 + '" y="' + by + '" width="' + L + '" height="' + bh + '" rx="5" fill="#fff" stroke="' + fill + '" stroke-width="2"/>';
    var r1 = x0 + L * (t[4] ? 0.40 : 0.26), r2 = x0 + L * 0.72;
    s += '<path d="M' + r1 + ' ' + by + ' L' + (r1 + 8) + ' ' + ty + ' L' + (r2 - 4) + ' ' + ty + ' L' + (r2 + 6) + ' ' + by + ' Z" fill="#fff" stroke="' + fill + '" stroke-width="2" stroke-linejoin="round"/>';
    [x0 + L * 0.25, x0 + L * 0.77].forEach(function (wx) {
      s += '<circle cx="' + wx + '" cy="' + gy + '" r="' + wr + '" fill="' + fill + '" stroke="#fff" stroke-width="2"/>';
    });
    return s;
  }

  function badgeSVG(brand) {
    var id = brand.id, color = brand.color;
    var dark = shade(color, -36), light = shade(color, 48);
    var shape = SHAPES[hash(id) % SHAPES.length];
    var letter = brand.name.replace('Ö', 'O').charAt(0).toUpperCase();
    var s = '<svg viewBox="0 0 120 120" xmlns="http://www.w3.org/2000/svg">';
    s += '<g fill="' + color + '" stroke="' + dark + '" stroke-width="4" stroke-linejoin="round">' + outline(shape) + '</g>';
    // tanak unutrašnji prsten (dekorativan, generički)
    s += '<g fill="none" stroke="' + light + '" stroke-width="2" opacity="0.8">' + outline(shape).replace(/r="52"/, 'r="44"').replace(/rx="54" ry="42"/, 'rx="46" ry="34"') + '</g>';
    // slovo marke
    s += '<text x="60" y="50" text-anchor="middle" font-family="Trebuchet MS, Arial, sans-serif" font-weight="900" font-size="32" fill="#fff" stroke="' + dark + '" stroke-width="1.5" paint-order="stroke">' + letter + '</text>';
    s += '<g transform="translate(0,1)">' + carMini(BODY[id] || 'sedan', dark) + '</g>';
    s += '</svg>';
    return s;
  }

  // Ako postoji fajl logos/<id>.svg (ili .png) koji korisnik sam ubaci, prikazuje se preko
  // amblema; ako ne postoji, slika se sama sakrije i ostaje originalni amblem.
  function badgeHTML(brand) {
    return '<span class="logobox">' + badgeSVG(brand) +
      '<img class="logoimg" alt="" src="logos/' + brand.id + '.svg" ' +
      'onerror="if(!this.dataset.t){this.dataset.t=1;this.src=\'logos/' + brand.id + '.png\';}else{this.remove();}">' +
      '</span>';
  }
  window.BADGES = { badgeSVG: badgeSVG, badgeHTML: badgeHTML, SHAPES: SHAPES };
})();
