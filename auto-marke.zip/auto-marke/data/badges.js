// Originalni, izmišljeni amblemi za kviz (NISU pravi logoi marki — čisto
// geometrijski oblik + boja marke + slovo), tako da se "oseća" kao logo-kviz
// bez kopiranja ičijeg zaštićenog žiga.
(function () {
  'use strict';

  var SHAPES = ['circle', 'shield', 'diamond', 'hexagon', 'oval', 'square'];

  function hash(s) {
    var h = 0;
    for (var i = 0; i < s.length; i++) h = (h * 31 + s.charCodeAt(i)) >>> 0;
    return h;
  }

  function shade(hex, amt) {
    var c = hex.replace('#', '');
    var num = parseInt(c, 16);
    var r = Math.max(0, Math.min(255, (num >> 16) + amt));
    var g = Math.max(0, Math.min(255, ((num >> 8) & 0xff) + amt));
    var b = Math.max(0, Math.min(255, (num & 0xff) + amt));
    return '#' + ((1 << 24) + (r << 16) + (g << 8) + b).toString(16).slice(1);
  }

  function outline(shape) {
    var cx = 60, cy = 60;
    switch (shape) {
      case 'circle':
        return '<circle cx="' + cx + '" cy="' + cy + '" r="52"/>';
      case 'oval':
        return '<ellipse cx="' + cx + '" cy="' + cy + '" rx="54" ry="42"/>';
      case 'diamond':
        return '<path d="M60 6 L114 60 L60 114 L6 60 Z"/>';
      case 'hexagon':
        return '<path d="M60 6 L108 33 L108 87 L60 114 L12 87 L12 33 Z"/>';
      case 'square':
        return '<rect x="10" y="10" width="100" height="100" rx="18"/>';
      case 'shield':
      default:
        return '<path d="M60 6 L108 22 V58 C108 88 88 106 60 116 C32 106 12 88 12 58 V22 Z"/>';
    }
  }

  function badgeSVG(brand) {
    var id = brand.id, color = brand.color;
    var dark = shade(color, -36), light = shade(color, 48);
    var shape = SHAPES[hash(id) % SHAPES.length];
    var letter = brand.name.replace('Ö', 'O').charAt(0).toUpperCase();
    var s = '<svg viewBox="0 0 120 120" xmlns="http://www.w3.org/2000/svg">';
    s += '<g fill="' + color + '" stroke="' + dark + '" stroke-width="4" stroke-linejoin="round">' + outline(shape) + '</g>';
    // tanak unutrašnji prsten (dekorativan, generički)
    s += '<g fill="none" stroke="' + light + '" stroke-width="2" opacity="0.8">' + outline(shape).replace(/r="52"/, 'r="44"').replace(/rx="54" ry="42"/, 'rx="46" ry="34"') + '</g>';
    // slovo marke
    s += '<text x="60" y="76" text-anchor="middle" font-family="Trebuchet MS, Arial, sans-serif" font-weight="900" font-size="50" fill="#fff" stroke="' + dark + '" stroke-width="1.5" paint-order="stroke">' + letter + '</text>';
    s += '</svg>';
    return s;
  }

  window.BADGES = { badgeSVG: badgeSVG, SHAPES: SHAPES };
})();
