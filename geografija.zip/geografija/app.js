(function () {
  'use strict';

  var ROUND = 10;
  var app = document.getElementById('app');
  var COUNTRIES = window.COUNTRIES, SHAPES = window.SHAPES, ILL = window.ILL;
  var TEXT_Q = window.TEXT_Q, NEIGHBORS = window.NEIGHBORS, AVOID = window.AVOID_PAIR || {};
  var byIso = {};
  COUNTRIES.forEach(function (c) { byIso[c.c] = c; });

  var CATS = [
    { id: 'zastave', name: 'Zastave', emo: '🚩', modes: true },
    { id: 'gradovi', name: 'Glavni gradovi', emo: '🏙️', modes: true },
    { id: 'granice', name: 'Granice', emo: '🗺️', modes: true },
    { id: 'strane', name: 'Strane sveta', emo: '🧭' },
    { id: 'slike', name: 'Pogodi sa slike', emo: '🖼️' },
    { id: 'reke', name: 'Reke', emo: '🌊' },
    { id: 'jezera', name: 'Jezera', emo: '🏞️' },
    { id: 'planine', name: 'Planine', emo: '⛰️' },
    { id: 'mora', name: 'Mora i okeani', emo: '🐋' },
    { id: 'vulkani', name: 'Vulkani', emo: '🌋' },
    { id: 'reljef', name: 'Reljef', emo: '🏔️' },
    { id: 'znamenitosti', name: 'Znamenitosti', emo: '🗼' },
    { id: 'mix', name: 'Mešano', emo: '🎲' }
  ];
  function catInfo(id) { return CATS.filter(function (c) { return c.id === id; })[0]; }
  var AVATARS = ['🦊', '🐼'];

  // ---------- pomoćne funkcije ----------
  function shuffle(a) {
    a = a.slice();
    for (var i = a.length - 1; i > 0; i--) {
      var j = Math.floor(Math.random() * (i + 1));
      var t = a[i]; a[i] = a[j]; a[j] = t;
    }
    return a;
  }
  function esc(s) {
    return String(s).replace(/[&<>"]/g, function (c) {
      return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c];
    });
  }
  function store(key, val) {
    try {
      if (val === undefined) return localStorage.getItem('geo_' + key);
      localStorage.setItem('geo_' + key, val);
    } catch (e) { return null; }
    return null;
  }
  function getBest(cat, m) {
    var v = store(cat + ':' + m);
    return v === null || v === undefined ? null : parseInt(v, 10);
  }
  function stars(score) { return score >= 9 ? 3 : score >= 7 ? 2 : score >= 4 ? 1 : 0; }
  function starText(n) { return '⭐'.repeat(n) + '☆'.repeat(3 - n); }
  function fmtTime(sec) { var m = Math.floor(sec / 60), s = sec % 60; return m + ':' + (s < 10 ? '0' : '') + s; }
  function sample(arr, n) { return shuffle(arr).slice(0, n); }

  // rekordi: po temi (i po režimu Evropa/Svet za zastave, gradove, granice)
  function getRec(id, m) {
    try { return JSON.parse(store('rec:' + id + ':' + m) || 'null'); } catch (e) { return null; }
  }
  function saveRec(id, m, name, s, t) { store('rec:' + id + ':' + m, JSON.stringify({ n: name, s: s, t: t })); }
  function beats(r, s, t) { return s > 0 && (!r || s > r.s || (s === r.s && t < r.t)); }
  function recText(r) { return r ? '🏆 ' + esc(r.n) + ' · ' + r.s + '/10' : '&nbsp;'; }

  var mode = store('mode') === 'w' ? 'w' : 'eu';

  function poolFor(filter) {
    return COUNTRIES.filter(function (c) {
      return (mode === 'w' || c.r === 'eu') && (!filter || filter(c));
    });
  }
  function flagImg(iso, cls) {
    return '<img class="' + (cls === undefined ? 'flag' : cls) + '" src="flags/' + iso + '.svg" alt="zastava">';
  }
  function shapeSvg(iso) {
    return '<svg class="shape" viewBox="0 0 200 200" role="img" aria-label="oblik države"><path d="' + SHAPES[iso] + '"/></svg>';
  }
  function opts(correctHtml, wrongHtmls) {
    return shuffle([{ html: correctHtml, correct: true }].concat(wrongHtmls.map(function (w) { return { html: w, correct: false }; })));
  }

  // ---------- generatori pitanja ----------
  function qFlag(c, pool) {
    var others = sample(pool.filter(function (x) { return x.c !== c.c; }), 3);
    if (Math.random() < 0.5) {
      return {
        big: flagImg(c.c), prompt: 'Koja država ima ovu zastavu?', answerText: c.n,
        options: opts(esc(c.n), others.map(function (o) { return esc(o.n); }))
      };
    }
    return {
      big: '<div class="big">🚩</div>', prompt: 'Pronađi zastavu: ' + c.n, answerText: c.n,
      options: opts(flagImg(c.c, ''), others.map(function (o) { return flagImg(o.c, ''); }))
    };
  }

  function qCapital(c, pool) {
    var others = sample(pool.filter(function (x) { return x.cap && x.c !== c.c; }), 3);
    if (Math.random() < 0.5) {
      return {
        big: flagImg(c.c), prompt: c.n + ' – koji je glavni grad ove države?', answerText: c.cap,
        options: opts(esc(c.cap), others.map(function (o) { return esc(o.cap); }))
      };
    }
    return {
      big: '<div class="big">🏙️</div>', prompt: c.cap + ' je glavni grad koje države?', answerText: c.n,
      options: opts(esc(c.n), others.map(function (o) { return esc(o.n); }))
    };
  }

  function qShape(c, pool) {
    var others = sample(pool.filter(function (x) { return x.c !== c.c; }), 3);
    return {
      big: shapeSvg(c.c), prompt: 'Koja država ima ovakav oblik?', answerText: c.n,
      options: opts(esc(c.n), others.map(function (o) { return esc(o.n); }))
    };
  }

  function qNeighbor(iso) {
    var c = byIso[iso];
    var good = NEIGHBORS[iso][Math.floor(Math.random() * NEIGHBORS[iso].length)];
    var avoid = (AVOID[iso] || []).concat(NEIGHBORS[iso], [iso]);
    var cand = Object.keys(NEIGHBORS).filter(function (k) { return avoid.indexOf(k) === -1; });
    var wrong = sample(cand, 3);
    return {
      big: flagImg(iso), prompt: 'Koja država se graniči sa državom: ' + c.n + '?', answerText: byIso[good].n,
      options: opts(esc(byIso[good].n), wrong.map(function (w) { return esc(byIso[w].n); }))
    };
  }

  // kompas: strelica pokazuje na stranu sveta
  var DIRS8 = [[0, 'sever'], [45, 'severoistok'], [90, 'istok'], [135, 'jugoistok'], [180, 'jug'], [225, 'jugozapad'], [270, 'zapad'], [315, 'severozapad']];
  function qArrow() {
    var pick = Math.random() < 0.7 ? DIRS8[Math.floor(Math.random() * 4) * 2] : DIRS8[Math.floor(Math.random() * 8)];
    var others = sample(DIRS8.filter(function (d) { return d[1] !== pick[1]; }), 3);
    return {
      big: '<div class="illwrap">' + ILL.compass(pick[0]) + '</div>',
      prompt: 'Na koju stranu sveta pokazuje narandžasta strelica?', answerText: pick[1],
      options: opts(esc(pick[1]), others.map(function (o) { return esc(o[1]); }))
    };
  }

  // kompas: klikni na traženu stranu (ruža vetrova je ponekad okrenuta!)
  function qClick(targetIdx) {
    var names = ['sever', 'istok', 'jug', 'zapad'];
    var rot = [0, 90, 180, 270][Math.floor(Math.random() * 4)];
    var R = 84, a = rot * Math.PI / 180;
    var svg = '<svg class="click" viewBox="0 0 300 240" role="group" aria-label="kompas"><g transform="translate(30 0)">' + ILL.rose(rot) + '</g>' +
      '<text x="' + (150 + 106 * Math.sin(a)).toFixed(1) + '" y="' + (120 - 106 * Math.cos(a) + 4).toFixed(1) +
      '" text-anchor="middle" font-size="13" font-weight="800" fill="#e5584f">SEVER</text>';
    names.forEach(function (n, i) {
      var ang = (i * 90 + rot) * Math.PI / 180;
      var x = 150 + R * Math.sin(ang), y = 120 - R * Math.cos(ang);
      svg += '<g class="hit" data-i="' + i + '" tabindex="0" role="button" aria-label="strana sveta">' +
        '<circle cx="' + x.toFixed(1) + '" cy="' + y.toFixed(1) + '" r="17"/>' +
        '<text class="lbl" x="' + x.toFixed(1) + '" y="' + (y + 5).toFixed(1) + '" text-anchor="middle" font-size="15" font-weight="800">' + n.charAt(0).toUpperCase() + '</text></g>';
    });
    svg += '</svg>';
    return {
      click: true, big: svg,
      prompt: 'Sever je označen crvenom bojom. Klikni na ' + names[targetIdx].toUpperCase() + '!',
      answerText: names[targetIdx],
      options: names.map(function (n, i) { return { html: n, correct: i === targetIdx }; })
    };
  }

  function textQuestions(cat, n) {
    return sample(TEXT_Q[cat], n).map(function (t) {
      var big = t[4] && ILL[t[4]]
        ? '<div class="illwrap">' + (t[4] === 'compass' ? ILL.compass() : ILL[t[4]]()) + '</div>'
        : '<div class="big">' + t[3] + '</div>';
      return { big: big, prompt: t[0], answerText: t[1], options: opts(esc(t[1]), t[2].map(esc)) };
    });
  }

  var MIX_IDS = ['zastave', 'gradovi', 'granice', 'strane', 'slike', 'reke', 'jezera', 'planine', 'mora', 'vulkani', 'reljef', 'znamenitosti'];

  function buildRound(cat) {
    var list;
    if (cat === 'zastave') {
      var pf = poolFor();
      return sample(pf, ROUND).map(function (c) { return qFlag(c, pf); });
    }
    if (cat === 'gradovi') {
      var pc = poolFor(function (c) { return c.cap; });
      return sample(pc, ROUND).map(function (c) { return qCapital(c, pc); });
    }
    if (cat === 'granice') {
      var ps = poolFor(function (c) { return c.s; });
      var shapes = sample(ps, 6).map(function (c) { return qShape(c, ps); });
      var nb = sample(Object.keys(NEIGHBORS), 4).map(qNeighbor);
      return shuffle(shapes.concat(nb));
    }
    if (cat === 'strane') {
      var t = shuffle([1, 2, 3]);
      list = [qClick(t[0]), qClick(t[1]), qClick(t[2]), qArrow(), qArrow()].concat(textQuestions('strane', 5));
      return shuffle(list);
    }
    if (cat === 'mix') {
      list = [];
      sample(MIX_IDS, ROUND).forEach(function (id) {
        var r = buildRound(id);
        list.push(r[Math.floor(Math.random() * r.length)]);
      });
      return shuffle(list);
    }
    return textQuestions(cat, ROUND);
  }

  // ---------- ekrani ----------
  var state = null;

  function modeSeg() {
    return '<div class="seg" role="group" aria-label="Zastave, gradovi i granice važe za">' +
      '<button data-mode="eu" class="' + (mode === 'eu' ? 'on' : '') + '">🇪🇺 Evropa</button>' +
      '<button data-mode="w" class="' + (mode === 'w' ? 'on' : '') + '">🌍 Ceo svet</button></div>';
  }
  function bindMode(refresh) {
    Array.prototype.forEach.call(app.querySelectorAll('[data-mode]'), function (b) {
      b.addEventListener('click', function () { mode = b.getAttribute('data-mode'); store('mode', mode); refresh(); });
    });
  }

  function home() {
    state = null;
    var h = '<h1>🌍 Geografija za male istraživače</h1>';
    h += '<p class="sub">Biraj temu i odgovori na 10 pitanja. Nema žurbe, a svaka greška je prilika da naučiš! 🙂</p>';
    h += '<div class="row top2"><button class="btn duel" id="duel">⚔️ Takmičenje za dvoje</button><button class="btn" id="board">🏆 Tabela</button></div>';
    h += modeSeg();
    h += '<div class="grid">';
    CATS.forEach(function (c) {
      var best = getBest(c.id, c.modes ? mode : '-');
      var rec = getRec(c.id, c.modes ? mode : '-');
      h += '<button class="cat" data-cat="' + c.id + '"><span class="emo">' + c.emo + '</span><span class="name">' + c.name +
        '</span><span class="stars">' + (best === null ? '&nbsp;' : starText(stars(best))) + '</span><span class="rec">' + recText(rec) + '</span></button>';
    });
    h += '</div>';
    app.innerHTML = h;
    bindMode(home);
    document.getElementById('duel').addEventListener('click', duelSetup);
    document.getElementById('board').addEventListener('click', leaderboard);
    Array.prototype.forEach.call(app.querySelectorAll('[data-cat]'), function (b) {
      b.addEventListener('click', function () { start(b.getAttribute('data-cat')); });
    });
  }

  function start(cat) {
    state = { duel: false, cat: cat, info: catInfo(cat), qs: buildRound(cat), i: 0, score: 0, t0: Date.now() };
    question();
  }

  function question() {
    var q = state.qs[state.i];
    var h = '<div class="top"><button class="btn" id="back">⬅ Nazad</button>' +
      '<div class="progress"><i style="width:' + (state.i / state.qs.length * 100) + '%"></i></div>' +
      '<span class="count">' + (state.i + 1) + ' / ' + state.qs.length + '</span></div>';
    if (state.duel) {
      var pl = state.players[state.p];
      h += '<div class="badge p' + state.p + '">' + AVATARS[state.p] + ' ' + esc(pl.name) + ' je na potezu</div>';
    }
    h += '<section class="qcard">' + q.big + '<h2>' + esc(q.prompt) + '</h2>';
    if (!q.click) {
      h += '<div class="opts">';
      q.options.forEach(function (o, idx) { h += '<button class="opt" data-i="' + idx + '">' + o.html + '</button>'; });
      h += '</div>';
    }
    h += '<div class="fb" id="fb"></div><button class="btn next" id="next" hidden>Dalje ➜</button></section>';
    app.innerHTML = h;
    document.getElementById('back').addEventListener('click', function () {
      if (!state.duel || window.confirm('Prekinuti takmičenje?')) home();
    });
    var btns = Array.prototype.slice.call(app.querySelectorAll(q.click ? '.hit' : '.opt'));
    btns.forEach(function (b) {
      var go = function () { answer(q, btns, parseInt(b.getAttribute('data-i'), 10)); };
      b.addEventListener('click', go);
      if (q.click) {
        b.addEventListener('keydown', function (e) { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); go(); } });
      }
    });
  }

  var PRAISE = ['Bravo! 🎉', 'Tačno! ⭐', 'Super! 👏', 'Odlično! 🌟', 'Tako se to radi! 💪'];

  function answer(q, btns, idx) {
    if (state.locked) return;
    state.locked = true;
    var ok = q.options[idx].correct;
    btns.forEach(function (b, i) {
      b.disabled = true;
      if (q.options[i].correct) b.classList.add('good');
      else if (i === idx) b.classList.add('bad');
    });
    var svg = app.querySelector('svg.click');
    if (svg) svg.classList.add('done');
    if (ok) {
      if (state.duel) state.players[state.p].score++; else state.score++;
    }
    var fb = document.getElementById('fb');
    fb.className = 'fb ' + (ok ? 'good' : 'bad');
    fb.textContent = ok ? PRAISE[Math.floor(Math.random() * PRAISE.length)] : 'Skoro! Tačan odgovor je: ' + q.answerText;
    var next = document.getElementById('next');
    next.hidden = false;
    next.textContent = state.i === state.qs.length - 1 ? 'Završi 🏁' : 'Dalje ➜';
    next.addEventListener('click', function () {
      state.locked = false;
      state.i++;
      if (state.i >= state.qs.length) { state.duel ? duelTurnEnd() : finish(); } else question();
    });
    next.focus();
  }

  function finish() {
    var s = state.score;
    var m = state.info.modes ? mode : '-';
    var prev = getBest(state.info.id, m);
    if (prev === null || s > prev) store(state.info.id + ':' + m, String(s));
    state.t = Math.round((Date.now() - state.t0) / 1000);
    state.isRec = beats(getRec(state.info.id, m), s, state.t);
    renderResult();
  }

  function renderResult() {
    var s = state.score, n = state.qs.length, m = state.info.modes ? mode : '-';
    var msg = s >= 9 ? 'Bravo, pravi istraživač! 🏆' : s >= 7 ? 'Odlično ti ide! 🎉' : s >= 4 ? 'Dobro! Još malo vežbe i biće sjajno. 💪' : 'Ništa zato — učiš dok igraš. Probaj ponovo! 🌱';
    var rec = getRec(state.info.id, m);
    var h = '<section class="qcard result"><div class="big">' + state.info.emo + '</div>' +
      '<div class="stars">' + starText(stars(s)) + '</div>' +
      '<p class="score">' + s + ' od ' + n + '</p><h2>' + msg + '</h2>';
    if (state.isRec) {
      h += '<div class="newrec"><div>🎉 <b>Novi rekord!</b> Upiši svoje ime:</div>' +
        '<div class="rrow"><input id="rn" maxlength="14" placeholder="Ime" value="' + esc(store('lastname') || '') + '"><button class="btn next" id="saverec">Sačuvaj 🏆</button></div></div>';
    } else if (rec) {
      h += '<p class="recline">🏆 Rekord u ovoj temi: <b>' + esc(rec.n) + '</b> — ' + rec.s + '/10 (' + fmtTime(rec.t) + ')</p>';
    }
    h += '<div class="row"><button class="btn next" id="again">🔁 Igraj ponovo</button><button class="btn" id="menu">🏠 Sve teme</button></div></section>';
    app.innerHTML = h;
    var cat = state.info.id;
    document.getElementById('again').addEventListener('click', function () { start(cat); });
    document.getElementById('menu').addEventListener('click', home);
    var sv = document.getElementById('saverec');
    if (sv) {
      var save = function () {
        var name = document.getElementById('rn').value.trim() || 'Igrač';
        store('lastname', name);
        saveRec(state.info.id, m, name, s, state.t);
        state.isRec = false;
        renderResult();
      };
      sv.addEventListener('click', save);
      document.getElementById('rn').addEventListener('keydown', function (e) { if (e.key === 'Enter') save(); });
    }
  }

  // ---------- takmičenje za dvoje ----------
  var lastDuel = { names: ['', ''], cat: 'mix' };

  function duelSetup() {
    state = null;
    var h = '<div class="top"><button class="btn" id="back">⬅ Nazad</button></div>';
    h += '<h1>⚔️ Takmičenje</h1><p class="sub">Oba igrača dobijaju ista pitanja, jedan za drugim. Pobeđuje ko ima više tačnih odgovora!</p>';
    h += '<section class="qcard setup">';
    h += '<label class="nm p0">' + AVATARS[0] + ' <input id="n0" maxlength="14" placeholder="Igrač 1" value="' + esc(lastDuel.names[0]) + '"></label>';
    h += '<label class="nm p1">' + AVATARS[1] + ' <input id="n1" maxlength="14" placeholder="Igrač 2" value="' + esc(lastDuel.names[1]) + '"></label>';
    h += '<h2>Tema takmičenja</h2><div class="chips" role="radiogroup">';
    CATS.forEach(function (c) {
      h += '<button class="chip' + (c.id === lastDuel.cat ? ' on' : '') + '" data-cat="' + c.id + '" role="radio">' + c.emo + ' ' + c.name + '</button>';
    });
    h += '</div>' + modeSeg() + '<button class="btn next" id="go">Počni! ▶</button></section>';
    app.innerHTML = h;
    bindMode(function () { saveNames(); duelSetup(); });
    document.getElementById('back').addEventListener('click', home);
    var sel = lastDuel.cat;
    Array.prototype.forEach.call(app.querySelectorAll('.chip'), function (b) {
      b.addEventListener('click', function () {
        sel = b.getAttribute('data-cat');
        lastDuel.cat = sel;
        Array.prototype.forEach.call(app.querySelectorAll('.chip'), function (x) { x.classList.toggle('on', x === b); });
      });
    });
    function saveNames() {
      lastDuel.names = [document.getElementById('n0').value.trim(), document.getElementById('n1').value.trim()];
    }
    document.getElementById('go').addEventListener('click', function () {
      saveNames();
      duelStart(lastDuel.names[0] || 'Igrač 1', lastDuel.names[1] || 'Igrač 2', sel);
    });
  }

  function duelStart(n0, n1, cat) {
    state = {
      duel: true, cat: cat, info: catInfo(cat), qs: buildRound(cat), i: 0, p: 0,
      players: [{ name: n0, score: 0, t: 0 }, { name: n1, score: 0, t: 0 }]
    };
    duelTurnStart();
  }

  function duelTurnStart() {
    var pl = state.players[state.p];
    state.i = 0;
    app.innerHTML = '<section class="qcard result"><div class="big">' + AVATARS[state.p] + '</div>' +
      '<h2>' + (state.p === 0 ? 'Prvi na redu: ' : 'Sada je na redu: ') + esc(pl.name) + '!</h2>' +
      '<p class="sub">Tema: ' + state.info.emo + ' ' + state.info.name + '</p>' +
      '<div class="row"><button class="btn next" id="ready">Spreman sam! ▶</button></div></section>';
    document.getElementById('ready').addEventListener('click', function () {
      state.t0 = Date.now();
      question();
    });
  }

  function duelTurnEnd() {
    var pl = state.players[state.p];
    pl.t = Math.round((Date.now() - state.t0) / 1000);
    if (state.p === 0) {
      state.p = 1;
      app.innerHTML = '<section class="qcard result"><div class="big">🎉</div><h2>Kraj kruga za ' + esc(pl.name) + '!</h2>' +
        '<p class="sub">Rezultat se otkriva na kraju. Predaj uređaj: ' + esc(state.players[1].name) + ' je na redu!</p>' +
        '<div class="row"><button class="btn next" id="cont">Nastavi ▶</button></div></section>';
      document.getElementById('cont').addEventListener('click', duelTurnStart);
    } else {
      duelResult();
    }
  }

  function addBoard(entries) {
    var arr = [];
    try { arr = JSON.parse(store('board') || '[]'); } catch (e) { arr = []; }
    arr = arr.concat(entries);
    arr.sort(function (a, b) { return b.s - a.s || a.t - b.t; });
    store('board', JSON.stringify(arr.slice(0, 50)));
  }

  function duelResult() {
    var a = state.players[0], b = state.players[1], n = state.qs.length;
    var cname = state.info.emo + ' ' + state.info.name;
    addBoard([a, b].map(function (p) { return { n: p.name, s: p.score, t: p.t, c: cname, q: n }; }));
    var rm = state.info.modes ? mode : '-';
    var newRec = [a, b].map(function (p) {
      var ok = beats(getRec(state.cat, rm), p.score, p.t);
      if (ok) saveRec(state.cat, rm, p.name, p.score, p.t);
      return ok;
    });
    var banner;
    if (a.score === b.score) banner = '🤝 Nerešeno! Obojica imate ' + a.score + '.';
    else banner = '🏆 Pobednik je ' + esc(a.score > b.score ? a.name : b.name) + '!';
    var win = a.score === b.score ? -1 : (a.score > b.score ? 0 : 1);
    var h = '<section class="qcard result"><h2 class="banner">' + banner + '</h2><div class="vs">';
    [a, b].forEach(function (p, i) {
      h += '<div class="pcard p' + i + (win === i ? ' win' : '') + '"><div class="big">' + AVATARS[i] + (win === i ? '👑' : '') + '</div>' +
        '<div class="pn">' + esc(p.name) + '</div><div class="score">' + p.score + ' / ' + n + '</div>' +
        '<div>' + starText(stars(p.score)) + '</div><div class="tm">⏱ ' + fmtTime(p.t) + '</div>' + (newRec[i] ? '<div class="newtag">🏆 Novi rekord!</div>' : '') + '</div>';
    });
    h += '</div><div class="row"><button class="btn next" id="rematch">🔁 Revanš</button>' +
      '<button class="btn" id="board">🏆 Tabela</button><button class="btn" id="menu">🏠 Sve teme</button></div></section>';
    app.innerHTML = h;
    var names = [a.name, b.name], cat = state.cat;
    document.getElementById('rematch').addEventListener('click', function () { duelStart(names[0], names[1], cat); });
    document.getElementById('board').addEventListener('click', leaderboard);
    document.getElementById('menu').addEventListener('click', home);
  }

  function leaderboard() {
    var arr = [];
    try { arr = JSON.parse(store('board') || '[]'); } catch (e) { arr = []; }
    var h = '<div class="top"><button class="btn" id="back">⬅ Nazad</button></div><h1>🏆 Tabela rezultata</h1>';
    var rrows = '';
    CATS.forEach(function (c) {
      (c.modes ? ['eu', 'w'] : ['-']).forEach(function (m) {
        var r = getRec(c.id, m);
        if (r) rrows += '<tr><td>' + c.emo + ' ' + c.name + (c.modes ? (m === 'eu' ? ' (Evropa)' : ' (Svet)') : '') + '</td><td>' + esc(r.n) + '</td><td>' + r.s + '/10</td><td>' + fmtTime(r.t) + '</td></tr>';
      });
    });
    if (rrows) {
      h += '<section class="qcard"><h2>🥇 Rekordi po temama</h2><table class="board"><thead><tr><th>Tema</th><th>Ime</th><th>Poeni</th><th>Vreme</th></tr></thead><tbody>' + rrows + '</tbody></table></section>';
    }
    if (!arr.length) {
      if (!rrows) h += '<p class="sub">Još nema rezultata. Igrajte i oborite rekord! ⚔️</p>';
    } else {
      h += '<section class="qcard"><h2>⚔️ Takmičenja za dvoje</h2><table class="board"><thead><tr><th>#</th><th>Ime</th><th>Poeni</th><th>Tema</th><th>Vreme</th></tr></thead><tbody>';
      arr.slice(0, 10).forEach(function (r, i) {
        h += '<tr><td>' + (i === 0 ? '🥇' : i === 1 ? '🥈' : i === 2 ? '🥉' : (i + 1)) + '</td><td>' + esc(r.n) + '</td><td>' + r.s + '/' + (r.q || 10) +
          '</td><td>' + esc(r.c) + '</td><td>' + fmtTime(r.t) + '</td></tr>';
      });
      h += '</tbody></table><div class="row"><button class="btn" id="clear">🗑️ Obriši tabelu</button></div></section>';
    }
    app.innerHTML = h;
    document.getElementById('back').addEventListener('click', home);
    var clr = document.getElementById('clear');
    if (clr) clr.addEventListener('click', function () {
      if (window.confirm('Obrisati sve rezultate?')) { store('board', '[]'); leaderboard(); }
    });
  }

  home();
})();
