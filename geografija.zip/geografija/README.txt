GEOGRAFIJA ZA MALE ISTRAZIVACE (uzrast 7-10)

Pokretanje: raspakuj zip i dvaput klikni na index.html (radi u običnom pregledaču, bez interneta).

Teme: strane sveta (interaktivni kompas), pogodi sa slike, zastave, glavni gradovi, granice (oblici država + ko se s kim graniči), reke, jezera,
planine, mora i okeani, vulkani, reljef, znamenitosti, mešano. Evropa / Ceo svet važi za
zastave, gradove i granice.

Dodavanje pitanja: otvori data/questions.js, u odgovarajuću listu dodaj red:
  ['Pitanje?', 'Tačan odgovor', ['Netačan 1', 'Netačan 2', 'Netačan 3'], '🌊'],

Dodavanje država: data/countries.js (zastave su u flags/ kao <oznaka>.svg).

Izvori: zastave - flag-icons (MIT licenca); oblici država - Natural Earth (javno vlasništvo).

Rekordi: na svakoj temi piše ko drži rekord (ime, poeni); ko ga obori upisuje svoje ime. Svi rekordi su i u "Tabela".
Takmičenje za dvoje: dugme "Takmičenje za dvoje" na početnom ekranu. Oba igrača dobijaju ista pitanja jedan za drugim;
rezultati se čuvaju u tabeli (u pregledaču na kome se igra).
Slike su nacrtane u kodu (data/illustrations.js).
