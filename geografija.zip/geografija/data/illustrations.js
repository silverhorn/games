// Nacrtane ilustracije (SVG) — bez interneta i bez spoljnih slika
(function () {
  var A = 'xmlns="http://www.w3.org/2000/svg" viewBox="0 0 240 160" class="ill" role="img" aria-label="ilustracija"';
  var SEA = '#3fa7e8', SAND = '#f3dd9b', GRASS = '#62b36a', DARK = '#2f8f4e';
  var ILL = {};

  function waves(color) {
    var s = '';
    [[20, 20], [150, 30], [70, 140], [185, 120], [30, 105], [205, 70]].forEach(function (p) {
      s += '<path d="M' + p[0] + ' ' + p[1] + ' q6 -5 12 0 t12 0" stroke="' + color + '" stroke-width="2" fill="none" stroke-linecap="round" opacity=".6"/>';
    });
    return s;
  }

  // ----- kompas -----
  // ruža vetrova u kutiji 240x240, centar (120,120); rot = obrtanje u stepenima
  ILL.rose = function (rot) {
    var h = '<circle cx="120" cy="120" r="92" fill="#fff" stroke="#2d7ff9" stroke-width="5"/>' +
      '<circle cx="120" cy="120" r="78" fill="#eaf6ff" stroke="#9fc4f0" stroke-width="2"/>';
    h += '<g transform="rotate(' + (rot || 0) + ' 120 120)">';
    for (var a = 45; a < 360; a += 90) {
      h += '<polygon points="120,62 126,120 114,120" fill="#b9c8d8" transform="rotate(' + a + ' 120 120)"/>';
    }
    h += '<polygon points="120,36 131,120 109,120" fill="#e5584f"/>' +
      '<polygon points="204,120 120,131 120,109" fill="#5c6f82"/>' +
      '<polygon points="120,204 109,120 131,120" fill="#5c6f82"/>' +
      '<polygon points="36,120 120,109 120,131" fill="#5c6f82"/>';
    h += '</g><circle cx="120" cy="120" r="7" fill="#ffc83d" stroke="#1f2d3d" stroke-width="2"/>';
    return h;
  };

  ILL.compass = function (arrow) {
    var h = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 300 240" class="ill compass" role="img" aria-label="kompas">';
    h += '<g transform="translate(30 0)">' + ILL.rose(0);
    if (arrow !== null && arrow !== undefined) {
      h += '<g transform="rotate(' + arrow + ' 120 120)">' +
        '<line x1="120" y1="120" x2="120" y2="58" stroke="#fff" stroke-width="13" stroke-linecap="round"/>' +
        '<polygon points="120,28 100,64 140,64" fill="#fff"/>' +
        '<line x1="120" y1="120" x2="120" y2="58" stroke="#ff8a1f" stroke-width="7" stroke-linecap="round"/>' +
        '<polygon points="120,34 105,62 135,62" fill="#ff8a1f"/></g>' +
        '<circle cx="120" cy="120" r="8" fill="#ffc83d" stroke="#1f2d3d" stroke-width="2"/>';
    }
    h += '</g>';
    h += '<g font-size="13" font-weight="800" fill="#1f2d3d" font-family="Trebuchet MS,Segoe UI,sans-serif">' +
      '<text x="150" y="16" text-anchor="middle" fill="#e5584f">SEVER</text>' +
      '<text x="150" y="236" text-anchor="middle">JUG</text>' +
      '<text x="250" y="125" text-anchor="start">ISTOK</text>' +
      '<text x="50" y="125" text-anchor="end">ZAPAD</text></g></svg>';
    return h;
  };

  // ----- Sunce i nebo -----
  ILL.sunrise = function () {
    var rays = '';
    for (var a = -80; a <= 80; a += 20) {
      var r = a * Math.PI / 180;
      rays += '<line x1="' + (120 + 36 * Math.sin(r)).toFixed(1) + '" y1="' + (110 - 36 * Math.cos(r)).toFixed(1) +
        '" x2="' + (120 + 54 * Math.sin(r)).toFixed(1) + '" y2="' + (110 - 54 * Math.cos(r)).toFixed(1) +
        '" stroke="#fff6b0" stroke-width="3" stroke-linecap="round"/>';
    }
    return '<svg ' + A + '><defs><linearGradient id="gsr" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#6f9bff"/><stop offset=".65" stop-color="#ffc58a"/><stop offset="1" stop-color="#ff9d6c"/></linearGradient></defs>' +
      '<rect width="240" height="160" fill="url(#gsr)"/>' + rays +
      '<circle cx="120" cy="110" r="30" fill="#fff6b0"/>' +
      '<path d="M0 112 Q30 96 62 108 T124 106 T190 100 T240 108 V160 H0Z" fill="#5f9a62"/>' +
      '<path d="M0 132 Q50 118 100 130 T240 126 V160 H0Z" fill="#477f4d"/></svg>';
  };

  ILL.sunset = function () {
    return '<svg ' + A + '><defs><linearGradient id="gss" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#3b3f8f"/><stop offset=".6" stop-color="#ff7a59"/><stop offset="1" stop-color="#ffd08a"/></linearGradient></defs>' +
      '<rect width="240" height="160" fill="url(#gss)"/>' +
      '<circle cx="120" cy="104" r="28" fill="#ffe27a"/>' +
      '<rect y="112" width="240" height="48" fill="#2d5f9a"/>' +
      '<rect x="98" y="118" width="44" height="3" rx="1.5" fill="#ffd27a"/><rect x="104" y="127" width="32" height="3" rx="1.5" fill="#ffd27a" opacity=".8"/><rect x="110" y="136" width="20" height="3" rx="1.5" fill="#ffd27a" opacity=".6"/></svg>';
  };

  ILL.noon = function () {
    var rays = '';
    for (var a = 0; a < 360; a += 30) {
      var r = a * Math.PI / 180;
      rays += '<line x1="' + (190 + 26 * Math.sin(r)).toFixed(1) + '" y1="' + (34 - 26 * Math.cos(r)).toFixed(1) +
        '" x2="' + (190 + 36 * Math.sin(r)).toFixed(1) + '" y2="' + (34 - 36 * Math.cos(r)).toFixed(1) +
        '" stroke="#ffd23d" stroke-width="3" stroke-linecap="round"/>';
    }
    return '<svg ' + A + '><rect width="240" height="160" fill="#8fd0ff"/>' + rays +
      '<circle cx="190" cy="34" r="20" fill="#ffd23d"/>' +
      '<ellipse cx="60" cy="30" rx="26" ry="9" fill="#fff"/><ellipse cx="78" cy="24" rx="16" ry="8" fill="#fff"/>' +
      '<rect y="118" width="240" height="42" fill="#6cc17d"/>' +
      '<ellipse cx="70" cy="126" rx="24" ry="5" fill="#000" opacity=".2"/>' +
      '<rect x="66" y="88" width="8" height="38" fill="#8a5a2b"/>' +
      '<circle cx="70" cy="76" r="22" fill="' + DARK + '"/><circle cx="55" cy="88" r="15" fill="' + DARK + '"/><circle cx="85" cy="88" r="15" fill="' + DARK + '"/></svg>';
  };

  ILL.night = function () {
    var stars = [[20, 20, 1.2], [60, 38, 1], [95, 16, 1.4], [200, 28, 1.1], [220, 70, 1.3], [180, 90, 1], [30, 70, 1], [210, 120, 1.2], [130, 70, 1], [170, 60, 1], [15, 120, 1.1], [100, 60, 1.2], [225, 20, 1.3], [75, 80, 1]];
    var s = '<svg ' + A + '><rect width="240" height="160" fill="#0f1b3d"/>';
    stars.forEach(function (p) { s += '<circle cx="' + p[0] + '" cy="' + p[1] + '" r="' + p[2] + '" fill="#fff" opacity=".85"/>'; });
    var d = [[52, 110], [76, 106], [96, 116], [118, 124], [120, 143], [150, 140], [150, 120], [118, 124]];
    s += '<polyline points="' + d.map(function (p) { return p.join(','); }).join(' ') + '" fill="none" stroke="#9fb7ff" stroke-width="1.5"/>';
    s += '<line x1="150" y1="134" x2="150" y2="50" stroke="#ffd36b" stroke-width="1.5" stroke-dasharray="4 4"/>';
    d.slice(0, 7).forEach(function (p) { s += '<circle cx="' + p[0] + '" cy="' + p[1] + '" r="3.2" fill="#fff"/>'; });
    s += '<circle cx="150" cy="40" r="11" fill="#fff6b0" opacity=".3"/><circle cx="150" cy="40" r="5" fill="#fff6b0"/>' +
      '<line x1="150" y1="30" x2="150" y2="50" stroke="#fff6b0" stroke-width="1.2"/><line x1="140" y1="40" x2="160" y2="40" stroke="#fff6b0" stroke-width="1.2"/>';
    s += '<path d="M0 154 Q60 148 120 154 T240 152 V160 H0Z" fill="#07101f"/></svg>';
    return s;
  };

  // ----- oblici reljefa -----
  ILL.island = function () {
    return '<svg ' + A + '><rect width="240" height="160" fill="' + SEA + '"/>' + waves('#fff') +
      '<path d="M55 92 C52 48 108 28 152 44 C200 54 206 102 168 124 C130 144 62 138 55 92Z" fill="' + SAND + '"/>' +
      '<path d="M70 90 C68 58 112 42 148 54 C186 62 190 98 160 112 C128 128 76 124 70 90Z" fill="' + GRASS + '"/>' +
      '<path d="M118 92 Q124 78 120 64" stroke="#8a5a2b" stroke-width="4" fill="none" stroke-linecap="round"/>' +
      '<g transform="translate(120 64)" fill="' + DARK + '"><ellipse rx="16" ry="4" transform="rotate(-25)"/><ellipse rx="16" ry="4" transform="rotate(25)"/><ellipse rx="16" ry="4" transform="rotate(-70)"/><ellipse rx="16" ry="4" transform="rotate(70)"/></g></svg>';
  };

  ILL.peninsula = function () {
    return '<svg ' + A + '><rect width="240" height="160" fill="' + SEA + '"/>' + waves('#fff') +
      '<path d="M0 0 H240 V34 C240 46 170 44 152 56 L152 118 C152 140 98 140 98 118 L98 56 C80 44 0 46 0 34 Z" fill="' + GRASS + '" stroke="' + SAND + '" stroke-width="5" stroke-linejoin="round"/>' +
      '<circle cx="125" cy="84" r="8" fill="' + DARK + '"/><circle cx="125" cy="106" r="8" fill="' + DARK + '"/><circle cx="40" cy="18" r="9" fill="' + DARK + '"/><circle cx="200" cy="16" r="9" fill="' + DARK + '"/></svg>';
  };

  ILL.bay = function () {
    var land = 'M0 0 H240 V116 Q200 124 160 114 T0 118 Z';
    return '<svg ' + A + '><defs><clipPath id="cbay"><path d="' + land + '"/></clipPath></defs>' +
      '<rect width="240" height="160" fill="' + SEA + '"/>' + waves('#fff') +
      '<path d="' + land + '" fill="' + GRASS + '"/>' +
      '<g clip-path="url(#cbay)"><circle cx="120" cy="120" r="52" fill="' + SAND + '"/><circle cx="120" cy="120" r="46" fill="' + SEA + '"/></g>' +
      '<circle cx="40" cy="40" r="10" fill="' + DARK + '"/><circle cx="200" cy="50" r="10" fill="' + DARK + '"/><circle cx="120" cy="28" r="10" fill="' + DARK + '"/></svg>';
  };

  ILL.strait = function () {
    return '<svg ' + A + '><rect width="240" height="160" fill="' + SEA + '"/>' + waves('#fff') +
      '<path d="M0 0H240V45 C200 48 170 62 120 62 C70 62 40 48 0 45Z" fill="' + GRASS + '" stroke="' + SAND + '" stroke-width="4"/>' +
      '<path d="M0 160H240V115 C200 112 170 98 120 98 C70 98 40 112 0 115Z" fill="' + GRASS + '" stroke="' + SAND + '" stroke-width="4"/>' +
      '<circle cx="60" cy="20" r="9" fill="' + DARK + '"/><circle cx="180" cy="22" r="9" fill="' + DARK + '"/><circle cx="60" cy="140" r="9" fill="' + DARK + '"/><circle cx="180" cy="138" r="9" fill="' + DARK + '"/></svg>';
  };

  ILL.delta = function () {
    var br = [[52, 124], [86, 134], [120, 138], [154, 134], [188, 124]];
    var s = '<svg ' + A + '><rect width="240" height="160" fill="' + SEA + '"/>' + waves('#fff') +
      '<path d="M0 0 H240 V50 Q180 58 135 54 L196 118 Q160 146 120 142 Q80 146 44 118 L105 54 Q60 58 0 50 Z" fill="' + GRASS + '" stroke="' + SAND + '" stroke-width="4" stroke-linejoin="round"/>';
    s += '<path d="M120 0 V56" stroke="' + SEA + '" stroke-width="8" fill="none"/>';
    br.forEach(function (p) {
      s += '<path d="M120 56 Q' + ((120 + p[0]) / 2) + ' ' + (56 + (p[1] - 56) * 0.5) + ' ' + p[0] + ' ' + p[1] + '" stroke="' + SEA + '" stroke-width="4" fill="none" stroke-linecap="round"/>';
    });
    return s + '</svg>';
  };

  ILL.lake = function () {
    return '<svg ' + A + '><rect width="240" height="160" fill="#7fcf7a"/>' +
      '<path d="M45 80 C45 40 100 28 140 40 C190 52 210 90 175 115 C140 140 60 130 45 80Z" fill="' + SEA + '" stroke="' + SAND + '" stroke-width="5"/>' +
      '<path d="M90 70 q8 -5 16 0 t16 0" stroke="#fff" stroke-width="2" fill="none" opacity=".7"/><path d="M110 92 q8 -5 16 0 t16 0" stroke="#fff" stroke-width="2" fill="none" opacity=".7"/>' +
      '<circle cx="24" cy="30" r="12" fill="' + DARK + '"/><circle cx="214" cy="28" r="12" fill="' + DARK + '"/><circle cx="26" cy="132" r="12" fill="' + DARK + '"/><circle cx="212" cy="140" r="12" fill="' + DARK + '"/><circle cx="120" cy="150" r="10" fill="' + DARK + '"/></svg>';
  };

  ILL.volcano = function () {
    var lava = 'M120 56 C116 80 128 96 112 124 C108 134 118 142 112 150';
    return '<svg ' + A + '><rect width="240" height="160" fill="#bfe3ff"/>' +
      '<path d="M20 150 L96 66 Q108 52 120 52 Q132 52 144 66 L220 150 Z" fill="#7a5a4a"/>' +
      '<path d="M120 52 Q132 52 144 66 L220 150 L140 150 Z" fill="#664a3c" opacity=".6"/>' +
      '<ellipse cx="120" cy="55" rx="14" ry="4" fill="#3b2a22"/>' +
      '<path d="' + lava + '" stroke="#ff5a2a" stroke-width="7" fill="none" stroke-linecap="round"/><path d="' + lava + '" stroke="#ffb13d" stroke-width="2.5" fill="none" stroke-linecap="round"/>' +
      '<g fill="#8a8f99" opacity=".9"><circle cx="120" cy="40" r="10"/><circle cx="132" cy="28" r="12"/><circle cx="112" cy="22" r="10"/><circle cx="126" cy="12" r="9"/></g>' +
      '<g fill="#ff8a1f"><circle cx="100" cy="44" r="2.5"/><circle cx="142" cy="40" r="2.5"/><circle cx="150" cy="54" r="2"/></g>' +
      '<rect y="146" width="240" height="14" fill="#5f9a62"/></svg>';
  };

  ILL.canyon = function () {
    var rock = 'M0 66 L70 66 L84 84 L94 84 L104 108 L112 108 L114 134 L126 134 L128 108 L136 108 L146 84 L156 84 L170 66 L240 66 V160 H0Z';
    return '<svg ' + A + '><defs><clipPath id="ccan"><path d="' + rock + '"/></clipPath></defs>' +
      '<rect width="240" height="160" fill="#bfe3ff"/><circle cx="205" cy="30" r="14" fill="#ffe27a"/>' +
      '<path d="' + rock + '" fill="#d9835a"/>' +
      '<g clip-path="url(#ccan)" fill="#c46f48" opacity=".7"><rect y="76" width="240" height="8"/><rect y="96" width="240" height="8"/><rect y="118" width="240" height="8"/><rect y="140" width="240" height="8"/></g>' +
      '<rect x="114" y="128" width="12" height="6" fill="' + SEA + '"/></svg>';
  };

  ILL.desert = function () {
    return '<svg ' + A + '><rect width="240" height="160" fill="#ffe9a8"/><circle cx="60" cy="40" r="22" fill="#ffcf3d"/>' +
      '<path d="M0 120 Q60 80 120 115 T240 105 V160 H0Z" fill="#f0c36a"/>' +
      '<path d="M0 142 Q80 108 150 140 T240 130 V160 H0Z" fill="#e0a94a"/>' +
      '<g fill="#3f9a57"><rect x="186" y="84" width="10" height="36" rx="5"/><rect x="174" y="94" width="8" height="16" rx="4"/><rect x="176" y="106" width="16" height="6" rx="3"/><rect x="198" y="90" width="8" height="14" rx="4"/><rect x="190" y="100" width="16" height="6" rx="3"/></g></svg>';
  };

  ILL.mountain = function () {
    return '<svg ' + A + '><rect width="240" height="160" fill="#bfe3ff"/><circle cx="40" cy="34" r="14" fill="#ffe27a"/>' +
      '<path d="M10 140 L88 40 L166 140Z" fill="#8c97a6"/><path d="M88 40 L112 70 L100 64 L88 76 L76 64 L64 70Z" fill="#fff"/>' +
      '<path d="M100 140 L170 56 L236 140Z" fill="#6f7b8b"/><path d="M170 56 L190 80 L180 74 L170 86 L160 74 L150 80Z" fill="#fff"/>' +
      '<path d="M0 134 Q60 120 120 134 T240 130 V160 H0Z" fill="#5f9a62"/>' +
      '<g fill="#2f8f4e"><path d="M30 146 L38 124 L46 146Z"/><path d="M52 150 L60 130 L68 150Z"/><path d="M190 148 L198 126 L206 148Z"/></g></svg>';
  };

  window.ILL = ILL;
})();
