/* ANATOMIJA – crtež tela (SVG, bez slika; sve je nacrtano kodom).
   Telo je nacrtano u koordinatama 300 x 640. Sredina tela je x = 150.
   Svaki deo tela je <g class="part" data-id="..."> da bi se mogao dodirnuti. */
(function () {
  "use strict";
  var PARTS = {};            // id -> { sys, layer, svg }
  var ORDER = [];            // redosled crtanja

  var C = {
    skin: "#24506d", skin2: "#2c6283", edge: "#8fe3ff",
    bone: "#f6ecd2", boneS: "#b09a6c", boneD: "#8c784f",
    red: "#ff5a6e", blue: "#4aa3ff", gold: "#ffd43b"
  };

  function def(id, sys, layer, svg) { PARTS[id] = { sys: sys, layer: layer, svg: svg }; ORDER.push(id); }
  function mir(m) { return '<g transform="translate(300 0) scale(-1 1)">' + m + "</g>"; }
  function both(m) { return m + mir(m); }
  function hitS(d, w) { return '<path class="hit" d="' + d + '" stroke-width="' + w + '"/>'; }
  function hitC(cx, cy, r) { return '<circle class="hitf" cx="' + cx + '" cy="' + cy + '" r="' + r + '"/>'; }
  function line(d, col, w, extra) {
    return '<path d="' + d + '" fill="none" stroke="' + col + '" stroke-width="' + w + '" stroke-linecap="round" stroke-linejoin="round" ' + (extra || "") + "/>";
  }
  function bone(d, w) { // duga kost: tamnija ivica pa svetla sredina
    return line(d, C.boneD, w + 3) + line(d, C.bone, w);
  }
  function knob(cx, cy, r) { return '<circle cx="' + cx + '" cy="' + cy + '" r="' + r + '" fill="' + C.bone + '" stroke="' + C.boneS + '" stroke-width="1.4"/>'; }
  function part(id, sys, extra, inner) {
    return '<g class="part ' + (extra || "") + '" data-id="' + id + '" data-sys="' + sys + '">' + inner + "</g>";
  }

  /* ───────── SILUETA ───────── */
  function silhouette() {
    var fills = [
      '<ellipse cx="150" cy="62" rx="40" ry="45"/>',
      '<rect x="134" y="98" width="32" height="36" rx="8"/>',
      '<path d="M98 142 C98 128 108 122 124 122 L176 122 C192 122 202 128 202 142 L199 240 C197 285 201 330 203 376 C203 384 196 388 188 388 L112 388 C104 388 97 384 97 376 C99 330 103 285 101 240 Z"/>'
    ];
    var limbs = [
      ["M106 148 L76 252", 32], ["M76 252 L63 340", 26],
      ["M127 372 L131 488", 54], ["M131 488 L129 590", 38]
    ];
    var hand = '<ellipse cx="58" cy="366" rx="13" ry="21"/>';
    var foot = '<ellipse cx="127" cy="616" rx="25" ry="13"/>';
    function limbSet(fill, strokeW, bw) {
      var s = "";
      limbs.forEach(function (l) { s += '<path d="' + l[0] + '" fill="none" stroke="' + fill + '" stroke-width="' + (l[1] + bw) + '" stroke-linecap="round" stroke-linejoin="round"/>'; });
      s += hand.replace("/>", ' fill="' + fill + '" stroke="' + fill + '" stroke-width="' + strokeW + '"/>');
      s += foot.replace("/>", ' fill="' + fill + '" stroke="' + fill + '" stroke-width="' + strokeW + '"/>');
      return s;
    }
    function core(fill, strokeW) {
      var s = "";
      fills.forEach(function (f) { s += f.replace("/>", ' fill="' + fill + '" stroke="' + fill + '" stroke-width="' + strokeW + '" stroke-linejoin="round"/>'); });
      return s;
    }
    var edge = core(C.edge, 6) + both(limbSet(C.edge, 6, 6));
    var fillS = core(C.skin, 0.01) + both(limbSet(C.skin, 0.01, 0));
    return '<g class="sil">' + edge + fillS + "</g>";
  }

  /* ───────── ORGANI ───────── */
  // Mozak
  def("mozak", "nervi", "organi", part("mozak", "nervi", "organ",
    '<rect x="146" y="86" width="8" height="26" rx="3" fill="#ffc7de" stroke="#d96a97" stroke-width="1.5"/>' +
    '<ellipse cx="150" cy="86" rx="17" ry="6.5" fill="#f07cae" stroke="#c8527f" stroke-width="1.5"/>' +
    '<path d="M120 60 C113 46 124 31 139 34 C143 25 157 25 161 34 C176 31 187 46 180 60 C185 71 175 81 163 78 C159 85 141 85 137 78 C125 81 115 71 120 60 Z" fill="#ff9ec4" stroke="#d96a97" stroke-width="2"/>' +
    line("M150 33 C146 47 154 60 150 80", "#d96a97", 2) +
    line("M126 50 C131 44 137 52 143 45 M126 64 C132 58 138 66 144 60 M156 46 C162 52 168 44 174 50 M156 60 C162 66 168 58 174 64 M136 72 C140 68 144 74 147 70 M153 70 C157 74 161 68 165 72", "#d96a97", 1.8)
  ));

  // Dušnik
  def("dusnik", "disanje", "organi", part("dusnik", "disanje", "organ",
    line("M146 112 L146 158", "#d9ebfa", 10) +
    line("M146 114 L146 158", "#6b9fcf", 10, 'stroke-dasharray="2 3.6" stroke-linecap="butt"') +
    line("M146 158 C139 166 131 174 125 186 M146 158 C153 166 161 174 167 186", "#d9ebfa", 6) +
    hitS("M146 112 L146 158", 18)
  ));

  // Pluća
  var lungL =
    '<path d="M147 150 C136 144 121 148 114 166 C108 188 109 218 117 232 C125 243 143 241 148 229 Z" fill="#ff9bb3" stroke="#e0607f" stroke-width="2"/>' +
    line("M111 194 C122 198 135 197 147 190", "#e0607f", 1.6) +
    line("M146 160 C138 170 130 178 124 190 M138 172 C131 176 126 184 119 190 M134 178 L133 206 M128 190 L122 214", "#ffd6e0", 3) +
    '<path d="M121 156 C116 168 114 182 116 196" fill="none" stroke="#ffd1dd" stroke-width="3" stroke-linecap="round" opacity=".55"/>';
  def("pluca", "disanje", "organi", part("pluca", "disanje", "organ", both(lungL)));

  // Ošit
  def("osit", "disanje", "organi", part("osit", "disanje", "organ",
    line("M101 252 Q150 218 199 252", "#e8616b", 9) +
    line("M104 247 Q150 214 196 247", "#ffb3b8", 1.5, 'stroke-dasharray="3 3"') +
    hitS("M101 252 Q150 218 199 252", 18)
  ));

  // Jednjak
  def("jednjak", "varenje", "organi", part("jednjak", "varenje", "organ",
    line("M154 120 C154 170 154 222 161 252", "#f0a58a", 7) +
    line("M154 124 C154 172 154 222 161 250", "#ffd7c6", 1.6) +
    hitS("M154 120 C154 170 154 222 161 252", 14)
  ));

  // Jetra
  def("jetra", "varenje", "organi", part("jetra", "varenje", "organ",
    '<path d="M102 258 C106 246 132 246 160 252 C182 256 174 282 152 286 C132 290 108 288 102 272 Z" fill="#a8502d" stroke="#7a3217" stroke-width="2"/>' +
    '<path d="M110 256 C124 252 140 254 154 258" fill="none" stroke="#d38a63" stroke-width="2.4" stroke-linecap="round" opacity=".7"/>' +
    '<path d="M132 284 C138 292 148 292 150 284 Z" fill="#69b86b" stroke="#3e8b44" stroke-width="1.5"/>'
  ));

  // Želudac
  def("zeludac", "varenje", "organi", part("zeludac", "varenje", "organ",
    '<path d="M161 250 C178 246 196 255 196 273 C196 293 177 301 162 295 C152 291 151 280 159 277 C165 273 159 267 157 262 C155 256 157 252 161 250 Z" fill="#ff9d6c" stroke="#cf6832" stroke-width="2"/>' +
    line("M170 258 C182 258 188 266 186 276 M166 272 C176 274 182 282 176 290", "#ffd1b5", 2.2)
  ));

  // Gušterača
  def("gusteraca", "varenje", "organi", part("gusteraca", "varenje", "organ",
    '<path d="M132 292 C146 283 174 284 190 290 C193 298 182 302 168 300 C154 298 144 301 134 299 C128 298 128 294 132 292 Z" fill="#f2c04e" stroke="#b88a1e" stroke-width="1.8"/>'
  ));

  // Bubrezi
  var kid = '<path d="M112 266 C122 260 129 271 127 283 C125 295 117 301 112 297 C106 292 108 276 112 266 Z" fill="#a8455c" stroke="#7a2a40" stroke-width="1.8"/>' +
            line("M116 272 C120 280 120 288 116 294", "#d98a9c", 1.6);
  def("bubrezi", "izlucivanje", "organi", part("bubrezi", "izlucivanje", "organ", both(kid)));

  // Tanko crevo
  var tPath = "M127 308 H173 C181 308 181 318 173 318 H127 C119 318 119 328 127 328 H173 C181 328 181 338 173 338 H127 C119 338 119 348 127 348 H168";
  def("tanko", "varenje", "organi", part("tanko", "varenje", "organ",
    line(tPath, "#d9663f", 11) + line(tPath, "#ff9a76", 8) + line(tPath, "#ffd5c2", 1.8)
  ));

  // Debelo crevo
  var dPath = "M122 356 C112 356 109 348 109 340 L109 304 C109 296 116 293 124 293 L176 293 C184 293 191 296 191 304 L191 340 C191 348 188 356 180 356 C170 356 166 362 158 368";
  def("debelo", "varenje", "organi", part("debelo", "varenje", "organ",
    line(dPath, "#9a5a32", 13) + line(dPath, "#d9895a", 10) +
    line(dPath, "#9a5a32", 10, 'stroke-dasharray="1.4 5" stroke-linecap="butt"') +
    hitS(dPath, 16)
  ));

  // Bešika
  def("besika", "izlucivanje", "organi", part("besika", "izlucivanje", "organ",
    line("M118 300 C118 328 136 350 144 358 M182 300 C182 328 164 350 156 358", "#ffe9a8", 2.4) +
    '<path d="M150 356 C162 356 168 368 164 378 C160 386 140 386 136 378 C132 368 138 356 150 356 Z" fill="#ffd166" stroke="#d29a26" stroke-width="2"/>' +
    line("M143 366 C146 364 152 364 155 366", "#fff2c4", 2)
  ));

  // Srce
  def("srce", "krvotok", "organi", part("srce", "krvotok", "organ heart",
    '<g class="beat">' +
    '<path d="M166 194 C168 180 156 176 150 184" fill="none" stroke="#d6293f" stroke-width="8" stroke-linecap="round"/>' +
    '<path d="M154 194 C148 184 140 182 134 186" fill="none" stroke="#3b82e6" stroke-width="7" stroke-linecap="round"/>' +
    '<path d="M159 196 C155 187 142 188 142 202 C142 216 153 227 159 238 C165 227 176 216 176 202 C176 188 163 187 159 196 Z" fill="#ff4d6d" stroke="#b81e3e" stroke-width="2"/>' +
    line("M159 197 L159 234", "#b81e3e", 1.6, 'opacity=".55"') +
    line("M147 200 C147 206 150 212 154 216", "#ff9fb0", 3, 'opacity=".8"') +
    "</g>"
  ));

  /* ───────── KRVOTOK (sudovi) ───────── */
  var arteryPaths = [
    "M164 198 C166 170 150 164 148 180 L150 346",
    "M152 170 L150 112 C146 100 138 90 138 74",
    "M150 112 C154 100 162 90 162 74",
    "M150 172 C132 164 114 160 102 168 C90 190 82 232 72 262 C66 296 62 330 60 352",
    "M156 172 C176 164 190 162 198 168 C210 190 218 232 228 262 C234 296 238 330 240 352",
    "M150 346 C140 354 134 372 132 392 L132 490 L130 590",
    "M150 346 C160 354 166 372 168 392 L168 490 L170 590",
    "M166 196 C172 186 182 182 190 190"
  ];
  var veinPaths = [
    "M144 112 L144 196",
    "M155 346 L155 252 C155 242 148 238 146 228",
    "M144 176 C130 170 116 168 108 176 C96 198 88 236 78 266 C72 300 68 332 66 354",
    "M160 176 C176 172 186 170 192 176 C204 198 212 236 222 266 C228 300 232 332 234 354",
    "M152 346 C145 358 140 376 139 394 L139 490 L137 590",
    "M158 346 C165 358 160 376 161 394 L161 490 L163 590",
    "M156 196 C146 186 136 184 128 190"
  ];
  var vesselInner = "";
  arteryPaths.forEach(function (d, i) {
    var w = i === 0 ? 7 : 4.2;
    vesselInner += line(d, "#d6293f", w + 1.4) + line(d, "#ff5a6e", w) + line(d, "#ffd0d6", 1.6, 'class="flow flow-a" stroke-dasharray="2 10"');
  });
  def("arterije", "krvotok", "krvotok", part("arterije", "krvotok", "vessels",
    vesselInner + arteryPaths.map(function (d) { return hitS(d, 14); }).join("")
  ));
  var veinInner = "";
  veinPaths.forEach(function (d, i) {
    var w = i < 2 ? 5 : 3.6;
    veinInner += line(d, "#1f5fc2", w + 1.4) + line(d, "#4aa3ff", w) + line(d, "#cfe6ff", 1.5, 'class="flow flow-v" stroke-dasharray="2 10"');
  });
  def("vene", "krvotok", "krvotok", part("vene", "krvotok", "vessels",
    veinInner + veinPaths.map(function (d) { return hitS(d, 14); }).join("")
  ));
  // Kapilari – lupa na podlaktici
  var capNet = "";
  for (var i = 0; i < 7; i++) {
    capNet += line("M" + (50 + i * 3) + " " + (288) + " C" + (56 + i * 2) + " " + (296) + " " + (46 + i * 4) + " " + (306) + " " + (54 + i * 3) + " " + (314), i % 2 ? "#ff5a6e" : "#4aa3ff", 1.3);
  }
  capNet += line("M44 300 C52 298 58 304 66 302 M44 308 C54 308 60 312 68 310", "#ff9aa8", 1.2);
  def("kapilari", "krvotok", "krvotok", part("kapilari", "krvotok", "magnifier",
    '<circle cx="58" cy="301" r="19" fill="#10283f" stroke="#ffd43b" stroke-width="3"/>' +
    '<line x1="72" y1="315" x2="84" y2="328" stroke="#ffd43b" stroke-width="5" stroke-linecap="round"/>' +
    capNet + hitC(58, 301, 22)
  ));
  // Kap krvi – dugme
  def("krv", "krvotok", "krvotok", part("krv", "krvotok", "dropbtn",
    '<path d="M254 108 C254 108 240 126 240 137 C240 146 246 152 254 152 C262 152 268 146 268 137 C268 126 254 108 254 108 Z" fill="#ff4d6d" stroke="#b81e3e" stroke-width="2"/>' +
    '<path d="M247 136 C247 141 249 144 253 146" fill="none" stroke="#ffc0cb" stroke-width="2.4" stroke-linecap="round"/>' +
    hitC(254, 134, 24)
  ));

  /* ───────── NERVI ───────── */
  var nervePaths = [
    "M150 112 L150 340",
    "M150 140 C130 138 110 144 96 160 C80 186 74 230 68 262 C64 300 60 330 58 360",
    "M150 140 C170 138 190 144 204 160 C220 186 226 230 232 262 C236 300 240 330 242 360",
    "M150 336 C140 350 130 372 128 400 L130 490 L128 600",
    "M150 336 C160 350 170 372 172 400 L170 490 L172 600"
  ];
  var branch = "M150 150 C136 150 126 156 120 166 M150 150 C164 150 174 156 180 166 M150 182 C134 184 124 192 118 204 M150 182 C166 184 176 192 182 204 M150 214 C136 218 126 228 122 240 M150 214 C164 218 174 228 178 240 M150 250 C138 256 128 266 124 278 M150 250 C162 256 172 266 176 278 M150 296 C138 300 130 310 126 324 M150 296 C162 300 170 310 174 324";
  def("kicmena", "nervi", "nervi", part("kicmena", "nervi", "nerve",
    line("M150 112 L150 340", "#b88a00", 8) + line("M150 112 L150 340", "#ffd43b", 5.5) +
    line("M150 112 L150 340", "#fff3b0", 1.4, 'class="flow" stroke-dasharray="2 10"') +
    hitS("M150 112 L150 340", 16)
  ));
  var nv = "";
  nervePaths.slice(1).forEach(function (d) { nv += line(d, "#b88a00", 4.4) + line(d, "#ffd43b", 2.6) + line(d, "#fff6c7", 1.2, 'class="flow" stroke-dasharray="2 9"'); });
  nv += line(branch, "#ffd43b", 1.6, 'opacity=".9"');
  def("nervi", "nervi", "nervi", part("nervi", "nervi", "nerve",
    nv + nervePaths.slice(1).map(function (d) { return hitS(d, 14); }).join("") + hitS(branch, 10)
  ));

  /* ───────── KOSTUR ───────── */
  // lobanja
  var teeth = "";
  for (var t = 0; t < 8; t++) teeth += '<rect x="' + (135.2 + t * 4.2) + '" y="93" width="3.5" height="7" rx="1" fill="#fff" stroke="' + C.boneS + '" stroke-width=".7"/>';
  def("lobanja", "kostur", "kostur", part("lobanja", "kostur", "bone",
    '<path d="M128 92 C128 110 140 116 150 116 C160 116 172 110 172 92 Z" fill="' + C.bone + '" stroke="' + C.boneS + '" stroke-width="2"/>' +
    '<path d="M150 18 C121 18 111 43 113 66 C115 80 123 86 126 98 L138 104 L162 104 L174 98 C177 86 185 80 187 66 C189 43 179 18 150 18 Z" fill="' + C.bone + '" stroke="' + C.boneS + '" stroke-width="2"/>' +
    '<ellipse cx="136" cy="62" rx="9.5" ry="10.5" fill="#1b2b38"/><ellipse cx="164" cy="62" rx="9.5" ry="10.5" fill="#1b2b38"/>' +
    '<path d="M150 72 L144.5 85 L155.5 85 Z" fill="#1b2b38"/>' + teeth +
    line("M121 40 C132 28 168 28 179 40", "#d9c79c", 1.6, 'opacity=".8"')
  ));
  // kičma
  var spine = "";
  (function () {
    var y = 116, k, w;
    for (k = 0; k < 7; k++) { w = 14 + k * 0.5; spine += '<rect x="' + (150 - w / 2) + '" y="' + y + '" width="' + w + '" height="6.4" rx="3" fill="' + C.bone + '" stroke="' + C.boneS + '" stroke-width="1.1"/>'; y += 7.9; }
    for (k = 0; k < 12; k++) { w = 18 + k * 0.4; spine += '<rect x="' + (150 - w / 2) + '" y="' + y + '" width="' + w + '" height="8" rx="3" fill="' + C.bone + '" stroke="' + C.boneS + '" stroke-width="1.1"/>'; y += 9.5; }
    for (k = 0; k < 5; k++) { w = 24 + k * 0.5; spine += '<rect x="' + (150 - w / 2) + '" y="' + y + '" width="' + w + '" height="9.6" rx="3.5" fill="' + C.bone + '" stroke="' + C.boneS + '" stroke-width="1.1"/>'; y += 11; }
    spine += '<path d="M137 ' + y + ' L163 ' + y + ' L156 ' + (y + 26) + ' L150 ' + (y + 34) + ' L144 ' + (y + 26) + ' Z" fill="' + C.bone + '" stroke="' + C.boneS + '" stroke-width="1.4" stroke-linejoin="round"/>';
  })();
  def("kicma", "kostur", "kostur", part("kicma", "kostur", "bone", spine + hitS("M150 116 L150 360", 22)));
  // rebra
  var ribs = "";
  for (var r = 0; r < 10; r++) {
    var ys = 134 + 9 * r, d;
    if (r <= 6) { var ye = 148 + 9.5 * r; d = "M144 " + ys + " C100 " + (ys - 4) + " " + (96 + r * 1.2) + " " + (ye + 20) + " 143 " + ye; }
    else { d = "M144 " + ys + " C" + (112 + (r - 7) * 3) + " " + (ys - 2) + " " + (104 + (r - 7) * 3) + " " + (ys + 16) + " " + (124 + (r - 7) * 3) + " " + (ys + 28); }
    ribs += bone(d, 3.6);
  }
  def("rebra", "kostur", "kostur", part("rebra", "kostur", "bone", both(ribs)));
  // grudna kost
  def("grudna", "kostur", "kostur", part("grudna", "kostur", "bone",
    '<path d="M143 142 L157 142 L158 190 L153 212 L150 222 L147 212 L142 190 Z" fill="' + C.bone + '" stroke="' + C.boneS + '" stroke-width="1.6" stroke-linejoin="round"/>' +
    line("M146 158 L154 158 M146 176 L154 176", C.boneS, 1.2)
  ));
  // ključna kost
  def("kljucna", "kostur", "kostur", part("kljucna", "kostur", "bone",
    both(bone("M146 138 C132 128 114 130 100 142", 5.2) + hitS("M146 138 C132 128 114 130 100 142", 14))
  ));
  // nadlaktica
  def("nadlaktica", "kostur", "kostur", part("nadlaktica", "kostur", "bone",
    both(bone("M99 152 L76 248", 10) + knob(100, 148, 9) + knob(75, 252, 7.5))
  ));
  // podlaktica
  def("podlaktica", "kostur", "kostur", part("podlaktica", "kostur", "bone",
    both(bone("M79 259 L67 341", 5.4) + bone("M72 259 C65 286 62 314 58 340", 5.4) + hitS("M76 259 L62 340", 16))
  ));
  // šaka
  var handB = "";
  [[56, 346], [62, 346], [68, 344], [51, 349]].forEach(function (p) { handB += knob(p[0], p[1], 4.2); });
  [["M54 352 L44 376", "M44 376 L38 396"], ["M60 352 L55 380", "M55 380 L53 404"], ["M66 351 L65 382", "M65 382 L66 408"], ["M71 349 L74 378", "M74 378 L78 400"]].forEach(function (f) {
    handB += bone(f[0], 3.2) + bone(f[1], 2.8);
  });
  handB += bone("M52 349 L40 364", 3.4) + bone("M40 364 L33 380", 3);
  def("saka", "kostur", "kostur", part("saka", "kostur", "bone", both(handB + hitC(58, 376, 24))));
  // karlica
  var pelv = '<path d="M146 336 C130 322 108 322 102 342 C100 360 108 376 122 380 C132 382 142 374 146 362 Z" fill="' + C.bone + '" stroke="' + C.boneS + '" stroke-width="2" stroke-linejoin="round"/>' +
             '<ellipse cx="128" cy="364" rx="5.6" ry="7.5" fill="#2a4a63" transform="rotate(-10 128 364)"/>' +
             line("M110 336 C120 332 132 334 140 340", C.boneS, 1.4, 'opacity=".8"');
  def("karlica", "kostur", "kostur", part("karlica", "kostur", "bone",
    both(pelv) + '<path d="M146 372 L154 372 L152 384 L148 384 Z" fill="' + C.bone + '" stroke="' + C.boneS + '" stroke-width="1.4"/>'
  ));
  // butna kost
  def("butna", "kostur", "kostur", part("butna", "kostur", "bone",
    both(bone("M121 390 L131 486", 12) + bone("M135 376 L121 392", 9) + knob(135, 372, 9) + knob(116, 389, 5.5) + '<ellipse cx="131" cy="490" rx="15" ry="8" fill="' + C.bone + '" stroke="' + C.boneS + '" stroke-width="1.6"/>')
  ));
  // čašica kolena
  def("casica", "kostur", "kostur", part("casica", "kostur", "bone",
    both('<ellipse cx="131" cy="499" rx="8.5" ry="9.5" fill="' + C.bone + '" stroke="' + C.boneD + '" stroke-width="2"/><path d="M127 495 C129 492 133 492 135 495" fill="none" stroke="' + C.boneS + '" stroke-width="1.4"/>')
  ));
  // potkolenica
  def("potkolenica", "kostur", "kostur", part("potkolenica", "kostur", "bone",
    both(bone("M132 508 L130 590", 9.5) + bone("M121 510 L122 586", 5.2) + '<ellipse cx="128" cy="594" rx="13" ry="6" fill="' + C.bone + '" stroke="' + C.boneS + '" stroke-width="1.4"/>' + hitS("M128 508 L127 590", 20))
  ));
  // stopalo
  var foot = '<ellipse cx="127" cy="603" rx="11" ry="7" fill="' + C.bone + '" stroke="' + C.boneS + '" stroke-width="1.4"/>';
  [[112, 622], [120, 626], [127, 628], [134, 627], [141, 622]].forEach(function (p) { foot += bone("M127 607 L" + p[0] + " " + p[1], 3.2); });
  def("stopalo", "kostur", "kostur", part("stopalo", "kostur", "bone", both(foot + hitC(127, 614, 20))));

  /* ───────── MIŠIĆI ───────── */
  var MS = 'fill="#e8505b" stroke="#9c2736" stroke-width="1.6" stroke-linejoin="round"';
  var MF = "#ffa0a8";
  function fib(d) { return line(d, MF, 1.3, 'opacity=".85"'); }
  def("zvakacki", "misici", "misici", part("zvakacki", "misici", "muscle",
    both('<path d="M120 76 C113 86 118 100 132 102 C135 94 133 84 126 76 Z" ' + MS + '/>' + fib("M121 82 C122 90 126 96 130 98 M125 80 C127 88 129 94 131 98"))
  ));
  def("deltoid", "misici", "misici", part("deltoid", "misici", "muscle",
    both('<path d="M104 130 C90 130 76 144 78 166 C82 176 94 174 102 164 C110 154 112 138 104 130 Z" ' + MS + '/>' + fib("M98 136 C90 146 86 158 86 168 M104 140 C98 150 94 160 92 168"))
  ));
  def("grudni", "misici", "misici", part("grudni", "misici", "muscle",
    both('<path d="M148 138 C130 132 112 138 104 152 C106 176 124 192 148 190 Z" ' + MS + '/>' + fib("M146 144 C130 146 118 154 112 160 M146 156 C132 158 122 166 118 172 M146 170 C134 172 128 178 126 184"))
  ));
  def("biceps", "misici", "misici", part("biceps", "misici", "muscle",
    both('<path d="M92 172 C80 192 76 222 80 246 C90 244 98 218 100 190 Z" ' + MS + '/>' + fib("M92 180 C86 200 84 224 84 240 M95 186 C91 204 90 222 88 238"))
  ));
  def("podlakticni", "misici", "misici", part("podlakticni", "misici", "muscle",
    both('<path d="M72 262 C58 290 56 318 60 338 L68 338 C72 314 78 290 88 268 Z" ' + MS + '/>' + fib("M72 270 C66 292 64 312 64 332 M78 272 C73 292 70 312 68 330"))
  ));
  var abs = "";
  for (var ar = 0; ar < 4; ar++) for (var ac = 0; ac < 2; ac++)
    abs += '<rect x="' + (126 + ac * 25) + '" y="' + (198 + ar * 22) + '" width="23" height="19.5" rx="6" ' + MS + "/>";
  def("trbusni", "misici", "misici", part("trbusni", "misici", "muscle",
    abs + both('<path d="M118 192 C108 232 108 270 116 300 L124 296 C120 262 120 224 124 196 Z" ' + MS + "/>")
  ));
  def("butni", "misici", "misici", part("butni", "misici", "muscle",
    both('<path d="M106 380 C98 424 106 468 120 488 L142 488 C150 452 148 414 144 380 Z" ' + MS + '/>' + fib("M114 392 C108 426 112 458 122 480 M124 388 C120 424 122 454 128 480 M134 386 C134 420 134 450 136 480"))
  ));
  def("list", "misici", "misici", part("list", "misici", "muscle",
    both('<path d="M118 506 C106 530 110 560 123 580 L137 580 C147 556 148 528 140 506 Z" ' + MS + '/>' + fib("M122 514 C116 534 118 556 126 574 M132 514 C130 534 130 556 132 574") +
      '<path d="M126 580 L128 604 L134 604 L134 580 Z" fill="#f2c4a0" stroke="#b58056" stroke-width="1.4"/>')
  ));

  /* ───────── ČULA ───────── */
  def("oko", "cula", "cula", part("oko", "cula", "sense",
    both('<ellipse cx="134" cy="58" rx="13" ry="8.5" fill="#fff" stroke="#6d5bd0" stroke-width="1.6"/><circle cx="134" cy="58" r="6" fill="#4a8fd8"/><circle cx="134" cy="58" r="2.8" fill="#10283f"/><circle cx="132.4" cy="56.3" r="1.3" fill="#fff"/>' + hitC(134, 58, 17))
  ));
  def("uvo", "cula", "cula", part("uvo", "cula", "sense",
    both('<path d="M111 56 C98 52 95 70 102 82 C106 88 113 86 113 78 Z" fill="#f2b6a0" stroke="#c98a74" stroke-width="1.8" stroke-linejoin="round"/><path d="M106 62 C102 66 104 74 108 78" fill="none" stroke="#c98a74" stroke-width="1.4"/>' + hitC(106, 68, 16))
  ));
  def("nos", "cula", "cula", part("nos", "cula", "sense",
    '<path d="M150 62 C146 72 143 78 145 83 C147 87 153 87 155 83 C157 78 154 72 150 62 Z" fill="#f2b6a0" stroke="#c98a74" stroke-width="1.8" stroke-linejoin="round"/><circle cx="147.4" cy="83" r="1.3" fill="#8a4a38"/><circle cx="152.6" cy="83" r="1.3" fill="#8a4a38"/>' + hitC(150, 76, 14)
  ));
  def("jezik", "cula", "cula", part("jezik", "cula", "sense",
    '<ellipse cx="150" cy="96" rx="15" ry="8" fill="#7a2236" stroke="#4d1222" stroke-width="1.6"/><path d="M141 96 C142 106 158 106 159 96 C155 99 145 99 141 96 Z" fill="#ff7f96" stroke="#d94a67" stroke-width="1.4"/>' + hitC(150, 98, 17)
  ));
  def("koza", "cula", "cula", part("koza", "cula", "sense skinbtn",
    '<circle class="pulse" cx="58" cy="372" r="19" fill="none" stroke="#b197fc" stroke-width="2.4"/><circle cx="58" cy="372" r="15" fill="#b197fc" stroke="#6d4fd0" stroke-width="2"/>' +
    '<text x="58" y="378" text-anchor="middle" font-size="17" style="pointer-events:none">✋</text>' + hitC(58, 372, 24)
  ));

  /* ───────── SKLAPANJE KRAJNJE SLIKE ───────── */
  var LAYERS = ["misici", "kostur", "krvotok", "nervi", "organi", "cula"];
  var DEFS = "";
  var VB = {
    sve: [40, 0, 220, 400], disanje: [60, 96, 180, 300], varenje: [60, 96, 180, 300], izlucivanje: [60, 96, 180, 300],
    cula: [20, 0, 260, 420], kostur: [20, 0, 260, 640], misici: [20, 0, 260, 640], krvotok: [20, 0, 260, 640], nervi: [20, 0, 260, 640]
  };

  function layersMarkup(only) {
    var s = "";
    LAYERS.forEach(function (L) {
      var inner = "";
      ORDER.forEach(function (id) {
        var p = PARTS[id];
        if (p.layer === L && (!only || only.indexOf(id) >= 0)) inner += p.svg;
      });
      s += '<g class="lay L-' + L + '">' + inner + "</g>";
    });
    return s;
  }

  function stage(sys, cls) {
    var vb = VB[sys] || VB.sve;
    return '<svg class="stage ' + (cls || "") + '" data-sys="' + sys + '" viewBox="' + vb.join(" ") + '" preserveAspectRatio="xMidYMid meet" xmlns="http://www.w3.org/2000/svg" role="img" aria-label="Ljudsko telo">' +
      DEFS + silhouette() + layersMarkup() + '<g class="overlay"></g></svg>';
  }

  // prazan nacrt tela (za slagalice): samo silueta + tačke za delove
  function emptyStage(cls) {
    return '<svg class="stage ' + (cls || "") + '" viewBox="0 0 300 640" preserveAspectRatio="xMidYMid meet" xmlns="http://www.w3.org/2000/svg">' +
      silhouette() + '<g class="slots"></g><g class="overlay"></g></svg>';
  }

  window.BODY = {
    PARTS: PARTS, ORDER: ORDER, VB: VB,
    stage: stage, emptyStage: emptyStage,
    part: function (id) { return PARTS[id] && PARTS[id].svg; },
    sysOf: function (id) { return PARTS[id] && PARTS[id].sys; },
    layerOf: function (id) { return PARTS[id] && PARTS[id].layer; }
  };
})();
