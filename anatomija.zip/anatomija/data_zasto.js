/* ANATOMIJA – „Zašto se to dešava?“ kartice.
   PRVA ponuđena opcija (opc[0]) je tačna. Igra ih pri prikazivanju nasumično promeša. */
window.ZASTO = [
{ id: "stucanje", emoji: "😳", deo: "osit",
  q: "Zašto štucamo?",
  opc: ["Ošit se iznenada trzne, a glasne žice se naglo zatvore", "Srce preskoči jedan otkucaj", "Pluća se prepune pa pukne mehurić"],
  odg: "Ošit je veliki mišić ispod pluća. Kad se iznenada trzne, vazduh naglo uleti, a glasne žice se zatvore i čuje se „HIK!“. Najčešće štucamo kad jedemo ili pijemo prebrzo ili kad se mnogo smejemo. Obično prođe samo od sebe.",
  probaj: "Udahni polako i zadrži vazduh dok izbrojiš do 10. Ume da pomogne." },

{ id: "najezimo", emoji: "🥶", deo: "koza",
  q: "Zašto se naježimo?",
  opc: ["Sićušni mišići u koži podignu dlačice", "Krv se na trenutak zaledi ispod kože", "Koža se sama od sebe zgužva"],
  odg: "Kad ti je hladno ili si uzbuđen, sićušni mišići pored svake dlačice se stegnu i podignu je. Tako nastaju one tačkice, „guščja koža“. Naši daleki preci imali su gusto krzno, pa su uspravne dlake zadržavale topao vazduh uz telo. Kod nas je ostao samo taj refleks.",
  probaj: "Pogledaj podlakticu kad ti je hladno. Vidi se kako se dlačice dižu." },

{ id: "znoj", emoji: "💦", deo: "koza",
  q: "Zašto se znojimo?",
  opc: ["Znoj hladi telo dok isparava sa kože", "Telo izbacuje vodu koju smo previše popili", "Da bi nas znoj oprao od blata"],
  odg: "Znoj je „klima-uređaj“ tela. Kad je vruće ili kad trčiš, znojne žlezde izluče vodu na kožu. Dok ona isparava, hladi telo. Zato je dobro da piješ vodu kad se znojiš, jer je tako vraćaš." },

{ id: "kijanje", emoji: "🤧", deo: "nos",
  q: "Zašto kijamo?",
  opc: ["Nešto nam nadražuje nos pa telo hoće da to izbaci", "Zato što je mozak uplašen", "Zato što su pluća prazna"],
  odg: "Kad prašina, polen ili hladan vazduh nadraže nos, mozak naredi: „Izbaci to odmah!“. Mišići grudi, ošita i grla se naglo stegnu i vazduh izleti veoma brzo. Zato prekrij nos i usta laktom ili maramicom, da ne raspršiš klice." },

{ id: "zevanje", emoji: "🥱", deo: "mozak",
  q: "Zašto zevamo?",
  opc: ["Naučnici ne znaju sigurno; jedna ideja je da zevanje malo rashladi i razbudi mozak", "Zato što nam fali kiseonik u krvi", "Zato što stomak traži hranu"],
  odg: "Ovo je zagonetka koju naučnici još rešavaju! Dugo se mislilo da zevamo zbog nedostatka kiseonika, ali ogledi su pokazali da to nije tačno. Jedna ideja je da nas duboki udah hladnijeg vazduha malo rashladi i razbudi. Zevanje je i zarazno: kad vidiš da neko zeva, zevneš i ti.",
  probaj: "Zevni pred nekim iz porodice i vidi hoće li i on zevnuti." },

{ id: "kasalj", emoji: "😷", deo: "dusnik",
  q: "Zašto kašljemo?",
  opc: ["Da bismo očistili disajne puteve", "Da bismo zagrejali pluća", "Da nas mozak podseti da pijemo vodu"],
  odg: "Kašalj je refleks koji čisti dušnik i pluća. Kad nešto nadraži disajne puteve (prašina, sluz, mrvica), mozak naredi snažan izdah koji to izbaci. Kašalj te štiti. Ako kašalj traje dugo ili boli, reci odraslima i idite kod doktora." },

{ id: "zagrcnemo", emoji: "😵", deo: "dusnik",
  q: "Zašto se zagrcnemo kad pričamo dok jedemo?",
  opc: ["Poklopac dušnika ne stigne da se zatvori, pa hrana krene u pogrešnu cev", "Hrana se zaglavi u ušima", "Jezik zaboravi da guta"],
  odg: "Dušnik (za vazduh) i jednjak (za hranu) su jedan pored drugog. Kad gutaš, mali poklopac (epiglotis) zatvori dušnik. Ako pričaš ili se smeješ dok gutaš, poklopac ne stigne, pa hrana krene ka dušniku. Telo odmah zakašlje da je izbaci. Zato jedi polako i ne pričaj punih usta." },

{ id: "groznica", emoji: "🤒", deo: "mozak",
  q: "Zašto dobijemo temperaturu kad smo bolesni?",
  opc: ["Telo namerno podigne temperaturu da bi se lakše borilo protiv klica", "Zato što su krvni sudovi pregoreli", "Zato što je telo gladno"],
  odg: "Mozak podigne telesnu temperaturu jer mnogim klicama ne prija toplo, a naše odbrambene ćelije bolje rade kad je toplije. Normalna temperatura je oko 36,5 do 37,5 °C. Kad imaš temperaturu, odmori se, pij vodu i obavezno reci odraslima." },

{ id: "curi_nos", emoji: "🤧", deo: "nos",
  q: "Zašto nam curi nos kad smo prehlađeni?",
  opc: ["Nos pravi više sluzi da zarobi klice i ispere ih", "Nos plače umesto očiju", "Nos otopi sve što je smrznuto u njemu"],
  odg: "Sluz u nosu je zaštitnik. Hvata prašinu i klice. Kad nas napadne virus, nos napravi mnogo više sluzi da bi klice isprao napolje. Kad je ima previše, ona curi. I kad plačeš curi ti nos, jer suze odlaze kroz mali kanalić iz oka u nos." },

{ id: "krci", emoji: "🍽️", deo: "tanko",
  q: "Zašto nam stomak krči?",
  opc: ["Mišići u crevima guraju hranu, tečnost i vazduh", "U stomaku žive male životinjice", "Želudac se sam sa sobom svađa"],
  odg: "Mišići u želucu i crevima neprestano gnječe i guraju hranu, tečnost i vazduh. Kad je želudac prazan, taj zvuk se čuje jače. Zato krčanje ne znači uvek da si gladan: creva rade i kad smo siti." },

{ id: "gladni", emoji: "🍔", deo: "zeludac",
  q: "Kako telo zna da smo gladni?",
  opc: ["Prazan stomak i manje šećera u krvi šalju signal mozgu", "Mozak čuje kako stomak krči", "Zubi jave mozgu da su prazni"],
  odg: "Kad je želudac prazan, a u krvi ima manje šećera, telo šalje signale mozgu (jedan od njih je hormon grelin): „Vreme je za jelo!“. Kad se najedeš, drugi signali kažu mozgu: „Dosta!“. Njima treba oko 20 minuta da stignu, zato je dobro da jedeš polako." },

{ id: "zedj", emoji: "🥤", deo: "bubrezi",
  q: "Zašto nam se pije voda?",
  opc: ["Telo gubi vodu znojenjem i mokrenjem, pa mozak javi: žeđ!", "Usta su prazna i dosađuju se", "Pluća traže vodu da bi disala"],
  odg: "Više od polovine našeg tela je voda. Gubimo je kad se znojimo, dišemo i mokrimo. Kad je ima manje, mozak pošalje signal: žeđ! Voda pomaže krvi da teče, bubrezima da čiste telo i zglobovima da se lako pokreću." },

{ id: "leptiri", emoji: "🦋", deo: "zeludac",
  q: "Zašto osetimo „leptiriće u stomaku“ kad smo uzbuđeni?",
  opc: ["Mozak i creva stalno razgovaraju, a uzbuđenje usmeri krv ka mišićima i uzburka stomak", "Zato što smo progutali pravog leptira", "Zato što stomak vežba"],
  odg: "Kad smo uzbuđeni ili nervozni, mozak pošalje telu signal da se spremi. Više krvi ide ka mišićima, a varenje se malo poremeti, pa se stomak „uzvrpolji“. Creva imaju i svoje nerve koji stalno razgovaraju sa mozgom. Zato emocije osećamo i u stomaku." },

{ id: "srce_lupa", emoji: "🏃", deo: "srce",
  q: "Zašto srce jače lupa kad trčimo ili se uplašimo?",
  opc: ["Mišićima treba više kiseonika, pa srce brže pumpa; strah dodatno ubrza srce hormonom adrenalinom", "Srce se smeje kad trčimo", "Srce se sudara sa rebrima"],
  odg: "Kad trčiš, mišići rade jako i traže više kiseonika, pa srce brže pumpa krv. Kad se uplašimo, telo ispusti adrenalin, hormon spremnosti. Srce odmah ubrza da bi mišići bili spremni da se brane ili beže. Kad se smiriš, srce se opet uspori.",
  probaj: "Izmeri puls pre i posle 20 čučnjeva. To možeš i u laboratoriji!" },

{ id: "krv_crvena", emoji: "🩸", deo: "krv",
  q: "Zašto je krv crvena?",
  opc: ["Zbog hemoglobina u crvenim zrncima, koji sadrži gvožđe", "Zato što u njoj ima paradajza", "Zato što je krv vruća"],
  odg: "Crvena zrnca nose kiseonik, a hemoglobin se za njega veže i postaje jarko crven. Krv sa manje kiseonika je tamnija. Zato vene izgledaju plavo kroz kožu, a krv u njima je ipak crvena." },

{ id: "pocrveni", emoji: "😊", deo: "kapilari",
  q: "Zašto pocrvenimo kad nas je sramota?",
  opc: ["Krvni sudovi u obrazima se prošire pa dođe više krvi", "Obrazi se sami oboje", "Koža se zagreje od misli"],
  odg: "Emocije aktiviraju nerve koji šire sićušne krvne sudove (kapilare) u obrazima. Kroz njih prođe više krvi i obrazi pocrvene. To ne možemo sami da kontrolišemo, a u redu je da pocrvenimo. Svima se dešava." },

{ id: "modrica", emoji: "🟣", deo: "kapilari",
  q: "Zašto nastane modrica kad se udarimo?",
  opc: ["Udarac pocepa sitne krvne sudove pa krv ostane ispod kože", "Koža se pofarba od udarca", "Kost promeni boju"],
  odg: "Udarac pocepa sićušne krvne sudove ispod kože, a krv ostane zarobljena i vidi se kroz kožu. Telo je polako razgrađuje i zato modrica menja boje: crvenkasta, ljubičasta, zelena, žuta i na kraju nestane.",
  probaj: "Ako imaš modricu, gledaj je svaki dan i vidi kako menja boje." },

{ id: "krasta", emoji: "🩹", deo: "krv",
  q: "Šta se desi kad se ogrebemo pa krene krv?",
  opc: ["Trombociti zatvore ranu i nastane krasta, a ispod nje raste nova koža", "Krv se osuši i pretvori u prašinu", "Koža pobegne sa tog mesta"],
  odg: "Trombociti (sitni delovi krvi) se zalepe jedan za drugog i zatvore ranu. Krv se zgruša i napravi koru, kraste. Ispod nje se već pravi nova koža. Zato kraste ne treba skidati! Ranu operi vodom i reci odraslima." },

{ id: "suze", emoji: "😢", deo: "oko",
  q: "Zašto nam idu suze?",
  opc: ["Suze vlaže i čiste oko, a idu i kad smo tužni ili veoma srećni", "Oči imaju česme koje ne mogu da se zatvore", "Suze idu samo kad smo tužni"],
  odg: "Oči stalno prave tanak film suza koji ih vlaži i čisti. Kad se seče luk, u oku se pojavi nadražujući gas, pa oko napravi više suza da ga ispere. Suze idu i kad smo tužni ili jako srećni, jer nam emocije uzburkaju nerve." },

{ id: "trepcemo", emoji: "😉", deo: "oko",
  q: "Zašto trepćemo?",
  opc: ["Treptaj vlaži i čisti oko i štiti ga od prašine", "Zato što mozak na trenutak ugasi svetlo", "Da bismo bolje čuli"],
  odg: "Svakim treptajem razmažemo tanak sloj suza po oku, pa se ono vlaži i čisti. Trepnemo oko 15 do 20 puta u minuti. Kad dugo gledaš u ekran, trepćeš mnogo ređe i oči se osuše, zato povremeno odmori pogled.",
  probaj: "Pokušaj da ne trepneš pola minuta. Šta osećaš?" },

{ id: "vrtoglavica", emoji: "😵‍💫", deo: "uvo",
  q: "Zašto nam se vrti u glavi kad se zavrtimo i staneš?",
  opc: ["Tečnost u unutrašnjem uvu se još njiše, a oči javljaju mozgu da mirujemo", "Mozak se odvrne kao šraf", "Oči se zavrte unutra"],
  odg: "U unutrašnjem uvu su cevčice sa tečnošću koje osećaju okretanje. Kad staneš, tečnost još malo nastavi da se njiše, a oči kažu mozgu da miruješ. Mozak je zbunjen i sve ti se vrti. Posle nekoliko sekundi tečnost se umiri i prestaje.",
  probaj: "Okreni se 5 puta pa stani i pridrži se za nešto. Pazi na nameštaj!" },

{ id: "prsti_nabori", emoji: "🛁", deo: "koza",
  q: "Zašto nam se prsti naboraju u vodi?",
  opc: ["Nervi suze krvne sudove u prstima pa se koža nabora", "Prsti upiju vodu kao sunđer", "Koža se razboli od vode"],
  odg: "Kad su dugo u vodi, nervi naređuju krvnim sudovima u prstima da se suze, i koža se nabora. Naučnici misle da nam nabori pomažu da bolje uhvatimo mokre predmete, kao šare na gumama automobila. Kad izađeš iz vode, prsti se posle nekog vremena vrate u normalu.",
  probaj: "Drži prste u toploj vodi nekoliko minuta i gledaj kako se menjaju." },

{ id: "drhtanje", emoji: "🧥", deo: "butni",
  q: "Zašto drhtimo kad nam je hladno?",
  opc: ["Mišići se brzo i sitno stežu i prave toplotu", "Kosti se zalede", "Srce poželi da pobegne"],
  odg: "Kad mozak primeti da nam je hladno, naredi mišićima da se brzo i sitno stežu i opuštaju. Taj rad pravi toplotu i greje telo. Zato kad vežbamo, brzo se zagrejemo." },

{ id: "trnci", emoji: "🦵", deo: "nervi",
  q: "Zašto nam „utrne“ noga kad dugo sedimo?",
  opc: ["Pritisak steže nerv i krvne sudove pa signali ne idu kako treba", "Noga se umori i zaspi", "Kosti zaspe"],
  odg: "Kad dugo sedimo na nozi, pritisnemo nerv i krvne sudove, pa nerv ne šalje signale kako treba. Kad pritisak popusti, nerv se „probudi“ i šalje pomešane signale. To su trnci, tzv. „mravci“. Prođu za koji trenutak.",
  probaj: "Kad utrne noga, polako je protresi i sačekaj. Ne ustaj naglo." },

{ id: "spavanje", emoji: "😴", deo: "mozak",
  q: "Zašto moramo da spavamo?",
  opc: ["Telo se odmara i popravlja, a mozak sređuje ono što smo naučili", "Zato što je napolju mrak", "Zato što nam se oči umore od gledanja"],
  odg: "Dok spavamo, telo se odmara i popravlja, a mozak „pospremi“ sve što si tokom dana naučio i zapamti ono važno. U snu telo luči i hormon rasta. Deci tvojih godina treba oko 9 do 12 sati sna svake noći." },

{ id: "rast", emoji: "📏", deo: "butna",
  q: "Kako rastemo u visinu?",
  opc: ["Na krajevima kostiju je meka hrskavica koja raste i pretvara se u kost", "Kosti se napumpaju vazduhom", "Koža vuče kosti nagore"],
  odg: "Na krajevima dugih kostiju postoje „ploče rasta“ od meke hrskavice. One se stalno razmnožavaju, a hrskavica se pretvara u kost. Tako kosti postaju duže. Kad odrasteš, ploče rasta se zatvore i kosti prestaju da rastu u dužinu. Za zdrav rast trebaju ti hrana, kretanje i san." },

{ id: "mlecni_zubi", emoji: "🦷", deo: "lobanja",
  q: "Zašto nam ispadaju mlečni zubi?",
  opc: ["Ispod njih rastu stalni zubi i guraju ih napolje", "Zato što se pokvare od slatkiša", "Zato što su umorni od grickanja"],
  odg: "Mlečnih zuba ima 20. Ispod njih već čekaju stalni zubi. Kad porastu, guraju mlečne nagore, koren mlečnog zuba se razgradi i zub se olabavi. Stalnih zuba ima do 32 i novi ne rastu, zato ih peri dva puta dnevno!",
  probaj: "Pogledaj u ogledalo i prebroj sekutiće, očnjake i kutnjake." },

{ id: "nokti", emoji: "💅", deo: "saka",
  q: "Zašto nas ne boli kad nam režu nokte ili kosu?",
  opc: ["Nokti i kosa su od mrtvih ćelija, bez nerava i krvnih sudova", "Zato što su dugački", "Zato što ih ne vidimo kad se seku"],
  odg: "Nokti i kosa su napravljeni od ćelija koje su već „gotove“ i nemaju ni nerve ni krvne sudove, pa nema šta da boli. Živ je samo koren, ispod kože. Nokti rastu oko 3 milimetra mesečno, a kosa oko jedan centimetar." },

{ id: "otisci", emoji: "☝️", deo: "saka",
  q: "Zašto imamo otiske prstiju?",
  opc: ["Linije pomažu da bolje držimo i osetimo, a svaki otisak je drugačiji", "Da bismo ostavljali tragove", "Da nam prsti budu lepši"],
  odg: "Linije na vrhovima prstiju povećavaju trenje pa čvršće držimo predmete, i pomažu da osetimo sitne površine. Svaki otisak je drugačiji, čak i kod blizanaca! Zato se otisci koriste da bi se ljudi prepoznali.",
  probaj: "Utisni prst u jastuče za pečat ili mekani plastelin i pogledaj linije lupom." },

{ id: "kosti_zarastaju", emoji: "🦴", deo: "kljucna",
  q: "Kako zarasta slomljena kost?",
  opc: ["Ćelije u kosti naprave „zakrpu“ koja se pretvori u novu kost", "Doktor je zalepi lepkom i gotovo", "Kost sama izraste ispočetka"],
  odg: "Kost je živo tkivo. Kad se slomi, ćelije naprave zakrpu (kalus) koja polako postaje nova kost. Gips drži kost mirnom dok ne zaraste. Kod dece to ide brže nego kod odraslih." }
];
