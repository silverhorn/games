/* ANATOMIJA – jezgro: stanje igre, poeni (XP), značke, zvuk, glasno čitanje, ruter. */
(function () {
  "use strict";
  var KEY = "anatomija_v1";

  function fresh() { return { xp: 0, parts: {}, zasto: {}, badges: {}, done: {}, best: {}, det: {}, sound: true, lab: {} }; }
  function load() {
    try {
      var j = JSON.parse(localStorage.getItem(KEY));
      if (j && typeof j === "object") { var f = fresh(); for (var k in j) f[k] = j[k]; return f; }
    } catch (e) { /* localStorage može da bude zabranjen na file:// */ }
    return fresh();
  }
  var S = load();
  function save() { try { localStorage.setItem(KEY, JSON.stringify(S)); } catch (e) {} }

  /* ───────── pomoćne ───────── */
  function $(sel, root) { return (root || document).querySelector(sel); }
  function $$(sel, root) { return Array.prototype.slice.call((root || document).querySelectorAll(sel)); }
  function shuffle(a) {
    a = a.slice();
    for (var i = a.length - 1; i > 0; i--) { var j = Math.floor(Math.random() * (i + 1)); var t = a[i]; a[i] = a[j]; a[j] = t; }
    return a;
  }
  function esc(s) { return String(s).replace(/[&<>"]/g, function (c) { return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]; }); }
  function sysInfo(id) { for (var i = 0; i < SISTEMI.length; i++) if (SISTEMI[i].id === id) return SISTEMI[i]; return SISTEMI[0]; }
  var reduce = window.matchMedia && matchMedia("(prefers-reduced-motion: reduce)").matches;

  /* ───────── zvuk ───────── */
  var ac = null;
  function tone(f, d, type, vol, delay) {
    if (!S.sound) return;
    try {
      ac = ac || new (window.AudioContext || window.webkitAudioContext)();
      if (ac.state === "suspended") ac.resume();
      var o = ac.createOscillator(), g = ac.createGain(), t0 = ac.currentTime + (delay || 0);
      o.type = type || "sine"; o.frequency.setValueAtTime(f, t0);
      g.gain.setValueAtTime(0.0001, t0);
      g.gain.exponentialRampToValueAtTime(vol || 0.08, t0 + 0.015);
      g.gain.exponentialRampToValueAtTime(0.0001, t0 + d);
      o.connect(g); g.connect(ac.destination); o.start(t0); o.stop(t0 + d + 0.05);
    } catch (e) {}
  }
  var sfx = {
    tap: function () { tone(660, 0.06, "triangle", 0.05); },
    ok: function () { tone(523, 0.12, "triangle", 0.09); tone(659, 0.12, "triangle", 0.09, 0.1); tone(784, 0.22, "triangle", 0.09, 0.2); },
    no: function () { tone(240, 0.16, "sine", 0.06); tone(200, 0.2, "sine", 0.05, 0.12); },
    win: function () { [523, 659, 784, 1047].forEach(function (f, i) { tone(f, 0.18, "triangle", 0.09, i * 0.11); }); },
    thump: function () { tone(70, 0.14, "sine", 0.35); tone(56, 0.16, "sine", 0.3, 0.17); },
    pop: function () { tone(880, 0.05, "square", 0.025); }
  };

  /* ───────── glatko približavanje crteža ───────── */
  function tweenVB(svg, to, dur) {
    var cur = svg.getAttribute("viewBox").split(" ").map(Number);
    if (reduce) { svg.setAttribute("viewBox", to.join(" ")); return; }
    var t0 = performance.now(); dur = dur || 420;
    (function f(t) {
      var k = Math.min(1, (t - t0) / dur); k = 1 - Math.pow(1 - k, 3);
      svg.setAttribute("viewBox", cur.map(function (v, i) { return (v + (to[i] - v) * k).toFixed(1); }).join(" "));
      if (k < 1) requestAnimationFrame(f);
    })(t0);
  }

  /* ───────── glasno čitanje ───────── */
  function speak(text) {
    if (!("speechSynthesis" in window)) return;
    try {
      speechSynthesis.cancel();
      var u = new SpeechSynthesisUtterance(text);
      var vs = speechSynthesis.getVoices() || [], v = null, i;
      var want = ["sr", "hr", "bs", "sl"];
      for (var w = 0; w < want.length && !v; w++) for (i = 0; i < vs.length; i++) if ((vs[i].lang || "").toLowerCase().indexOf(want[w]) === 0) { v = vs[i]; break; }
      if (v) { u.voice = v; u.lang = v.lang; } else { u.lang = "sr-RS"; }
      u.rate = 0.9; speechSynthesis.speak(u);
    } catch (e) {}
  }
  function stopSpeak() { try { if ("speechSynthesis" in window) speechSynthesis.cancel(); } catch (e) {} }
  var canSpeak = "speechSynthesis" in window;

  /* ───────── obaveštenja i konfeti ───────── */
  function toast(html, cls, ms) {
    var box = $("#toasts"); if (!box) return;
    var t = document.createElement("div");
    t.className = "toast " + (cls || ""); t.innerHTML = html;
    box.appendChild(t);
    setTimeout(function () { t.classList.add("out"); setTimeout(function () { t.remove(); }, 350); }, ms || 3200);
  }
  function confetti(n) {
    if (reduce) return;
    var cv = $("#confetti"); if (!cv) return;
    var ctx = cv.getContext("2d"), W = cv.width = window.innerWidth, H = cv.height = window.innerHeight;
    var cols = ["#ff5a6e", "#ffd43b", "#2fd6a6", "#4aa3ff", "#a78bfa", "#ff9d6c"], ps = [], i;
    for (i = 0; i < (n || 70); i++) ps.push({ x: W / 2 + (Math.random() - 0.5) * 120, y: H * 0.4, vx: (Math.random() - 0.5) * 11, vy: -Math.random() * 11 - 3, s: Math.random() * 7 + 4, c: cols[i % cols.length], r: Math.random() * 6, vr: (Math.random() - 0.5) * 0.4 });
    var t0 = performance.now();
    (function frame(t) {
      var dt = t - t0; ctx.clearRect(0, 0, W, H);
      ps.forEach(function (p) { p.vy += 0.3; p.x += p.vx; p.y += p.vy; p.r += p.vr; ctx.save(); ctx.translate(p.x, p.y); ctx.rotate(p.r); ctx.fillStyle = p.c; ctx.globalAlpha = Math.max(0, 1 - dt / 2300); ctx.fillRect(-p.s / 2, -p.s / 3, p.s, p.s / 1.6); ctx.restore(); });
      if (dt < 2300) requestAnimationFrame(frame); else ctx.clearRect(0, 0, W, H);
    })(t0);
  }

  /* ───────── poeni i rang ───────── */
  function rankOf(xp) { var r = RANGOVI[0]; for (var i = 0; i < RANGOVI.length; i++) if (xp >= RANGOVI[i].od) r = RANGOVI[i]; return r; }
  function nextRank(xp) { for (var i = 0; i < RANGOVI.length; i++) if (xp < RANGOVI[i].od) return RANGOVI[i]; return null; }
  function addXP(n, why) {
    if (!n) return;
    var before = rankOf(S.xp).ime;
    S.xp += n; save(); updateHeader();
    var chip = $("#xp"); if (chip && !reduce) { chip.classList.remove("bump"); void chip.offsetWidth; chip.classList.add("bump"); }
    var after = rankOf(S.xp).ime;
    if (after !== before) { toast("🎖️ Novi čin: <b>" + after + "</b>!", "rank", 4200); confetti(90); sfx.win(); }
  }
  function updateHeader() {
    var n = $("#xpn"), r = $("#rank"), s = $("#snd");
    if (n) n.textContent = S.xp;
    if (r) r.textContent = rankOf(S.xp).ime;
    if (s) s.textContent = S.sound ? "🔊" : "🔇";
  }

  /* ───────── značke ───────── */
  function award(id) {
    if (S.badges[id]) return false;
    var b = null; for (var i = 0; i < ZNACKE.length; i++) if (ZNACKE[i].id === id) b = ZNACKE[i];
    if (!b) return false;
    S.badges[id] = Date.now(); save();
    toast('<span class="tb">' + b.emoji + "</span> Nova značka: <b>" + esc(b.ime) + "</b>", "badge", 4200);
    confetti(60); sfx.win();
    return true;
  }
  function sysParts(sys) { return (REDOSLED[sys] || []); }
  function checkBadges() {
    var any = Object.keys(S.parts).length;
    if (any) award("prvi");
    ["kostur", "misici", "krvotok", "disanje", "varenje", "izlucivanje", "nervi", "cula"].forEach(function (s) {
      var l = sysParts(s), ok = l.length > 0;
      l.forEach(function (id) { if (!S.parts[id]) ok = false; });
      if (ok) award(s);
    });
    var z = Object.keys(S.zasto).length;
    if (z >= 10) award("zasto10");
    if (z >= ZASTO.length) award("zasto_sve");
    var d = 0; for (var k in S.det) if (S.det[k]) d++;
    if (d >= SLUCAJEVI.length) award("detektiv");
  }
  function markPart(id) {
    if (S.parts[id]) return false;
    S.parts[id] = 1; save(); addXP(3); checkBadges(); return true;
  }
  function totalParts() { return Object.keys(DELOVI).length; }

  /* ───────── ruter ───────── */
  var views = {}, meta = {}, cleanup = null;
  function reg(name, title, fn) { views[name] = fn; meta[name] = title; }
  function go(path) { location.hash = "#/" + (path || ""); }
  function parentOf(name, arg) { return arg ? "#/" + name : "#/"; }
  var cur = { name: "home", arg: "" };

  function route() {
    var h = location.hash.replace(/^#\/?/, ""), p = h.split("/");
    var name = p[0] || "home", arg = p[1] || "";
    if (!views[name]) { name = "home"; arg = ""; }
    if (cleanup) { try { cleanup(); } catch (e) {} cleanup = null; }
    stopSpeak();
    cur = { name: name, arg: arg };
    var app = $("#app"); app.innerHTML = "";
    var root = document.createElement("div"); root.className = "view v-" + name; app.appendChild(root);
    window.scrollTo(0, 0);
    var t = meta[name] || "Anatomija";
    $("#ttl").textContent = t;
    $("#back").hidden = name === "home";
    document.title = (name === "home" ? "" : t.replace(/^\S+\s/, "") + " · ") + "Anatomija";
    try { cleanup = views[name](root, arg) || null; }
    catch (e) { root.innerHTML = '<div class="card"><h2>Ups!</h2><p>Nešto nije u redu. Vrati se na početak.</p><a class="btn" href="#/">Početna</a></div>'; if (window.console) console.error(e); }
  }

  function init() {
    $("#back").addEventListener("click", function () {
      sfx.tap();
      if (history.length > 1 && cur.arg === "" && cur.name !== "home") location.hash = "#/";
      else location.hash = parentOf(cur.name, cur.arg);
    });
    $("#snd").addEventListener("click", function () { S.sound = !S.sound; save(); updateHeader(); if (S.sound) sfx.tap(); });
    $("#xp").addEventListener("click", function () { location.hash = "#/znacke"; });
    window.addEventListener("hashchange", route);
    window.addEventListener("resize", function () { var c = $("#confetti"); if (c) { c.width = innerWidth; c.height = innerHeight; } });
    updateHeader();
    route();
  }

  window.A = {
    S: S, save: save, $: $, $$: $$, shuffle: shuffle, esc: esc, sysInfo: sysInfo, reduce: reduce,
    tweenVB: tweenVB, sfx: sfx, tone: tone, speak: speak, stopSpeak: stopSpeak, canSpeak: canSpeak, toast: toast, confetti: confetti,
    addXP: addXP, award: award, checkBadges: checkBadges, markPart: markPart, totalParts: totalParts,
    rankOf: rankOf, nextRank: nextRank, updateHeader: updateHeader,
    reg: reg, go: go, init: init, resetAll: function () { try { localStorage.removeItem(KEY); } catch (e) {} location.hash = "#/"; location.reload(); }
  };
})();
