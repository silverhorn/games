/* ANATOMIJA – podaci za igre: kviz, doktor-detektiv, putovanja, memorija, značke.
   Kviz: PRVA opcija je tačna, igra ih meša. Pitanja idu od najlakših ka najtežim. */

/* ───────────── KVIZ (3 nivoa) ───────────── */
window.KVIZ = [
 { id: 1, ime: "Mali istraživač", emoji: "🌱", opis: "Osnovno o telu. Za početak!", pitanja: [
  { q: "Koji organ pumpa krv kroz telo?", o: ["Srce", "Stomak", "Mozak", "Pluća"], e: "Srce je mišić koji pumpa krv. Kuca ceo život, i dok spavaš!" },
  { q: "Čime razmišljamo?", o: ["Mozgom", "Srcem", "Stomakom", "Kolenom"], e: "Mozak je šef tela. On misli, pamti i šalje naređenja." },
  { q: "Čime dišemo?", o: ["Plućima", "Bubrezima", "Jetrom", "Zubima"], e: "Pluća uzimaju kiseonik iz vazduha i izbacuju ugljen-dioksid." },
  { q: "Koji organ vidi svetlost?", o: ["Oko", "Uvo", "Nos", "Jezik"], e: "Očima vidimo. Slika se stvara na mrežnjači u zadnjem delu oka." },
  { q: "Šta nam omogućava da čujemo zvukove?", o: ["Uši", "Nos", "Prsti", "Laktovi"], e: "Uši hvataju zvuk, koji je talasanje vazduha." },
  { q: "Šta drži telo uspravno i čuva organe?", o: ["Kosti", "Kosa", "Koža", "Nokti"], e: "Kosti čine kostur koji nosi telo i štiti organe." },
  { q: "Koji organ je u glavi i štiti ga lobanja?", o: ["Mozak", "Srce", "Želudac", "Jetra"], e: "Lobanja je kao tvrdi šlem za mozak." },
  { q: "Šta nas pokreće zajedno sa kostima?", o: ["Mišići", "Zubi", "Trepavice", "Nokti"], e: "Mišići se stežu i vuku kosti. Tako se krećemo." },
  { q: "Gde se hrana vari prva, odmah posle usta i jednjaka?", o: ["U želucu", "U plućima", "U srcu", "U uvu"], e: "Zalogaj ide kroz jednjak do želuca, gde se meša sa kiselinom." },
  { q: "Čime osećamo mirise?", o: ["Nosom", "Okom", "Uvom", "Laktom"], e: "Nos hvata mirisne čestice i šalje signal mozgu." },
  { q: "Koliko zuba imaju odrasli ljudi (najviše)?", o: ["32", "10", "20", "50"], e: "Odrasli imaju do 32 stalna zuba. Deca imaju 20 mlečnih." },
  { q: "Šta je najveći organ koji prekriva celo telo?", o: ["Koža", "Jetra", "Srce", "Pluća"], e: "Koža štiti telo, i omogućava osećaj dodira." }
 ]},
 { id: 2, ime: "Mladi doktor", emoji: "🩺", opis: "Šta radi koji deo i kako.", pitanja: [
  { q: "Koji deo krvi nosi kiseonik?", o: ["Crvena zrnca", "Bela zrnca", "Trombociti", "Plazma je sva kiseonik"], e: "Crvena zrnca imaju hemoglobin koji hvata kiseonik i boji krv u crveno." },
  { q: "Koji krvni sudovi nose krv IZ srca ka telu?", o: ["Arterije", "Vene", "Kapilari", "Dušnik"], e: "Arterije kreću iz srca. Vene vraćaju krv nazad." },
  { q: "Šta rade bela krvna zrnca?", o: ["Brane telo od klica", "Nose kiseonik", "Zatvaraju ranu", "Prave kosti"], e: "Bela zrnca su „vojska“ tela koja se bori protiv klica." },
  { q: "Gde se hranljive materije iz hrane najviše upijaju u krv?", o: ["U tankom crevu", "U jednjaku", "U želucu", "U bešici"], e: "Tanko crevo ima resice koje upijaju hranljive materije u krv." },
  { q: "Koji organ čisti krv i pravi mokraću?", o: ["Bubrezi", "Pluća", "Jetra", "Želudac"], e: "Dva bubrega filtriraju krv. Višak vode i otpad izlaze kao mokraća." },
  { q: "Koji mišić je glavni za disanje?", o: ["Ošit (dijafragma)", "Biceps", "Žvakački mišić", "Mišić lista"], e: "Ošit se spusti pri udisaju, i pluća uvuku vazduh." },
  { q: "Šta su alveole?", o: ["Sićušni mehurići u plućima", "Kosti u uvu", "Delovi srca", "Zubi mudrosti"], e: "U alveolama kiseonik prelazi u krv, a ugljen-dioksid izlazi u vazduh." },
  { q: "Šta se nalazi na mrežnjači oka?", o: ["Slika (naopačke!)", "Suze", "Pljuvačka", "Mala kost"], e: "Slika nastaje naopačke, a mozak je okrene kako treba." },
  { q: "Koja kost je najduža i najjača u telu?", o: ["Butna kost", "Nadlaktična kost", "Rebro", "Lobanja"], e: "Butna kost (femur) čini otprilike četvrtinu visine čoveka." },
  { q: "Šta radi biceps?", o: ["Savija lakat", "Ispravlja koleno", "Okreće glavu", "Pokreće oči"], e: "Biceps se stegne i povuče podlakticu ka ramenu." },
  { q: "Šta pravi žuč koja pomaže u varenju masti?", o: ["Jetra", "Srce", "Bubreg", "Slezina"], e: "Jetra pravi žuč, a čuva se u žučnoj kesici." },
  { q: "Kakva je zapravo krv u venama, iako vene izgledaju plavo kroz kožu?", o: ["Tamnocrvena, jer ima manje kiseonika", "Plava", "Zelena", "Providna"], e: "Krv je uvek crvena. Vene izgledaju plavičasto zbog načina na koji svetlost prolazi kroz kožu." }
 ]},
 { id: 3, ime: "Profesor anatomije", emoji: "🎓", opis: "Za prave stručnjake. Pažljivo!", pitanja: [
  { q: "Koliko kostiju ima odrasli čovek?", o: ["206", "100", "350", "52"], e: "Odrasli ima 206 kostiju. Beba ih ima više, pa neke vremenom srastu." },
  { q: "Koja je najmanja kost u telu?", o: ["Uzengija u uvu", "Čašica kolena", "Rebro", "Kost prsta na nozi"], e: "Uzengija je duga oko 3 milimetra." },
  { q: "Koliko odaja ima srce?", o: ["4", "1", "2", "6"], e: "Srce ima 4 odaje: dve pretkomore i dve komore." },
  { q: "Kud putuje krv iz desne strane srca?", o: ["U pluća", "U mozak", "U stomak", "U noge direktno"], e: "Desna strana šalje krv u pluća po kiseonik, leva je pumpa kroz telo." },
  { q: "Šta je peristaltika?", o: ["Talasasto stezanje mišića koje gura hranu", "Zvuk srca", "Vrsta kosti", "Trepljanje oka"], e: "Zahvaljujući peristaltici hrana ide nadole čak i kad stojiš naglavačke." },
  { q: "Koji deo oka reguliše koliko svetlosti ulazi?", o: ["Zenica (sa dužicom)", "Sočivo", "Očni nerv", "Rožnjača"], e: "Zenica se sužava na jakom svetlu, a širi u mraku." },
  { q: "Koji organ ima moć da naraste nazad posle povrede?", o: ["Jetra", "Srce", "Bubreg", "Oko"], e: "Jetra se regeneriše, čak i ako se ukloni deo." },
  { q: "Šta je refleks?", o: ["Brz odgovor tela koji vodi kičmena moždina", "Dug san", "Vrsta mišića", "Jak miris"], e: "Refleks je brz i nehotični odgovor. Povučeš ruku sa vruće šolje pre nego što pomisliš." },
  { q: "Koliko zuba imaju deca (mlečni zubi)?", o: ["20", "16", "28", "32"], e: "Mlečnih zuba ima 20, a stalnih do 32." },
  { q: "Kako se zove mišić na prednjoj strani butine koji ima 4 glave?", o: ["Kvadriceps", "Biceps", "Triceps", "Deltoid"], e: "Kvadriceps ispravlja koleno." },
  { q: "Koji hormon ubrzava srce kad se uplašimo?", o: ["Adrenalin", "Insulin", "Hemoglobin", "Pljuvačka"], e: "Adrenalin priprema telo da se bori ili da beži." },
  { q: "Gde nastaju nove ćelije krvi?", o: ["U koštanoj srži", "U jetri", "U želucu", "U ušima"], e: "Koštana srž, mekani deo unutar kostiju, pravi milione novih zrnaca svake sekunde." }
 ]}
];

/* ───────────── DOKTOR DETEKTIV ─────────────
   Dodirni deo tela koji je odgovor. "ok" = lista prihvaćenih delova, "sloj" = u kom sloju se nalazi. */
window.SLUCAJEVI = [
 { ime: "Ana", emoji: "👧", prica: "Ana je trčala trku i sad joj srce lupa kao ludo i jako diše. Koji organ je najviše radio da bi mišići dobili kiseonik?", ok: ["srce"], sloj: "krvotok", hint: "Ovaj mišić pumpa krv.", sta: "Srce! Brže pumpa da bi mišići dobili više kiseonika." },
 { ime: "Petar", emoji: "👦", prica: "Petar je pričao dok je gutao keks i počeo da kašlje. Kroz koju cev je hrana skrenula umesto kroz jednjak?", ok: ["dusnik"], sloj: "disanje", hint: "To je cev za vazduh.", sta: "Dušnik! Mali poklopac nije stigao da ga zatvori." },
 { ime: "Maja", emoji: "👧", prica: "Maja je dodirnula vrelu šolju i trgla ruku pre nego što je osetila bol. Ko je tako brzo naredio refleks?", ok: ["kicmena"], sloj: "nervi", hint: "Nalazi se unutar kičme.", sta: "Kičmena moždina! Ona refleks obrađuje brzo, pre mozga." },
 { ime: "Jovan", emoji: "👦", prica: "Jovan je pojeo ručak. Hrana se već pretvorila u kašu. Koji organ u obliku slova J je to uradio?", ok: ["zeludac"], sloj: "varenje", hint: "Meša hranu sa kiselinom.", sta: "Želudac! Drobi hranu i meša je sa kiselinom." },
 { ime: "Nina", emoji: "👧", prica: "Nina je popila mnogo soka. Koji organi će ga isfiltrirati i napraviti mokraću?", ok: ["bubrezi"], sloj: "izlucivanje", hint: "Dva su i oblika graha.", sta: "Bubrezi! Filtriraju krv i prave mokraću." },
 { ime: "Marko", emoji: "👦", prica: "Marko je pao sa trotineta i slomio kost koja povezuje grudnu kost i rame. Koja je to?", ok: ["kljucna"], sloj: "kostur", hint: "Nalazi se ispod vrata, vodoravno.", sta: "Ključna kost! Najčešće se lomi kod dece pri padu." },
 { ime: "Ivana", emoji: "👧", prica: "Ivana je podigla tešku torbu savijenim laktom. Koji mišić na prednjoj strani nadlaktice je radio?", ok: ["biceps"], sloj: "misici", hint: "Ima dve „glave“.", sta: "Biceps! Skuplja se i savija lakat." },
 { ime: "Luka", emoji: "👦", prica: "Luka je pojeo masnu hranu. Koji najveći organ unutar tela pravi žuč da bi se mast svarila?", ok: ["jetra"], sloj: "varenje", hint: "Nalazi se desno, ispod ošita.", sta: "Jetra! Pravi žuč, a čisti i krv." },
 { ime: "Sara", emoji: "👧", prica: "Sara je ušla u pekaru i osetila miris svežeg hleba. Koji deo tela je uhvatio miris?", ok: ["nos"], sloj: "cula", hint: "Nalazi se na sredini lica.", sta: "Nos! Mirisne čestice se vežu za posebne ćelije u nosu." },
 { ime: "Filip", emoji: "👦", prica: "Filip se zavrteo u krug i staje, ali mu se još vrti u glavi. Koji organ sa tečnošću je zbunjen?", ok: ["uvo"], sloj: "cula", hint: "Pomaže nam da čujemo i držimo ravnotežu.", sta: "Uvo! Tečnost u unutrašnjem uvu se još njiše." },
 { ime: "Teodora", emoji: "👧", prica: "Teodora je zagrizla jabuku. Koji mišić na obrazu je podigao donju vilicu?", ok: ["zvakacki"], sloj: "misici", hint: "Na obrazu, uz donju vilicu.", sta: "Žvakački mišić! Jedan od najjačih u odnosu na veličinu." },
 { ime: "Lazar", emoji: "👦", prica: "Lazar je skočio sa trampoline i dočekao se na noge. Koja najjača kost u telu je izdržala težinu?", ok: ["butna"], sloj: "kostur", hint: "Nalazi se u butini.", sta: "Butna kost! Najduža i najjača kost u telu." },
 { ime: "Mia", emoji: "👧", prica: "Mia je zaplakala dok je sekla luk. Koji organ pravi suze da ispere nadražaj?", ok: ["oko"], sloj: "cula", hint: "Njime se gleda.", sta: "Oko! Suze ga čiste i vlaže." },
 { ime: "Vuk", emoji: "👦", prica: "Vuk je udahnuo duboko. Koji veliki mišić ispod pluća se spustio da uvuče vazduh?", ok: ["osit"], sloj: "disanje", hint: "Oblik kupole.", sta: "Ošit! Glavni mišić za disanje." }
];

/* ───────────── PUTOVANJA KROZ TELO ─────────────
   Stanice su zadate koordinatama na crtežu tela (viewBox 300x640).
   Svaka stanica ima pitanje; tačan odgovor je uvek prvi. */
window.PUTOVANJA = [
 { id: "hrana", ime: "Putovanje zalogaja", emoji: "🍪", sloj: "varenje", token: "🍪",
   opis: "Pratimo jedan keks od usta do kraja puta. Odgovaraj na pitanja da bi keks išao dalje!",
   stanice: [
    { x: 150, y: 94, ime: "Usta", q: "Šta se dešava sa keksom u ustima?", o: ["Zubi ga zdrobe, a pljuvačka ga ovlaži i počne da vari", "Odmah se pretvara u krv", "Ostaje isti"], e: "Zubi melju, jezik meša, a pljuvačka počinje da razlaže hranu." },
    { x: 157, y: 170, ime: "Jednjak", q: "Šta radi jednjak?", o: ["Mišići ga talasasto stežu i guraju zalogaj nadole", "Pravi žuč", "Vari hranu"], e: "Mišići jednjaka guraju zalogaj. Zato možeš da guraš hranu čak i naglavačke." },
    { x: 176, y: 272, v: [[157,246]], ime: "Želudac", q: "Šta se desi u želucu?", o: ["Hrana se zdrobi i pomeša sa kiselinom u gustu kašu", "Hrana se pretvori u vazduh", "Hrana se pretvori u kost"], e: "Zidovi želuca mešaju hranu sa želudačnim sokom, dok ne nastane kaša." },
    { x: 150, y: 291, ime: "Jetra i gušterača pomažu", q: "Šta daju jetra i gušterača da bi se hrana svarila?", o: ["Žuč i sokove za varenje", "Vazduh", "Kiseonik"], e: "Jetra pravi žuč, a gušterača sokove. Oni stižu u tanko crevo." },
    { x: 150, y: 328, ime: "Tanko crevo", q: "Šta se dešava u tankom crevu?", o: ["Hranljive materije se upiju u krv", "Hrana se zamrzne", "Hrana se skroz izbaci"], e: "Resice u tankom crevu upiju hranljive materije u krv." },
    { x: 186, y: 320, ime: "Debelo crevo", q: "Šta radi debelo crevo?", o: ["Upija vodu i pravi stolicu od onoga što telo ne koristi", "Pravi suze", "Pravi mokraću"], e: "Ostatak se upije i oblikuje u stolicu. Potom odlazi napolje." }
   ]},
 { id: "krv", ime: "Putovanje kapi krvi", emoji: "🩸", sloj: "krvotok", token: "🩸",
   opis: "Idemo sa jednom kapljicom krvi po celom krugu. Krug traje otprilike jedan minut!",
   stanice: [
    { x: 143, y: 222, ime: "Srce (desna strana)", q: "Kapljica je ostala bez kiseonika i vratila se u srce. Ko je šalje dalje, u pluća?", o: ["Desna strana srca", "Mozak", "Stomak"], e: "Desna strana srca šalje krv bez kiseonika u pluća." },
    { x: 126, y: 192, ime: "Pluća", q: "Šta kapljica radi u plućima?", o: ["Uzima kiseonik, a odaje ugljen-dioksid", "Uzima hranu", "Pravi suze"], e: "U plućima krv pokupi kiseonik. Ugljen-dioksid izlazi pri izdahu." },
    { x: 166, y: 212, ime: "Srce (leva strana)", q: "Šta sada radi leva strana srca (jača)?", o: ["Gura krv sa kiseonikom kroz celo telo", "Gura vazduh u pluća", "Pravi hranu"], e: "Leva strana je jača, jer potiskuje krv do vrha glave i vrha prstiju na nogama." },
    { x: 162, y: 181, v: [[164,198]], ime: "Aorta", q: "Kojim sudom ide krv iz srca?", o: ["Aortom, najvećom arterijom", "Dušnikom", "Jednjakom"], e: "Aorta je najveća arterija i iz nje se granaju sve druge." },
    { x: 58, y: 301, v: [[150,172],[132,166],[112,163],[101,170],[90,194],[80,236],[72,262]], ime: "Kapilari u ruci", q: "Šta kapljica radi u najsitnijim sudovima ruke?", o: ["Predaje kiseonik, a uzima ugljen-dioksid", "Pravi nove kosti", "Pije sok"], e: "U kapilarima krv predaje kiseonik ćelijama i uzima otpad." },
    { x: 144, y: 168, v: [[70,290],[78,266],[88,236],[97,200],[108,176],[120,170],[132,170]], ime: "Vene", q: "Kako krv stiže nazad u srce?", o: ["Kroz vene, a mišići ih potiskuju i zalisci čuvaju smer", "Kroz dušnik", "Kroz jednjak"], e: "Vene imaju zaliske. Mišići guraju krv ka srcu, a zalisci ne dozvoljavaju da krene unazad." }
   ]},
 { id: "vazduh", ime: "Putovanje daha", emoji: "🌬️", sloj: "disanje", token: "💨",
   opis: "Prati jedan udah od nosa do krvi i nazad napolje.",
   stanice: [
    { x: 150, y: 76,  ime: "Nos", q: "Šta radi nos sa vazduhom koji udišemo?", o: ["Greje ga, vlaži i hvata prašinu u sluz i dlačice", "Pretvara ga u vodu", "Pravi od njega hranu"], e: "Nos pretopli i očisti vazduh da bi pluća bila zaštićena." },
    { x: 150, y: 108, ime: "Grlo", q: "Šta se desi kad gutamo?", o: ["Poklopac (epiglotis) zatvori dušnik", "Dušnik se pretvori u jednjak", "Pluća se isključe"], e: "Epiglotis štiti dušnik da hrana ne uđe u njega." },
    { x: 150, y: 136, ime: "Dušnik", q: "Šta hvata prašinu u dušniku?", o: ["Sluz i sitne trepljice", "Zubi", "Kosti"], e: "Trepljice guraju sluz sa prašinom ka grlu, da se iskašlje ili proguta." },
    { x: 132, y: 174, ime: "Bronhije", q: "Šta su bronhije?", o: ["Cevčice koje se granaju u svako plućno krilo", "Kosti", "Mišići"], e: "Dušnik se grana u dve bronhije, pa u mnogo sitnih cevčica." },
    { x: 118, y: 200, ime: "Alveole", q: "Šta se dešava u alveolama?", o: ["Kiseonik prelazi u krv, a ugljen-dioksid ide napolje", "Hrana se vari", "Prave se suze"], e: "Zidovi alveola su tanki kao jedna ćelija. Tu razmena gasova!" },
    { x: 150, y: 238, ime: "Ošit", q: "Šta radi ošit pri izdahu?", o: ["Opusti se i vrati gore, pa izbaci vazduh", "Stegne se jače", "Pravi hranu"], e: "Pri izdahu se ošit opusti i vazduh izlazi." }
   ]},
 { id: "signal", ime: "Putovanje signala", emoji: "⚡", sloj: "nervi", token: "⚡",
   opis: "Dodirnuli smo nešto vruće! Pogledaj kojim putem signal stiže do mozga i nazad do mišića.",
   stanice: [
    { x: 58, y: 374, ime: "Prst", q: "Šta osete senzori u koži prsta?", o: ["Toplo i bol", "Ukus", "Zvuk"], e: "Koža ima senzore za dodir, toplo, hladno i bol." },
    { x: 68, y: 262, v: [[59,345],[62,315]], ime: "Nerv ruke", q: "Kako signal putuje kroz nerv?", o: ["Kao kratak električni impuls", "Kao tečnost", "Kao vazduh"], e: "Nervi prenose električne impulse brzinom i preko 100 m/s." },
    { x: 150, y: 222, v: [[78,214],[84,182],[98,158],[114,146],[132,139],[150,140]], ime: "Kičmena moždina", q: "Ko u ovom slučaju prvi odgovara refleksom?", o: ["Kičmena moždina, još pre mozga", "Pluća", "Bubrezi"], e: "Kičmena moždina naredi mišiću da povuče ruku, pre nego što mozak shvati." },
    { x: 77, y: 206, v: [[150,140],[132,139],[114,146],[98,158],[84,184]], ime: "Mišić nadlaktice", q: "Šta radi mišić kad stigne naređenje?", o: ["Stegne se i povuče ruku od vrućeg", "Zaspi", "Pravi suze"], e: "Mišić se stegne, i ruka se povuče u deliću sekunde." },
    { x: 150, y: 56, v: [[84,184],[98,158],[114,146],[132,139],[150,130],[150,112]], ime: "Mozak", q: "A šta radi mozak?", o: ["Primi poruku i javi: „Au, vruće je!“", "Ništa ne primeti", "Odmah zaspi"], e: "Mozak tek posle refleksa shvati šta se desilo i oseti bol." }
   ]}
];

/* ───────────── MEMORIJA (par: deo ↔ šta radi) ───────────── */
window.MEMO_PAROVI = [
  { a: "❤️ Srce", b: "Pumpa krv" },
  { a: "🧠 Mozak", b: "Misli i pamti" },
  { a: "🌬️ Pluća", b: "Unose kiseonik" },
  { a: "🍲 Želudac", b: "Drobi hranu kiselinom" },
  { a: "🫘 Bubrezi", b: "Čiste krv" },
  { a: "🟤 Jetra", b: "Pravi žuč" },
  { a: "🍝 Tanko crevo", b: "Upija hranu u krv" },
  { a: "👁️ Oko", b: "Vidi svetlost" },
  { a: "👂 Uvo", b: "Čuje zvuk" },
  { a: "🦴 Kosti", b: "Drže telo uspravno" },
  { a: "💪 Mišići", b: "Pomeraju kosti" },
  { a: "✋ Koža", b: "Čuva telo i oseća dodir" },
  { a: "🎒 Bešika", b: "Skuplja mokraću" },
  { a: "👅 Jezik", b: "Oseća ukus" }
];

/* ───────────── ZNAČKE ───────────── */
window.ZNACKE = [
  { id: "prvi",     emoji: "🔍", ime: "Prvi pregled",       opis: "Otvori svoj prvi deo tela." },
  { id: "kostur",   emoji: "🦴", ime: "Majstor kostiju",    opis: "Upoznaj sve kosti u skeletu." },
  { id: "misici",   emoji: "💪", ime: "Jaki mišići",        opis: "Upoznaj sve mišiće." },
  { id: "krvotok",  emoji: "❤️", ime: "Prijatelj srca",     opis: "Upoznaj srce i krvotok." },
  { id: "disanje",  emoji: "🌬️", ime: "Duboki dah",         opis: "Upoznaj sistem za disanje." },
  { id: "varenje",  emoji: "🍎", ime: "Majstor varenja",    opis: "Upoznaj sve organe za varenje." },
  { id: "izlucivanje", emoji: "💧", ime: "Čistač tela",     opis: "Upoznaj bubrege i bešiku." },
  { id: "nervi",    emoji: "🧠", ime: "Pametna glava",      opis: "Upoznaj mozak i nerve." },
  { id: "cula",     emoji: "👁️", ime: "Pet čula",           opis: "Upoznaj sva čula." },
  { id: "sklop_org", emoji: "🧩", ime: "Slagač organa",     opis: "Složi sve organe na pravo mesto." },
  { id: "sklop_kost", emoji: "☠️", ime: "Slagač kostura",   opis: "Složi kostur." },
  { id: "put_hrana", emoji: "🍪", ime: "Pratilac zalogaja", opis: "Završi putovanje zalogaja." },
  { id: "put_krv",  emoji: "🩸", ime: "Kap krvi",           opis: "Završi putovanje kapi krvi." },
  { id: "put_vazduh", emoji: "💨", ime: "Dah na putu",      opis: "Završi putovanje daha." },
  { id: "put_signal", emoji: "⚡", ime: "Munjevit signal",  opis: "Završi putovanje signala." },
  { id: "zasto10",  emoji: "❓", ime: "Pitalica",           opis: "Otkrij 10 odgovora u „Zašto?“." },
  { id: "zasto_sve", emoji: "🌟", ime: "Sveznalica",        opis: "Otkrij sve odgovore u „Zašto?“." },
  { id: "kviz1",    emoji: "🌱", ime: "Mali znalac",         opis: "Završi prvi nivo kviza." },
  { id: "kviz2",    emoji: "🩺", ime: "Veliki znalac",        opis: "Završi drugi nivo kviza." },
  { id: "kviz3",    emoji: "🎓", ime: "Profesor kviza",       opis: "Završi treći nivo kviza." },
  { id: "detektiv", emoji: "🕵️", ime: "Doktor detektiv",    opis: "Reši sve slučajeve." },
  { id: "memo",     emoji: "🃏", ime: "Pamtilica",          opis: "Pronađi sve parove u memoriji." },
  { id: "puls",     emoji: "💓", ime: "Merač pulsa",        opis: "Izmeri svoj puls." },
  { id: "dah",      emoji: "🫧", ime: "Smireni dah",        opis: "Odradi vežbu disanja." },
  { id: "refleks",  emoji: "⏱️", ime: "Brzi refleks",       opis: "Izmeri brzinu reakcije." },
  { id: "oko",      emoji: "👀", ime: "Oštro oko",          opis: "Isprobaj ogled sa okom." },
  { id: "zubi",     emoji: "🦷", ime: "Blistavi zubi",      opis: "Operi sve zube." }
];

window.RANGOVI = [
  { od: 0,    ime: "Mali istraživač" },
  { od: 40,   ime: "Pomoćnik doktora" },
  { od: 120,  ime: "Mladi doktor" },
  { od: 250,  ime: "Doktor" },
  { od: 420,  ime: "Veliki doktor" },
  { od: 650,  ime: "Profesor anatomije" }
];
