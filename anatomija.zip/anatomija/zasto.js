/* ANATOMIJA – „Zašto?“ (pogodi pa saznaj) i „Doktor detektiv“. */
(function () {
  "use strict";
  var $ = A.$, $$ = A.$$, S = A.S, esc = A.esc;

  /* ───────── ZAŠTO? ───────── */
  A.reg("zasto", "❓ Zašto?", function (root, arg) {
    var idx = -1;
    ZASTO.forEach(function (z, i) { if (z.id === arg) idx = i; });
    if (idx < 0) return list(root);
    return one(root, idx);
  });

  function list(root) {
    var n = Object.keys(S.zasto).length;
    root.innerHTML = '<h2 class="pagetitle">Zašto se to dešava?</h2>' +
      '<p class="lead">Telo radi čudne stvari! Izaberi pitanje, pogodi odgovor pa saznaj šta se zaista dešava. <b>' + n + " od " + ZASTO.length + "</b> otkriveno.</p>" +
      '<div class="bar dark"><i style="width:' + Math.round(n / ZASTO.length * 100) + '%"></i></div>' +
      '<div class="zgrid">' + ZASTO.map(function (z) {
        return '<a class="zcard' + (S.zasto[z.id] ? " done" : "") + '" href="#/zasto/' + z.id + '"><span class="ze">' + z.emoji + '</span><span class="zq">' + esc(z.q) + "</span>" + (S.zasto[z.id] ? '<span class="zk">✓</span>' : "") + "</a>";
      }).join("") + "</div>";
  }

  function one(root, idx) {
    var z = ZASTO[idx], tries = 0, solved = false;
    var opts = A.shuffle(z.opc.map(function (t, i) { return { t: t, ok: i === 0 }; }));
    var prev = ZASTO[idx - 1], next = ZASTO[idx + 1];
    var deo = DELOVI[z.deo];

    root.innerHTML =
      '<div class="card zq-card">' +
        '<div class="zhead"><span class="te big">' + z.emoji + "</span><h2>" + esc(z.q) + "</h2></div>" +
        (A.canSpeak ? '<button class="btn soft rd" id="rd" aria-label="Pročitaj naglas">🔊 Čitaj</button>' : "") +
        '<p class="lead">Šta misliš, zašto je tako? Izaberi odgovor.</p>' +
        '<div class="opts" id="opts">' + opts.map(function (o) { return '<button class="opt" data-ok="' + (o.ok ? 1 : 0) + '">' + esc(o.t) + "</button>"; }).join("") + "</div>" +
        '<div class="fb" id="fb"></div>' +
        '<div class="znav">' +
          (prev ? '<a class="btn ghost" href="#/zasto/' + prev.id + '">← Prethodno</a>' : "<span></span>") +
          '<a class="btn ghost" href="#/zasto">Sva pitanja</a>' +
          (next ? '<a class="btn ghost" href="#/zasto/' + next.id + '">Sledeće →</a>' : "<span></span>") +
        "</div>" +
      "</div>";

    var rd = $("#rd", root);
    if (rd) rd.addEventListener("click", function () { A.speak(solved ? z.odg : z.q + " " + z.opc.join(". ")); });

    function reveal(win) {
      solved = true;
      $$(".opt", root).forEach(function (b) { b.disabled = true; if (b.getAttribute("data-ok") === "1") b.classList.add("good"); });
      var first = win && !S.zasto[z.id];
      if (win) { S.zasto[z.id] = 1; A.save(); }
      if (first) { A.addXP(5); A.checkBadges(); }
      $("#fb", root).innerHTML =
        '<div class="say ' + (win ? "ok" : "") + '">' + (win ? "✔ <b>Tačno!</b>" : "Nema veze, sad znaš!") + (first ? " +5 poena" : "") + "</div>" +
        '<div class="explain"><h3>Evo šta se dešava</h3><p>' + esc(z.odg) + "</p></div>" +
        (z.probaj ? '<div class="explain try"><h3>🧪 Isprobaj</h3><p>' + esc(z.probaj) + "</p></div>" : "") +
        '<div class="row">' + (deo ? '<a class="btn soft" href="#/skener/' + z.deo + '">Pokaži na telu: ' + esc(deo.ime) + "</a>" : "") + (next ? '<a class="btn" href="#/zasto/' + next.id + '">Sledeće pitanje →</a>' : "") + "</div>";
      if (win) { A.sfx.ok(); if (first) A.confetti(30); }
      var f = $("#fb", root); if (f && !A.reduce) setTimeout(function () { f.scrollIntoView({ behavior: "smooth", block: "nearest" }); }, 60);
    }

    $("#opts", root).addEventListener("click", function (ev) {
      var b = ev.target.closest(".opt"); if (!b || solved) return;
      if (b.getAttribute("data-ok") === "1") { b.classList.add("good"); reveal(true); return; }
      tries++; b.classList.add("bad"); b.disabled = true; A.sfx.no();
      if (tries >= 2) { reveal(false); return; }
      $("#fb", root).innerHTML = '<div class="say no">Skoro! Probaj još jednom.</div>';
    });
  }

  /* ───────── DOKTOR DETEKTIV ───────── */
  A.reg("detektiv", "🕵️ Doktor detektiv", function (root) {
    var cur = 0, wrong = 0, solved = false, sys = "sve", timers = [];
    for (var i = 0; i < SLUCAJEVI.length; i++) if (!S.det[i]) { cur = i; break; }

    root.innerHTML =
      '<div class="skener det">' +
        '<div class="syschips" role="tablist">' + SISTEMI.map(function (s) { return '<button class="chip sys" data-sys="' + s.id + '" style="--c:' + s.boja + '"><span>' + s.emoji + "</span>" + esc(s.ime) + "</button>"; }).join("") + "</div>" +
        '<div class="left"><div class="stagebox" id="sbox"><div class="scan"></div>' + BODY.stage("sve", "main") + "</div></div>" +
        '<div class="right"><div id="case"></div></div>' +
      "</div>";
    var svg = $("svg.stage", root), box = $("#sbox", root);

    function chips() { $$(".chip.sys", root).forEach(function (b) { b.classList.toggle("on", b.getAttribute("data-sys") === sys); }); }
    function setSys(s) {
      sys = s; svg.setAttribute("data-sys", s); A.tweenVB(svg, BODY.VB[s]);
      box.classList.remove("scanning"); void box.offsetWidth; box.classList.add("scanning"); chips();
      $$(".part.sel,.part.right", svg).forEach(function (p) { p.classList.remove("sel", "right"); });
    }
    function dots() {
      return '<div class="dots">' + SLUCAJEVI.map(function (c, i) { return '<button class="dot' + (S.det[i] ? " ok" : "") + (i === cur ? " cur" : "") + '" data-i="' + i + '" aria-label="Slučaj ' + (i + 1) + '">' + (S.det[i] ? "✓" : i + 1) + "</button>"; }).join("") + "</div>";
    }
    function show() {
      var c = SLUCAJEVI[cur]; wrong = 0; solved = false;
      $$(".chip.sys", root).forEach(function (b) { b.classList.remove("hintpulse"); });
      $$(".part.sel,.part.right", svg).forEach(function (p) { p.classList.remove("sel", "right"); });
      $("#case", root).innerHTML =
        '<article class="card casecard">' +
          '<div class="zhead"><span class="te big">' + c.emoji + "</span><div><div class=\"stname\">Slučaj " + (cur + 1) + " od " + SLUCAJEVI.length + "</div><h2>Pacijent: " + esc(c.ime) + "</h2></div></div>" +
          '<p class="story">' + esc(c.prica) + "</p>" +
          '<p class="lead">Dodirni na telu deo koji je odgovor. Ako ga ne vidiš, probaj drugi sloj (Kostur, Mišići...).</p>' +
          '<div class="say" id="dsay">🔎 Čekam tvoj odgovor…</div>' +
          '<div class="row">' + (A.canSpeak ? '<button class="btn soft" id="drd">🔊 Čitaj</button>' : "") + '<button class="btn ghost" id="dh">💡 Savet</button><button class="btn ghost" id="dskip">Preskoči →</button></div>' +
          dots() +
        "</article>";
      var rd = $("#drd", root); if (rd) rd.addEventListener("click", function () { A.speak(c.prica); });
      $("#dh", root).addEventListener("click", function () { $("#dsay", root).className = "say"; $("#dsay", root).innerHTML = "💡 Savet: " + esc(c.hint); });
      $("#dskip", root).addEventListener("click", function () { go((cur + 1) % SLUCAJEVI.length); });
      $$(".dot", root).forEach(function (d) { d.addEventListener("click", function () { go(+d.getAttribute("data-i")); }); });
    }
    function go(i) { cur = i; show(); }

    function allDone() {
      var n = 0; for (var k in S.det) if (S.det[k]) n++;
      return n >= SLUCAJEVI.length;
    }
    function check(id) {
      var c = SLUCAJEVI[cur], say = $("#dsay", root);
      if (solved) return;
      if (c.ok.indexOf(id) >= 0) {
        solved = true;
        $$('.part[data-id="' + id + '"]', svg).forEach(function (p) { p.classList.add("sel"); });
        var first = !S.det[cur]; S.det[cur] = 1; A.save();
        A.markPart(id); A.sfx.ok();
        if (first) { A.addXP(6); A.checkBadges(); A.confetti(30); }
        say.className = "say ok";
        say.innerHTML = "✔ <b>Tačno!</b> " + esc(c.sta) + (first ? " +6 poena" : "") +
          '<div class="row" style="margin-top:10px"><button class="btn" id="dn">' + (allDone() ? "Gotovo! 🎉" : "Sledeći slučaj →") + '</button><a class="btn soft" href="#/skener/' + id + '">Više o ovom delu</a></div>';
        $("#dn", root).addEventListener("click", function () {
          if (allDone()) { A.confetti(90); say.innerHTML = "🏆 <b>Rešio si sve slučajeve!</b> Pravi si doktor detektiv."; return; }
          var nx = cur; for (var k = 1; k <= SLUCAJEVI.length; k++) { var t = (cur + k) % SLUCAJEVI.length; if (!S.det[t]) { nx = t; break; } }
          go(nx);
        });
        $$(".dot", root).forEach(function (d) { if (+d.getAttribute("data-i") === cur) { d.classList.add("ok"); d.textContent = "✓"; } });
      } else {
        wrong++; A.sfx.no();
        var nm = DELOVI[id] ? DELOVI[id].ime : "taj deo";
        say.className = "say no";
        say.innerHTML = "To je <b>" + esc(nm) + "</b>. Nije on! Probaj još jednom." + (wrong >= 2 ? "<br>💡 Savet: " + esc(c.hint) : "");
        if (wrong >= 4) { var chip = $('.chip.sys[data-sys="' + c.sloj + '"]', root); if (chip) chip.classList.add("hintpulse"); }
      }
    }

    root.addEventListener("click", function (e) {
      var ch = e.target.closest && e.target.closest(".chip.sys");
      if (ch) { A.sfx.tap(); setSys(ch.getAttribute("data-sys")); return; }
      var p = e.target.closest && e.target.closest("svg.stage .part");
      if (p) check(p.getAttribute("data-id"));
    });

    chips(); show();
    return function () { timers.forEach(clearTimeout); };
  });
})();
