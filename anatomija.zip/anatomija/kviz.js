/* ANATOMIJA – Kviz (3 nivoa + kviz sa slikom) i Memorija. */
(function () {
  "use strict";
  var $ = A.$, $$ = A.$$, S = A.S, esc = A.esc;

  function stars(n) { return "⭐".repeat(n) + "☆".repeat(3 - n); }
  function starsFor(c, total) { var r = c / total; return r >= 0.9 ? 3 : r >= 0.65 ? 2 : r >= 0.4 ? 1 : 0; }

  /* ───────── KVIZ ───────── */
  A.reg("kviz", "🎓 Kviz", function (root, arg) {
    if (arg === "slika") return pictureQuiz(root);
    var lv = KVIZ.filter(function (k) { return String(k.id) === arg; })[0];
    if (!lv) return menu(root);
    return run(root, lv);
  });

  function menu(root) {
    root.innerHTML = '<h2 class="pagetitle">Kviz</h2><p class="lead">Pitanja idu od lakih ka težim. Nema žurbe i nema kazni. Posle svakog pitanja saznaš objašnjenje.</p>' +
      '<div class="menu2">' + KVIZ.map(function (k) {
        var b = S.best["kviz" + k.id] || 0;
        return '<a class="card mode link" href="#/kviz/' + k.id + '"><div class="mh"><span class="te">' + k.emoji + "</span><div><h2>" + esc(k.ime) + '</h2><p class="lead">' + esc(k.opis) + "</p></div></div>" +
          '<span class="stars">' + stars(b) + '</span><span class="btn soft">Počni (' + k.pitanja.length + " pitanja)</span></a>";
      }).join("") +
      '<a class="card mode link" href="#/kviz/slika"><div class="mh"><span class="te">🖼️</span><div><h2>Pogodi sa slike</h2><p class="lead">Jedan deo tela je osvetljen. Koji je to?</p></div></div>' +
      '<span class="stars">' + stars(S.best.kvizslika || 0) + '</span><span class="btn soft">Počni (10 pitanja)</span></a>' +
      "</div>";
  }

  function run(root, lv) {
    var qs = lv.pitanja, i = 0, good = 0, answered = false;
    function render() {
      var q = qs[i]; answered = false;
      var opts = A.shuffle(q.o.map(function (t, k) { return { t: t, ok: k === 0 }; }));
      root.innerHTML =
        '<div class="card qwrap">' +
          '<div class="qhead"><b>' + lv.emoji + " " + esc(lv.ime) + '</b><span>Pitanje ' + (i + 1) + " / " + qs.length + "</span></div>" +
          '<div class="bar dark"><i style="width:' + Math.round(i / qs.length * 100) + '%"></i></div>' +
          '<h2 class="qq big">' + esc(q.q) + "</h2>" +
          (A.canSpeak ? '<button class="btn soft rd" id="rd" aria-label="Pročitaj naglas">🔊</button>' : "") +
          '<div class="opts" id="opts">' + opts.map(function (o) { return '<button class="opt" data-ok="' + (o.ok ? 1 : 0) + '">' + esc(o.t) + "</button>"; }).join("") + "</div>" +
          '<div class="fb" id="fb"></div>' +
        "</div>";
      var rd = $("#rd", root); if (rd) rd.addEventListener("click", function () { A.speak(q.q + " " + q.o.join(". ")); });
      $("#opts", root).addEventListener("click", function (ev) {
        var b = ev.target.closest(".opt"); if (!b || answered) return;
        answered = true;
        var ok = b.getAttribute("data-ok") === "1";
        $$(".opt", root).forEach(function (o) { o.disabled = true; if (o.getAttribute("data-ok") === "1") o.classList.add("good"); });
        if (ok) { good++; A.sfx.ok(); } else { b.classList.add("bad"); A.sfx.no(); }
        $("#fb", root).innerHTML = '<div class="say ' + (ok ? "ok" : "no") + '">' + (ok ? "✔ <b>Tačno!</b> " : "Nije baš. ") + esc(q.e) + "</div>" +
          '<button class="btn" id="nx">' + (i === qs.length - 1 ? "Vidi rezultat 🏁" : "Sledeće pitanje →") + "</button>";
        $("#nx", root).addEventListener("click", function () { A.sfx.tap(); i++; if (i >= qs.length) end(); else render(); });
        var f = $("#fb", root); if (f && !A.reduce) setTimeout(function () { f.scrollIntoView({ behavior: "smooth", block: "nearest" }); }, 60);
      });
    }
    function end() {
      var st = starsFor(good, qs.length), prevC = S.best["kvizc" + lv.id] || 0;
      var gain = Math.max(0, good - prevC) * 4;
      S.best["kviz" + lv.id] = Math.max(S.best["kviz" + lv.id] || 0, st);
      S.best["kvizc" + lv.id] = Math.max(prevC, good); A.save();
      if (gain) A.addXP(gain);
      if (st >= 2) A.award("kviz" + lv.id);
      if (st === 3) { A.confetti(90); A.sfx.win(); }
      var msg = st === 3 ? "Fantastično! Pravi stručnjak!" : st === 2 ? "Bravo! Mnogo znaš o telu." : st === 1 ? "Dobro je! Pogledaj Skener pa probaj ponovo." : "Nema veze, učiš dok igraš. Probaj ponovo!";
      var nxt = lv.id < 3 ? '<a class="btn" href="#/kviz/' + (lv.id + 1) + '">Sledeći nivo →</a>' : '<a class="btn" href="#/kviz">Svi nivoi</a>';
      root.innerHTML = '<div class="card qwrap result"><h2>' + lv.emoji + " " + esc(lv.ime) + '</h2><div class="bigstars">' + stars(st) + '</div><p class="lead">Tačnih odgovora: <b>' + good + " od " + qs.length + "</b>. " + msg + (gain ? " +" + gain + " poena." : "") + "</p>" +
        '<div class="row"><button class="btn ghost" id="again">Ponovo</button>' + nxt + "</div></div>";
      $("#again", root).addEventListener("click", function () { A.go("kviz"); setTimeout(function () { A.go("kviz/" + lv.id); }, 30); });
    }
    render();
  }

  /* ───────── POGODI SA SLIKE ───────── */
  var T1 = ["srce", "mozak", "pluca", "zeludac", "oko", "nos", "lobanja", "kicma", "rebra", "uvo"];
  var T2 = ["jetra", "tanko", "debelo", "bubrezi", "besika", "butna", "biceps", "trbusni", "karlica", "jezik", "saka", "stopalo", "nadlaktica", "potkolenica", "grudni", "deltoid", "butni", "list"];
  var T3 = ["jednjak", "dusnik", "osit", "gusteraca", "kljucna", "grudna", "casica", "podlaktica", "zvakacki", "podlakticni", "kicmena"];
  function sample(a, n) { return A.shuffle(a).slice(0, n); }

  function pictureQuiz(root) {
    var ids = sample(T1, 4).concat(sample(T2, 4), sample(T3, 2)), i = 0, good = 0, answered = false;
    function sysFor(id) { return BODY.layerOf(id) === "organi" ? "sve" : DELOVI[id].sys; }
    function render() {
      var id = ids[i], d = DELOVI[id]; answered = false;
      var same = Object.keys(DELOVI).filter(function (k) { return k !== id && DELOVI[k].sys === d.sys; });
      var other = Object.keys(DELOVI).filter(function (k) { return k !== id && DELOVI[k].sys !== d.sys; });
      var wrong = sample(same, 3);
      if (wrong.length < 3) wrong = wrong.concat(sample(other, 3 - wrong.length));
      var opts = A.shuffle([id].concat(wrong));
      root.innerHTML =
        '<div class="skener picq">' +
          '<div class="left"><div class="stagebox"><div class="scan"></div>' + BODY.stage(sysFor(id), "main qz") + "</div></div>" +
          '<div class="right"><div class="card qwrap">' +
            '<div class="qhead"><b>🖼️ Pogodi sa slike</b><span>Pitanje ' + (i + 1) + " / " + ids.length + "</span></div>" +
            '<div class="bar dark"><i style="width:' + Math.round(i / ids.length * 100) + '%"></i></div>' +
            '<h2 class="qq big">Koji je ovo deo tela?</h2>' +
            '<div class="opts" id="opts">' + opts.map(function (o) { return '<button class="opt" data-id="' + o + '">' + DELOVI[o].emoji + " " + esc(DELOVI[o].ime) + "</button>"; }).join("") + "</div>" +
            '<div class="fb" id="fb"></div>' +
          "</div></div>" +
        "</div>";
      var svg = $("svg.stage", root);
      $$('.part[data-id="' + id + '"]', svg).forEach(function (p) { p.classList.add("sel"); });
      $("#opts", root).addEventListener("click", function (ev) {
        var b = ev.target.closest(".opt"); if (!b || answered) return;
        answered = true;
        var ok = b.getAttribute("data-id") === id;
        $$(".opt", root).forEach(function (o) { o.disabled = true; if (o.getAttribute("data-id") === id) o.classList.add("good"); });
        if (ok) { good++; A.sfx.ok(); A.markPart(id); } else { b.classList.add("bad"); A.sfx.no(); }
        $("#fb", root).innerHTML = '<div class="say ' + (ok ? "ok" : "no") + '">' + (ok ? "✔ <b>Tačno!</b> " : "To je <b>" + esc(d.ime) + "</b>. ") + esc(d.cemu) + "</div>" +
          '<button class="btn" id="nx">' + (i === ids.length - 1 ? "Vidi rezultat 🏁" : "Sledeće →") + "</button>";
        $("#nx", root).addEventListener("click", function () { A.sfx.tap(); i++; if (i >= ids.length) end(); else render(); });
      });
    }
    function end() {
      var st = starsFor(good, ids.length), prevC = S.best.kvizslikac || 0, gain = Math.max(0, good - prevC) * 4;
      S.best.kvizslika = Math.max(S.best.kvizslika || 0, st); S.best.kvizslikac = Math.max(prevC, good); A.save();
      if (gain) A.addXP(gain);
      if (st === 3) { A.confetti(80); A.sfx.win(); }
      root.innerHTML = '<div class="card qwrap result"><h2>🖼️ Pogodi sa slike</h2><div class="bigstars">' + stars(st) + '</div><p class="lead">Tačnih odgovora: <b>' + good + " od " + ids.length + "</b>." + (gain ? " +" + gain + " poena." : "") + "</p>" +
        '<div class="row"><button class="btn ghost" id="again">Ponovo</button><a class="btn" href="#/kviz">Svi kvizovi</a></div></div>';
      $("#again", root).addEventListener("click", function () { A.go("kviz"); setTimeout(function () { A.go("kviz/slika"); }, 30); });
    }
    render();
  }

  /* ───────── MEMORIJA ───────── */
  A.reg("memo", "🃏 Memorija", function (root, arg) {
    var n = +arg;
    if (!(n === 6 || n === 8 || n === 12)) {
      root.innerHTML = '<h2 class="pagetitle">Memorija</h2><p class="lead">Okreni dve kartice. Spoj deo tela sa onim što radi.</p>' +
        '<div class="menu2">' + [[6, "Lako", 12], [8, "Srednje", 16], [12, "Teško", 24]].map(function (l) {
          return '<a class="card mode link" href="#/memo/' + l[0] + '"><div class="mh"><span class="te">🃏</span><div><h2>' + l[1] + '</h2><p class="lead">' + l[0] + " parova, " + l[2] + ' kartica</p></div></div><span class="btn soft">Igraj</span></a>';
        }).join("") + "</div>";
      return;
    }
    var pairs = A.shuffle(MEMO_PAROVI).slice(0, n), deck = [];
    pairs.forEach(function (p, k) { deck.push({ k: k, t: p.a, side: "a" }); deck.push({ k: k, t: p.b, side: "b" }); });
    deck = A.shuffle(deck);
    var open = [], lock = false, found = 0, moves = 0, timers = [];
    var cols = n === 6 ? 3 : n === 8 ? 4 : 6;

    root.innerHTML = '<div class="qhead memohead"><b>🃏 Memorija</b><span id="mv">Potezi: 0</span><span id="fd">Parovi: 0 / ' + n + '</span></div>' +
      '<div class="memo cols' + cols + '" id="board">' + deck.map(function (c, i) {
        return '<button class="mcard side-' + c.side + '" data-i="' + i + '" aria-label="Kartica"><span class="face back">❓</span><span class="face front">' + esc(c.t) + "</span></button>";
      }).join("") + "</div>";

    $("#board", root).addEventListener("click", function (ev) {
      var b = ev.target.closest(".mcard"); if (!b || lock || b.classList.contains("flip") || b.classList.contains("match")) return;
      b.classList.add("flip"); A.sfx.pop(); open.push(b);
      if (open.length === 2) {
        moves++; $("#mv", root).textContent = "Potezi: " + moves; lock = true;
        var a = deck[+open[0].getAttribute("data-i")], c = deck[+open[1].getAttribute("data-i")];
        if (a.k === c.k) {
          timers.push(setTimeout(function () {
            open.forEach(function (x) { x.classList.add("match"); });
            open = []; lock = false; found++; A.sfx.ok(); $("#fd", root).textContent = "Parovi: " + found + " / " + n;
            if (found === n) win();
          }, 450));
        } else {
          timers.push(setTimeout(function () { open.forEach(function (x) { x.classList.remove("flip"); }); open = []; lock = false; A.sfx.no(); }, 1100));
        }
      }
    });
    function win() {
      var key = "memo" + n, first = !S.done[key];
      S.done[key] = 1; S.done.memo = 1; A.save();
      if (first) A.addXP(n * 2 + 5);
      A.award("memo"); A.confetti(80);
      var box = document.createElement("div");
      box.className = "card qwrap result";
      box.innerHTML = "<h2>🎉 Svi parovi su pronađeni!</h2><p class=\"lead\">Potezi: <b>" + moves + "</b>." + (first ? " +" + (n * 2 + 5) + " poena." : "") + '</p><div class="row"><button class="btn ghost" id="again">Ponovo</button><a class="btn" href="#/memo">Drugi nivo</a></div>';
      root.appendChild(box);
      $("#again", root).addEventListener("click", function () { A.go("memo"); setTimeout(function () { A.go("memo/" + n); }, 30); });
      box.scrollIntoView({ behavior: A.reduce ? "auto" : "smooth", block: "nearest" });
    }
    return function () { timers.forEach(clearTimeout); };
  });
})();
