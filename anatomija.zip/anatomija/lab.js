/* ANATOMIJA – Laboratorija: puls, disanje, refleks, oko i zubi. */
(function () {
  "use strict";
  var $ = A.$, $$ = A.$$, S = A.S, esc = A.esc;
  var HEART = '<path d="M50 86 C10 56 0 36 0 23 A22 22 0 0 1 50 15 A22 22 0 0 1 100 23 C100 36 90 56 50 86 Z" fill="#ff4d6d" stroke="#b81e3e" stroke-width="4" stroke-linejoin="round"/><path d="M18 26 C18 20 24 16 31 17" fill="none" stroke="#ffc0cb" stroke-width="5" stroke-linecap="round"/>';

  var LABS = [
    { id: "puls", e: "💓", t: "Puls", d: "Vidi kako srce ubrzava i izmeri svoj puls.", c: "#ff8f9c" },
    { id: "dah", e: "🌬️", t: "Disanje", d: "Smireno diši uz balon i gledaj pluća.", c: "#8cc8ff" },
    { id: "refleks", e: "⏱️", t: "Refleks", d: "Koliko brzo reaguješ? Probaj i refleks kolena.", c: "#ffe27a" },
    { id: "oko", e: "👁️", t: "Oko", d: "Zenica na svetlu i mraku, i slepa mrlja.", c: "#c8b8ff" },
    { id: "zubi", e: "🦷", t: "Zubi", d: "Operi sve zube i upoznaj sekutiće, očnjake i kutnjake.", c: "#a9ea8e" }
  ];

  A.reg("lab", "🧪 Laboratorija", function (root, arg) {
    var f = { puls: puls, dah: dah, refleks: refleks, oko: oko, zubi: zubi }[arg];
    if (!f) {
      root.innerHTML = '<h2 class="pagetitle">Laboratorija</h2><p class="lead">Ovde sve probaš na sopstvenom telu. Izaberi ogled.</p>' +
        '<div class="menu2">' + LABS.map(function (l) {
          return '<a class="card mode link" href="#/lab/' + l.id + '"><div class="mh"><span class="te" style="background:' + l.c + '">' + l.e + "</span><div><h2>" + l.t + (S.lab[l.id] ? " ✓" : "") + '</h2><p class="lead">' + esc(l.d) + '</p></div></div><span class="btn soft">Počni</span></a>';
        }).join("") + "</div>";
      return;
    }
    return f(root);
  });

  function done(id, xp) {
    var first = !S.lab[id];
    S.lab[id] = 1; A.save();
    if (first) { A.addXP(xp || 10); }
    A.award(id);
    return first;
  }

  /* ───────── PULS ───────── */
  function puls(root) {
    var ACTS = [
      { e: "😴", t: "Spavam", b: 65, x: "Dok spavaš, telu treba malo kiseonika, pa srce kuca polako." },
      { e: "🪑", t: "Sedim", b: 85, x: "Kad mirno sediš, srce kuca umereno." },
      { e: "🚶", t: "Hodam", b: 105, x: "Mišići rade malo više, pa srce ubrza." },
      { e: "🏃", t: "Trčim", b: 150, x: "Mišići rade jako i traže mnogo kiseonika. Srce jako ubrza da ga pošalje." },
      { e: "🤸", t: "Skačem", b: 165, x: "Skakanje je veliki napor. Zato srce kuca najbrže." }
    ];
    var bpm = 85, raf = 0, sound = false, taps = 0, measuring = false, tleft = 15, tmr = 0, hist = [];

    root.innerHTML =
      '<h2 class="pagetitle">💓 Puls</h2>' +
      '<div class="labgrid">' +
        '<section class="card lab">' +
          '<h3>Šta radiš? Pogledaj srce</h3>' +
          '<div class="row acts">' + ACTS.map(function (a, i) { return '<button class="btn soft act' + (a.b === bpm ? " on" : "") + '" data-i="' + i + '" style="--c:#ff8f9c">' + a.e + " " + a.t + "</button>"; }).join("") + "</div>" +
          '<div class="heartbox"><svg viewBox="-6 -12 112 106" class="bigheart" id="bh">' + HEART + '</svg><div class="bpm"><b id="bpm">' + bpm + '</b><span>otkucaja u minuti</span></div></div>' +
          '<canvas id="ecg" class="ecg" height="110"></canvas>' +
          '<p class="lead" id="ax">' + ACTS[1].x + "</p>" +
          '<button class="btn ghost" id="snd2">🔇 Slušaj otkucaje</button>' +
        "</section>" +
        '<section class="card lab">' +
          '<h3>Izmeri svoj puls</h3>' +
          '<ol class="steps"><li>Stavi dva prsta na zglob šake (ispod palca) ili sa strane vrata.</li><li>Kad osetiš otkucaj, dodirni srce. Ukupno meriš 15 sekundi.</li><li>Brojač će sam izračunati koliko otkucaja imaš u minuti.</li></ol>' +
          '<button class="tapheart" id="tap" aria-label="Dodirni na svaki otkucaj"><svg viewBox="-6 -12 112 106">' + HEART + '</svg><span id="tapn">Dodirni da počneš</span></button>' +
          '<div class="say" id="res">Savet: izmeri puls dok miruješ, pa posle 20 čučnjeva.</div>' +
          '<ul class="hist" id="hist"></ul>' +
        "</section>" +
      "</div>";

    /* EKG */
    var cv = $("#ecg", root), ctx = cv.getContext("2d"), dpr = window.devicePixelRatio || 1, W = 0, H = 110, buf = [], phase = 0, last = 0, beatNo = 0;
    function size() { W = cv.clientWidth || 300; cv.width = W * dpr; cv.height = H * dpr; ctx.setTransform(dpr, 0, 0, dpr, 0, 0); buf = []; }
    function g(p, c, w) { var d = (p - c) / w; return Math.exp(-d * d); }
    function wave(p) { return 0.13 * g(p, 0.12, 0.03) - 0.14 * g(p, 0.255, 0.01) + 1.0 * g(p, 0.29, 0.011) - 0.28 * g(p, 0.325, 0.012) + 0.28 * g(p, 0.55, 0.05); }
    function frame(t) {
      raf = requestAnimationFrame(frame);
      if (!last) last = t; var dt = Math.min(0.1, (t - last) / 1000); last = t;
      var spd = 140, step = 2, period = 60 / bpm, n = Math.max(1, Math.round(dt * spd / step)), maxN = Math.ceil(W / step) + 2;
      for (var k = 0; k < n; k++) {
        var prev = phase; phase += (step / spd) / period;
        if (phase >= 1) { phase -= 1; }
        if (prev < 0.29 && (phase >= 0.29 || phase < prev)) { beatNo++; if (sound) A.sfx.thump(); }
        buf.push(wave(phase)); if (buf.length > maxN) buf.shift();
      }
      ctx.clearRect(0, 0, W, H);
      ctx.strokeStyle = "rgba(143,227,255,.25)"; ctx.lineWidth = 1;
      for (var gx = 0; gx < W; gx += 28) { ctx.beginPath(); ctx.moveTo(gx, 0); ctx.lineTo(gx, H); ctx.stroke(); }
      ctx.strokeStyle = "#2fd6a6"; ctx.lineWidth = 3; ctx.lineJoin = "round"; ctx.beginPath();
      var off = W - buf.length * step;
      buf.forEach(function (y, i) { var x = off + i * step, py = H * 0.68 - y * H * 0.55; if (i === 0) ctx.moveTo(x, py); else ctx.lineTo(x, py); });
      ctx.stroke();
    }
    size(); raf = requestAnimationFrame(frame);
    window.addEventListener("resize", size);

    function setBpm(i) {
      bpm = ACTS[i].b;
      $$(".act", root).forEach(function (b, k) { b.classList.toggle("on", k === i); });
      $("#bpm", root).textContent = bpm;
      $("#ax", root).textContent = ACTS[i].x;
      $("#bh", root).style.animationDuration = (60 / bpm) + "s";
      A.sfx.tap();
    }
    $("#bh", root).style.animationDuration = (60 / bpm) + "s";
    $$(".act", root).forEach(function (b) { b.addEventListener("click", function () { setBpm(+b.getAttribute("data-i")); }); });
    $("#snd2", root).addEventListener("click", function () { sound = !sound; this.textContent = sound ? "🔊 Zvuk uključen" : "🔇 Slušaj otkucaje"; if (sound) A.sfx.thump(); });

    /* merenje */
    function finish() {
      measuring = false; clearInterval(tmr);
      var v = taps * 4;
      hist.unshift(v); hist = hist.slice(0, 4);
      var msg = v < 40 ? "Izgleda da si propustio poneki otkucaj. Pokušaj ponovo." :
        v <= 110 ? "Tvoj puls je oko <b>" + v + "</b> otkucaja u minuti. To je lep puls za dete tvojih godina kad miruje." :
        v <= 150 ? "Tvoj puls je oko <b>" + v + "</b>. To je malo brže jer si se kretao ili si uzbuđen. Odmori se par minuta i izmeri ponovo!" :
        "Tvoj puls je oko <b>" + v + "</b>. Srce kuca brzo posle napora. Odmori se, pa izmeri ponovo.";
      $("#res", root).innerHTML = msg;
      $("#hist", root).innerHTML = hist.map(function (h, i) { return "<li>" + (i === 0 ? "Sada" : "Ranije") + ": <b>" + h + "</b></li>"; }).join("");
      $("#tapn", root).textContent = "Dodirni za novo merenje";
      if (v >= 40) { done("puls", 10); A.sfx.ok(); }
    }
    $("#tap", root).addEventListener("click", function () {
      var tp = this;
      if (!measuring) {
        measuring = true; taps = 1; tleft = 15; $("#tapn", root).textContent = "Otkucaji: 1 · " + tleft + " s";
        $("#res", root).textContent = "Meri… dodiruj na svaki otkucaj.";
        tmr = setInterval(function () { tleft--; $("#tapn", root).textContent = "Otkucaji: " + taps + " · " + tleft + " s"; if (tleft <= 0) finish(); }, 1000);
      } else { taps++; $("#tapn", root).textContent = "Otkucaji: " + taps + " · " + tleft + " s"; }
      tp.classList.remove("hit"); void tp.offsetWidth; tp.classList.add("hit"); A.sfx.pop();
    });

    return function () { cancelAnimationFrame(raf); clearInterval(tmr); window.removeEventListener("resize", size); };
  }

  /* ───────── DISANJE ───────── */
  function dah(root) {
    var running = false, timers = [], n = 0, GOAL = 4, IN = 4, OUT = 5;
    root.innerHTML =
      '<h2 class="pagetitle">🌬️ Disanje</h2>' +
      '<div class="labgrid">' +
        '<section class="card lab center">' +
          '<h3>Diši uz balon</h3>' +
          '<div class="breathbox"><div class="balloon" id="bl"><span id="bt">Spreman?</span></div></div>' +
          '<div class="bcount" id="bc">Udisaji: 0 / ' + GOAL + "</div>" +
          '<button class="btn big" id="bstart">Počni da dišeš</button>' +
        "</section>" +
        '<section class="card lab">' +
          '<h3>Šta se dešava u telu?</h3>' +
          '<div class="stagebox lungbox" id="lg">' + BODY.emptyStage("lungs") + "</div>" +
          '<p class="lead" id="bx">Kad udahneš, ošit se spusti i pluća se napune vazduhom. Kad izdahneš, ošit se vrati gore, a vazduh izađe.</p>' +
          '<p class="lead">Sporo disanje smiruje telo i srce. Zato ti je lakše kad se uplašiš ili naljutiš ako dišeš polako.</p>' +
        "</section>" +
      "</div>";
    var bl = $("#bl", root), bt = $("#bt", root), lg = $("#lg", root);
    var svg = $("svg.stage", root);
    svg.setAttribute("viewBox", "70 90 160 190");
    $(".slots", svg).innerHTML = BODY.part("dusnik") + BODY.part("pluca") + BODY.part("osit");
    function phase(kind) {
      var dur = kind === "in" ? IN : OUT;
      bl.style.transition = "transform " + dur + "s ease-in-out, background " + dur + "s";
      lg.style.setProperty("--d", dur + "s");
      bl.classList.toggle("in", kind === "in"); lg.classList.toggle("in", kind === "in");
      bt.textContent = kind === "in" ? "Udahni…" : "Izdahni…";
    }
    function cycle() {
      if (!running) return;
      phase("in");
      timers.push(setTimeout(function () {
        if (!running) return;
        phase("out");
        timers.push(setTimeout(function () {
          n++; $("#bc", root).textContent = "Udisaji: " + n + " / " + GOAL;
          if (n === GOAL) { done("dah", 10); A.toast("🌬️ Bravo! Smireno si dahnuo " + GOAL + " puta.", "ok"); }
          cycle();
        }, OUT * 1000));
      }, IN * 1000));
    }
    $("#bstart", root).addEventListener("click", function () {
      running = !running;
      this.textContent = running ? "Stani" : "Nastavi";
      if (running) cycle(); else { timers.forEach(clearTimeout); timers = []; bt.textContent = "Pauza"; bl.style.transition = "transform 1s"; bl.classList.remove("in"); lg.classList.remove("in"); }
      A.sfx.tap();
    });
    return function () { running = false; timers.forEach(clearTimeout); };
  }

  /* ───────── REFLEKS ───────── */
  function refleks(root) {
    var state = "idle", t0 = 0, tmo = 0, times = [], TRIES = 5;
    root.innerHTML =
      '<h2 class="pagetitle">⏱️ Refleks</h2>' +
      '<div class="labgrid">' +
        '<section class="card lab center">' +
          '<h3>Koliko brzo reaguješ?</h3>' +
          '<p class="lead">Kad polje postane zeleno, odmah ga dodirni!</p>' +
          '<button class="react idle" id="rx"><span id="rt">Dodirni da počneš</span></button>' +
          '<div class="say" id="rr">Imaš ' + TRIES + " pokušaja.</div>" +
          '<ul class="hist" id="rl"></ul>' +
          '<p class="small">Signal ide od oka do mozga, a onda niz nerve do mišića prsta. Za sve to treba oko pola sekunde ili manje.</p>' +
        "</section>" +
        '<section class="card lab center">' +
          '<h3>Refleks kolena 🔨</h3>' +
          '<svg viewBox="0 0 260 220" class="kneesvg" id="knee">' +
            '<rect x="30" y="80" width="130" height="46" rx="23" fill="#ffcfa3" stroke="#c98a58" stroke-width="3"/>' +
            '<g id="shin" style="transform-origin:160px 103px"><rect x="150" y="84" width="40" height="120" rx="20" fill="#ffcfa3" stroke="#c98a58" stroke-width="3"/><ellipse cx="170" cy="210" rx="24" ry="9" fill="#ffcfa3" stroke="#c98a58" stroke-width="3"/></g>' +
            '<circle cx="160" cy="103" r="22" fill="#ffcfa3" stroke="#c98a58" stroke-width="3"/>' +
            '<g id="ham" style="transform-origin:236px 20px"><rect x="150" y="14" width="86" height="12" rx="6" fill="#6b7f92"/><rect x="226" y="2" width="18" height="36" rx="6" fill="#33506b"/></g>' +
          "</svg>" +
          '<button class="btn" id="hit">🔨 Udari čekićem</button>' +
          '<p class="lead" id="kx">Doktor lako udari ispod kolena. Probaj!</p>' +
        "</section>" +
      "</div>";

    var rx = $("#rx", root), rt = $("#rt", root);
    function reset(txt) { state = "idle"; rx.className = "react idle"; rt.textContent = txt || "Dodirni da počneš"; }
    function arm() {
      state = "wait"; rx.className = "react wait"; rt.textContent = "Čekaj… (crveno)";
      tmo = setTimeout(function () { state = "go"; rx.className = "react go"; rt.textContent = "SADA! Dodirni!"; t0 = performance.now(); A.sfx.pop(); }, 1500 + Math.random() * 2800);
    }
    rx.addEventListener("click", function () {
      if (state === "idle") { if (times.length >= TRIES) { times = []; $("#rl", root).innerHTML = ""; } arm(); return; }
      if (state === "wait") { clearTimeout(tmo); A.sfx.no(); $("#rr", root).innerHTML = "Prerano! Čekaj da postane zeleno."; reset("Dodirni da pokušaš ponovo"); return; }
      if (state === "go") {
        var ms = Math.round(performance.now() - t0); times.push(ms); A.sfx.ok();
        $("#rl", root).innerHTML = times.map(function (t, i) { return "<li>" + (i + 1) + ". pokušaj: <b>" + t + " ms</b></li>"; }).join("");
        if (times.length >= TRIES) {
          var avg = Math.round(times.reduce(function (a, b) { return a + b; }, 0) / times.length);
          var c = avg < 350 ? "Munja! Veoma brz refleks." : avg < 500 ? "Super! Brza reakcija." : avg < 700 ? "Dobro! Sa vežbom ide još brže." : "Polako, i to je u redu. Probaj ponovo!";
          $("#rr", root).innerHTML = "Prosek: <b>" + avg + " ms</b>. " + c;
          done("refleks", 10); reset("Dodirni za novu seriju");
        } else { $("#rr", root).innerHTML = "<b>" + ms + " ms</b>. Još " + (TRIES - times.length) + "."; reset("Dodirni za sledeći pokušaj"); }
      }
    });

    var shin = $("#shin", root), ham = $("#ham", root), kneeBusy = false;
    $("#hit", root).addEventListener("click", function () {
      if (kneeBusy) return; kneeBusy = true;
      ham.style.transition = "transform .12s"; ham.style.transform = "rotate(-28deg)";
      A.sfx.pop();
      setTimeout(function () {
        ham.style.transform = "rotate(8deg)";
        shin.style.transition = "transform .15s ease-out"; shin.style.transform = "rotate(-38deg)";
        $("#kx", root).innerHTML = "Noga se sama trgla! To je refleks. Signal je išao do <b>kičmene moždine</b> i odmah nazad do mišića butine. Mozak nije stigao ni da odluči!";
      }, 130);
      setTimeout(function () { ham.style.transform = "rotate(0)"; shin.style.transition = "transform .6s ease-in-out"; shin.style.transform = "rotate(0)"; kneeBusy = false; }, 900);
    });
    return function () { clearTimeout(tmo); };
  }

  /* ───────── OKO ───────── */
  function oko(root) {
    var movedL = 0, movedD = 0;
    root.innerHTML =
      '<h2 class="pagetitle">👁️ Oko</h2>' +
      '<div class="labgrid">' +
        '<section class="card lab">' +
          '<h3>Zenica: mrak ili svetlo</h3>' +
          '<div class="eyebox" id="eb"><svg viewBox="0 0 240 140" class="eyesvg">' +
            '<path d="M10 70 C50 15 190 15 230 70 C190 125 50 125 10 70 Z" fill="#fffdf8" stroke="#33506b" stroke-width="5"/>' +
            '<circle cx="120" cy="70" r="40" fill="#5b8fd0" stroke="#33506b" stroke-width="3"/>' +
            '<circle cx="120" cy="70" r="40" fill="none" stroke="#7fb0e8" stroke-width="10" stroke-dasharray="2 5" opacity=".6"/>' +
            '<circle id="pup" cx="120" cy="70" r="20" fill="#0a1220"/>' +
            '<circle cx="106" cy="56" r="6" fill="#fff" opacity=".9"/>' +
          "</svg></div>" +
          '<div class="sl"><span>🌙</span><input id="lt" type="range" min="0" max="100" value="50" aria-label="Svetlo"><span>☀️</span></div>' +
          '<p class="lead" id="lx">Pomeraj klizač. Pogledaj kako se crna tačka u sredini menja.</p>' +
        "</section>" +
        '<section class="card lab">' +
          '<h3>Slepa mrlja</h3>' +
          '<ol class="steps"><li>Zatvori <b>levo</b> oko.</li><li>Desnim okom gledaj u plus (+).</li><li>Pomeraj klizač, ili približavaj i odmicaj lice, dok kružić ne nestane.</li></ol>' +
          '<div class="spot" id="sp"><span class="plus">+</span><span class="dot" id="dt"></span></div>' +
          '<div class="sl"><span>blizu</span><input id="ds" type="range" min="12" max="92" value="30" aria-label="Pomeri kružić"><span>daleko</span></div>' +
          '<p class="lead">U oku je mesto gde očni nerv izlazi i tu nema ćelija koje vide. To je slepa mrlja. Mozak je sam popuni, pa je obično ne primetimo!</p>' +
        "</section>" +
      "</div>";
    var pup = $("#pup", root), eb = $("#eb", root);
    function setLight(v) {
      var r = 8 + (100 - v) / 100 * 22; pup.setAttribute("r", r.toFixed(1));
      var l = 8 + v * 0.8; eb.style.background = "hsl(" + (v > 55 ? 50 : 215) + "," + (v > 55 ? 90 : 45) + "%," + l + "%)";
      $("#lx", root).textContent = v < 30 ? "Mrak: zenica se širi da uhvati što više svetlosti." : v > 70 ? "Jako svetlo: zenica se sužava da zaštiti oko." : "Srednje svetlo: zenica je srednje velika.";
    }
    $("#lt", root).addEventListener("input", function () { setLight(+this.value); movedL = Math.max(movedL, Math.abs(this.value - 50)); chk(); });
    setLight(50);
    function setDot(v) { $("#dt", root).style.left = v + "%"; }
    $("#ds", root).addEventListener("input", function () { setDot(+this.value); movedD = Math.max(movedD, Math.abs(this.value - 30)); chk(); });
    setDot(30);
    function chk() { if (movedL >= 40 && movedD >= 25) done("oko", 10); }
    return null;
  }

  /* ───────── ZUBI ───────── */
  function zubi(root) {
    var TYPES = ["kutnjak", "kutnjak", "očnjak", "sekutić", "sekutić", "sekutić", "sekutić", "očnjak", "kutnjak", "kutnjak"];
    var CLS = { "kutnjak": "kutnjak", "očnjak": "ocnjak", "sekutić": "sekutic" };
    var INFO = { "sekutić": "seče hranu", "očnjak": "kida hranu", "kutnjak": "melje hranu" };
    var teeth = [], clean = 0, lastX = 0, lastY = 0, down = false;
    function row(top) {
      return '<div class="trow ' + (top ? "up" : "down") + '">' + TYPES.map(function (t, i) {
        return '<div class="tooth ' + CLS[t] + '" data-t="' + t + '"><i class="plak"></i></div>';
      }).join("") + "</div>";
    }
    var total = TYPES.length * 2;
    root.innerHTML = '<h2 class="pagetitle">🦷 Zubi</h2>' +
      '<div class="labgrid"><section class="card lab center"><h3>Operi zube!</h3><p class="lead">Prevlači četkicu preko zuba dok svi ne postanu beli.</p>' +
      '<div class="mouth" id="mouth">' + row(true) + row(false) + '<div class="brush" id="br">🪥</div></div>' +
      '<div class="bcount" id="zc">Čisti zubi: 0 / ' + total + '</div><div class="say" id="zs">Počni sa bilo kojim zubom.</div></section>' +
      '<section class="card lab"><h3>Tri vrste zuba</h3><ul class="kinds"><li><span class="kt sekutic"></span><b>Sekutići</b> su ispred i seku hranu.</li><li><span class="kt ocnjak"></span><b>Očnjaci</b> su šiljati i kidaju hranu.</li><li><span class="kt kutnjak"></span><b>Kutnjaci</b> su široki i melju hranu.</li></ul>' +
      '<p class="lead">Deca imaju 20 mlečnih zuba. Oni ispadaju i na njihovo mesto niču stalni, a odrasli ih imaju do 32. Peri zube dva puta dnevno, oko dva minuta, i ne zaboravi prostor između zuba.</p></section></div>';
    var mouth = $("#mouth", root), br = $("#br", root);
    $$(".tooth", root).forEach(function (el) { teeth.push({ el: el, dirt: 1, plak: el.querySelector(".plak"), done: false }); });
    function brush(ev) {
      var r0 = mouth.getBoundingClientRect();
      br.style.left = (ev.clientX - r0.left) + "px"; br.style.top = (ev.clientY - r0.top) + "px";
      if (!down) return;
      var d = Math.hypot(ev.clientX - lastX, ev.clientY - lastY); lastX = ev.clientX; lastY = ev.clientY;
      if (d < 1.5) return;
      teeth.forEach(function (t) {
        if (t.done) return;
        var r = t.el.getBoundingClientRect();
        if (ev.clientX >= r.left - 4 && ev.clientX <= r.right + 4 && ev.clientY >= r.top - 4 && ev.clientY <= r.bottom + 4) {
          t.dirt = Math.max(0, t.dirt - Math.min(0.18, d / 90));
          t.plak.style.opacity = t.dirt.toFixed(2);
          if (t.dirt <= 0.05) {
            t.done = true; t.plak.style.opacity = 0; t.el.classList.add("clean"); clean++; A.sfx.pop();
            var k = t.el.getAttribute("data-t");
            $("#zc", root).textContent = "Čisti zubi: " + clean + " / " + total;
            $("#zs", root).innerHTML = "✨ Čist <b>" + k + "</b>: " + INFO[k] + ".";
            if (clean === teeth.length) win();
          }
        }
      });
    }
    function win() { $("#zs", root).innerHTML = "🎉 <b>Svi zubi blistaju!</b> Peri ih svako jutro i veče."; done("zubi", 10); A.confetti(60); A.sfx.win(); }
    mouth.addEventListener("pointerdown", function (e) { down = true; lastX = e.clientX; lastY = e.clientY; try { mouth.setPointerCapture(e.pointerId); } catch (x) {} brush(e); });
    mouth.addEventListener("pointermove", brush);
    mouth.addEventListener("pointerup", function () { down = false; });
    mouth.addEventListener("pointercancel", function () { down = false; });
    return null;
  }
})();
