/* ANATOMIJA – „Putovanja“: pratimo zalogaj, kap krvi, dah i nervni signal kroz telo. */
(function () {
  "use strict";
  var $ = A.$, $$ = A.$$, S = A.S, esc = A.esc;
  var NS = "http://www.w3.org/2000/svg";

  // koji deo crteža se prikazuje za koje putovanje
  var VBS = { hrana: [40, 20, 220, 380], krv: [30, 104, 240, 270], vazduh: [40, 20, 220, 380], signal: [20, 0, 260, 420] };
  var SYS_OF = { hrana: "varenje", krv: "krvotok", vazduh: "disanje", signal: "nervi" };

  A.reg("put", "🚀 Putovanja", function (root, arg) {
    var j = PUTOVANJA.filter(function (p) { return p.id === arg; })[0];
    if (!j) return menu(root);
    return play(root, j);
  });

  function menu(root) {
    root.innerHTML = '<h2 class="pagetitle">Putovanja kroz telo</h2><p class="lead">Izaberi putnika i prati ga kroz telo. Na svakoj stanici odgovori na pitanje da bi putnik išao dalje.</p>' +
      '<div class="menu2">' + PUTOVANJA.map(function (p) {
        var done = S.badges["put_" + (p.id === "krv" ? "krv" : p.id)];
        return '<a class="card mode link" href="#/put/' + p.id + '"><div class="mh"><span class="te">' + p.emoji + "</span><div><h2>" + esc(p.ime) + (done ? " ✓" : "") + '</h2><p class="lead">' + esc(p.opis) + '</p></div></div>' +
          '<span class="btn soft">Kreni (' + p.stanice.length + " stanica)</span></a>";
      }).join("") + "</div>";
  }

  function play(root, j) {
    var step = 0, tries = 0, anim = 0, answered = false, timers = [];
    var sys = SYS_OF[j.id], vb = VBS[j.id];

    root.innerHTML =
      '<div class="sklopi put">' +
        '<div class="left"><div class="stagebox" id="sbox">' + BODY.stage(sys, "journey") + "</div></div>" +
        '<div class="right">' +
          '<div class="puzhead"><h2>' + j.emoji + " " + esc(j.ime) + '</h2><span class="cnt" id="cnt"></span></div>' +
          '<div class="card qcard" id="qc"></div>' +
        "</div>" +
      "</div>";

    var svg = $("svg.stage", root), ov = $(".overlay", svg);
    svg.setAttribute("viewBox", vb.join(" "));
    svg.style.pointerEvents = "none";

    // putanja i stanice
    var st = j.stanice;
    // putanja: stanice + međutačke (v) koje savijaju put duž pravih sudova, nerava i organa
    var path = [], idx = [];
    st.forEach(function (s, i) {
      (s.v || []).forEach(function (q) { path.push({ x: q[0], y: q[1] }); });
      idx[i] = path.length; path.push({ x: s.x, y: s.y });
    });
    var pts = path.map(function (q) { return q.x + "," + q.y; }).join(" ");
    ov.innerHTML =
      '<polyline points="' + pts + '" fill="none" stroke="#000" stroke-opacity=".35" stroke-width="7" stroke-linecap="round" stroke-linejoin="round"/>' +
      '<polyline class="trail" points="' + pts + '" fill="none" stroke="#ffd43b" stroke-width="3" stroke-dasharray="2 7" stroke-linecap="round" stroke-linejoin="round"/>' +
      st.map(function (s, i) {
        return '<g class="pin" data-i="' + i + '"><circle cx="' + s.x + '" cy="' + s.y + '" r="9.5"/><text x="' + s.x + '" y="' + (s.y + 4) + '" text-anchor="middle">' + (i + 1) + "</text></g>";
      }).join("") +
      '<g class="token"><circle r="13"/><text text-anchor="middle" y="6">' + j.token + "</text></g>";
    var token = $(".token", ov);
    function moveTo(x, y) { token.setAttribute("transform", "translate(" + x + " " + y + ")"); }
    moveTo(st[0].x, st[0].y);

    function setPin(i, cls) { var p = $('.pin[data-i="' + i + '"]', ov); if (p) p.setAttribute("class", "pin " + cls); }
    function pins() { st.forEach(function (s, i) { setPin(i, i < step ? "done" : i === step ? "cur" : ""); }); }

    function glide(i, cb) {
      var seg = path.slice(idx[i - 1], idx[i] + 1), cum = [0], k;
      for (k = 1; k < seg.length; k++) cum.push(cum[k - 1] + Math.hypot(seg[k].x - seg[k - 1].x, seg[k].y - seg[k - 1].y));
      var L = cum[cum.length - 1] || 1, t0 = performance.now(), dur = A.reduce ? 1 : Math.min(2200, 350 + L * 6);
      (function f(t) {
        var u = Math.min(1, (t - t0) / dur), e = u < .5 ? 2 * u * u : 1 - Math.pow(-2 * u + 2, 2) / 2, d = e * L, m = 1;
        while (m < cum.length - 1 && cum[m] < d) m++;
        var w = (d - cum[m - 1]) / ((cum[m] - cum[m - 1]) || 1);
        moveTo(seg[m - 1].x + (seg[m].x - seg[m - 1].x) * w, seg[m - 1].y + (seg[m].y - seg[m - 1].y) * w - Math.sin(Math.PI * u) * 4);
        if (u < 1) anim = requestAnimationFrame(f); else cb && cb();
      })(t0);
    }

    function ask() {
      answered = false; tries = 0; pins();
      var s = st[step];
      $("#cnt", root).textContent = (step + 1) + " / " + st.length;
      var opts = A.shuffle(s.o.map(function (t, i) { return { t: t, ok: i === 0 }; }));
      $("#qc", root).innerHTML =
        '<div class="stname">📍 Stanica ' + (step + 1) + ": <b>" + esc(s.ime) + "</b></div>" +
        '<h3 class="qq">' + esc(s.q) + "</h3>" +
        '<div class="opts">' + opts.map(function (o, i) { return '<button class="opt" data-ok="' + (o.ok ? 1 : 0) + '">' + esc(o.t) + "</button>"; }).join("") + "</div>" +
        '<div class="fb" id="fb"></div>';
      if (A.canSpeak) $("#qc", root).insertAdjacentHTML("afterbegin", '<button class="btn soft rd" id="rd" aria-label="Pročitaj naglas">🔊</button>');
      var rd = $("#rd", root); if (rd) rd.addEventListener("click", function () { A.speak(s.ime + ". " + s.q + " " + s.o.slice().join(". ")); });
      setTimeout(function () { $$(".opt", root).forEach(function (b) { b.disabled = false; }); }, 0);
    }

    $("#qc", root).addEventListener("click", function (ev) {
      var b = ev.target.closest(".opt"); if (!b || answered) return;
      var ok = b.getAttribute("data-ok") === "1", s = st[step];
      if (ok) {
        answered = true; b.classList.add("good"); A.sfx.ok(); A.addXP(2);
        $$(".opt", root).forEach(function (o) { o.disabled = true; });
        $("#fb", root).innerHTML = '<div class="say ok">✔ ' + esc(s.e) + '</div><button class="btn" id="go">' + (step === st.length - 1 ? "Završi putovanje 🏁" : "Dalje →") + "</button>";
        $("#go", root).addEventListener("click", next);
        setPin(step, "done");
      } else {
        tries++; b.classList.add("bad"); b.disabled = true; A.sfx.no();
        $("#fb", root).innerHTML = '<div class="say no">Skoro! Probaj još jednom.</div>';
      }
    });

    function next() {
      A.sfx.tap();
      if (step === st.length - 1) { finish(); return; }
      step++; pins();
      $("#qc", root).innerHTML = '<div class="traveling">' + j.token + " putuje…</div>";
      glide(step, ask);
    }
    function finish() {
      var key = "put_" + j.id, first = !S.badges[key];
      A.award(key); if (first) A.addXP(25);
      A.confetti(70);
      $("#qc", root).innerHTML = '<div class="say win">🎉 <b>Stigli smo na cilj!</b> ' + esc(j.ime) + " je završeno." + (first ? " +25 poena." : "") + "</div>" +
        '<div class="row" style="margin-top:12px"><a class="btn ghost" href="#/put/' + j.id + '" id="again">Ponovo</a><a class="btn" href="#/put">Druga putovanja</a></div>';
      $("#again", root).addEventListener("click", function (e) { e.preventDefault(); A.go("put"); setTimeout(function () { A.go("put/" + j.id); }, 30); });
      $("#cnt", root).textContent = "gotovo";
    }

    ask();
    return function () { cancelAnimationFrame(anim); timers.forEach(clearTimeout); };
  }
})();
