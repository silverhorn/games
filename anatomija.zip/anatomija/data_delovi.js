/* ANATOMIJA – podaci: sistemi organa i svi delovi tela.
   Svaki deo ima: gde je, šta je, čemu služi, kako radi i zanimljivosti. */
window.SISTEMI = [
  { id: "sve",         ime: "Sve organi",       emoji: "🧍", boja: "#7be0c3", opis: "Pogled na sve važne organe odjednom." },
  { id: "kostur",      ime: "Kostur",           emoji: "🦴", boja: "#f3ead2", opis: "Kosti drže telo uspravno, čuvaju organe i sa mišićima nas pokreću." },
  { id: "misici",      ime: "Mišići",           emoji: "💪", boja: "#ff6b6b", opis: "Mišići se stežu i opuštaju, i tako pomeraju kosti. Svaki korak, osmeh i mig su mišići!" },
  { id: "krvotok",     ime: "Srce i krv",       emoji: "❤️", boja: "#ff4d6d", opis: "Srce pumpa krv kroz krvne sudove i tako svaki deo tela dobija kiseonik i hranu." },
  { id: "disanje",     ime: "Disanje",          emoji: "🌬️", boja: "#ff9bb3", opis: "Pluća unose kiseonik iz vazduha, a izbacuju ugljen-dioksid." },
  { id: "varenje",     ime: "Varenje",          emoji: "🍎", boja: "#ffa94d", opis: "Hrana se razloži na sitne delove koje telo može da upije i iskoristi." },
  { id: "izlucivanje", ime: "Čišćenje tela",    emoji: "💧", boja: "#4dabf7", opis: "Bubrezi čiste krv i prave mokraću, a bešika je skuplja." },
  { id: "nervi",       ime: "Mozak i nervi",    emoji: "🧠", boja: "#ffd43b", opis: "Mozak je šef tela. Nervi su kablovi koji prenose poruke tamo i nazad." },
  { id: "cula",        ime: "Čula",             emoji: "👁️", boja: "#b197fc", opis: "Oči, uši, nos, jezik i koža – naši „prozori“ u svet." }
];

window.DELOVI = {

/* ───────────── MOZAK I NERVI ───────────── */
mozak: { sys: "nervi", ime: "Mozak", emoji: "🧠",
  gde: "U glavi, zaštićen tvrdom lobanjom.",
  sta: "Mozak je komandni centar tela. Težak je oko 1,4 kilograma i izgleda kao naborana, mekana lopta.",
  cemu: "Mozak misli, pamti, uči i oseća. Šalje naređenja mišićima. I kad spavaš, on radi: stara se da srce kuca i da dišeš.",
  kako: "Mozak ima milijarde sitnih nervnih ćelija (neurona). One jedna drugoj šalju sićušne električne signale, kao mreža lampica koje se pale i gase.",
  zan: [
    "Mozak ima oko 86 milijardi nervnih ćelija.",
    "Mozak je samo oko 2% težine tela, a troši oko petinu energije koju telo napravi.",
    "Veliki mozak misli i pamti, mali mozak čuva ravnotežu, a moždano stablo vodi računa o disanju i kucanju srca.",
    "Nabori na mozgu povećavaju njegovu površinu, pa u lobanju stane mnogo više nervnih ćelija."
  ], zasto: ["spavanje", "rast"] },

kicmena: { sys: "nervi", ime: "Kičmena moždina", emoji: "🧵",
  gde: "Unutar kičmenog stuba, od mozga niz celu leđa.",
  sta: "Debeo „kabl“ od nerava, otprilike debljine prsta.",
  cemu: "Prenosi poruke između mozga i celog tela.",
  kako: "Naređenja iz mozga idu niz kičmenu moždinu pa kroz nerve do mišića. Osećaji iz tela (dodir, toplo, bol) putuju u suprotnom smeru, do mozga.",
  zan: [
    "Kad dodirneš nešto vruće, povučeš ruku pre nego što osetiš bol. Taj brzi odgovor je refleks, a njega obrađuje kičmena moždina, ne mozak!",
    "Kod odraslih je kičmena moždina duga oko 45 centimetara."
  ], zasto: ["trnci"] },

nervi: { sys: "nervi", ime: "Nervi", emoji: "⚡",
  gde: "Prolaze kroz celo telo, sve do vrhova prstiju na rukama i nogama.",
  sta: "Tanke „žice“ napravljene od izduženih nervnih ćelija.",
  cemu: "Prenose signale između mozga i svakog dela tela.",
  kako: "Signal je kratak električni impuls. Jedni nervi nose poruke ka mozgu (šta osećaš), a drugi od mozga ka mišićima (kako da se pomeriš).",
  zan: [
    "Najduži nerv u telu je išijadični nerv. Proteže se od donjeg dela leđa sve do stopala.",
    "Nervni signal može da putuje preko 100 metara u sekundi.",
    "Kad udariš lakat i „zaškaklja“ te kao struja, udario si nerv, a ne kost!"
  ], zasto: ["trnci"] },

/* ───────────── SRCE I KRV ───────────── */
srce: { sys: "krvotok", ime: "Srce", emoji: "❤️",
  gde: "U sredini grudnog koša, malo nakrivo na levu stranu, iza grudne kosti.",
  sta: "Srce je jak mišić veličine tvoje stisnute pesnice.",
  cemu: "Pumpa krv kroz celo telo da bi svaki deo dobio kiseonik i hranu.",
  kako: "Srce ima četiri odaje. Desna strana šalje krv u pluća da pokupi kiseonik. Leva strana, jača, tu krv potiskuje kroz celo telo. Zalisci su kao vrata koja puštaju krv samo u jednom smeru. Svako stezanje mišića jedan je otkucaj.",
  zan: [
    "Srce kuca oko 100.000 puta dnevno i ne umara se.",
    "Tokom života srce otkuca više od 2 milijarde puta.",
    "Srce počinje da kuca još u maminom stomaku, kad si bio manji od zrna pasulja.",
    "Dok miruješ, srce deteta kuca oko 70 do 100 puta u minuti."
  ], zasto: ["srce_lupa", "krv_crvena"] },

arterije: { sys: "krvotok", ime: "Arterije", emoji: "🔴",
  gde: "Razgranate su kroz celo telo i kreću iz srca.",
  sta: "Debeli, čvrsti i elastični krvni sudovi.",
  cemu: "Nose krv bogatu kiseonikom iz srca ka telu.",
  kako: "Zidovi arterija su mišićni i elastični. Šire se i skupljaju sa svakim otkucajem. Taj talas možeš da osetiš na zglobu šake ili na vratu – to je puls!",
  zan: [
    "Najveća arterija je aorta, skoro debela kao baštensko crevo.",
    "Krv u arterijama je jarko crvena jer je puna kiseonika."
  ], zasto: ["srce_lupa"] },

vene: { sys: "krvotok", ime: "Vene", emoji: "🔵",
  gde: "Prate arterije kroz celo telo. Mnoge se vide kao plavičaste linije ispod kože, na primer na zglobu šake.",
  sta: "Krvni sudovi koji vraćaju krv u srce.",
  cemu: "Vraćaju iskorišćenu krv (sa manje kiseonika) iz tela nazad u srce.",
  kako: "U venama su mali zalisci koji sprečavaju da se krv vrati unazad. Mišići koji se kreću stežu vene i guraju krv ka srcu. Zato je kretanje zdravo!",
  zan: [
    "Vene izgledaju plavo kroz kožu, ali krv u njima nije plava. I ona je crvena, samo tamnija."
  ], zasto: ["krv_crvena"] },

kapilari: { sys: "krvotok", ime: "Kapilari", emoji: "🕸️",
  gde: "Svuda u telu: između arterija i vena, u svakom mišiću, organu i u koži.",
  sta: "Najtanji krvni sudovi, tanji od vlasi kose.",
  cemu: "Ovde krv predaje kiseonik i hranu ćelijama, a uzima otpad.",
  kako: "Zidovi kapilara su tanki kao jedan sloj ćelija, pa kiseonik lako prođe iz krvi do ćelija.",
  zan: [
    "Kad bi se svi krvni sudovi odraslog čoveka poređali u niz, bili bi dugi oko 100.000 kilometara. To je više puta oko cele Zemlje, po proceni naučnika.",
    "Kad pocrveniš od stida, kapilari u obrazima se prošire pa dođe više krvi."
  ], zasto: ["pocrveni"] },

krv: { sys: "krvotok", ime: "Krv", emoji: "🩸",
  gde: "Teče kroz krvne sudove po celom telu.",
  sta: "Crvena tečnost. Odrasla osoba ima oko 5 litara krvi.",
  cemu: "Prenosi kiseonik, hranu i vodu do svih delova tela, odnosi otpad, brani nas od klica i zatvara rane.",
  kako: "U krvi plivaju: crvena zrnca (nose kiseonik), bela zrnca (čuvari protiv klica) i trombociti (zatvaraju ranu). Sve to pliva u tečnosti koja se zove plazma.",
  zan: [
    "Crvena zrnca su crvena zbog hemoglobina, koji sadrži gvožđe.",
    "Crvena zrnca žive oko 4 meseca, a koštana srž pravi nova, milione svake sekunde.",
    "Postoje četiri krvne grupe: A, B, AB i 0."
  ], zasto: ["krv_crvena", "krasta"] },

/* ───────────── DISANJE ───────────── */
pluca: { sys: "disanje", ime: "Pluća", emoji: "🌬️",
  gde: "U grudnom košu, levo i desno od srca, zaštićena rebrima.",
  sta: "Dva meka, sunđerasta organa. Desno plućno krilo je malo veće, jer levo mora da ostavi mesta za srce.",
  cemu: "Unose kiseonik iz vazduha u krv i izbacuju ugljen-dioksid, gas koji telu ne treba.",
  kako: "Vazduh ide kroz dušnik, pa kroz sve manje cevčice, do sićušnih mehurića (alveola). Zidovi alveola su tanki: kiseonik prelazi u krv, a ugljen-dioksid iz krvi izlazi u vazduh. Ti ga izdahneš.",
  zan: [
    "Kad bi se sve alveole raširile, prekrile bi oko 70 kvadratnih metara, kao veliki stan.",
    "Udahneš oko 20.000 puta dnevno.",
    "Pluća nemaju mišiće! Ošit i mišići između rebara im pomažu da se šire."
  ], zasto: ["stucanje", "kijanje", "zagrcnemo"] },

dusnik: { sys: "disanje", ime: "Dušnik", emoji: "🎐",
  gde: "Ide od grla niz vrat, ispred jednjaka, do pluća.",
  sta: "Cev od hrskavičavih prstenova, duga oko 10 do 12 cm kod odraslih.",
  cemu: "Vodi vazduh do pluća.",
  kako: "Iznutra je obložen sluzi i sitnim trepljama. One hvataju prašinu i klice i guraju ih nagore, da ih iskašljemo ili progutamo.",
  zan: [
    "Prstenovi od hrskavice drže dušnik otvorenim, kao spirala na crevu usisivača.",
    "Na vrhu je mali „poklopac“ (epiglotis) koji se zatvori kad gutaš, da hrana ne ode u pogrešnu cev."
  ], zasto: ["zagrcnemo", "kijanje", "curi_nos"] },

osit: { sys: "disanje", ime: "Ošit (dijafragma)", emoji: "🎈",
  gde: "Odmah ispod pluća. Odvaja grudni koš od stomaka.",
  sta: "Veliki mišić oblika kupole.",
  cemu: "To je glavni mišić za disanje.",
  kako: "Kad udahneš, ošit se stegne i spusti, pa se pluća šire i uvlače vazduh. Kad izdahneš, ošit se opusti i vrati gore.",
  zan: [
    "Štucanje nastaje kad se ošit iznenada trzne!",
    "Ošit radi bez prestanka, i kad spavaš, i ne moraš da misliš na njega."
  ], zasto: ["stucanje"] },

/* ───────────── VARENJE ───────────── */
jednjak: { sys: "varenje", ime: "Jednjak", emoji: "🌭",
  gde: "Cev iza dušnika, koja povezuje grlo i želudac.",
  sta: "Mišićna cev duga oko 25 cm.",
  cemu: "Gura zalogaj do želuca.",
  kako: "Mišići jednjaka se talasasto stežu i guraju hranu nadole. To se zove peristaltika. Zato možeš da gutaš čak i naglavačke!",
  zan: [
    "Zalogaj stigne do želuca za nekoliko sekundi.",
    "Na ulazu u želudac je mišić-vratanca koja ne puštaju kiselinu da ide nazad."
  ], zasto: ["zagrcnemo"] },

zeludac: { sys: "varenje", ime: "Želudac", emoji: "🍲",
  gde: "U gornjem levom delu stomaka, ispod ošita.",
  sta: "Mišićna vreća oblika slova J. Prazan je mali kao pesnica, a kad se napuni, rastegne se i primi oko litar hrane i pića.",
  cemu: "Drobi hranu i meša je sa kiselinom da bi se razložila.",
  kako: "Zidovi se stežu i mešaju hranu. Želudačni sok sa kiselinom razlaže hranu u gustu kašu. Sluz štiti zid želuca od sopstvene kiseline.",
  zan: [
    "Hrana ostaje u želucu oko 2 do 4 sata.",
    "Kad stomak „krči“, to se pomeraju vazduh i tečnost kroz želudac i creva.",
    "Kiselina u želucu je dovoljno jaka da ubije mnoge klice koje pojedeš."
  ], zasto: ["krci", "gladni", "leptiri"] },

jetra: { sys: "varenje", ime: "Jetra", emoji: "🟤",
  gde: "Desno u stomaku, odmah ispod ošita i pluća. Delom je pokrivena rebrima.",
  sta: "Najveći organ unutar tela, težak oko 1,5 kg, braonkaste boje.",
  cemu: "Čisti krv, pravi žuč koja pomaže da se svari masnoća, čuva energiju i vitamine.",
  kako: "Sva krv iz creva prvo prolazi kroz jetru. Ona izdvoji štetne materije, razloži šta treba, a višak šećera sačuva za kad nam zatreba.",
  zan: [
    "Jetra ima čudesnu moć: posle povrede može da naraste nazad!",
    "Jetra obavlja stotine različitih poslova.",
    "Žuč se čuva u maloj žučnoj kesici ispod jetre."
  ], zasto: [] },

gusteraca: { sys: "varenje", ime: "Gušterača", emoji: "🥐",
  gde: "Iza želuca, položena kao mali dugi list.",
  sta: "Mala žlezda duga oko 15 cm.",
  cemu: "Pravi sokove za varenje i insulin.",
  kako: "Sokovi gušterače idu u tanko crevo i razlažu masti, belančevine i šećere. Insulin ide u krv i pomaže da šećer uđe u ćelije kao energija.",
  zan: [
    "Gušterača radi dva posla: „fabrika“ soka za varenje i „čuvar“ šećera u krvi."
  ], zasto: [] },

tanko: { sys: "varenje", ime: "Tanko crevo", emoji: "🍝",
  gde: "U sredini stomaka, namotano u mnogo petlji.",
  sta: "Uska cev, duga nekoliko metara (kod odraslog oko 6).",
  cemu: "Ovde se hrana vari do kraja i hranljive materije prelaze u krv.",
  kako: "Zid creva je pun sićušnih resica, kao baršunasti tepih. One uvećavaju površinu pa se hranljive materije (šećeri, masti, belančevine, vitamini) brzo upijaju u krv.",
  zan: [
    "Tanko crevo je duže od debelog, ali je tanje. Zato se tako i zove.",
    "Zbog resica je površina tankog creva ogromna, mnogo veća od površine tvog stomaka. Zato se hrana tako brzo upija."
  ], zasto: ["krci", "gladni"] },

debelo: { sys: "varenje", ime: "Debelo crevo", emoji: "🥨",
  gde: "Uokviruje tanko crevo: ide gore desno, preko stomaka, pa dole levo.",
  sta: "Deblja cev, duga oko 1,5 metar.",
  cemu: "Upija vodu i pravi stolicu od onoga što telo ne može da iskoristi.",
  kako: "Ono što stigne iz tankog creva je tečno. Debelo crevo upije vodu i od ostatka napravi stolicu koju izbacimo. U njemu žive i „dobre bakterije“ koje nam pomažu.",
  zan: [
    "U crevima živi milijarde i milijarde bakterija, a većina nam je od koristi.",
    "Hrani je potrebno oko jedan do dva dana da prođe kroz ceo put."
  ], zasto: ["krci", "leptiri"] },

/* ───────────── ČIŠĆENJE TELA ───────────── */
bubrezi: { sys: "izlucivanje", ime: "Bubrezi", emoji: "🫘",
  gde: "Dva su, levo i desno u leđima, ispod rebara, na visini struka.",
  sta: "Organi oblika graha, veliki kao tvoja stisnuta pesnica.",
  cemu: "Čiste krv i prave mokraću.",
  kako: "Krv prolazi kroz milione sitnih filtera. Višak vode i otpad se izdvoje kao mokraća, a ono što telu treba vrati se u krv.",
  zan: [
    "Bubrezi filtriraju svu krv u telu otprilike 40 puta dnevno.",
    "Čovek može da živi i sa samo jednim zdravim bubregom.",
    "Kad piješ dovoljno vode, bubrezima je lakše."
  ], zasto: ["zedj"] },

besika: { sys: "izlucivanje", ime: "Bešika", emoji: "🎒",
  gde: "Dole u stomaku, iza karlične kosti.",
  sta: "Elastična vrećica od mišića.",
  cemu: "Skuplja mokraću dok ne dođe vreme za WC.",
  kako: "Mokraća stiže iz bubrega kroz dve tanke cevčice. Kad se bešika napuni, šalje signal mozgu: „Treba u WC!“. Mozak odlučuje kad će se mišić opustiti.",
  zan: [
    "Bešika odraslog može da primi pola litra ili više, a deca manje.",
    "Dok je prazna, bešika je mala kao kruška."
  ], zasto: ["zedj"] },

/* ───────────── ČULA ───────────── */
oko: { sys: "cula", ime: "Oko", emoji: "👁️",
  gde: "U očnim dupljama lobanje, zaštićeno kapcima i trepavicama.",
  sta: "Loptast organ širine oko 2,5 cm.",
  cemu: "Omogućava nam da vidimo.",
  kako: "Svetlost uđe kroz zenicu, a sočivo je skupi tako da na mrežnjači (zadnji deo oka) nastane slika. Slika je naopačke! Očni nerv šalje signal u mozak, a mozak sliku okrene kako treba.",
  zan: [
    "Zenica se širi u mraku, a sužava na svetlu. Probaj u laboratoriji!",
    "Trepnemo oko 15 do 20 puta u minuti.",
    "Na mestu gde očni nerv izlazi iz oka nema ćelija za gledanje. To je slepa mrlja, a mozak je sam popuni."
  ], zasto: ["trepcemo", "suze"] },

uvo: { sys: "cula", ime: "Uvo", emoji: "👂",
  gde: "Sa obe strane glave. Spoljašnji deo vidiš, a ostalo je sakriveno u kostima glave.",
  sta: "Organ za sluh i ravnotežu. Ima tri dela: spoljašnje, srednje i unutrašnje uvo.",
  cemu: "Čujemo zvukove i čuvamo ravnotežu.",
  kako: "Zvuk je talasanje vazduha. Uvo ga uhvati i bubna opna zatreperi. Tri sitne kosti (čekić, nakovanj i uzengija) pojačaju treperenje, a u pužnici se ono pretvori u signale za mozak. Unutrašnje uvo ima i tečnost koja mozgu javlja da li si uspravan.",
  zan: [
    "Najmanja kost u telu, uzengija, nalazi se u uvu i duga je oko 3 milimetra.",
    "Kad se zavrtiš i staneš, zavrti ti se u glavi jer se tečnost u uvu još njiše."
  ], zasto: ["vrtoglavica"] },

nos: { sys: "cula", ime: "Nos", emoji: "👃",
  gde: "U sredini lica, iznad usta.",
  sta: "Organ mirisa i ulaz za vazduh.",
  cemu: "Osećamo mirise, a nos još i greje i čisti vazduh koji udišemo.",
  kako: "Mirisne čestice se zalepe za posebne ćelije na vrhu nosa. One šalju signal mozgu, a mozak kaže: „Ovo miriše na kolač!“. Dlačice i sluz u nosu hvataju prašinu.",
  zan: [
    "Čovek može da razlikuje hiljade različitih mirisa.",
    "Miris i ukus rade zajedno. Zato hrana nema ukus kad ti je nos zapušen."
  ], zasto: ["kijanje", "curi_nos"] },

jezik: { sys: "cula", ime: "Jezik", emoji: "👅",
  gde: "U ustima, pričvršćen za dno usne duplje.",
  sta: "Jak mišić prekriven ukusnim pupoljcima.",
  cemu: "Osećamo ukuse. Jezik pomaže da žvaćemo, gutamo i govorimo.",
  kako: "Na jeziku su hiljade ukusnih pupoljaka. Oni razlikuju slatko, kiselo, slano, gorko i umami (ukus supe i mesa).",
  zan: [
    "Jezik nema ni jednu kost. Sav je od mišića.",
    "Pljuvačka počinje da vari hranu već u ustima."
  ], zasto: ["zagrcnemo"] },

koza: { sys: "cula", ime: "Koža", emoji: "✋",
  gde: "Prekriva celo telo.",
  sta: "Najveći organ tela. Kod odraslog je široka oko 2 kvadratna metra.",
  cemu: "Štiti od klica, vode i sunca, održava temperaturu i daje nam čulo dodira.",
  kako: "U koži su sićušni „senzori“ koji osete dodir, pritisak, toplo, hladno i bol. Znojne žlezde izlučuju znoj koji nas hladi. Koža stalno pravi nove ćelije, a stare opadaju.",
  zan: [
    "Na vrhovima prstiju ima najviše senzora za dodir.",
    "Koža se potpuno obnovi otprilike za mesec dana.",
    "Nokti i kosa su deo kože. Ne bole kad se seku jer su od mrtvih ćelija."
  ], zasto: ["znoj", "najezimo", "krasta", "modrica", "prsti_nabori", "otisci", "nokti"] },

/* ───────────── KOSTUR ───────────── */
lobanja: { sys: "kostur", ime: "Lobanja", emoji: "💀",
  gde: "U glavi.",
  sta: "Skup od 22 kosti koje su međusobno srasle, osim donje vilice.",
  cemu: "Štiti mozak i oblikuje lice. U njoj su oči, nos, uši i zubi.",
  kako: "Kosti lobanje su spojene šavovima. Bebe imaju „meku tačku“ jer im se kosti još nisu spojile, da bi glava mogla da raste.",
  zan: [
    "Donja vilica je jedina kost glave koja može da se pomera.",
    "Lobanja nije jedna kost, nego slagalica od mnogo kostiju koje se čvrsto drže zajedno."
  ], zasto: ["mlecni_zubi"] },

kicma: { sys: "kostur", ime: "Kičma", emoji: "🪜",
  gde: "Sredina leđa, od lobanje do karlice.",
  sta: "Niz kostiju koje se zovu pršljenovi. Dete ih ima oko 33. Između njih su meki hrskavičavi jastučići.",
  cemu: "Drži telo uspravno, štiti kičmenu moždinu i dozvoljava nam da se savijamo.",
  kako: "Jastučići između pršljenova amortizuju udarce kao opruge. Kičma ima blago S oblik koji nam pomaže da lakše nosimo težinu.",
  zan: [
    "Žirafa i čovek imaju isti broj vratnih pršljenova: sedam!",
    "Ujutru smo malo viši nego uveče, jer se jastučići tokom sna „napune“."
  ], zasto: ["rast", "spavanje"] },

rebra: { sys: "kostur", ime: "Rebra", emoji: "🧺",
  gde: "Oko grudnog koša.",
  sta: "12 pari kostiju, što je ukupno 24 rebra.",
  cemu: "Štite srce i pluća kao kavez i pomažu disanje.",
  kako: "Rebra su pozadi vezana za kičmu, a većina njih se spreda hrskavicom vezuje za grudnu kost. Kad udahneš, malo se podignu i prošire, pa pluća dobiju mesta.",
  zan: [
    "Rebra su malo savitljiva, pa se ne lome lako.",
    "Poslednja dva para rebara ne dodiruju grudnu kost. Zovu se „plutajuća rebra“."
  ], zasto: ["stucanje"] },

grudna: { sys: "kostur", ime: "Grudna kost", emoji: "🗡️",
  gde: "U sredini grudi.",
  sta: "Pljosnata kost oblika mača, duga oko 15 do 17 cm kod odraslih.",
  cemu: "Spaja prednji deo rebara i štiti srce.",
  kako: "Rebra se za nju vezuju hrskavicom, pa grudni koš ostaje čvrst, a ipak se pomera dok dišeš.",
  zan: [
    "Stavi ruku na sredinu grudi. Osetićeš grudnu kost ispod kože. Iza nje srce kuca!"
  ], zasto: ["srce_lupa"] },

kljucna: { sys: "kostur", ime: "Ključna kost", emoji: "🔑",
  gde: "Ispod vrata, vodoravno, od grudne kosti do ramena. Ima levu i desnu.",
  sta: "Tanka kost oblika slova S.",
  cemu: "Drži rame na pravom mestu i prenosi snagu iz ruke u telo.",
  kako: "Ona je kao potpornjak: ruka može da se kreće na sve strane, a ključna kost ne dozvoljava da rame upadne ka grudima.",
  zan: [
    "Ključna kost je jedna od kostiju koje se kod dece najčešće slome, na primer posle pada sa bicikla.",
    "Možeš da je opipaš ispod kože, odmah ispod vrata."
  ], zasto: ["kosti_zarastaju"] },

nadlaktica: { sys: "kostur", ime: "Nadlaktična kost", emoji: "🍖",
  gde: "Od ramena do lakta.",
  sta: "Duga kost nadlaktice (humerus).",
  cemu: "Daje ruci oblik, a mišići se za nju vezuju da bi ruka mogla da se savija.",
  kako: "Na vrhu ima glatku, loptastu glavu koja se uklapa u rame kao kugla u čašu. To je zglob, i zato ruka može da se okreće na sve strane.",
  zan: [
    "Kad udariš lakat i zaškaklja te kao struja, nisi udario kost nego nerv koji tu prolazi."
  ], zasto: ["kosti_zarastaju"] },

podlaktica: { sys: "kostur", ime: "Kosti podlaktice", emoji: "🦯",
  gde: "Od lakta do šake.",
  sta: "Dve kosti: palčana i lakatna.",
  cemu: "Omogućavaju da okrećemo šaku.",
  kako: "Kad okrećeš dlan gore-dole, jedna kost se ukršta preko druge.",
  zan: [
    "Kad dlan okreneš nagore, kosti su jedna pored druge. Kad ga okreneš nadole, one se ukrste!"
  ], zasto: [] },

saka: { sys: "kostur", ime: "Šaka", emoji: "🖐️",
  gde: "Na kraju ruke.",
  sta: "27 kostiju u svakoj šaci: 8 u zglobu, 5 u dlanu i 14 u prstima.",
  cemu: "Hvatanje, držanje, pisanje, crtanje i igra!",
  kako: "Mnogo malih kostiju i zglobova pomaže da se prsti savijaju na sve načine. Mišići podlaktice vuku tetive kao konce na lutki.",
  zan: [
    "U prstima nema mišića! Njih pomeraju tetive od mišića u podlaktici.",
    "Palac je poseban jer može da dodirne ostale prste. Zato možemo da hvatamo sitne stvari.",
    "Više od polovine svih kostiju u telu nalazi se u šakama i stopalima!"
  ], zasto: ["otisci", "nokti"] },

karlica: { sys: "kostur", ime: "Karlica", emoji: "🦋",
  gde: "Dole, između kičme i nogu.",
  sta: "Kostna „činija“ oblika leptira.",
  cemu: "Nosi težinu gornjeg dela tela, štiti organe u donjem delu stomaka i povezuje kičmu sa nogama.",
  kako: "U karlici su dve udubine u koje ulazi butna kost. Tako nastaje kuk.",
  zan: [
    "Karlica je jedan od najčvršćih delova skeleta.",
    "Kad sedneš, oslanjaš se baš na karlicu."
  ], zasto: [] },

butna: { sys: "kostur", ime: "Butna kost", emoji: "🍗",
  gde: "U butini, od kuka do kolena.",
  sta: "Najduža i najjača kost u telu.",
  cemu: "Nosi težinu tela dok hodamo, trčimo i skačemo.",
  kako: "Gore ima loptastu glavu koja ulazi u karlicu, a dole se spaja sa kolenom. Veoma je izdržljiva, čak i kad skačemo.",
  zan: [
    "Butna kost čini otprilike četvrtinu visine čoveka.",
    "Butna kost može da izdrži opterećenje nekoliko puta veće od težine celog tela."
  ], zasto: ["rast", "kosti_zarastaju"] },

casica: { sys: "kostur", ime: "Čašica kolena", emoji: "🥄",
  gde: "Na prednjoj strani kolena.",
  sta: "Mala, trouglasta kost-štit.",
  cemu: "Štiti koleno i pojačava snagu butnog mišića.",
  kako: "Ugrađena je u tetivu butnih mišića i klizi kad savijaš nogu.",
  zan: [
    "Bebe nemaju pravu čašicu. Tek posle nekoliko godina se hrskavica pretvori u kost."
  ], zasto: ["rast"] },

potkolenica: { sys: "kostur", ime: "Kosti potkolenice", emoji: "🦵",
  gde: "Od kolena do stopala.",
  sta: "Dve kosti: debela golenjača i tanka lisna kost.",
  cemu: "Nose težinu i pomažu da se stopalo okreće.",
  kako: "Golenjača nosi skoro svu težinu. Lisna kost je tanja, drži mišiće i čuva članak da se ne ukrivi.",
  zan: [
    "Golenjača je druga najduža kost u telu."
  ], zasto: [] },

stopalo: { sys: "kostur", ime: "Stopalo", emoji: "🦶",
  gde: "Na kraju noge.",
  sta: "Svako stopalo ima 26 kostiju i mnogo zglobova.",
  cemu: "Nosi celo telo, pomaže da održimo ravnotežu i ublažava korake.",
  kako: "Stopalo ima svod kao most. Pri koraku se pritisne i opruži, kao opruga, pa lakše hodamo i skačemo.",
  zan: [
    "Oba stopala zajedno imaju 52 kosti, a to je četvrtina svih kostiju u telu!",
    "Odrasli ima 206 kostiju, a beba se rodi sa nekoliko stotina, pa neke vremenom srastu."
  ], zasto: ["rast"] },

/* ───────────── MIŠIĆI ───────────── */
zvakacki: { sys: "misici", ime: "Žvakački mišić", emoji: "🍎",
  gde: "Na obrazu, uz donju vilicu.",
  sta: "Mišić koji služi za žvakanje.",
  cemu: "Podiže donju vilicu da zubi mogu da grizu i melju hranu.",
  kako: "Kad se stegne, priljubi donju vilicu uz gornju. Stavi prste na obraz i zagrizi: osetićeš kako se stegne!",
  zan: [
    "Žvakački mišić je jedan od najjačih mišića u odnosu na svoju veličinu."
  ], zasto: [] },

deltoid: { sys: "misici", ime: "Mišić ramena", emoji: "🛡️",
  gde: "Na ramenu.",
  sta: "Trouglast mišić koji pokriva rame kao kapa (deltoid).",
  cemu: "Podiže ruku u stranu, napred i nazad.",
  kako: "Kad ga stegneš, vuče nadlakticu u stranu, napred ili nazad, zavisno od toga koji njegov deo radi.",
  zan: [
    "Ime mu potiče od grčkog slova delta (Δ), jer je trouglast."
  ], zasto: [] },

grudni: { sys: "misici", ime: "Grudni mišić", emoji: "🦅",
  gde: "Na grudima, ispod kože, ispred rebara.",
  sta: "Veliki mišić oblika lepeze.",
  cemu: "Gura i privlači ruke ka telu: kad se grliš, guraš vrata i radiš sklekove.",
  kako: "Jednim krajem je vezan za grudnu kost, a drugim za nadlakticu.",
  zan: [
    "Kod sklekova najviše radi grudni mišić (i ruke)."
  ], zasto: [] },

biceps: { sys: "misici", ime: "Dvoglavi mišić (biceps)", emoji: "💪",
  gde: "Na prednjoj strani nadlaktice.",
  sta: "Mišić sa dve „glave“. Zato mu je ime bi-ceps.",
  cemu: "Savija lakat. Podižeš torbu ili uzimaš nešto sa police.",
  kako: "Kad se stegne, skrati se i izdebi, pa povuče podlakticu ka ramenu. Mišići samo vuku, nikad ne guraju! Zato rade u parovima: biceps savija ruku, a triceps (zadnja strana nadlaktice) je ispravlja.",
  zan: [
    "Mišići uvek rade u parovima, jedan vuče na jednu, drugi na drugu stranu.",
    "Mišići se najbolje jačaju kroz igru i kretanje."
  ], zasto: [] },

podlakticni: { sys: "misici", ime: "Mišići podlaktice", emoji: "✍️",
  gde: "Između lakta i šake.",
  sta: "Grupa mišića sa dugim tetivama.",
  cemu: "Pokreću šaku i prste.",
  kako: "Mišići podlaktice vuku tetive koje idu sve do prstiju. Kad pišeš ili crtaš, oni rade.",
  zan: [
    "Stisni pesnicu i opipaj podlakticu. Osetićeš kako se mišići mrdaju!"
  ], zasto: [] },

trbusni: { sys: "misici", ime: "Trbušni mišići", emoji: "🍫",
  gde: "Na trbuhu, od grudi do karlice.",
  sta: "Ravni mišići poredani kao kockice (zato kažu „šest kockica“).",
  cemu: "Drže trup, savijaju telo napred i pomažu kod kašlja, smeha i disanja.",
  kako: "Zajedno sa mišićima leđa čine „steznik“ oko stomaka koji drži kičmu.",
  zan: [
    "Kad se smeješ, kijaš ili kašlješ, trbušni mišići se stežu.",
    "„Šest kockica“ se vidi samo kad iznad njih ima malo masnog tkiva."
  ], zasto: ["kijanje"] },

butni: { sys: "misici", ime: "Butni mišić (kvadriceps)", emoji: "🏃",
  gde: "Na prednjoj strani butine.",
  sta: "Najveća grupa mišića koja ima četiri „glave“. Zato se zove kvadriceps.",
  cemu: "Ispravlja koleno: hodanje, trčanje, skakanje i penjanje.",
  kako: "Mišić se stegne i povuče tetivu preko čašice kolena, pa se potkolenica ispravi.",
  zan: [
    "Najveći pojedinačni mišić u telu je mišić zadnjice (gluteus maksimus).",
    "Telo ima više od 600 mišića."
  ], zasto: ["drhtanje"] },

list: { sys: "misici", ime: "Mišić lista", emoji: "🦿",
  gde: "Zadnji deo potkolenice.",
  sta: "Mišić lista noge.",
  cemu: "Podiže petu, pa se odgurneš kad hodaš i skačeš.",
  kako: "Ahilova tetiva povezuje mišić lista sa petnom kosti.",
  zan: [
    "Ahilova tetiva je najjača i najdeblja tetiva u telu."
  ], zasto: [] }
};

/* Poredak delova unutar svakog sistema (za dugmiće ispod tela) */
window.REDOSLED = {
  sve:         ["mozak", "pluca", "srce", "jetra", "zeludac", "tanko", "debelo", "bubrezi", "besika"],
  kostur:      ["lobanja", "kicma", "rebra", "grudna", "kljucna", "nadlaktica", "podlaktica", "saka", "karlica", "butna", "casica", "potkolenica", "stopalo"],
  misici:      ["zvakacki", "deltoid", "grudni", "biceps", "podlakticni", "trbusni", "butni", "list"],
  krvotok:     ["srce", "arterije", "vene", "kapilari", "krv"],
  disanje:     ["dusnik", "pluca", "osit"],
  varenje:     ["jednjak", "zeludac", "jetra", "gusteraca", "tanko", "debelo"],
  izlucivanje: ["bubrezi", "besika"],
  nervi:       ["mozak", "kicmena", "nervi"],
  cula:        ["oko", "uvo", "nos", "jezik", "koza"]
};
