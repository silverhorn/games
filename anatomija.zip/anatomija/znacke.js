/* ANATOMIJA – moje značke, čin i poeni. */
(function () {
  "use strict";
  var $ = A.$, S = A.S, esc = A.esc;

  A.reg("znacke", "🏅 Moje značke", function (root) {
    var r = A.rankOf(S.xp), nx = A.nextRank(S.xp);
    var pct = nx ? Math.round(((S.xp - r.od) / (nx.od - r.od)) * 100) : 100;
    var got = ZNACKE.filter(function (b) { return S.badges[b.id]; }).length;
    var nParts = Object.keys(S.parts).length;

    root.innerHTML =
      '<section class="rankcard">' +
        '<div class="rc-top"><span class="rc-ico">🎖️</span><div><div class="rc-lbl">Tvoj čin</div><h2>' + esc(r.ime) + "</h2></div>" +
        '<div class="rc-xp"><b>' + S.xp + "</b><span>poena</span></div></div>" +
        '<div class="bar"><i style="width:' + pct + '%"></i></div>' +
        "<small>" + (nx ? "Još " + (nx.od - S.xp) + " poena do čina „" + esc(nx.ime) + "“" : "Dostigao si najviši čin. Bravo, profesore!") + "</small>" +
      "</section>" +
      '<div class="statrow">' +
        '<div class="stat"><b>' + got + " / " + ZNACKE.length + "</b><span>značaka</span></div>" +
        '<div class="stat"><b>' + nParts + " / " + A.totalParts() + "</b><span>delova tela</span></div>" +
        '<div class="stat"><b>' + Object.keys(S.zasto).length + " / " + ZASTO.length + "</b><span>odgovora „Zašto?“</span></div>" +
      "</div>" +
      '<h2 class="pagetitle">Značke</h2>' +
      '<div class="badges">' + ZNACKE.map(function (b) {
        var on = !!S.badges[b.id];
        return '<div class="badge' + (on ? " on" : " locked") + '"><span class="bi">' + (on ? b.emoji : "🔒") + '</span><b>' + esc(b.ime) + "</b><small>" + esc(b.opis) + "</small></div>";
      }).join("") + "</div>" +
      '<div class="resetbox"><button class="btn ghost" id="rs">Počni sve iznova</button></div>';

    var rs = $("#rs", root);
    rs.addEventListener("click", function () {
      if (rs.getAttribute("data-sure") !== "1") {
        rs.setAttribute("data-sure", "1");
        rs.textContent = "Sigurno? Briše se sav napredak. Dodirni opet da potvrdiš.";
        setTimeout(function () { if (rs && rs.isConnected) { rs.removeAttribute("data-sure"); rs.textContent = "Počni sve iznova"; } }, 5000);
        return;
      }
      A.resetAll();
    });
  });
})();
