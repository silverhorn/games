/* ANATOMIJA – „Sklopi telo“: prevuci organe i kosti na pravo mesto (ili dodirni deo pa mesto). */
(function () {
  "use strict";
  var $ = A.$, $$ = A.$$, S = A.S, esc = A.esc;

  var SETS = {
    organi: {
      ime: "Organi", emoji: "🫁", opis: "Složi organe tamo gde im je mesto u telu.", vb: [40, 0, 220, 400],
      lvl: [
        ["mozak", "pluca", "srce", "jetra", "zeludac", "tanko"],
        ["mozak", "pluca", "srce", "jetra", "zeludac", "tanko", "debelo", "bubrezi", "besika"],
        ["mozak", "dusnik", "pluca", "srce", "osit", "jednjak", "jetra", "zeludac", "gusteraca", "tanko", "debelo", "bubrezi", "besika"]
      ]
    },
    kostur: {
      ime: "Kostur", emoji: "🦴", opis: "Složi kosti i napravi ceo skelet.", vb: [20, 0, 260, 640],
      lvl: [
        ["lobanja", "kicma", "rebra", "karlica", "butna", "potkolenica"],
        ["lobanja", "kicma", "rebra", "karlica", "butna", "potkolenica", "nadlaktica", "podlaktica", "stopalo"],
        ["lobanja", "kicma", "rebra", "grudna", "kljucna", "nadlaktica", "podlaktica", "saka", "karlica", "butna", "casica", "potkolenica", "stopalo"]
      ]
    }
  };
  var LVN = ["Lako", "Srednje", "Teško"];

  // izračunaj okvir (bbox) dela tela u koordinatama crteža
  var meas = null, bbCache = {};
  function bbox(id) {
    if (bbCache[id]) return bbCache[id];
    if (!meas) {
      meas = document.createElement("div");
      meas.style.cssText = "position:absolute;left:-9999px;top:0;width:300px;height:640px;visibility:hidden;pointer-events:none";
      meas.innerHTML = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 300 640" width="300" height="640"></svg>';
      document.body.appendChild(meas);
    }
    var sv = meas.firstChild; sv.innerHTML = BODY.part(id);
    var b = sv.firstChild.getBBox();
    bbCache[id] = { x: b.x, y: b.y, w: b.width, h: b.height, cx: b.x + b.width / 2, cy: b.y + b.height / 2 };
    sv.innerHTML = "";
    return bbCache[id];
  }

  A.reg("sklopi", "🧩 Sklopi telo", function (root, arg) {
    var m = /^(organi|kostur)-([123])$/.exec(arg || "");
    if (!m) return menu(root);
    return play(root, m[1], +m[2]);
  });

  function menu(root) {
    function card(key) {
      var s = SETS[key];
      return '<article class="card mode"><div class="mh"><span class="te">' + s.emoji + '</span><div><h2>' + s.ime + '</h2><p class="lead">' + s.opis + "</p></div></div>" +
        '<div class="row">' + [1, 2, 3].map(function (n) {
          var done = S.done["sk_" + key + n];
          return '<a class="btn soft" style="--c:' + (key === "organi" ? "#ff9bb3" : "#f3ead2") + '" href="#/sklopi/' + key + "-" + n + '">' + LVN[n - 1] + " (" + s.lvl[n - 1].length + ")" + (done ? " ✓" : "") + "</a>";
        }).join("") + "</div></article>";
    }
    root.innerHTML = '<h2 class="pagetitle">Sklopi telo</h2><p class="lead">Prevuci deo na crtež tela. Možeš i da dodirneš deo, pa dodirneš mesto gde ide. Ako pogrešiš, dobićeš savet.</p>' +
      '<div class="menu2">' + card("organi") + card("kostur") + "</div>";
  }

  function play(root, key, lvl) {
    var set = SETS[key], ids = set.lvl[lvl - 1], placed = {}, sel = null, mistakes = 0, drag = null, timers = [];
    var left = ids.length;

    root.innerHTML =
      '<div class="sklopi">' +
        '<div class="left"><div class="stagebox puz" id="sbox">' + BODY.emptyStage("puz") + "</div></div>" +
        '<div class="right">' +
          '<div class="puzhead"><h2>' + set.emoji + " " + set.ime + " · " + LVN[lvl - 1] + '</h2><span class="cnt" id="cnt"></span></div>' +
          '<div class="say" id="say">👆 Dodirni ili prevuci deo na pravo mesto.</div>' +
          '<div class="tray" id="tray"></div>' +
          '<div class="row"><button class="btn ghost" id="hint">💡 Pokaži gde ide</button></div>' +
        "</div>" +
      "</div>";

    var svg = $("svg.stage", root), slots = $(".slots", svg), box = $("#sbox", root), tray = $("#tray", root), say = $("#say", root);
    svg.setAttribute("viewBox", set.vb.join(" "));

    ids.forEach(function (id) { slots.insertAdjacentHTML("beforeend", '<g class="slot" data-slot="' + id + '">' + BODY.part(id) + "</g>"); });
    A.shuffle(ids).forEach(function (id) {
      var b = bbox(id), pad = 6;
      tray.insertAdjacentHTML("beforeend",
        '<button class="piece" data-id="' + id + '" aria-label="' + esc(DELOVI[id].ime) + '">' +
        '<svg class="mini" viewBox="' + [b.x - pad, b.y - pad, b.w + pad * 2, b.h + pad * 2].join(" ") + '" preserveAspectRatio="xMidYMid meet">' + BODY.part(id) + "</svg>" +
        "<span>" + esc(DELOVI[id].ime) + "</span></button>");
    });
    function count() { $("#cnt", root).textContent = (ids.length - left) + " / " + ids.length; }
    count();

    function pt(ev) { var p = svg.createSVGPoint(); p.x = ev.clientX; p.y = ev.clientY; return p.matrixTransform(svg.getScreenCTM().inverse()); }
    function setSel(id) {
      sel = id;
      $$(".piece", tray).forEach(function (p) { p.classList.toggle("sel", p.getAttribute("data-id") === id); });
    }
    function say2(html, cls) { say.className = "say " + (cls || ""); say.innerHTML = html; }

    function tryPlace(id, p) {
      var b = bbox(id), tx = Math.max(b.w / 2 * 0.9, 22) + 12, ty = Math.max(b.h / 2 * 0.9, 22) + 12;
      if (Math.abs(p.x - b.cx) <= tx && Math.abs(p.y - b.cy) <= ty) { place(id); return true; }
      mistakes++;
      A.sfx.no();
      var pc = $('.piece[data-id="' + id + '"]', tray);
      if (pc) { pc.classList.remove("shake"); void pc.offsetWidth; pc.classList.add("shake"); }
      say2("Tu nije. Savet: <b>" + esc(DELOVI[id].ime) + "</b> je ovde: " + esc(DELOVI[id].gde), "no");
      return false;
    }
    function place(id) {
      placed[id] = 1; left--;
      var sl = $('.slot[data-slot="' + id + '"]', svg);
      sl.classList.add("placed");
      var pc = $('.piece[data-id="' + id + '"]', tray); if (pc) pc.remove();
      if (sel === id) setSel(null);
      A.sfx.ok(); A.addXP(2); A.markPart(id); count();
      say2("✔ <b>" + esc(DELOVI[id].ime) + "</b>: " + esc(DELOVI[id].cemu), "ok");
      if (left === 0) finish();
    }
    function finish() {
      var key2 = "sk_" + key + lvl, first = !S.done[key2];
      S.done[key2] = 1;
      if (lvl === 3) { S.done[key === "organi" ? "sklop_org" : "sklop_kost"] = 1; A.award(key === "organi" ? "sklop_org" : "sklop_kost"); }
      var bonus = first ? 15 + lvl * 10 : 0;
      A.save(); if (bonus) A.addXP(bonus);
      A.confetti(80); A.sfx.win();
      var nxt = lvl < 3 ? '<a class="btn" href="#/sklopi/' + key + "-" + (lvl + 1) + '">Teži nivo →</a>' : '<a class="btn" href="#/sklopi">Drugi izbor</a>';
      say2("🎉 <b>Bravo! Sklopio si sve!</b> " + (mistakes ? "Pogrešaka: " + mistakes + ". " : "Bez ijedne greške! ") + (bonus ? "+" + bonus + " poena. " : "") +
        '<div class="row" style="margin-top:10px"><button class="btn ghost" id="again">Ponovo</button> ' + nxt + "</div>", "win");
      $("#again", root).addEventListener("click", function () { A.go("sklopi"); setTimeout(function () { A.go("sklopi/" + key + "-" + lvl); }, 30); });
      tray.innerHTML = ""; $("#hint", root).hidden = true;
    }

    // klik na crtež: ako je izabran deo, pokušaj da ga postaviš
    svg.addEventListener("click", function (ev) { if (sel) tryPlace(sel, pt(ev)); });

    // prevlačenje
    tray.addEventListener("pointerdown", function (ev) {
      var pc = ev.target.closest(".piece"); if (!pc) return;
      ev.preventDefault();
      drag = { id: pc.getAttribute("data-id"), x: ev.clientX, y: ev.clientY, moved: false, ghost: null, pc: pc };
      try { pc.setPointerCapture(ev.pointerId); } catch (e) {}
    });
    tray.addEventListener("pointermove", function (ev) {
      if (!drag) return;
      if (!drag.moved && Math.hypot(ev.clientX - drag.x, ev.clientY - drag.y) > 8) {
        drag.moved = true; setSel(drag.id);
        var g = document.createElement("div"); g.className = "dgh";
        g.innerHTML = drag.pc.querySelector("svg").outerHTML; document.body.appendChild(g); drag.ghost = g;
        drag.pc.classList.add("lifted");
      }
      if (drag.ghost) { drag.ghost.style.left = ev.clientX + "px"; drag.ghost.style.top = ev.clientY + "px"; }
    });
    function endDrag(ev, cancel) {
      if (!drag) return;
      var d = drag; drag = null;
      d.pc.classList.remove("lifted");
      if (d.ghost) d.ghost.remove();
      if (cancel) return;
      if (!d.moved) { setSel(sel === d.id ? null : d.id); A.sfx.pop(); if (sel) say2("Izabrao si: <b>" + esc(DELOVI[d.id].ime) + "</b>. Dodirni mesto na telu gde ide."); return; }
      var r = svg.getBoundingClientRect();
      if (ev.clientX >= r.left && ev.clientX <= r.right && ev.clientY >= r.top && ev.clientY <= r.bottom) tryPlace(d.id, pt(ev));
    }
    tray.addEventListener("pointerup", function (ev) { endDrag(ev, false); });
    tray.addEventListener("pointercancel", function (ev) { endDrag(ev, true); });

    $("#hint", root).addEventListener("click", function () {
      var id = sel || Object.keys(ids.reduce(function (o, k) { if (!placed[k]) o[k] = 1; return o; }, {}))[0];
      if (!id) return;
      var sl = $('.slot[data-slot="' + id + '"]', svg);
      sl.classList.remove("blink"); void sl.getBoundingClientRect(); sl.classList.add("blink");
      timers.push(setTimeout(function () { sl.classList.remove("blink"); }, 2600));
      say2("💡 <b>" + esc(DELOVI[id].ime) + "</b>: " + esc(DELOVI[id].gde));
    });

    return function () { timers.forEach(clearTimeout); $$(".dgh").forEach(function (g) { g.remove(); }); };
  }
})();
