/* ANATOMIJA – početni ekran i Skener tela (glavni deo igre). */
(function () {
  "use strict";
  var $ = A.$, $$ = A.$$, S = A.S, esc = A.esc;

  /* ───────── POČETNA ───────── */
  function allFacts() {
    var out = [];
    for (var id in DELOVI) DELOVI[id].zan.forEach(function (f) { out.push({ f: f, id: id }); });
    return out;
  }

  A.reg("home", "Anatomija", function (root) {
    var r = A.rankOf(S.xp), nx = A.nextRank(S.xp);
    var pct = nx ? Math.round(((S.xp - r.od) / (nx.od - r.od)) * 100) : 100;
    var nParts = Object.keys(S.parts).length, nZ = Object.keys(S.zasto).length;
    var nBadge = Object.keys(S.badges).length;
    var solved = 0; for (var k in S.det) if (S.det[k]) solved++;
    var puts = ["put_hrana", "put_krv", "put_vazduh", "put_signal"].filter(function (b) { return S.badges[b]; }).length;
    var kv = [1, 2, 3].reduce(function (a, n) { return a + (S.best["kviz" + n] || 0); }, 0);
    var tiles = [
      { h: "skener", e: "🔬", t: "Skener tela", d: "Dodirni deo tela i saznaj gde je, šta je, čemu služi i kako radi.", c: "mint", p: nParts / A.totalParts(), pt: nParts + " od " + A.totalParts() + " delova", big: true },
      { h: "sklopi", e: "🧩", t: "Sklopi telo", d: "Stavi organe i kosti na njihovo mesto.", c: "sky", p: ((S.done.sklop_org ? 1 : 0) + (S.done.sklop_kost ? 1 : 0)) / 2, pt: "" },
      { h: "put", e: "🚀", t: "Putovanja", d: "Prati zalogaj, kap krvi, dah i signal kroz telo.", c: "coral", p: puts / 4, pt: puts + " od 4" },
      { h: "zasto", e: "❓", t: "Zašto?", d: "Zašto štucamo, zevamo, naježimo se? Pogodi pa saznaj.", c: "lemon", p: nZ / ZASTO.length, pt: nZ + " od " + ZASTO.length },
      { h: "lab", e: "🧪", t: "Laboratorija", d: "Izmeri puls, diši, proveri refleks, oko i operi zube.", c: "lilac", p: Object.keys(S.lab).length / 5, pt: "" },
      { h: "detektiv", e: "🕵️", t: "Doktor detektiv", d: "Reši slučajeve i pronađi „krivca“ u telu.", c: "peach", p: solved / SLUCAJEVI.length, pt: solved + " od " + SLUCAJEVI.length },
      { h: "memo", e: "🃏", t: "Memorija", d: "Spoji organ sa onim što radi.", c: "mint2", p: S.done.memo ? 1 : 0, pt: "" },
      { h: "kviz", e: "🎓", t: "Kviz", d: "Tri nivoa: od laganog do profesorskog.", c: "sky2", p: kv / 9, pt: "", big: true },
      { h: "znacke", e: "🏅", t: "Moje značke", d: "Sakupi sve značke i postani profesor.", c: "gold", p: nBadge / ZNACKE.length, pt: nBadge + " od " + ZNACKE.length, big: true }
    ];
    var facts = allFacts();
    var cur = facts[Math.floor(Math.random() * facts.length)];

    root.innerHTML =
      '<section class="hero">' +
        '<div class="hero-text">' +
          "<h2>Zdravo, mali doktore!</h2>" +
          '<p class="lead">Otkrij kako ti radi telo. Dodirni srce na slici da počneš.</p>' +
          '<div class="rankbox"><div class="rk"><b>' + esc(r.ime) + "</b><span>" + S.xp + " poena</span></div>" +
          '<div class="bar"><i style="width:' + pct + '%"></i></div>' +
          "<small>" + (nx ? "Još " + (nx.od - S.xp) + " poena do čina „" + esc(nx.ime) + "“" : "Dostigao si najviši čin!") + "</small></div>" +
          '<a class="btn big" href="#/skener">Počni skeniranje</a>' +
        "</div>" +
        '<div class="hero-fig" aria-label="Telo – dodirni srce">' + BODY.stage("sve", "herofig") + "</div>" +
      "</section>" +
      '<section class="tiles" id="tiles">' +
        tiles.map(function (t) {
          return '<a class="tile c-' + t.c + (t.big ? " wide" : "") + '" href="#/' + t.h + '">' +
            '<span class="te">' + t.e + "</span>" +
            '<span class="tt">' + esc(t.t) + "</span>" +
            '<span class="td">' + esc(t.d) + "</span>" +
            (t.pt ? '<span class="tp">' + esc(t.pt) + "</span>" : "") +
            '<span class="tbar"><i style="width:' + Math.round(Math.min(1, t.p || 0) * 100) + '%"></i></span>' +
          "</a>";
        }).join("") +
      "</section>" +
      '<section class="funfact card"><h3>💡 Da li si znao?</h3><p id="ff">' + esc(cur.f) + '</p>' +
      '<div class="row"><button class="btn ghost" id="ffn">Još jedna</button> <button class="btn ghost" id="ffs">🔊 Čitaj</button> <button class="btn ghost" id="ffo">Pokaži gde je</button></div></section>';

    var curId = cur.id;
    function pick() { var f = facts[Math.floor(Math.random() * facts.length)]; curId = f.id; $("#ff", root).textContent = f.f; }
    $("#ffn", root).addEventListener("click", function () { A.sfx.tap(); pick(); });
    $("#ffs", root).addEventListener("click", function () { A.speak($("#ff", root).textContent); });
    $("#ffo", root).addEventListener("click", function () { A.go("skener/" + curId); });

    $(".hero-fig", root).addEventListener("click", function (e) {
      var p = e.target.closest && e.target.closest(".part");
      A.sfx.thump();
      A.go("skener/" + (p ? p.getAttribute("data-id") : "srce"));
    });
  });

  /* ───────── SKENER TELA ───────── */
  var PROBAJ = {
    srce: [{ t: "💓 Poslušaj otkucaje", a: "heart" }, { t: "Izmeri puls", go: "lab/puls" }],
    arterije: [{ t: "Izmeri puls", go: "lab/puls" }],
    pluca: [{ t: "🌬️ Diši sa mnom", a: "breathe" }, { t: "Vežba disanja", go: "lab/dah" }],
    dusnik: [{ t: "🌬️ Diši sa mnom", a: "breathe" }],
    osit: [{ t: "🌬️ Diši sa mnom", a: "breathe" }, { t: "Zašto štucamo?", go: "zasto/stucanje" }],
    oko: [{ t: "👀 Ogled sa okom", go: "lab/oko" }],
    mozak: [{ t: "⏱️ Izmeri refleks", go: "lab/refleks" }],
    kicmena: [{ t: "⏱️ Probaj refleks", go: "lab/refleks" }],
    nervi: [{ t: "⚡ Putovanje signala", go: "put/signal" }],
    zeludac: [{ t: "🍪 Putovanje zalogaja", go: "put/hrana" }],
    jednjak: [{ t: "🍪 Putovanje zalogaja", go: "put/hrana" }],
    tanko: [{ t: "🍪 Putovanje zalogaja", go: "put/hrana" }],
    lobanja: [{ t: "🦷 Operi zube", go: "lab/zubi" }],
    jezik: [{ t: "🦷 Operi zube", go: "lab/zubi" }],
    krv: [{ t: "🩸 Putovanje kapi krvi", go: "put/krv" }]
  };

  var ROWS = [["gde", "📍", "Gde je?"], ["sta", "🔎", "Šta je?"], ["cemu", "🎯", "Čemu služi?"], ["kako", "⚙️", "Kako radi?"]];

  A.reg("skener", "🔬 Skener tela", function (root, arg) {
    var sys = "sve", sel = null, timers = [];
    if (arg && DELOVI[arg]) { sel = arg; sys = DELOVI[arg].sys; }
    else if (arg && REDOSLED[arg]) sys = arg;

    root.innerHTML =
      '<div class="skener">' +
        '<div class="syschips" role="tablist" aria-label="Sistemi organa">' +
          SISTEMI.map(function (s) { return '<button class="chip sys" role="tab" data-sys="' + s.id + '" style="--c:' + s.boja + '"><span>' + s.emoji + "</span>" + esc(s.ime) + "</button>"; }).join("") +
        "</div>" +
        '<div class="left">' +
          '<div class="stagebox" id="stagebox"><div class="scan"></div>' + BODY.stage(sys, "main") + "</div>" +
        "</div>" +
        '<div class="right">' +
          '<div class="sysdesc" id="sysdesc"></div>' +
          '<div class="partchips" id="partchips"></div>' +
          '<div id="card"></div>' +
        "</div>" +
      "</div>";

    var svg = $("svg.stage", root), box = $("#stagebox", root);

    function visibleIn(s, id) {
      if (s === "sve") return BODY.layerOf(id) === "organi";
      return DELOVI[id].sys === s;
    }
    function tween(to) {
      var cur = svg.getAttribute("viewBox").split(" ").map(Number);
      if (A.reduce) { svg.setAttribute("viewBox", to.join(" ")); return; }
      var t0 = performance.now(), dur = 420;
      (function f(t) {
        var k = Math.min(1, (t - t0) / dur); k = 1 - Math.pow(1 - k, 3);
        svg.setAttribute("viewBox", cur.map(function (v, i) { return (v + (to[i] - v) * k).toFixed(1); }).join(" "));
        if (k < 1) requestAnimationFrame(f);
      })(t0);
    }
    function drawChips() {
      $$(".chip.sys", root).forEach(function (b) { b.classList.toggle("on", b.getAttribute("data-sys") === sys); b.setAttribute("aria-selected", b.getAttribute("data-sys") === sys); });
      var info = A.sysInfo(sys), list = REDOSLED[sys] || [];
      var seen = list.filter(function (id) { return S.parts[id]; }).length;
      $("#sysdesc", root).style.setProperty("--c", info.boja);
      $("#sysdesc", root).innerHTML = "<b>" + info.emoji + " " + esc(info.ime) + "</b> " + esc(info.opis) +
        '<span class="cnt">' + seen + " od " + list.length + " otkriveno</span>";
      $("#partchips", root).innerHTML = list.map(function (id) {
        var d = DELOVI[id];
        return '<button class="chip part' + (S.parts[id] ? " seen" : "") + (id === sel ? " on" : "") + '" data-id="' + id + '" style="--c:' + info.boja + '">' + d.emoji + " " + esc(d.ime) + (S.parts[id] ? " ✓" : "") + "</button>";
      }).join("");
    }
    function setSys(s) {
      sys = s;
      svg.setAttribute("data-sys", s);
      tween(BODY.VB[s]);
      box.classList.remove("scanning"); void box.offsetWidth; box.classList.add("scanning");
      if (sel && !visibleIn(s, sel)) { sel = null; markSel(); }
      drawChips(); renderCard();
    }
    function markSel() {
      $$(".part.sel", svg).forEach(function (p) { p.classList.remove("sel"); });
      if (sel) $$('.part[data-id="' + sel + '"]', svg).forEach(function (p) { p.classList.add("sel"); });
    }
    function select(id) {
      if (!DELOVI[id]) return;
      if (!visibleIn(sys, id)) { sel = id; setSys(DELOVI[id].sys); }
      sel = id; markSel();
      var first = A.markPart(id);
      A.sfx.tap(); drawChips(); renderCard(first);
      var c = $("#card", root);
      if (c && window.innerWidth < 900 && !A.reduce) { setTimeout(function () { c.scrollIntoView({ behavior: "smooth", block: "nearest" }); }, 60); }
    }
    function renderCard() {
      var c = $("#card", root);
      if (!sel) {
        c.innerHTML = '<div class="info empty"><div class="big">👆</div><h2>Dodirni deo tela</h2><p>Dodirni organ na slici ili izaberi dugme iznad. Saznaćeš gde se nalazi, šta je, čemu služi i kako radi.</p></div>';
        return;
      }
      var d = DELOVI[sel], info = A.sysInfo(d.sys), list = REDOSLED[sys] || REDOSLED[d.sys] || [], idx = list.indexOf(sel);
      var probaj = (PROBAJ[sel] || []).map(function (p, i) { return '<button class="btn soft" data-p="' + i + '">' + esc(p.t) + "</button>"; }).join("");
      var zasto = (d.zasto || []).map(function (zid) {
        var z = ZASTO.filter(function (q) { return q.id === zid; })[0];
        return z ? '<a class="chip why" href="#/zasto/' + zid + '">' + z.emoji + " " + esc(z.q) + "</a>" : "";
      }).join("");
      var text = d.ime + ". Gde je? " + d.gde + " Šta je? " + d.sta + " Čemu služi? " + d.cemu + " Kako radi? " + d.kako;
      c.innerHTML =
        '<article class="info" style="--c:' + info.boja + '">' +
          '<header><span class="big">' + d.emoji + '</span><div class="nm"><h2>' + esc(d.ime) + '</h2><span class="tag">' + info.emoji + " " + esc(info.ime) + "</span></div>" +
          (A.canSpeak ? '<button class="btn soft" id="rd" aria-label="Pročitaj naglas">🔊 Čitaj</button>' : "") + "</header>" +
          '<dl class="qa">' + ROWS.map(function (r) { return '<div class="qrow"><dt><span>' + r[1] + "</span>" + r[2] + "</dt><dd>" + esc(d[r[0]]) + "</dd></div>"; }).join("") + "</dl>" +
          '<div class="fun"><h3>⭐ Zanimljivo</h3><ul>' + d.zan.map(function (f) { return "<li>" + esc(f) + "</li>"; }).join("") + "</ul></div>" +
          (probaj ? '<div class="try"><h3>🎮 Isprobaj</h3><div class="row">' + probaj + "</div></div>" : "") +
          (zasto ? '<div class="why"><h3>❓ Zašto?</h3><div class="row">' + zasto + "</div></div>" : "") +
          '<div class="nav"><button class="btn ghost" id="pv"' + (idx <= 0 ? " disabled" : "") + '>← Prethodni</button><button class="btn ghost" id="nx"' + (idx < 0 || idx >= list.length - 1 ? " disabled" : "") + '>Sledeći →</button></div>' +
        "</article>";
      var rd = $("#rd", c); if (rd) rd.addEventListener("click", function () { A.speak(text); });
      $("#pv", c).addEventListener("click", function () { if (idx > 0) select(list[idx - 1]); });
      $("#nx", c).addEventListener("click", function () { if (idx >= 0 && idx < list.length - 1) select(list[idx + 1]); });
      $$("[data-p]", c).forEach(function (b) {
        b.addEventListener("click", function () {
          var p = PROBAJ[sel][+b.getAttribute("data-p")];
          if (p.go) A.go(p.go);
          else if (p.a === "heart") heartbeat();
          else if (p.a === "breathe") breathe();
        });
      });
    }

    function heartbeat() {
      var n = 0;
      (function beat() {
        if (n++ >= 8) return;
        A.sfx.thump();
        svg.classList.remove("pump"); void svg.offsetWidth; svg.classList.add("pump");
        timers.push(setTimeout(beat, 800));
      })();
    }
    function breathe() {
      svg.classList.add("breathing");
      timers.push(setTimeout(function () { svg.classList.remove("breathing"); }, 13000));
    }

    root.addEventListener("click", function (e) {
      var chip = e.target.closest && e.target.closest(".chip.sys");
      if (chip) { A.sfx.tap(); setSys(chip.getAttribute("data-sys")); return; }
      var pc = e.target.closest && e.target.closest(".chip.part");
      if (pc) { select(pc.getAttribute("data-id")); return; }
      var p = e.target.closest && e.target.closest("svg.stage .part");
      if (p) select(p.getAttribute("data-id"));
    });

    drawChips(); markSel(); renderCard();
    if (sel) { A.markPart(sel); drawChips(); }

    return function () { timers.forEach(clearTimeout); };
  });
})();
