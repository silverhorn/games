ANATOMIJA – igra o ljudskom telu za decu 6–10 godina
Raspakuj zip i otvori index.html u pregledaču (ne treba server ni internet).
Fajlovi: index.html, style.css, igre.css, data_delovi.js, data_zasto.js, data_igre.js, body.js, core.js, skener.js, sklopi.js, put.js, zasto.js, kviz.js, lab.js, znacke.js – sve ostaje u istom folderu.

Šta je u igri:
- Skener tela: 45 delova u 8 sistema (kostur, mišići, srce i krv, disanje, varenje, čišćenje tela, mozak i nervi, čula). Dodirni deo i saznaš gde je, šta je, čemu služi i kako radi.
- Sklopi telo: prevuci organe i kosti na pravo mesto (3 nivoa, radi i dodirom).
- Putovanja: zalogaj, kap krvi, dah i nervni signal prolaze kroz telo, a na svakoj stanici ima pitanje.
- Zašto?: 30 pitanja zašto štucamo, zevamo, naježimo se i slično, sa objašnjenjem i ogledom.
- Doktor detektiv: 14 slučajeva, pronađi organ koji je „kriv“.
- Laboratorija: puls sa EKG-om, disanje uz balon, refleks i refleks kolena, oko (zenica i slepa mrlja), pranje zuba.
- Memorija, Kviz (3 nivoa i pogađanje sa slike), 27 značaka i činovi.

Napredak se čuva u pregledaču (localStorage). Dugme „Počni sve iznova“ je na ekranu sa značkama.
