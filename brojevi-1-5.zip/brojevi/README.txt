Brojevi 1-5 - igra za prvaka (po radnoj svesci).
Otvori index.html u browseru. 10 igara, bez tajmera i bez kazni.
Prebroji, Stavi u korpu, Vise ili manje, Povezi balone, Nastavi niz, Cvetovi, Zaokruzi, Rastavi broj, Zamislio sam broj, Leptir.
