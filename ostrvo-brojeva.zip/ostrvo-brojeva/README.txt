OSTRVO BROJEVA - igra za decu 7-10 godina (po radnom listu "Brojevi do 5")
Raspakuj zip i otvori index.html u pregledaču (ne treba server ni internet).
Fajlovi: index.html, style.css, app.js - sve ostaje u istom folderu.

Nivoi: Do 5 (kao na radnom listu), Do 10, Do 20, Do 100.
Igre (po jedna za svaki zadatak sa lista):
  Prebroji, Oboji kružiće, Nacrtaj olovke, Više ili jednako,
  Prekrižaj i zaokruži, Znakovi < > =, Poređaj brojeve, Nastavi niz
  + Mešano (10 zadataka iz svih igara).
Bez tajmera i bez kazni. Zvezdice se pamte u pregledaču.
