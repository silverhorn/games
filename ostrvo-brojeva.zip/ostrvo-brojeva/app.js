/* Ostrvo brojeva - igra za decu 7-10 godina, po radnom listu "Brojevi do 5".
   8 igara (po jedna za svaki zadatak sa lista) x 4 nivoa: do 5, do 10, do 20, do 100.
   Bez tajmera i bez kazni. Sve radi offline. */
(function(){
'use strict';

/* ---------- pomocne ---------- */
const $=(s,r=document)=>r.querySelector(s);
const $$=(s,r=document)=>Array.from(r.querySelectorAll(s));
const rnd=(a,b)=>a+Math.floor(Math.random()*(b-a+1));
const pick=a=>a[rnd(0,a.length-1)];
const shuf=a=>{a=a.slice();for(let i=a.length-1;i>0;i--){const j=rnd(0,i);[a[i],a[j]]=[a[j],a[i]]}return a};
const range=(a,b)=>Array.from({length:b-a+1},(_,i)=>a+i);
const same=(a,b)=>a.length===b.length&&a.every((v,i)=>v===b[i]);
const pl=(n,one,few,many)=>{const a=n%100,b=n%10;return a>=11&&a<=14?many:b===1?one:b>=2&&b<=4?few:many};
/* sledeci element iz promesanog spiska; kad se potrosi, mesa se ponovo (da se brojevi ne ponavljaju) */
const cyc=(M,key,arr)=>{let q=M[key];if(!q||!q.length)q=M[key]=shuf(arr);return q.pop()};

const LV=[
  {max:5,name:'Do 5',ico:'🌱',sub:'Seme'},
  {max:10,name:'Do 10',ico:'🌿',sub:'Izdanak'},
  {max:20,name:'Do 20',ico:'🌳',sub:'Drvo'},
  {max:100,name:'Do 100',ico:'🏔️',sub:'Planina'}
];
const PRAISE=['Bravo!','Super!','Tačno!','Odlično!','Tako je!','Sjajno!'];

/* ---------- pamcenje ---------- */
const KEY='ostrvo-brojeva-v1';
let save={stars:{},muted:false,level:0};
try{const s=JSON.parse(localStorage.getItem(KEY)||'null');if(s&&typeof s==='object')save=Object.assign(save,s)}catch(e){}
if(!(save.level>=0&&save.level<LV.length))save.level=0;
const persist=()=>{try{localStorage.setItem(KEY,JSON.stringify(save))}catch(e){}};

/* ---------- zvuk ---------- */
let ac;
function tone(f,d,t,type,v){
  if(save.muted)return;
  try{
    ac=ac||new (window.AudioContext||window.webkitAudioContext)();
    const o=ac.createOscillator(),g=ac.createGain();
    o.type=type||'sine';o.frequency.value=f;v=v||.13;
    o.connect(g);g.connect(ac.destination);
    const s=ac.currentTime+(t||0);
    g.gain.setValueAtTime(v,s);g.gain.exponentialRampToValueAtTime(.001,s+d);
    o.start(s);o.stop(s+d);
  }catch(e){}
}
const snd={
  tap(){tone(620,.07)},
  ok(){[523,659,784].forEach((f,i)=>tone(f,.2,i*.1))},
  no(){tone(270,.22,0,'triangle',.1)},
  win(){[523,659,784,1047].forEach((f,i)=>tone(f,.28,i*.13))}
};

/* ---------- slicice ---------- */
const ST_=(c,d)=>`fill="${c}" stroke="rgba(0,0,0,.22)" stroke-width="1.6" stroke-linejoin="round"`;
const SH={
  star:c=>`<svg viewBox="0 0 40 40" aria-hidden="true"><path d="M20 3l5.2 11.6 12.6 1.3-9.4 8.5 2.7 12.4L20 30.2 8.9 36.8l2.7-12.4-9.4-8.5 12.6-1.3z" ${ST_(c)}/></svg>`,
  tri:c=>`<svg viewBox="0 0 40 40" aria-hidden="true"><path d="M20 5L37 34H3z" ${ST_(c)}/></svg>`,
  circ:c=>`<svg viewBox="0 0 40 40" aria-hidden="true"><circle cx="20" cy="20" r="15" ${ST_(c)}/></svg>`,
  dia:c=>`<svg viewBox="0 0 40 40" aria-hidden="true"><path d="M20 3L37 20 20 37 3 20z" ${ST_(c)}/></svg>`,
  sq:c=>`<svg viewBox="0 0 40 40" aria-hidden="true"><rect x="5" y="9" width="30" height="22" rx="3" ${ST_(c)}/></svg>`,
  heart:c=>`<svg viewBox="0 0 40 40" aria-hidden="true"><path d="M20 35C6 25 3 16 8 10c4-4 9-3 12 2 3-5 8-6 12-2 5 6 2 15-12 25z" ${ST_(c)}/></svg>`
};
const COL={star:'#f5c518',tri:'#2f7fd1',circ:'#d9453b',dia:'#7a43b6',sq:'#3aa35c',heart:'#ec5b8c'};
const ROD=`<svg class="rod" viewBox="0 0 14 100" aria-hidden="true">${range(0,9).map(i=>`<rect x="1" y="${1+i*9.8}" width="12" height="8.6" rx="1.5"/>`).join('')}</svg>`;
const CUBE='<svg class="cube" viewBox="0 0 14 14" aria-hidden="true"><rect x="1" y="1" width="12" height="12" rx="2"/></svg>';
const blocks=(t,u,mini)=>`<div class="blocks${mini?' mini':''}"><div class="rods">${ROD.repeat(t)}</div><div class="cubes">${CUBE.repeat(u)}</div></div>`;
const PAIRS=[['🐿️','🌰'],['🐦','🥜'],['🐝','🌼'],['🐟','🐚'],['🐱','🐭'],['🐶','🦴'],['🐸','🍀'],['🐰','🥕']];

/* raspored elemenata po kutiji, bez preklapanja */
function scatter(n){
  const cols=Math.ceil(Math.sqrt(n*1.6)),rows=Math.ceil(n/cols);
  const cells=shuf(range(0,cols*rows-1)).slice(0,n);
  const jx=100/cols*.14,jy=100/rows*.14;
  return {cols,rows,pts:cells.map(i=>({
    x:(i%cols+.5)*100/cols+(Math.random()*2-1)*jx,
    y:(Math.floor(i/cols)+.5)*100/rows+(Math.random()*2-1)*jy}))};
}

/* ---------- tastatura za unos broja ---------- */
let keyFn=null;
document.addEventListener('keydown',e=>{if(keyFn&&!e.ctrlKey&&!e.metaKey&&!e.altKey)keyFn(e)});
function numpad(slot,onEnter,max){
  slot.innerHTML=`<div class="pad"><div class="val empty" id="padval" aria-live="polite">?</div><div class="keys">${'1234567890'.split('').map(k=>`<button type="button" class="key" data-k="${k}">${k}</button>`).join('')}<button type="button" class="key wide" data-k="bk" aria-label="Obriši">⌫</button><button type="button" class="key wide go" data-k="ok" aria-label="Potvrdi">✔</button></div></div>`;
  let v='';const val=$('#padval',slot);
  const draw=()=>{val.textContent=v===''?'?':v;val.classList.toggle('empty',v==='')};
  const api={get v(){return v},set(x){v=String(x);draw()},fresh:false,onchange:null,el:$('.pad',slot)};
  const press=k=>{
    snd.tap();
    if(k==='ok')return onEnter(v);
    if(k==='bk'){v=v.slice(0,-1);api.fresh=false;draw();api.onchange&&api.onchange(v);return}
    if(api.fresh){v='';api.fresh=false}
    if(v==='0')v='';
    if(v.length<max){v+=k;draw();api.onchange&&api.onchange(v)}
  };
  $$('.key',slot).forEach(b=>b.onclick=()=>press(b.dataset.k));
  keyFn=e=>{
    if(/^\d$/.test(e.key))press(e.key);
    else if(e.key==='Backspace')press('bk');
    else if(e.key==='Enter'){e.preventDefault();press('ok')}
  };
  return api;
}

/* ---------- okvir igre ---------- */
const app=$('#app');
let sess=null;

function wireMute(){
  const b=$('#mute');if(!b)return;
  const set=()=>{b.textContent=save.muted?'🔇':'🔊';b.setAttribute('aria-label',save.muted?'Uključi zvuk':'Isključi zvuk')};
  set();
  b.onclick=()=>{save.muted=!save.muted;persist();set();if(!save.muted)snd.tap()};
}
const medal=g=>g>=13?3:g>=9?2:g>=5?1:0;

function menu(){
  keyFn=null;sess=null;
  const L=save.level;
  const total=Object.values(save.stars).reduce((a,b)=>a+b,0);
  app.innerHTML=`<div class="wrap">
  <header class="hd"><h1>🏝️ Ostrvo brojeva</h1><span class="grow"></span><span class="chip" title="Sakupljene zvezdice">⭐ ${total}</span><button type="button" class="btn small" id="mute"></button></header>
  <p class="sub">Igre sa brojevima po radnom listu „Brojevi do 5“ — i dalje, sve do 100. Bez tajmera i bez kazni. 🙂</p>
  <h2 class="sec">1. Izaberi nivo</h2>
  <div class="levels" role="radiogroup" aria-label="Nivo">${LV.map((l,i)=>`<button type="button" class="lvl${i===L?' on':''}" role="radio" aria-checked="${i===L}" data-l="${i}"><span class="li">${l.ico}</span><b>${l.name}</b><small>${l.sub}</small></button>`).join('')}</div>
  <h2 class="sec">2. Izaberi igru</h2>
  <div class="grid">${ST.map((s,i)=>{const g=save.stars[L+':'+i]||0;return `<button type="button" class="tile" data-s="${i}"><span class="ti">${s.ico}</span><b>${s.name}</b><small>${s.desc}</small><span class="stars" aria-label="${g} od 15 zvezdica">${'⭐'.repeat(medal(g))||'☆'}<i>${g}/15</i></span></button>`}).join('')}
  <button type="button" class="tile mix" data-s="mix"><span class="ti">🎲</span><b>Mešano</b><small>10 zadataka iz svih igara</small><span class="stars">${'⭐'.repeat(medal((save.stars[L+':mix']||0)/2))||'☆'}<i>${save.stars[L+':mix']||0}/30</i></span></button></div>
  </div>`;
  wireMute();
  $$('.lvl').forEach(b=>b.onclick=()=>{save.level=+b.dataset.l;persist();snd.tap();menu()});
  $$('.tile').forEach(b=>b.onclick=()=>{snd.tap();startSession(b.dataset.s==='mix'?'mix':+b.dataset.s)});
}

function startSession(k){
  let items;
  if(k==='mix'){
    let seq;
    for(let t=0;t<30;t++){
      const o=shuf(range(0,ST.length-1));
      seq=[...o,...shuf(o)].slice(0,10);
      if(seq.every((v,i)=>i===0||v!==seq[i-1]))break;
    }
    items=seq.map(st=>({st,r:rnd(0,4)}));
  }else items=range(0,4).map(r=>({st:k,r}));
  sess={k,level:save.level,items,i:0,stars:0,mem:{}};
  nextRound();
}

function frame(){
  const n=sess.items.length;
  app.innerHTML=`<div class="wrap">
  <header class="hd"><button type="button" class="btn small" id="back">◀ Meni</button>
  <div class="dots" aria-label="Zadatak ${sess.i+1} od ${n}">${sess.items.map((_,i)=>`<i class="${i<sess.i?'d':i===sess.i?'c':''}"></i>`).join('')}</div>
  <span class="grow"></span><span class="chip" title="${LV[sess.level].name}" aria-label="Nivo ${LV[sess.level].name}">${LV[sess.level].ico}<span class="nm"> ${LV[sess.level].name}</span></span><button type="button" class="btn small" id="mute"></button></header>
  <section class="card"><h2 id="q"></h2><div id="area"></div></section>
  <div class="owlrow"><div class="owl" aria-hidden="true">🦉</div><div class="bubble" id="msg" role="status" aria-live="polite"></div></div>
  <div class="ctl"><button type="button" class="btn" id="hintb" hidden>💡 Pomoć</button><button type="button" class="btn ok" id="chk" hidden>Proveri ✔</button><button type="button" class="btn go" id="nx" hidden>Dalje ▶</button></div>
  </div>`;
  wireMute();
  $('#back').onclick=menu;
}

function makeCtx(){
  const msg=$('#msg');
  const c={mist:0,solved:false,hintText:'',area:$('#area'),ans:null,
    title(h){$('#q').innerHTML=h},
    hint(t){c.hintText=t},
    info(t){msg.className='bubble';msg.textContent=t},
    check(fn){const b=$('#chk');b.hidden=false;b.onclick=()=>{if(!c.solved)fn()}},
    showCheck(v){$('#chk').hidden=!v||c.solved},
    wrong(el,t){
      c.mist++;snd.no();msg.className='bubble';msg.textContent=t||'Pogledaj još jednom, pažljivo. 🙂';
      if(el){el.classList.remove('shake');void el.offsetWidth;el.classList.add('shake')}
      if(c.mist>=2&&c.hintText)$('#hintb').hidden=false;
    },
    right(t){
      if(c.solved)return;c.solved=true;
      const s=c.mist===0?3:c.mist===1?2:1;sess.stars+=s;snd.ok();
      msg.className='bubble good';msg.textContent=`${pick(PRAISE)} ${'⭐'.repeat(s)}${t?' '+t:''}`;
      $('#chk').hidden=true;$('#hintb').hidden=true;c.area.classList.add('lock');
      const nx=$('#nx');nx.hidden=false;nx.textContent=sess.i+1>=sess.items.length?'Kraj ▶':'Dalje ▶';
      nx.onclick=()=>{sess.i++;nextRound()};nx.focus();
      keyFn=e=>{if(e.key==='Enter'){e.preventDefault();nx.click()}};
    }
  };
  $('#hintb').onclick=()=>c.info('💡 '+c.hintText);
  return c;
}

function nextRound(){
  keyFn=null;
  if(sess.i>=sess.items.length)return finish();
  frame();
  const it=sess.items[sess.i];
  const c=makeCtx();
  window.__rc=c;
  ST[it.st].run(c,sess.level,it.r,sess.mem[it.st]||(sess.mem[it.st]={}));
}

function finish(){
  keyFn=null;snd.win();
  const max=sess.items.length*3,got=sess.stars;
  const key=sess.level+':'+sess.k;
  save.stars[key]=Math.max(save.stars[key]||0,got);persist();
  const ratio=got/max;
  const nxt=sess.k==='mix'?0:(sess.k+1)%ST.length;
  const praise=ratio>.85?'Fantastično! Pravi majstor brojeva!':ratio>.6?'Odlično ti ide!':'Dobro je! Svaki put je sve lakše. 💪';
  app.innerHTML=`<div class="wrap fin"><div class="trophy">🏆</div><h1>Kraj igre!</h1>
  <div class="st3" aria-label="${got} od ${max} zvezdica">${'⭐'.repeat(medal(ratio*15))||'☆'}</div>
  <p class="sub">Sakupljeno: <b>${got}</b> od ${max} zvezdica. ${praise}</p>
  <div class="ctl"><button type="button" class="btn" id="again">↺ Ponovo</button><button type="button" class="btn go" id="nextg">${ST[nxt].ico} ${ST[nxt].name} ▶</button><button type="button" class="btn" id="mn">Meni</button></div></div>`;
  $('#again').onclick=()=>startSession(sess.k);
  $('#nextg').onclick=()=>startSession(nxt);
  $('#mn').onclick=menu;
}

/* =====================================================
   1. PREBROJI  (zadatak 1: prebroj elemente skupa i upiši broj)
   ===================================================== */
function sCount(c,L,r,M){
  const mx=LV[L].max;
  let n,body;
  if(L<3){
    n=cyc(M,'n',range(L===0?1:L===1?3:9,mx));
    const kind=pick(Object.keys(SH)),size=n<=5?64:n<=10?52:42;
    const g=scatter(n);
    body=`<div class="setbox" style="height:${Math.max(150,g.rows*(size+18))}px">${g.pts.map(p=>`<button type="button" class="el" aria-label="Element" style="left:${p.x}%;top:${p.y}%;width:${size}px;height:${size}px">${SH[kind](COL[kind])}<span class="bd"></span></button>`).join('')}</div>`;
    c.title('Prebroji elemente skupa i upiši broj.<br><small>Dodirni svaki element da ga izbrojiš.</small>');
    c.hint('Dodiruj elemente jedan po jedan. Poslednji broj koji se pojavi je odgovor.');
  }else{
    n=cyc(M,'n',range(11,99));
    body=`<div class="setbox">${blocks(Math.floor(n/10),n%10)}</div>`;
    c.title('Prebroji štapiće i kockice, pa upiši broj.<br><small>Jedan štapić ima 10 kockica.</small>');
    c.hint(`Prebroji štapiće: svaki vredi 10. Zatim dodaj kockice koje stoje pored.`);
  }
  c.ans=n;
  c.area.innerHTML=body+'<div id="padslot"></div>';
  let cnt=0;
  $$('.el',c.area).forEach(b=>b.onclick=()=>{
    if(b.classList.contains('cd'))return;
    cnt++;b.classList.add('cd');$('.bd',b).textContent=cnt;snd.tap();
  });
  const pad=numpad($('#padslot',c.area),v=>{
    if(v==='')return c.info('Upiši broj pomoću tastature. 🙂');
    +v===n?c.right():c.wrong(pad.el,+v<n?'Ima ih više. Prebroji još jednom. 🙂':'Ima ih manje. Prebroji još jednom. 🙂');
  },2);
}

/* =====================================================
   2. OBOJI KRUŽIĆE  (zadatak 2: broj ispod skupa = koliko kružića obojiti)
   ===================================================== */
function sColor(c,L,r,M){
  const n=cyc(M,'n',L===0?range(1,5):L===1?range(2,10):L===2?range(3,20):range(11,99));
  const cols=[5,5,10,10][L],rows=[1,2,2,10][L],handles=L>=2;
  c.ans=n;
  c.title(`Oboji ${n} ${pl(n,'kružić','kružića','kružića')}.<br><small>Broj ispod skupa kaže koliko kružića treba obojiti.</small>`);
  c.hint(L>=2?'Jedan red ima 10 kružića. Dodirni kvadratić ispred reda da obojiš ceo red, pa dodaj ostale.':'Dodiruj kružiće i broji naglas dok bojiš.');
  let h='<div class="center"><div class="pill">';
  for(let y=0;y<rows;y++){
    h+='<div class="drow">'+(handles?`<button type="button" class="rowh" data-row="${y}" aria-label="Oboji ceo red ${y+1}">▶</button>`:'')+
      range(0,cols-1).map(()=>`<button type="button" class="dot${L===0?' big5':''}" aria-label="Kružić"></button>`).join('')+'</div>';
  }
  h+=`</div></div><div class="big" aria-label="Broj ${n}">${n}</div><div class="cnt" id="cnt"></div>`;
  c.area.innerHTML=h;
  const dots=$$('.dot',c.area);
  const upd=()=>{if(L>=2)$('#cnt').textContent=`Obojeno: ${dots.filter(d=>d.classList.contains('on')).length}`};
  upd();
  dots.forEach(d=>d.onclick=()=>{d.classList.toggle('on');snd.tap();upd()});
  $$('.rowh',c.area).forEach(b=>b.onclick=()=>{
    const row=dots.slice(+b.dataset.row*cols,(+b.dataset.row+1)*cols);
    const all=row.every(d=>d.classList.contains('on'));
    row.forEach(d=>d.classList.toggle('on',!all));snd.tap();upd();
  });
  c.check(()=>{
    const k=dots.filter(d=>d.classList.contains('on')).length;
    k===n?c.right():c.wrong($('.pill',c.area),k<n?'Treba obojiti još kružića. 🙂':'Obojeno je previše. Skini koji. 🙂');
  });
}

/* =====================================================
   3. NACRTAJ OLOVKE  (zadatak 3: u skupu nacrtaj i oboji odgovarajući broj olovaka)
   ===================================================== */
const PCOL=['#e4572e','#ffd24a','#3b8bff','#2fa862','#9b59d0','#ff8fc2'];
const pencilSVG=col=>`<rect x="-7" y="-36" width="14" height="10" rx="3" fill="#f2909f"/><rect x="-7" y="-27" width="14" height="5" fill="#b9c2cc"/><rect x="-7" y="-22" width="14" height="40" fill="${col}"/><rect x="-7" y="-22" width="4" height="40" fill="rgba(255,255,255,.3)"/><path d="M-7 18L7 18L0 36Z" fill="#f2d3a5"/><path d="M-2.8 29.5L2.8 29.5L0 36Z" fill="#2b2b2b"/>`;
const bundleSVG=col=>[-28,-14,0,14,28].map((x,i)=>`<g transform="translate(${x} 0)">${pencilSVG(PCOL[(PCOL.indexOf(col)+i)%PCOL.length])}</g>`).join('')+`<rect x="-38" y="-7" width="76" height="14" rx="6" fill="#8b5a2b"/><text x="0" y="4.5" text-anchor="middle" font-size="12" font-weight="700" fill="#fff">10</text>`;

function sPencil(c,L,r,M){
  const bundle=L===3;
  const n=cyc(M,'n',L===0?range(1,5):L===1?range(2,10):L===2?range(4,15):range(11,59));
  const sc=[1.3,1.1,.95,.78][L];
  c.ans=n;
  c.title(`Nacrtaj i oboji ${n} ${pl(n,'olovku','olovke','olovaka')} u skupu.<br><small>${bundle?'Snop ima 10 olovaka. Dodirni skup da staviš olovku ili snop.':'Dodirni skup da staviš olovku. Dodirni olovku da je skineš.'}</small>`);
  c.hint(bundle?'Prvo stavi snopove (svaki je 10), pa dodaj pojedinačne olovke.':'Stavljaj olovke jednu po jednu i broji ih. Dodirni olovku ako ti je suvišna.');
  const items=[];let col=PCOL[0],tool='p';
  c.area.innerHTML=`<svg class="oval" id="ov" viewBox="0 0 600 320" role="img" aria-label="Skup u koji crtaš olovke"><ellipse class="ov" cx="300" cy="160" rx="290" ry="150"/><g id="pg"></g></svg>
  <div class="big" aria-label="Broj ${n}">${n}</div>
  <div class="palette" role="radiogroup" aria-label="Boja">${PCOL.map((p,i)=>`<button type="button" class="sw${i===0?' sel':''}" role="radio" aria-checked="${i===0}" data-c="${p}" style="background:${p}" aria-label="Boja ${i+1}"></button>`).join('')}</div>
  <div class="tools">${bundle?'<button type="button" class="btn small on" data-t="p">✏️ Olovka (1)</button><button type="button" class="btn small" data-t="b">📦 Snop (10)</button>':''}<button type="button" class="btn small" id="addp">➕ Dodaj</button><button type="button" class="btn small" id="undo">↩ Poništi</button></div>
  <div class="cnt" id="cnt"></div>`;
  const svg=$('#ov',c.area),pg=$('#pg',c.area);
  const sum=()=>items.reduce((a,it)=>a+(it.b?10:1),0);
  const draw=()=>{
    pg.innerHTML=items.map((it,i)=>`<g class="pc" data-i="${i}" transform="translate(${it.x.toFixed(1)} ${it.y.toFixed(1)}) rotate(${it.rot}) scale(${(it.b?sc*.9:sc).toFixed(2)})">${it.b?bundleSVG(it.col):pencilSVG(it.col)}</g>`).join('');
    if(L>=2)$('#cnt',c.area).textContent=`Nacrtano: ${sum()}`;
  };
  const inside=(x,y)=>((x-300)/262)**2+((y-160)/128)**2<=1;
  const add=(x,y)=>{
    if(items.length>=80)return c.info('Ima dovoljno olovaka! Skini koju. 🙂');
    items.push({x,y,rot:rnd(-30,30),col,b:tool==='b'});snd.tap();draw();
  };
  svg.addEventListener('click',e=>{
    const g=e.target.closest('.pc');
    if(g){items.splice(+g.dataset.i,1);snd.tap();draw();return}
    const pt=svg.createSVGPoint();pt.x=e.clientX;pt.y=e.clientY;
    const p=pt.matrixTransform(svg.getScreenCTM().inverse());
    if(!inside(p.x,p.y))return c.info('Crtaj unutar skupa. 🙂');
    add(p.x,p.y);
  });
  $$('.sw',c.area).forEach(b=>b.onclick=()=>{
    $$('.sw',c.area).forEach(x=>{x.classList.remove('sel');x.setAttribute('aria-checked','false')});
    b.classList.add('sel');b.setAttribute('aria-checked','true');col=b.dataset.c;snd.tap();
  });
  $$('[data-t]',c.area).forEach(b=>b.onclick=()=>{
    tool=b.dataset.t;$$('[data-t]',c.area).forEach(x=>x.classList.toggle('on',x===b));snd.tap();
  });
  $('#addp',c.area).onclick=()=>{
    const gap=tool==='b'?64:40;
    let x=300,y=160;
    for(let t=0;t<80;t++){
      const a=Math.random()*Math.PI*2,rr=Math.sqrt(Math.random());
      const px=300+Math.cos(a)*rr*230,py=160+Math.sin(a)*rr*105;
      x=px;y=py;
      if(items.every(it=>Math.hypot(it.x-px,it.y-py)>gap))break;
    }
    add(x,y);
  };
  $('#undo',c.area).onclick=()=>{items.pop();snd.tap();draw()};
  draw();
  c.check(()=>{
    const k=sum();
    k===n?c.right():c.wrong(svg,k<n?'Treba još olovaka. 🙂':'Ima previše olovaka. Dodirni neku da je skineš. 🙂');
  });
}

/* =====================================================
   4. VIŠE ILI JEDNAKO  (zadatak 4: uporedi skupove / proveri da li su jednaki)
   ===================================================== */
function sCompare(c,L,r,M){
  const kind=['more','less','equal','more','equal'][r%5];
  if(kind==='equal')M.eq=M.eq===undefined?rnd(0,1)===1:!M.eq;
  const eq=kind==='equal'&&M.eq;
  let A,B;
  if(L<3){
    const cap=[5,10,20][L],md=[3,4,6][L];
    A=rnd(L===0?1:2,cap);
    if(eq)B=A;else do{B=Math.max(1,Math.min(cap,A+rnd(-md,md)))}while(B===A);
  }else{
    A=rnd(11,99);
    if(eq)B=A;else{
      const s=rnd(0,2);
      if(s===0&&A%10!==0&&Math.floor(A/10)!==A%10)B=(A%10)*10+Math.floor(A/10);
      else if(s===1)B=A+pick([-1,1,-10,10]);
      else B=rnd(11,99);
      if(B<11||B>99||B===A)B=A>50?A-pick([1,3,12]):A+pick([1,3,12]);
    }
  }
  const pr=pick(PAIRS);
  const grp=(n,e)=>L<3?`<div class="grp" style="font-size:${n<=5?40:n<=10?32:25}px">${range(1,n).map(()=>`<span>${e}</span>`).join('')}</div>`:blocks(Math.floor(n/10),n%10,true);
  c.hint(L<3?'Prebroji elemente u oba skupa, pa uporedi brojeve.':'Prvo uporedi štapiće (svaki je 10). Ako ih ima isto, uporedi kockice.');
  if(kind==='equal'){
    c.ans=eq?'da':'ne';
    c.title('Proveri da li skupovi imaju jednak broj elemenata.');
    c.area.innerHTML=`<div class="two"><div class="gset">${grp(A,pr[0])}</div><div class="gset">${grp(B,pr[1])}</div></div>
    <div class="yn"><button type="button" class="btn" data-a="da">✅ Da, jednak je</button><button type="button" class="btn" data-a="ne">❌ Ne, nije jednak</button></div>`;
    $$('[data-a]',c.area).forEach(b=>b.onclick=()=>b.dataset.a===c.ans?c.right():c.wrong(b,c.ans==='da'&&b.dataset.a==='ne'?'Prebroji još jednom — možda ih je isto. 🙂':'Prebroji još jednom — ne baš isto. 🙂'));
  }else{
    const more=kind==='more',right=more?Math.max(A,B):Math.min(A,B);
    c.ans=right;
    c.title(`Uporedi skupove. Dodirni skup koji ima <u>${more?'više':'manje'}</u> elemenata.`);
    c.area.innerHTML=`<div class="two"><button type="button" class="gbtn" data-n="${A}" aria-label="Prvi skup">${grp(A,pr[0])}</button><button type="button" class="gbtn" data-n="${B}" aria-label="Drugi skup">${grp(B,pr[1])}</button></div>`;
    $$('.gbtn',c.area).forEach(g=>g.onclick=()=>{
      if(+g.dataset.n===right)c.right();
      else{g.classList.add('bad');c.wrong(g,`Pogledaj još jednom: traži se skup koji ima ${more?'više':'manje'}. 🙂`)}
    });
  }
}

/* =====================================================
   5. PREKRIŽAJ I ZAOKRUŽI  (zadatak 5: veći od / manji od broja)
   ===================================================== */
function sMark(c,L,r,M){
  const lo=[1,1,1,10][L],hi=[5,10,20,99][L],k=L===0?4:5;
  const X=rnd(...[[1,3],[2,8],[3,17],[20,80]][L]),Y=rnd(...[[2,5],[3,9],[4,18],[20,90]][L]);
  const gen=(T,gt)=>{
    for(let t=0;t<400;t++){
      const nums=shuf(range(lo,hi)).slice(0,k);
      if(r>=2&&T>=lo&&T<=hi&&!nums.includes(T)){const j=nums.findIndex(v=>gt?v<=T:v>=T);if(j>=0)nums[j]=T}
      const m=nums.filter(v=>gt?v>T:v<T).length;
      if(m>=1&&m<=k-1)return nums;
    }
    return range(lo,lo+k-1);
  };
  const A=gen(X,true),B=gen(Y,false);
  const goalA=A.map((v,i)=>v>X?i:-1).filter(i=>i>=0),goalB=B.map((v,i)=>v<Y?i:-1).filter(i=>i>=0);
  c.ans={A:goalA,B:goalB};
  c.title('Prekrižaj i zaokruži brojeve.<br><small>Dodirni broj da ga prekrižiš ili zaokružiš. Dodirni ponovo da poništiš.</small>');
  c.hint('Veći od broja znači: stoji dalje od njega na brojevnoj pravoj. Sam taj broj nije veći (ni manji) od sebe.');
  const row=(id,txt,nums)=>`<div class="mrow" id="${id}"><p>${txt}</p><div class="nums">${nums.map((v,i)=>`<button type="button" class="nt" data-i="${i}">${v}</button>`).join('')}</div></div>`;
  c.area.innerHTML=row('rowA',`Prekrižaj brojeve koji su <b>veći</b> od broja <b>${X}</b>.`,A)+row('rowB',`Zaokruži brojeve koji su <b>manji</b> od broja <b>${Y}</b>.`,B);
  const sel={A:new Set(),B:new Set()};
  [['A','cross'],['B','ring']].forEach(([id,cl])=>{
    $$('.nt',$('#row'+id,c.area)).forEach(b=>b.onclick=()=>{
      const i=+b.dataset.i;
      if(sel[id].has(i)){sel[id].delete(i);b.classList.remove(cl)}else{sel[id].add(i);b.classList.add(cl)}
      snd.tap();$('#row'+id,c.area).classList.remove('bad');
    });
  });
  const eqs=(s,g)=>s.size===g.length&&g.every(i=>s.has(i));
  c.check(()=>{
    const okA=eqs(sel.A,goalA),okB=eqs(sel.B,goalB);
    if(okA&&okB)return c.right();
    if(!okA)$('#rowA',c.area).classList.add('bad');
    if(!okB)$('#rowB',c.area).classList.add('bad');
    c.wrong(null,!okA&&!okB?'Proveri oba reda. 🙂':!okA?'Proveri prvi red (prekrižavanje). 🙂':'Proveri drugi red (zaokruživanje). 🙂');
  });
}

/* =====================================================
   6. ZNAKOVI < > =  (zadatak 6: u kružić upiši znak)
   ===================================================== */
function makePair(L,t){
  for(let k=0;k<300;k++){
    let a,b;
    if(L===0){a=rnd(1,5);b=rnd(1,5)}
    else if(L===1){a=rnd(1,10);b=rnd(1,10)}
    else if(L===2){a=rnd(1,20);b=rnd(0,2)===0?a+rnd(-2,2):rnd(1,20)}
    else{
      const s=rnd(0,3);
      if(s===0){const x=rnd(1,9),y=rnd(1,9);a=x*10+y;b=y*10+x}
      else if(s===1){const x=rnd(1,9);a=x*10+rnd(0,9);b=x*10+rnd(0,9)}
      else if(s===2){const y=rnd(0,9);a=rnd(1,9)*10+y;b=rnd(1,9)*10+y}
      else{a=rnd(10,99);b=a+rnd(-3,3)}
    }
    if(a<1||b<1||a>LV[L].max||b>LV[L].max)continue;
    if((a<b?'lt':a>b?'gt':'eq')!==t)continue;
    return [a,b];
  }
  return t==='lt'?[3,5]:t==='gt'?[5,3]:[4,4];
}
function sSigns(c,L,r,M){
  const types=r<3?shuf(['lt','gt','eq']):[0,1,2].map(()=>pick(['lt','lt','gt','gt','eq']));
  const pairs=types.map(t=>makePair(L,t));
  const goal=pairs.map(([a,b])=>a<b?'<':a>b?'>':'=');
  c.ans=goal;
  c.title('U kružić upiši znak <, > ili =.<br><small>Dodirni kružić da promeniš znak.</small>');
  c.hint('Otvoreni kraj znaka uvek gleda ka većem broju. Ako su brojevi isti, piše se =.');
  c.area.innerHTML=`<div class="signs">${pairs.map(([a,b],i)=>`<div class="pair"><b>${a}</b><button type="button" class="circ" data-i="${i}" aria-label="Znak između ${a} i ${b}"></button><b>${b}</b></div>`).join('')}</div>
  <div class="hint">🐊 Krokodil uvek otvori usta prema većem broju!</div>`;
  const ORDER=['','<','>','='],cur=['','',''];
  const circs=$$('.circ',c.area);
  circs.forEach((b,i)=>b.onclick=()=>{
    cur[i]=ORDER[(ORDER.indexOf(cur[i])+1)%ORDER.length];
    b.textContent=cur[i];b.classList.remove('ok','bad');snd.tap();
  });
  c.check(()=>{
    if(cur.some(s=>s===''))return c.info('Upiši znak u svaki kružić. 🙂');
    let bad=0;
    circs.forEach((b,i)=>{const ok=cur[i]===goal[i];b.classList.toggle('ok',ok);b.classList.toggle('bad',!ok);if(!ok)bad++});
    bad?c.wrong(null,bad===3?'Nijedan znak nije dobar. Pogledaj krokodila. 🙂':'Popravi crvene kružiće. 🙂'):c.right();
  });
}

/* =====================================================
   7. POREĐAJ BROJEVE  (zadatak 7: od najmanjeg do najvećeg)
   ===================================================== */
function sOrder(c,L,r,M){
  const desc=r===2||r===4,k=5;
  const lo=[1,1,1,10][L],hi=[5,10,20,99][L];
  let nums;
  do{nums=shuf(range(lo,hi)).slice(0,k)}
  while(same(nums,nums.slice().sort((a,b)=>a-b))||same(nums,nums.slice().sort((a,b)=>b-a)));
  const goal=nums.slice().sort((a,b)=>desc?b-a:a-b);
  c.ans=goal;
  c.title(`Poređaj brojeve <u>${desc?'od najvećeg do najmanjeg':'od najmanjeg do najvećeg'}</u>.<br><small>Dodirni broj da ga staviš na mesto. Dodirni ga ponovo da ga vratiš.</small>`);
  c.hint(desc?'Prvo potraži najveći broj i stavi ga prvog. Zatim traži sledeći najveći.':'Prvo potraži najmanji broj i stavi ga prvog. Zatim traži sledeći najmanji.');
  const slots=Array(k).fill(null);let marks=Array(k).fill('');
  const draw=()=>{
    $('#pool',c.area).innerHTML=nums.filter(n=>!slots.includes(n)).map(n=>`<button type="button" class="tile2" data-n="${n}">${n}</button>`).join('')||'<span class="hint">Svi brojevi su na mestu. Pritisni „Proveri“.</span>';
    $('#slots',c.area).innerHTML=slots.map((v,i)=>`<button type="button" class="slot${v==null?'':' f'} ${marks[i]}" data-i="${i}" aria-label="Mesto ${i+1}">${v==null?'':v}</button>`).join('');
    $$('#pool .tile2',c.area).forEach(b=>b.onclick=()=>{
      const i=slots.indexOf(null);if(i<0)return;
      slots[i]=+b.dataset.n;marks=Array(k).fill('');snd.tap();draw();
    });
    $$('#slots .slot',c.area).forEach(b=>b.onclick=()=>{
      const i=+b.dataset.i;if(slots[i]==null)return;
      slots[i]=null;marks=Array(k).fill('');snd.tap();draw();
    });
    c.showCheck(!slots.includes(null));
  };
  c.area.innerHTML=`<div class="pool" id="pool"></div><div class="dir"><span>${desc?'najveći':'najmanji'}</span><i>→</i><span>${desc?'najmanji':'najveći'}</span></div><div class="slots" id="slots"></div>`;
  c.check(()=>{
    marks=slots.map((v,i)=>v===goal[i]?'good':'bad');draw();
    marks.includes('bad')?c.wrong($('#slots',c.area),'Zeleni su na pravom mestu. Popravi crvene. 🙂'):c.right();
  });
  draw();
}

/* =====================================================
   8. NASTAVI NIZ  (zadatak 8: otkrij pravilo i nastavi niz)
   ===================================================== */
function seqMake(L,r){
  const rep=(blk,len)=>({vals:Array.from({length:len},(_,i)=>blk[i%blk.length]),k:blk.length,mode:'rep',blk});
  const stp=(d,len,lo,hi,mod=1)=>{
    const span=d*(len-1),smin=d>0?lo:lo-span,smax=d>0?hi-span:hi;
    const cand=range(smin,smax).filter(s=>s%mod===0);
    const s=pick(cand.length?cand:range(smin,smax));
    return {vals:Array.from({length:len},(_,i)=>s+d*i),k:3,mode:'step',d};
  };
  const blk=(n,lo,hi)=>shuf(range(lo,hi)).slice(0,n);
  const R=[
    [()=>rep([1,2,3,4,5],13),()=>rep([5,4,3,2,1],13),()=>rep(blk(3,1,5),9),()=>rep(blk(4,1,5),12),()=>rep(blk(5,1,5),13)],
    [()=>stp(1,7,1,10),()=>stp(-1,7,1,10),()=>stp(2,5,1,10),()=>rep(blk(3,1,10),9),()=>stp(-2,5,1,10)],
    [()=>stp(2,7,1,20),()=>stp(3,7,1,20),()=>stp(-2,7,1,20),()=>stp(5,5,0,20,5),()=>rep(blk(4,1,20),12)],
    [()=>stp(10,7,1,99),()=>stp(-10,7,1,99),()=>stp(5,7,5,99,5),()=>stp(pick([20,25]),5,0,100,5),()=>rep(blk(3,10,99),9)]
  ];
  return R[L][r%5]();
}
function sSeq(c,L,r,M){
  const sp=seqMake(L,r),n=sp.vals.length;
  const given=new Set(range(0,sp.mode==='rep'?sp.k:2));
  const rest=shuf(range(0,n-1).filter(i=>!given.has(i)));
  const extra=Math.max(0,Math.min(sp.mode==='rep'?2:(r>=3?1:0),rest.length-2));
  rest.slice(0,extra).forEach(i=>given.add(i));
  const blanks=range(0,n-1).filter(i=>!given.has(i));
  c.ans=blanks.map(i=>sp.vals[i]);
  c.title(sp.mode==='rep'?'Brojevi se ponavljaju. Otkrij pravilo i upiši brojeve koji nedostaju.':'Otkrij pravilo i upiši brojeve koji nedostaju.');
  c.hint(sp.mode==='rep'?`Pravilo: brojevi ${sp.blk.join(', ')} stalno se ponavljaju istim redom.`:`Svaki sledeći broj je za ${Math.abs(sp.d)} ${sp.d>0?'veći':'manji'} od prethodnog.`);
  const val={};let sel=-1;
  c.area.innerHTML=`<div class="seq" id="seq">${sp.vals.map((v,i)=>given.has(i)?`<span class="cell">${v}</span>`:`<button type="button" class="cell blank" data-i="${i}" aria-label="Broj koji nedostaje, mesto ${i+1}"></button>`).join('')}</div><div id="padslot"></div>`;
  const cells=Object.fromEntries($$('.blank',c.area).map(b=>[b.dataset.i,b]));
  const paint=()=>{
    blanks.forEach(i=>{const b=cells[i];b.textContent=val[i]===undefined?'':val[i];b.classList.toggle('sel',i===sel)});
    c.showCheck(blanks.every(i=>val[i]!==undefined&&val[i]!==''));
  };
  const select=i=>{sel=i;pad.set(val[i]===undefined?'':val[i]);pad.fresh=val[i]!==undefined&&val[i]!=='';paint()};
  const pad=numpad($('#padslot',c.area),()=>{
    if(sel<0||val[sel]===undefined||val[sel]==='')return c.info('Upiši broj, pa pritisni ✔. 🙂');
    const nxt=blanks.find(i=>i>sel&&(val[i]===undefined||val[i]==='')) ?? blanks.find(i=>val[i]===undefined||val[i]==='');
    if(nxt!==undefined)select(nxt);else doCheck();
  },3);
  pad.onchange=v=>{if(sel<0)return;val[sel]=v;cells[sel].classList.remove('good','bad');paint()};
  blanks.forEach(i=>cells[i].onclick=()=>{snd.tap();select(i)});
  const doCheck=()=>{
    let bad=0;
    blanks.forEach(i=>{const ok=+val[i]===sp.vals[i];cells[i].classList.toggle('good',ok);cells[i].classList.toggle('bad',!ok);if(!ok)bad++});
    bad?c.wrong($('#seq',c.area),bad===blanks.length?'Pogledaj pravilo još jednom. 🙂':'Zeleni su dobri. Popravi crvene. 🙂'):c.right();
  };
  c.check(doCheck);c.showCheck(false);
  select(blanks[0]);
}

/* ---------- spisak igara ---------- */
const ST=[
  {name:'Prebroji',ico:'🔍',desc:'Izbroj skup i upiši broj',run:sCount},
  {name:'Oboji kružiće',ico:'🔵',desc:'Oboji tačno toliko kružića',run:sColor},
  {name:'Nacrtaj olovke',ico:'✏️',desc:'Nacrtaj tačno toliko olovaka',run:sPencil},
  {name:'Više ili jednako',ico:'⚖️',desc:'Uporedi dva skupa',run:sCompare},
  {name:'Prekrižaj i zaokruži',ico:'✂️',desc:'Veći i manji od broja',run:sMark},
  {name:'Znakovi < > =',ico:'🐊',desc:'Upiši pravi znak u kružić',run:sSigns},
  {name:'Poređaj brojeve',ico:'📏',desc:'Od najmanjeg do najvećeg',run:sOrder},
  {name:'Nastavi niz',ico:'🔁',desc:'Otkrij pravilo i nastavi',run:sSeq}
];

menu();
})();
